import { renderHook, act } from "@testing-library/react"
import { useOrientation } from "@/hooks/use-orientation"
import { changeOrientation } from "@/lib/test-utils"

describe("useOrientation", () => {
  beforeEach(() => {
    // Mock matchMedia for portrait orientation by default
    window.matchMedia = jest.fn().mockImplementation((query) => ({
      matches: query === "(orientation: portrait)",
      media: query,
      onchange: null,
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    }))
  })

  it("returns portrait by default", () => {
    const { result } = renderHook(() => useOrientation())

    expect(result.current).toBe("portrait")
  })

  it("returns landscape when orientation is landscape", () => {
    // Mock matchMedia for landscape orientation
    window.matchMedia = jest.fn().mockImplementation((query) => ({
      matches: query === "(orientation: landscape)",
      media: query,
      onchange: null,
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    }))

    const { result } = renderHook(() => useOrientation())

    expect(result.current).toBe("landscape")
  })

  it("updates orientation when it changes", () => {
    const { result } = renderHook(() => useOrientation())

    // Initially portrait
    expect(result.current).toBe("portrait")

    // Change to landscape
    act(() => {
      changeOrientation(false)
    })

    // Should now be landscape
    expect(result.current).toBe("landscape")
  })

  it("cleans up event listeners on unmount", () => {
    const removeEventListenerSpy = jest.spyOn(window, "removeEventListener")

    const { unmount } = renderHook(() => useOrientation())

    unmount()

    // Should have removed event listeners
    expect(removeEventListenerSpy).toHaveBeenCalled()
  })
})

