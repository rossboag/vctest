import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { AnimationEditor } from "@/components/AnimationEditor"
import { AnimationTimeline } from "@/components/animation-timeline"
import { useAnimationPresets } from "@/hooks/use-animation-presets"
import { useAiAnimationKeyframes } from "@/hooks/use-ai-animation-keyframes"

// Mock Konva
jest.mock("konva", () => {
  return {
    Animation: jest.fn().mockImplementation(() => ({
      start: jest.fn(),
      stop: jest.fn(),
    })),
    Tween: jest.fn().mockImplementation(() => ({
      play: jest.fn(),
      onFinish: jest.fn(),
    })),
  }
})

// Mock animation hooks
jest.mock("@/hooks/use-animation-presets", () => ({
  useAnimationPresets: jest.fn(),
}))

jest.mock("@/hooks/use-ai-animation-keyframes", () => ({
  useAiAnimationKeyframes: jest.fn(),
}))

// Mock animation utilities
jest.mock("@/lib/animation-presets", () => ({
  getAnimationPreset: jest.fn().mockImplementation((name) => {
    const presets = {
      fadeIn: {
        name: "fadeIn",
        duration: 1000,
        easing: "easeInOut",
        keyframes: [
          { time: 0, opacity: 0 },
          { time: 1000, opacity: 1 },
        ],
      },
      slideIn: {
        name: "slideIn",
        duration: 1000,
        easing: "easeOut",
        keyframes: [
          { time: 0, x: -100, opacity: 0 },
          { time: 1000, x: 0, opacity: 1 },
        ],
      },
    }
    return presets[name] || null
  }),
  getAllAnimationPresets: jest.fn().mockReturnValue([
    {
      name: "fadeIn",
      duration: 1000,
      easing: "easeInOut",
      keyframes: [
        { time: 0, opacity: 0 },
        { time: 1000, opacity: 1 },
      ],
    },
    {
      name: "slideIn",
      duration: 1000,
      easing: "easeOut",
      keyframes: [
        { time: 0, x: -100, opacity: 0 },
        { time: 1000, x: 0, opacity: 1 },
      ],
    },
  ]),
}))

jest.mock("@/lib/easing-functions", () => ({
  getEasingFunction: jest.fn().mockImplementation((name) => {
    return (t) => t // Linear easing for testing
  }),
  getAllEasingFunctions: jest.fn().mockReturnValue([
    { name: "linear", label: "Linear" },
    { name: "easeIn", label: "Ease In" },
    { name: "easeOut", label: "Ease Out" },
    { name: "easeInOut", label: "Ease In Out" },
  ]),
}))

describe("Animation and Rendering Tests", () => {
  beforeEach(() => {
    jest.clearAllMocks()

    // Mock animation presets hook
    useAnimationPresets.mockReturnValue({
      presets: [
        {
          id: "preset1",
          name: "Fade In",
          category: "Basic",
          duration: 1000,
          easing: "easeInOut",
          keyframes: [
            { time: 0, opacity: 0 },
            { time: 1000, opacity: 1 },
          ],
        },
        {
          id: "preset2",
          name: "Slide In",
          category: "Basic",
          duration: 1000,
          easing: "easeOut",
          keyframes: [
            { time: 0, x: -100, opacity: 0 },
            { time: 1000, x: 0, opacity: 1 },
          ],
        },
      ],
      isLoading: false,
      error: null,
      fetchPresets: jest.fn(),
      createPreset: jest.fn(),
      updatePreset: jest.fn(),
      deletePreset: jest.fn(),
    })

    // Mock AI animation keyframes hook
    useAiAnimationKeyframes.mockReturnValue({
      keyframes: null,
      isLoading: false,
      error: null,
      generateKeyframes: jest.fn().mockImplementation((prompt) => {
        // Simulate API response
        setTimeout(() => {
          return {
            keyframes: [
              { time: 0, opacity: 0, scale: 0.5 },
              { time: 500, opacity: 0.5, scale: 0.75 },
              { time: 1000, opacity: 1, scale: 1 },
            ],
          }
        }, 100)
      }),
    })
  })

  describe("AnimationEditor", () => {
    it("renders animation editor correctly", () => {
      render(<AnimationEditor elementId="element1" elementType="text" onApplyAnimation={jest.fn()} />)

      // Should render animation editor
      expect(screen.getByText("Animation Editor")).toBeInTheDocument()
      expect(screen.getByText("Presets")).toBeInTheDocument()
      expect(screen.getByText("Custom")).toBeInTheDocument()
      expect(screen.getByText("AI Generate")).toBeInTheDocument()
    })

    it("displays animation presets", () => {
      render(<AnimationEditor elementId="element1" elementType="text" onApplyAnimation={jest.fn()} />)

      // Should display presets
      expect(screen.getByText("Fade In")).toBeInTheDocument()
      expect(screen.getByText("Slide In")).toBeInTheDocument()
    })

    it("applies animation preset when clicked", () => {
      const mockApplyAnimation = jest.fn()

      render(<AnimationEditor elementId="element1" elementType="text" onApplyAnimation={mockApplyAnimation} />)

      // Click preset
      fireEvent.click(screen.getByText("Fade In"))

      // Should call onApplyAnimation
      expect(mockApplyAnimation).toHaveBeenCalledWith("element1", {
        id: "preset1",
        name: "Fade In",
        category: "Basic",
        duration: 1000,
        easing: "easeInOut",
        keyframes: [
          { time: 0, opacity: 0 },
          { time: 1000, opacity: 1 },
        ],
      })
    })

    it("generates AI animation when prompted", async () => {
      const mockGenerateKeyframes = jest.fn().mockResolvedValue({
        keyframes: [
          { time: 0, opacity: 0, scale: 0.5 },
          { time: 500, opacity: 0.5, scale: 0.75 },
          { time: 1000, opacity: 1, scale: 1 },
        ],
      })

      useAiAnimationKeyframes.mockReturnValue({
        keyframes: null,
        isLoading: false,
        error: null,
        generateKeyframes: mockGenerateKeyframes,
      })

      render(<AnimationEditor elementId="element1" elementType="text" onApplyAnimation={jest.fn()} />)

      // Click AI Generate tab
      fireEvent.click(screen.getByText("AI Generate"))

      // Enter prompt
      fireEvent.change(screen.getByPlaceholderText("Describe the animation..."), {
        target: { value: "Fade in and grow" },
      })

      // Click generate button
      fireEvent.click(screen.getByText("Generate"))

      // Should call generateKeyframes
      expect(mockGenerateKeyframes).toHaveBeenCalledWith("Fade in and grow")

      // Wait for keyframes to be generated
      await waitFor(() => {
        expect(screen.getByText("Apply")).toBeEnabled()
      })
    })
  })

  describe("AnimationTimeline", () => {
    it("renders timeline correctly", () => {
      render(
        <AnimationTimeline
          animations={[
            {
              id: "anim1",
              elementId: "element1",
              name: "Fade In",
              duration: 1000,
              delay: 0,
              easing: "easeInOut",
              keyframes: [
                { time: 0, opacity: 0 },
                { time: 1000, opacity: 1 },
              ],
            },
            {
              id: "anim2",
              elementId: "element2",
              name: "Slide In",
              duration: 1000,
              delay: 500,
              easing: "easeOut",
              keyframes: [
                { time: 0, x: -100, opacity: 0 },
                { time: 1000, x: 0, opacity: 1 },
              ],
            },
          ]}
          currentTime={0}
          duration={2000}
          onTimeChange={jest.fn()}
          onAnimationChange={jest.fn()}
          onAnimationDelete={jest.fn()}
        />,
      )

      // Should render timeline
      expect(screen.getByText("Timeline")).toBeInTheDocument()
      expect(screen.getByText("element1")).toBeInTheDocument()
      expect(screen.getByText("element2")).toBeInTheDocument()
    })

    it("updates current time when scrubbing", () => {
      const mockOnTimeChange = jest.fn()

      render(
        <AnimationTimeline
          animations={[]}
          currentTime={0}
          duration={2000}
          onTimeChange={mockOnTimeChange}
          onAnimationChange={jest.fn()}
          onAnimationDelete={jest.fn()}
        />,
      )

      // Get timeline scrubber
      const scrubber = screen.getByTestId("timeline-scrubber")

      // Simulate scrubbing
      fireEvent.mouseDown(scrubber)
      fireEvent.mouseMove(scrubber, { clientX: 100 })
      fireEvent.mouseUp(scrubber)

      // Should call onTimeChange
      expect(mockOnTimeChange).toHaveBeenCalled()
    })

    it("updates animation when dragging", () => {
      const mockOnAnimationChange = jest.fn()

      render(
        <AnimationTimeline
          animations={[
            {
              id: "anim1",
              elementId: "element1",
              name: "Fade In",
              duration: 1000,
              delay: 0,
              easing: "easeInOut",
              keyframes: [
                { time: 0, opacity: 0 },
                { time: 1000, opacity: 1 },
              ],
            },
          ]}
          currentTime={0}
          duration={2000}
          onTimeChange={jest.fn()}
          onAnimationChange={mockOnAnimationChange}
          onAnimationDelete={jest.fn()}
        />,
      )

      // Get animation bar
      const animationBar = screen.getByTestId("animation-bar-anim1")

      // Simulate dragging
      fireEvent.mouseDown(animationBar)
      fireEvent.mouseMove(animationBar, { clientX: 100 })
      fireEvent.mouseUp(animationBar)

      // Should call onAnimationChange
      expect(mockOnAnimationChange).toHaveBeenCalled()
    })

    it("deletes animation when delete button is clicked", () => {
      const mockOnAnimationDelete = jest.fn()

      render(
        <AnimationTimeline
          animations={[
            {
              id: "anim1",
              elementId: "element1",
              name: "Fade In",
              duration: 1000,
              delay: 0,
              easing: "easeInOut",
              keyframes: [
                { time: 0, opacity: 0 },
                { time: 1000, opacity: 1 },
              ],
            },
          ]}
          currentTime={0}
          duration={2000}
          onTimeChange={jest.fn()}
          onAnimationChange={jest.fn()}
          onAnimationDelete={mockOnAnimationDelete}
        />,
      )

      // Click delete button
      fireEvent.click(screen.getByLabelText("Delete animation"))

      // Should call onAnimationDelete
      expect(mockOnAnimationDelete).toHaveBeenCalledWith("anim1")
    })
  })
})

