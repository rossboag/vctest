import { render } from "@testing-library/react"
import { TouchInteractions } from "@/components/touch-interactions"
import { createTouchEvent, simulatePinchGesture } from "@/lib/test-utils"
import { useEditorStore } from "@/store/editor-store"
import { expect } from "@jest/globals"

// Mock the editor store
jest.mock("@/store/editor-store", () => ({
  useEditorStore: jest.fn(),
}))

describe("TouchInteractions", () => {
  const mockSetScale = jest.fn()
  const mockSetPosition = jest.fn()

  beforeEach(() => {
    jest.clearAllMocks()

    // Mock the store implementation
    useEditorStore.mockImplementation(() => ({
      scale: 1,
      setScale: mockSetScale,
      position: { x: 0, y: 0 },
      setPosition: mockSetPosition,
    }))

    // Mock isTouch to return true
    jest.mock("@/lib/mobile-utils", () => ({
      isTouch: () => true,
    }))

    // Create a canvas element for testing
    const canvas = document.createElement("div")
    canvas.id = "konva-canvas"
    document.body.appendChild(canvas)
  })

  afterEach(() => {
    // Clean up
    const canvas = document.getElementById("konva-canvas")
    if (canvas) {
      document.body.removeChild(canvas)
    }
  })

  it("renders without crashing", () => {
    render(<TouchInteractions />)
    // Component doesn't render anything visible
    expect(document.body).toBeTruthy()
  })

  it("handles touch start event", () => {
    render(<TouchInteractions />)

    const canvas = document.getElementById("konva-canvas")
    const touchStartEvent = createTouchEvent("touchstart", [{ x: 100, y: 100 }])

    canvas?.dispatchEvent(touchStartEvent)

    // No direct assertions since the event just sets up internal state
    expect(canvas).toBeTruthy()
  })

  it("handles pinch zoom gesture", async () => {
    render(<TouchInteractions />)

    const canvas = document.getElementById("konva-canvas")
    if (canvas) {
      await simulatePinchGesture(canvas, 100, 200)

      // Should have called setScale
      expect(mockSetScale).toHaveBeenCalled()
    }
  })

  it("handles pan gesture", () => {
    render(<TouchInteractions />)

    const canvas = document.getElementById("konva-canvas")
    if (canvas) {
      // Start touch
      const touchStartEvent = createTouchEvent("touchstart", [{ x: 100, y: 100 }])
      canvas.dispatchEvent(touchStartEvent)

      // Move touch
      const touchMoveEvent = createTouchEvent("touchmove", [{ x: 150, y: 150 }])
      canvas.dispatchEvent(touchMoveEvent)

      // Should have called setPosition
      expect(mockSetPosition).toHaveBeenCalled()
    }
  })

  it("cleans up event listeners on unmount", () => {
    const { unmount } = render(<TouchInteractions />)

    const canvas = document.getElementById("konva-canvas")
    const removeEventListenerSpy = jest.spyOn(canvas as any, "removeEventListener")

    unmount()

    // Should have removed event listeners
    expect(removeEventListenerSpy).toHaveBeenCalled()
  })
})

