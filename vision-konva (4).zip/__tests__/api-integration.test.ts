import { rest } from "msw"
import { setupServer } from "msw/node"
import { renderHook, waitFor } from "@testing-library/react"
import { useAiText } from "@/hooks/use-ai-text"
import { useAiImage } from "@/hooks/use-ai-image"
import { useAiColorPalette } from "@/hooks/use-ai-color-palette"
import { expect } from "@jest/globals"

// Setup Mock Service Worker
const server = setupServer(
  // Mock AI text endpoint
  rest.post("/api/ai/text", (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        text: "Generated text from AI",
      }),
    )
  }),

  // Mock AI image endpoint
  rest.post("/api/ai/image", (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        imageUrl: "https://example.com/generated-image.png",
      }),
    )
  }),

  // Mock AI color palette endpoint
  rest.post("/api/ai/color-palette", (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        colors: ["#FF5733", "#33FF57", "#3357FF", "#F3FF33", "#FF33F3"],
      }),
    )
  }),

  // Mock error case
  rest.post("/api/ai/error-test", (req, res, ctx) => {
    return res(
      ctx.status(500),
      ctx.json({
        success: false,
        error: "Internal server error",
      }),
    )
  }),
)

// Start server before all tests
beforeAll(() => server.listen())
// Reset handlers after each test
afterEach(() => server.resetHandlers())
// Close server after all tests
afterAll(() => server.close())

describe("API Integration Tests", () => {
  it("useAiText hook fetches text successfully", async () => {
    const { result } = renderHook(() => useAiText())

    // Initial state
    expect(result.current.isLoading).toBe(false)
    expect(result.current.error).toBeNull()

    // Call generate function
    result.current.generateText("Create a headline for a design app")

    // Should be loading
    expect(result.current.isLoading).toBe(true)

    // Wait for response
    await waitFor(() => {
      expect(result.current.isLoading).toBe(false)
    })

    // Should have data
    expect(result.current.text).toBe("Generated text from AI")
    expect(result.current.error).toBeNull()
  })

  it("useAiImage hook fetches image successfully", async () => {
    const { result } = renderHook(() => useAiImage())

    // Initial state
    expect(result.current.isLoading).toBe(false)
    expect(result.current.error).toBeNull()

    // Call generate function
    result.current.generateImage("A futuristic design studio")

    // Should be loading
    expect(result.current.isLoading).toBe(true)

    // Wait for response
    await waitFor(() => {
      expect(result.current.isLoading).toBe(false)
    })

    // Should have data
    expect(result.current.imageUrl).toBe("https://example.com/generated-image.png")
    expect(result.current.error).toBeNull()
  })

  it("useAiColorPalette hook fetches colors successfully", async () => {
    const { result } = renderHook(() => useAiColorPalette())

    // Initial state
    expect(result.current.isLoading).toBe(false)
    expect(result.current.error).toBeNull()

    // Call generate function
    result.current.generatePalette("Vibrant summer theme")

    // Should be loading
    expect(result.current.isLoading).toBe(true)

    // Wait for response
    await waitFor(() => {
      expect(result.current.isLoading).toBe(false)
    })

    // Should have data
    expect(result.current.colors).toEqual(["#FF5733", "#33FF57", "#3357FF", "#F3FF33", "#FF33F3"])
    expect(result.current.error).toBeNull()
  })

  it("handles API errors correctly", async () => {
    // Override the default handler for text endpoint to return an error
    server.use(
      rest.post("/api/ai/text", (req, res, ctx) => {
        return res(
          ctx.status(500),
          ctx.json({
            success: false,
            error: "Internal server error",
          }),
        )
      }),
    )

    const { result } = renderHook(() => useAiText())

    // Call generate function
    result.current.generateText("This will cause an error")

    // Wait for response
    await waitFor(() => {
      expect(result.current.isLoading).toBe(false)
    })

    // Should have error
    expect(result.current.error).toBeTruthy()
    expect(result.current.text).toBeNull()
  })
})

