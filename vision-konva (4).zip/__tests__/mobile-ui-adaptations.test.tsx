import { render, screen, fireEvent } from "@testing-library/react"
import { MobileUIAdaptations } from "@/components/mobile-ui-adaptations"
import { useEditorStore } from "@/store/editor-store"
import { isMobile } from "@/lib/mobile-utils"

// Mock dependencies
jest.mock("@/store/editor-store", () => ({
  useEditorStore: jest.fn(),
}))

jest.mock("@/lib/mobile-utils", () => ({
  isMobile: jest.fn(),
}))

describe("MobileUIAdaptations", () => {
  const mockUndo = jest.fn()
  const mockRedo = jest.fn()
  const mockSetScale = jest.fn()

  beforeEach(() => {
    jest.clearAllMocks()

    // Mock the store implementation
    useEditorStore.mockImplementation(() => ({
      scale: 1,
      setScale: mockSetScale,
      undo: mockUndo,
      redo: mockRedo,
      canUndo: true,
      canRedo: true,
    }))
  })

  it("renders nothing when not on mobile", () => {
    isMobile.mockReturnValue(false)

    render(<MobileUIAdaptations />)

    // Should not render anything
    expect(screen.queryByLabelText("Undo")).not.toBeInTheDocument()
  })

  it("renders mobile UI when on mobile", () => {
    isMobile.mockReturnValue(true)

    render(<MobileUIAdaptations />)

    // Should render mobile UI
    expect(screen.getByLabelText("Undo")).toBeInTheDocument()
    expect(screen.getByLabelText("Redo")).toBeInTheDocument()
    expect(screen.getByLabelText("Zoom In")).toBeInTheDocument()
    expect(screen.getByLabelText("Zoom Out")).toBeInTheDocument()
    expect(screen.getByLabelText("Layers")).toBeInTheDocument()
    expect(screen.getByLabelText("Timeline")).toBeInTheDocument()
    expect(screen.getByLabelText("Save")).toBeInTheDocument()
    expect(screen.getByLabelText("Export")).toBeInTheDocument()
  })

  it("calls undo when undo button is clicked", () => {
    isMobile.mockReturnValue(true)

    render(<MobileUIAdaptations />)

    fireEvent.click(screen.getByLabelText("Undo"))

    expect(mockUndo).toHaveBeenCalled()
  })

  it("calls redo when redo button is clicked", () => {
    isMobile.mockReturnValue(true)

    render(<MobileUIAdaptations />)

    fireEvent.click(screen.getByLabelText("Redo"))

    expect(mockRedo).toHaveBeenCalled()
  })

  it("calls setScale with increased value when zoom in is clicked", () => {
    isMobile.mockReturnValue(true)

    render(<MobileUIAdaptations />)

    fireEvent.click(screen.getByLabelText("Zoom In"))

    expect(mockSetScale).toHaveBeenCalledWith(1.1)
  })

  it("calls setScale with decreased value when zoom out is clicked", () => {
    isMobile.mockReturnValue(true)

    render(<MobileUIAdaptations />)

    fireEvent.click(screen.getByLabelText("Zoom Out"))

    expect(mockSetScale).toHaveBeenCalledWith(0.9)
  })

  it("displays current scale percentage", () => {
    isMobile.mockReturnValue(true)

    render(<MobileUIAdaptations />)

    expect(screen.getByText("100%")).toBeInTheDocument()
  })
})

