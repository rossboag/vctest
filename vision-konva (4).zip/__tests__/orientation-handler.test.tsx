import { render, screen, fireEvent } from "@testing-library/react"
import { OrientationHandler } from "@/components/orientation-handler"
import { useOrientation } from "@/hooks/use-orientation"

// Mock dependencies
jest.mock("@/hooks/use-orientation", () => ({
  useOrientation: jest.fn(),
}))

describe("OrientationHandler", () => {
  beforeEach(() => {
    jest.clearAllMocks()

    // Mock window.innerWidth for mobile device
    Object.defineProperty(window, "innerWidth", { value: 375, writable: true })
  })

  it("renders nothing when in landscape mode", () => {
    useOrientation.mockReturnValue("landscape")

    render(<OrientationHandler />)

    // Should not render anything
    expect(screen.queryByText("Rotate Your Device")).not.toBeInTheDocument()
  })

  it("renders nothing when on desktop", () => {
    useOrientation.mockReturnValue("portrait")

    // Set window.innerWidth for desktop
    Object.defineProperty(window, "innerWidth", { value: 1920, writable: true })

    render(<OrientationHandler />)

    // Should not render anything
    expect(screen.queryByText("Rotate Your Device")).not.toBeInTheDocument()
  })

  it("renders warning when on mobile in portrait mode", () => {
    useOrientation.mockReturnValue("portrait")

    render(<OrientationHandler />)

    // Should render warning
    expect(screen.getByText("Rotate Your Device")).toBeInTheDocument()
    expect(screen.getByText(/For the best editing experience/)).toBeInTheDocument()
    expect(screen.getByText("Continue Anyway")).toBeInTheDocument()
  })

  it("dismisses warning when continue button is clicked", () => {
    useOrientation.mockReturnValue("portrait")

    render(<OrientationHandler />)

    // Initially shows warning
    expect(screen.getByText("Rotate Your Device")).toBeInTheDocument()

    // Click continue button
    fireEvent.click(screen.getByText("Continue Anyway"))

    // Should dismiss warning
    expect(screen.queryByText("Rotate Your Device")).not.toBeInTheDocument()
  })

  it("updates when orientation changes", () => {
    useOrientation.mockReturnValue("portrait")

    render(<OrientationHandler />)

    // Initially shows warning
    expect(screen.getByText("Rotate Your Device")).toBeInTheDocument()

    // Change orientation to landscape
    useOrientation.mockReturnValue("landscape")

    // Trigger re-render
    fireEvent.resize(window)

    // Should dismiss warning
    expect(screen.queryByText("Rotate Your Device")).not.toBeInTheDocument()
  })
})

