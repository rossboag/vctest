import { renderHook, act } from "@testing-library/react"
import { useEditorStore } from "@/store/editor-store"
import { useLayerStore } from "@/store/layerStore"
import { useSelectionStore } from "@/store/selectionStore"
import { useCanvasStore } from "@/store/canvasStore"
import { useHistoryStore } from "@/store/historyStore"
import { describe, beforeEach, it, expect } from "vitest"

describe("State Management Tests", () => {
  beforeEach(() => {
    // Reset all stores before each test
    act(() => {
      useEditorStore.getState().reset()
      useLayerStore.getState().reset()
      useSelectionStore.getState().reset()
      useCanvasStore.getState().reset()
      useHistoryStore.getState().reset()
    })
  })

  describe("Editor Store", () => {
    it("updates scale correctly", () => {
      const { result } = renderHook(() => useEditorStore())

      // Initial state
      expect(result.current.scale).toBe(1)

      // Update scale
      act(() => {
        result.current.setScale(1.5)
      })

      // Should update scale
      expect(result.current.scale).toBe(1.5)
    })

    it("updates position correctly", () => {
      const { result } = renderHook(() => useEditorStore())

      // Initial state
      expect(result.current.position).toEqual({ x: 0, y: 0 })

      // Update position
      act(() => {
        result.current.setPosition({ x: 100, y: 200 })
      })

      // Should update position
      expect(result.current.position).toEqual({ x: 100, y: 200 })
    })

    it("handles undo/redo correctly", () => {
      const { result } = renderHook(() => useEditorStore())

      // Initial state
      expect(result.current.canUndo).toBe(false)
      expect(result.current.canRedo).toBe(false)

      // Perform an action
      act(() => {
        result.current.setScale(1.5)
        result.current.addHistoryEntry({ type: "scale", data: { oldScale: 1, newScale: 1.5 } })
      })

      // Should be able to undo
      expect(result.current.canUndo).toBe(true)
      expect(result.current.canRedo).toBe(false)

      // Undo
      act(() => {
        result.current.undo()
      })

      // Should be able to redo
      expect(result.current.canUndo).toBe(false)
      expect(result.current.canRedo).toBe(true)

      // Redo
      act(() => {
        result.current.redo()
      })

      // Should be able to undo again
      expect(result.current.canUndo).toBe(true)
      expect(result.current.canRedo).toBe(false)
    })
  })

  describe("Layer Store", () => {
    it("adds layers correctly", () => {
      const { result } = renderHook(() => useLayerStore())

      // Initial state
      expect(result.current.layers).toEqual([])

      // Add layer
      act(() => {
        result.current.addLayer({
          id: "layer1",
          name: "Layer 1",
          visible: true,
          locked: false,
          elements: [],
        })
      })

      // Should add layer
      expect(result.current.layers).toHaveLength(1)
      expect(result.current.layers[0].id).toBe("layer1")
    })

    it("removes layers correctly", () => {
      const { result } = renderHook(() => useLayerStore())

      // Add layers
      act(() => {
        result.current.addLayer({
          id: "layer1",
          name: "Layer 1",
          visible: true,
          locked: false,
          elements: [],
        })

        result.current.addLayer({
          id: "layer2",
          name: "Layer 2",
          visible: true,
          locked: false,
          elements: [],
        })
      })

      // Should have 2 layers
      expect(result.current.layers).toHaveLength(2)

      // Remove layer
      act(() => {
        result.current.removeLayer("layer1")
      })

      // Should remove layer
      expect(result.current.layers).toHaveLength(1)
      expect(result.current.layers[0].id).toBe("layer2")
    })

    it("updates layer visibility correctly", () => {
      const { result } = renderHook(() => useLayerStore())

      // Add layer
      act(() => {
        result.current.addLayer({
          id: "layer1",
          name: "Layer 1",
          visible: true,
          locked: false,
          elements: [],
        })
      })

      // Should be visible
      expect(result.current.layers[0].visible).toBe(true)

      // Update visibility
      act(() => {
        result.current.updateLayer("layer1", { visible: false })
      })

      // Should update visibility
      expect(result.current.layers[0].visible).toBe(false)
    })
  })

  describe("Selection Store", () => {
    it("selects elements correctly", () => {
      const { result } = renderHook(() => useSelectionStore())

      // Initial state
      expect(result.current.selectedIds).toEqual([])

      // Select element
      act(() => {
        result.current.selectElement("element1")
      })

      // Should select element
      expect(result.current.selectedIds).toEqual(["element1"])
    })

    it("deselects elements correctly", () => {
      const { result } = renderHook(() => useSelectionStore())

      // Select elements
      act(() => {
        result.current.selectElements(["element1", "element2"])
      })

      // Should select elements
      expect(result.current.selectedIds).toEqual(["element1", "element2"])

      // Deselect element
      act(() => {
        result.current.deselectElement("element1")
      })

      // Should deselect element
      expect(result.current.selectedIds).toEqual(["element2"])
    })

    it("clears selection correctly", () => {
      const { result } = renderHook(() => useSelectionStore())

      // Select elements
      act(() => {
        result.current.selectElements(["element1", "element2"])
      })

      // Should select elements
      expect(result.current.selectedIds).toEqual(["element1", "element2"])

      // Clear selection
      act(() => {
        result.current.clearSelection()
      })

      // Should clear selection
      expect(result.current.selectedIds).toEqual([])
    })
  })

  describe("Canvas Store", () => {
    it("updates canvas size correctly", () => {
      const { result } = renderHook(() => useCanvasStore())

      // Initial state
      expect(result.current.width).toBe(1920)
      expect(result.current.height).toBe(1080)

      // Update canvas size
      act(() => {
        result.current.setCanvasSize(800, 600)
      })

      // Should update canvas size
      expect(result.current.width).toBe(800)
      expect(result.current.height).toBe(600)
    })

    it("updates background color correctly", () => {
      const { result } = renderHook(() => useCanvasStore())

      // Initial state
      expect(result.current.backgroundColor).toBe("#FFFFFF")

      // Update background color
      act(() => {
        result.current.setBackgroundColor("#000000")
      })

      // Should update background color
      expect(result.current.backgroundColor).toBe("#000000")
    })
  })

  describe("History Store", () => {
    it("adds history entries correctly", () => {
      const { result } = renderHook(() => useHistoryStore())

      // Initial state
      expect(result.current.history).toEqual([])
      expect(result.current.currentIndex).toBe(-1)

      // Add history entry
      act(() => {
        result.current.addEntry({
          type: "element_added",
          data: { id: "element1", type: "text" },
        })
      })

      // Should add history entry
      expect(result.current.history).toHaveLength(1)
      expect(result.current.currentIndex).toBe(0)
    })

    it("navigates history correctly", () => {
      const { result } = renderHook(() => useHistoryStore())

      // Add history entries
      act(() => {
        result.current.addEntry({
          type: "element_added",
          data: { id: "element1", type: "text" },
        })

        result.current.addEntry({
          type: "element_moved",
          data: { id: "element1", oldPosition: { x: 0, y: 0 }, newPosition: { x: 100, y: 100 } },
        })
      })

      // Should have 2 entries
      expect(result.current.history).toHaveLength(2)
      expect(result.current.currentIndex).toBe(1)

      // Undo
      act(() => {
        result.current.undo()
      })

      // Should update current index
      expect(result.current.currentIndex).toBe(0)

      // Redo
      act(() => {
        result.current.redo()
      })

      // Should update current index
      expect(result.current.currentIndex).toBe(1)
    })

    it("clears future history when adding new entry after undo", () => {
      const { result } = renderHook(() => useHistoryStore())

      // Add history entries
      act(() => {
        result.current.addEntry({
          type: "element_added",
          data: { id: "element1", type: "text" },
        })

        result.current.addEntry({
          type: "element_moved",
          data: { id: "element1", oldPosition: { x: 0, y: 0 }, newPosition: { x: 100, y: 100 } },
        })
      })

      // Undo
      act(() => {
        result.current.undo()
      })

      // Add new entry
      act(() => {
        result.current.addEntry({
          type: "element_resized",
          data: { id: "element1", oldSize: { width: 100, height: 100 }, newSize: { width: 200, height: 200 } },
        })
      })

      // Should clear future history
      expect(result.current.history).toHaveLength(2)
      expect(result.current.currentIndex).toBe(1)
      expect(result.current.history[1].type).toBe("element_resized")
    })
  })
})

