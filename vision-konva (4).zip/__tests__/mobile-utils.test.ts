import { isMobile, isTouch, getDeviceType } from "@/lib/mobile-utils"
import { resizeWindow } from "@/lib/test-utils"

describe("Mobile Utils", () => {
  beforeEach(() => {
    // Reset window dimensions
    resizeWindow(1920, 1080)

    // Reset user agent
    Object.defineProperty(window.navigator, "userAgent", {
      value:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      configurable: true,
    })
  })

  describe("isMobile", () => {
    it("should return false for desktop viewport", () => {
      expect(isMobile()).toBe(false)
    })

    it("should return true for mobile viewport", () => {
      resizeWindow(375, 667)

      // Mock matchMedia for mobile
      window.matchMedia = jest.fn().mockImplementation((query) => ({
        matches: query === "(max-width: 768px)",
        media: query,
        onchange: null,
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn(),
      }))

      expect(isMobile()).toBe(true)
    })

    it("should return true for mobile user agent", () => {
      // Set mobile user agent
      Object.defineProperty(window.navigator, "userAgent", {
        value:
          "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
        configurable: true,
      })

      expect(isMobile()).toBe(true)
    })
  })

  describe("isTouch", () => {
    it("should return false when touch is not available", () => {
      // Remove touch capability
      window.ontouchstart = undefined
      Object.defineProperty(navigator, "maxTouchPoints", { value: 0 })

      expect(isTouch()).toBe(false)
    })

    it("should return true when ontouchstart is available", () => {
      // Add touch capability
      window.ontouchstart = jest.fn()

      expect(isTouch()).toBe(true)
    })

    it("should return true when maxTouchPoints is greater than 0", () => {
      // Remove ontouchstart but add maxTouchPoints
      window.ontouchstart = undefined
      Object.defineProperty(navigator, "maxTouchPoints", { value: 5 })

      expect(isTouch()).toBe(true)
    })
  })

  describe("getDeviceType", () => {
    it("should return desktop for large viewport", () => {
      resizeWindow(1920, 1080)
      expect(getDeviceType()).toBe("desktop")
    })

    it("should return tablet for medium viewport", () => {
      resizeWindow(800, 1024)
      expect(getDeviceType()).toBe("tablet")
    })

    it("should return mobile for small viewport", () => {
      resizeWindow(375, 667)
      expect(getDeviceType()).toBe("mobile")
    })
  })
})

