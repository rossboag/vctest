import { render } from "@testing-library/react"
import { axe, toHaveNoViolations } from "jest-axe"
import { MobileUIAdaptations } from "@/components/mobile-ui-adaptations"
import { OrientationHandler } from "@/components/orientation-handler"
import { ResponsiveEditor } from "@/components/responsive-editor"

// Add jest-axe matchers
expect.extend(toHaveNoViolations)

// Mock dependencies as needed
jest.mock("@/lib/mobile-utils", () => ({
  isMobile: () => true,
  getDeviceType: () => "mobile",
}))

jest.mock("@/hooks/use-orientation", () => ({
  useOrientation: () => "portrait",
}))

jest.mock("@/store/editor-store", () => ({
  useEditorStore: () => ({
    scale: 1,
    setScale: jest.fn(),
    undo: jest.fn(),
    redo: jest.fn(),
    canUndo: true,
    canRedo: true,
  }),
}))

// Mock other components
jest.mock("@/components/editor-toolbar", () => ({
  EditorToolbar: () => <div>Editor Toolbar</div>,
}))

jest.mock("@/components/right-toolbar", () => ({
  RightToolbar: () => <div>Right Toolbar</div>,
}))

jest.mock("@/components/top-toolbar", () => ({
  TopToolbar: () => <div>Top Toolbar</div>,
}))

jest.mock("@/components/editor-canvas", () => ({
  __esModule: true,
  default: () => <div>Editor Canvas</div>,
}))

jest.mock("@/components/timeline-panel", () => ({
  TimelinePanel: () => <div>Timeline Panel</div>,
}))

jest.mock("@/components/touch-interactions", () => ({
  TouchInteractions: () => null,
}))

describe("Accessibility Tests", () => {
  it("MobileUIAdaptations has no accessibility violations", async () => {
    const { container } = render(<MobileUIAdaptations />)
    const results = await axe(container)

    expect(results).toHaveNoViolations()
  })

  it("OrientationHandler has no accessibility violations", async () => {
    const { container } = render(<OrientationHandler />)
    const results = await axe(container)

    expect(results).toHaveNoViolations()
  })

  it("ResponsiveEditor has no accessibility violations", async () => {
    const { container } = render(<ResponsiveEditor />)
    const results = await axe(container)

    expect(results).toHaveNoViolations()
  })
})

