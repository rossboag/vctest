import { render, screen } from "@testing-library/react"
import { ResponsiveEditor } from "@/components/responsive-editor"
import { getDeviceType } from "@/lib/mobile-utils"
import { resizeWindow } from "@/lib/test-utils"

// Mock dependencies
jest.mock("@/lib/mobile-utils", () => ({
  getDeviceType: jest.fn(),
}))

jest.mock("@/components/editor-toolbar", () => ({
  EditorToolbar: () => <div data-testid="editor-toolbar">Editor Toolbar</div>,
}))

jest.mock("@/components/right-toolbar", () => ({
  RightToolbar: () => <div data-testid="right-toolbar">Right Toolbar</div>,
}))

jest.mock("@/components/top-toolbar", () => ({
  TopToolbar: () => <div data-testid="top-toolbar">Top Toolbar</div>,
}))

jest.mock("@/components/editor-canvas", () => ({
  __esModule: true,
  default: () => <div data-testid="editor-canvas">Editor Canvas</div>,
}))

jest.mock("@/components/timeline-panel", () => ({
  TimelinePanel: () => <div data-testid="timeline-panel">Timeline Panel</div>,
}))

jest.mock("@/components/mobile-ui-adaptations", () => ({
  MobileUIAdaptations: () => <div data-testid="mobile-ui-adaptations">Mobile UI Adaptations</div>,
}))

jest.mock("@/components/touch-interactions", () => ({
  TouchInteractions: () => <div data-testid="touch-interactions">Touch Interactions</div>,
}))

describe("ResponsiveEditor", () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  it("renders desktop layout", () => {
    getDeviceType.mockReturnValue("desktop")

    render(<ResponsiveEditor />)

    // Should render all components
    expect(screen.getByTestId("top-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("editor-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("right-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("editor-canvas")).toBeInTheDocument()
    expect(screen.getByTestId("timeline-panel")).toBeInTheDocument()
    expect(screen.getByTestId("touch-interactions")).toBeInTheDocument()

    // Should not render mobile UI
    expect(screen.queryByTestId("mobile-ui-adaptations")).not.toBeInTheDocument()
  })

  it("renders tablet layout", () => {
    getDeviceType.mockReturnValue("tablet")

    render(<ResponsiveEditor />)

    // Should render all components
    expect(screen.getByTestId("top-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("editor-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("right-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("editor-canvas")).toBeInTheDocument()
    expect(screen.getByTestId("timeline-panel")).toBeInTheDocument()
    expect(screen.getByTestId("touch-interactions")).toBeInTheDocument()

    // Should not render mobile UI
    expect(screen.queryByTestId("mobile-ui-adaptations")).not.toBeInTheDocument()
  })

  it("renders mobile layout", () => {
    getDeviceType.mockReturnValue("mobile")

    render(<ResponsiveEditor />)

    // Should render main components
    expect(screen.getByTestId("top-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("editor-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("right-toolbar")).toBeInTheDocument()
    expect(screen.getByTestId("editor-canvas")).toBeInTheDocument()
    expect(screen.getByTestId("touch-interactions")).toBeInTheDocument()

    // Should render mobile UI
    expect(screen.getByTestId("mobile-ui-adaptations")).toBeInTheDocument()

    // Should not render timeline panel
    expect(screen.queryByTestId("timeline-panel")).not.toBeInTheDocument()
  })

  it("updates layout on window resize", () => {
    getDeviceType.mockReturnValue("desktop")

    render(<ResponsiveEditor />)

    // Initially desktop
    expect(screen.queryByTestId("mobile-ui-adaptations")).not.toBeInTheDocument()

    // Change to mobile
    getDeviceType.mockReturnValue("mobile")
    resizeWindow(375, 667)

    // Should now show mobile UI
    expect(screen.getByTestId("mobile-ui-adaptations")).toBeInTheDocument()
  })
})

