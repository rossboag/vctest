import { render, screen, fireEvent } from "@testing-library/react"
import { ErrorBoundary } from "@/components/error-boundary"
import { useErrorTracking } from "@/lib/error-tracking"

// Mock error tracking
jest.mock("@/lib/error-tracking", () => ({
  useErrorTracking: jest.fn(),
  captureError: jest.fn(),
}))

// Component that throws an error
let ErrorComponent = ({ shouldThrow = false }) => {
  if (shouldThrow) {
    throw new Error("Test error")
  }
  return <div>No error</div>
}

describe("Error Handling Tests", () => {
  beforeEach(() => {
    jest.clearAllMocks()

    // Mock console.error to avoid test output noise
    jest.spyOn(console, "error").mockImplementation(() => {})

    // Mock useErrorTracking
    useErrorTracking.mockReturnValue({
      captureError: jest.fn(),
      errorCount: 0,
      clearErrors: jest.fn(),
    })
  })

  it("renders children when no error occurs", () => {
    render(
      <ErrorBoundary>
        <ErrorComponent shouldThrow={false} />
      </ErrorBoundary>,
    )

    // Should render children
    expect(screen.getByText("No error")).toBeInTheDocument()
  })

  it("renders fallback UI when error occurs", () => {
    render(
      <ErrorBoundary>
        <ErrorComponent shouldThrow={true} />
      </ErrorBoundary>,
    )

    // Should render fallback UI
    expect(screen.getByText(/Something went wrong/)).toBeInTheDocument()
    expect(screen.getByText(/Test error/)).toBeInTheDocument()
    expect(screen.getByText("Try Again")).toBeInTheDocument()
  })

  it("captures error with error tracking", () => {
    const mockCaptureError = jest.fn()
    useErrorTracking.mockReturnValue({
      captureError: mockCaptureError,
      errorCount: 0,
      clearErrors: jest.fn(),
    })

    render(
      <ErrorBoundary>
        <ErrorComponent shouldThrow={true} />
      </ErrorBoundary>,
    )

    // Should capture error
    expect(mockCaptureError).toHaveBeenCalled()
  })

  it("resets error state when Try Again is clicked", () => {
    render(
      <ErrorBoundary>
        <ErrorComponent shouldThrow={true} />
      </ErrorBoundary>,
    )

    // Should render fallback UI
    expect(screen.getByText(/Something went wrong/)).toBeInTheDocument()

    // Mock component to not throw on retry
    ErrorComponent = jest.fn().mockImplementation(({ shouldThrow }) => {
      return <div>No error</div>
    })

    // Click Try Again
    fireEvent.click(screen.getByText("Try Again"))

    // Should render children
    expect(screen.getByText("No error")).toBeInTheDocument()
  })
})

