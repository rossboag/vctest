"use client"

import type React from "react"

import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { animationPresets, easingFunctions, Easings } from "@/lib/animations"

export const AnimationEditor: React.FC = () => {
  const { selectedIds, createAnimation, playAnimation, stopAnimation } = useEditorStore()
  const [preset, setPreset] = useState("")
  const [easing, setEasing] = useState("Linear")
  const [duration, setDuration] = useState(1)

  const handleCreateAnimation = () => {
    if (selectedIds.length > 0 && preset) {
      const animationConfig = animationPresets[preset](/* pass the selected node here */)
      createAnimation(selectedIds[0], {
        ...animationConfig,
        easing: Easings[easing],
        duration: duration,
      })
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Animation Editor</h2>
      <Select value={preset} onValueChange={setPreset}>
        <option value="">Select a preset</option>
        {Object.keys(animationPresets).map((key) => (
          <option key={key} value={key}>
            {key}
          </option>
        ))}
      </Select>
      <Select value={easing} onValueChange={setEasing} className="mt-2">
        {easingFunctions.map(({ name }) => (
          <option key={name} value={name}>
            {name}
          </option>
        ))}
      </Select>
      <Input
        type="number"
        value={duration}
        onChange={(e) => setDuration(Number(e.target.value))}
        placeholder="Duration (seconds)"
        className="mt-2"
      />
      <Button onClick={handleCreateAnimation} className="mt-2 mr-2">
        Create Animation
      </Button>
      <Button onClick={() => playAnimation(selectedIds[0])} className="mt-2 mr-2">
        Play
      </Button>
      <Button onClick={() => stopAnimation(selectedIds[0])} className="mt-2">
        Stop
      </Button>
    </div>
  )
}

