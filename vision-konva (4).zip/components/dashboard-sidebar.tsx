import { Palette, Layout } from "lucide-react"

// Navigation items
const navigationItems = [
  {
    name: "Design Studio",
    href: "/design-studio",
    icon: Palette,
  },
  {
    title: "Layout Studio",
    href: "/layout-studio",
    icon: Layout,
  },
  // ... other navigation items
]

