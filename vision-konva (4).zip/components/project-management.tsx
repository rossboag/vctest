"use client"

import { useState, useEffect } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function ProjectManagement() {
  const { saveProject, loadProject } = useEditorStore()
  const [projectName, setProjectName] = useState("")
  const [savedProjects, setSavedProjects] = useState<string[]>([])

  useEffect(() => {
    const projects = Object.keys(localStorage).filter((key) => key.startsWith("savedProject_"))
    setSavedProjects(projects.map((key) => key.replace("savedProject_", "")))
  }, [])

  const handleSave = () => {
    if (projectName) {
      const projectData = saveProject()
      localStorage.setItem(`savedProject_${projectName}`, JSON.stringify(projectData))
      setSavedProjects([...savedProjects, projectName])
      setProjectName("")
    }
  }

  const handleLoad = (name: string) => {
    const projectData = JSON.parse(localStorage.getItem(`savedProject_${name}`) || "{}")
    loadProject(projectData)
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex space-x-2">
        <Input
          type="text"
          placeholder="Project name"
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
        />
        <Button onClick={handleSave}>Save Project</Button>
      </div>
      <div className="space-y-2">
        <h3 className="font-semibold">Saved Projects</h3>
        {savedProjects.map((name) => (
          <div key={name} className="flex justify-between items-center">
            <span>{name}</span>
            <Button onClick={() => handleLoad(name)}>Load</Button>
          </div>
        ))}
      </div>
    </div>
  )
}

