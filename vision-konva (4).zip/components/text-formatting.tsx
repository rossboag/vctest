import type React from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Select } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
  faBold,
  faItalic,
  faUnderline,
  faAlignLeft,
  faAlignCenter,
  faAlignRight,
} from "@fortawesome/free-solid-svg-icons"

export const TextFormatting: React.FC = () => {
  const { selectedIds, updateElement, elements } = useEditorStore()

  const selectedTextElement = elements.find((el) => el.type === "text" && selectedIds.includes(el.id))

  if (!selectedTextElement) return null

  const handleFontChange = (font: string) => {
    updateElement(selectedTextElement.id, { fontFamily: font })
  }

  const handleFontSizeChange = (size: number) => {
    updateElement(selectedTextElement.id, { fontSize: size })
  }

  const handleStyleChange = (style: "bold" | "italic" | "underline") => {
    const currentStyle = selectedTextElement.fontStyle || ""
    const newStyle = currentStyle.includes(style)
      ? currentStyle.replace(style, "").trim()
      : `${currentStyle} ${style}`.trim()
    updateElement(selectedTextElement.id, { fontStyle: newStyle })
  }

  const handleAlignmentChange = (alignment: "left" | "center" | "right") => {
    updateElement(selectedTextElement.id, { align: alignment })
  }

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-semibold">Text Formatting</h2>
      <div className="flex space-x-2">
        <Select onValueChange={handleFontChange} value={selectedTextElement.fontFamily}>
          <option value="Arial">Arial</option>
          <option value="Helvetica">Helvetica</option>
          <option value="Times New Roman">Times New Roman</option>
          <option value="Courier">Courier</option>
        </Select>
        <Input
          type="number"
          value={selectedTextElement.fontSize}
          onChange={(e) => handleFontSizeChange(Number(e.target.value))}
          min={1}
          max={200}
        />
      </div>
      <div className="flex space-x-2">
        <Button
          onClick={() => handleStyleChange("bold")}
          variant={selectedTextElement.fontStyle?.includes("bold") ? "default" : "outline"}
        >
          <FontAwesomeIcon icon={faBold} />
        </Button>
        <Button
          onClick={() => handleStyleChange("italic")}
          variant={selectedTextElement.fontStyle?.includes("italic") ? "default" : "outline"}
        >
          <FontAwesomeIcon icon={faItalic} />
        </Button>
        <Button
          onClick={() => handleStyleChange("underline")}
          variant={selectedTextElement.fontStyle?.includes("underline") ? "default" : "outline"}
        >
          <FontAwesomeIcon icon={faUnderline} />
        </Button>
      </div>
      <div className="flex space-x-2">
        <Button
          onClick={() => handleAlignmentChange("left")}
          variant={selectedTextElement.align === "left" ? "default" : "outline"}
        >
          <FontAwesomeIcon icon={faAlignLeft} />
        </Button>
        <Button
          onClick={() => handleAlignmentChange("center")}
          variant={selectedTextElement.align === "center" ? "default" : "outline"}
        >
          <FontAwesomeIcon icon={faAlignCenter} />
        </Button>
        <Button
          onClick={() => handleAlignmentChange("right")}
          variant={selectedTextElement.align === "right" ? "default" : "outline"}
        >
          <FontAwesomeIcon icon={faAlignRight} />
        </Button>
      </div>
    </div>
  )
}

