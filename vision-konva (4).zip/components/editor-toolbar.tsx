"use client"

import { Button } from "@/components/ui/button"
import { useEditorStore } from "@/store/editor-store"
import {
  ArrowLeftIcon,
  Shapes,
  Wand2,
  Play,
  ImageIcon,
  Film,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  FlipHorizontal,
  FlipVertical,
  RotateCw,
  Lock,
  Unlock,
  Group,
  Ungroup,
  Move,
  MenuIcon,
} from "lucide-react"
import { useState, useEffect } from "react"
import { ShapesMenu } from "./shapes-menu"
import { EffectsMenu } from "./effects-menu"
import { AnimationsMenu } from "./animations-menu"
import { ImageMenu } from "./image-menu"
import { VideoMenu } from "./video-menu"
import TextMenu from "./text-menu"
import { isMobile } from "@/lib/mobile-utils"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function EditorToolbar() {
  const {
    setActiveTool,
    activeTool,
    selectedIds,
    alignElements,
    distributeElements,
    flipElement,
    rotateElement,
    lockElement,
    unlockElement,
    groupElements,
    ungroupElements,
  } = useEditorStore()
  const [isShapesMenuOpen, setIsShapesMenuOpen] = useState(false)
  const [isEffectsMenuOpen, setIsEffectsMenuOpen] = useState(false)
  const [isAnimationsMenuOpen, setIsAnimationsMenuOpen] = useState(false)
  const [isImageMenuOpen, setIsImageMenuOpen] = useState(false)
  const [isVideoMenuOpen, setIsVideoMenuOpen] = useState(false)
  const [isTextMenuOpen, setIsTextMenuOpen] = useState(false)
  const [isMobileView, setIsMobileView] = useState(false)

  useEffect(() => {
    setIsMobileView(isMobile())

    const handleResize = () => {
      setIsMobileView(isMobile())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const handleToolClick = (tool: string) => {
    setActiveTool(tool)
    setIsShapesMenuOpen(false)
    setIsEffectsMenuOpen(false)
    setIsAnimationsMenuOpen(false)
    setIsImageMenuOpen(false)
    setIsVideoMenuOpen(false)
    setIsTextMenuOpen(false)

    switch (tool) {
      case "shapes":
        setIsShapesMenuOpen(true)
        break
      case "effects":
        setIsEffectsMenuOpen(true)
        break
      case "animations":
        setIsAnimationsMenuOpen(true)
        break
      case "image":
        setIsImageMenuOpen(true)
        break
      case "video":
        setIsVideoMenuOpen(true)
        break
      case "text":
        setIsTextMenuOpen(true)
        break
    }
  }

  return (
    <>
      {isMobileView ? (
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="fixed left-2 top-16 z-50 bg-background shadow-md"
              aria-label="Open Tools Menu"
            >
              <MenuIcon className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <div className="flex flex-col items-center py-2 space-y-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("select")}
                className={`w-full justify-start px-4 ${
                  activeTool === "select" ? "bg-accent text-accent-foreground" : ""
                }`}
                title="Select"
              >
                <ArrowLeftIcon className="h-4 w-4 mr-2" />
                <span>Select</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("shapes")}
                className={`w-full justify-start px-4 ${isShapesMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
                title="Shapes"
              >
                <Shapes className="h-4 w-4 mr-2" />
                <span>Shapes</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("text")}
                className={`w-full justify-start px-4 ${isTextMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
                title="Text"
              >
                <Type className="h-4 w-4 mr-2" />
                <span>Text</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("effects")}
                className={`w-full justify-start px-4 ${isEffectsMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
                title="Effects"
              >
                <Wand2 className="h-4 w-4 mr-2" />
                <span>Effects</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("animations")}
                className={`w-full justify-start px-4 ${isAnimationsMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
                title="Animations"
              >
                <Play className="h-4 w-4 mr-2" />
                <span>Animations</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("image")}
                className={`w-full justify-start px-4 ${isImageMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
                title="Image"
              >
                <ImageIcon className="h-4 w-4 mr-2" />
                <span>Image</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToolClick("video")}
                className={`w-full justify-start px-4 ${isVideoMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
                title="Video"
              >
                <Film className="h-4 w-4 mr-2" />
                <span>Video</span>
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      ) : (
        <div className="fixed left-0 top-12 bottom-[200px] w-16 bg-card border-r border-border flex flex-col items-center py-2 space-y-2 z-10">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("select")}
            className={`hover:bg-accent hover:text-accent-foreground ${
              activeTool === "select" ? "bg-accent text-accent-foreground" : ""
            }`}
            title="Select"
          >
            <ArrowLeftIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("shapes")}
            className={`hover:bg-accent hover:text-accent-foreground ${isShapesMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
            title="Shapes"
          >
            <Shapes className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("text")}
            className={`hover:bg-accent hover:text-accent-foreground ${isTextMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
            title="Text"
          >
            <Type className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("effects")}
            className={`hover:bg-accent hover:text-accent-foreground ${isEffectsMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
            title="Effects"
          >
            <Wand2 className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("animations")}
            className={`hover:bg-accent hover:text-accent-foreground ${isAnimationsMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
            title="Animations"
          >
            <Play className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("image")}
            className={`hover:bg-accent hover:text-accent-foreground ${isImageMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
            title="Image"
          >
            <ImageIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolClick("video")}
            className={`hover:bg-accent hover:text-accent-foreground ${isVideoMenuOpen ? "bg-accent text-accent-foreground" : ""}`}
            title="Video"
          >
            <Film className="h-4 w-4" />
          </Button>
        </div>
      )}

      {isShapesMenuOpen && <ShapesMenu onClose={() => setIsShapesMenuOpen(false)} />}
      {isEffectsMenuOpen && <EffectsMenu onClose={() => setIsEffectsMenuOpen(false)} />}
      {isAnimationsMenuOpen && <AnimationsMenu onClose={() => setIsAnimationsMenuOpen(false)} />}
      {isImageMenuOpen && <ImageMenu onClose={() => setIsImageMenuOpen(false)} />}
      {isVideoMenuOpen && <VideoMenu onClose={() => setIsVideoMenuOpen(false)} />}
      {isTextMenuOpen && <TextMenu onClose={() => setIsTextMenuOpen(false)} />}

      {/* New toolbar for transform and edit controls */}
      <div className="fixed top-0 left-16 right-0 h-12 bg-card border-b border-border flex items-center px-4 space-x-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => alignElements(selectedIds, "left")}
          disabled={selectedIds.length < 2}
          title="Align Left"
        >
          <AlignLeft className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => alignElements(selectedIds, "center")}
          disabled={selectedIds.length < 2}
          title="Align Center"
        >
          <AlignCenter className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => alignElements(selectedIds, "right")}
          disabled={selectedIds.length < 2}
          title="Align Right"
        >
          <AlignRight className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => distributeElements(selectedIds, "horizontal")}
          disabled={selectedIds.length < 3}
          title="Distribute Horizontally"
        >
          <AlignJustify className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => flipElement(selectedIds[0], "horizontal")}
          disabled={selectedIds.length !== 1}
          title="Flip Horizontal"
        >
          <FlipHorizontal className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => flipElement(selectedIds[0], "vertical")}
          disabled={selectedIds.length !== 1}
          title="Flip Vertical"
        >
          <FlipVertical className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => rotateElement(selectedIds[0], 90)}
          disabled={selectedIds.length !== 1}
          title="Rotate 90°"
        >
          <RotateCw className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => lockElement(selectedIds[0])}
          disabled={selectedIds.length !== 1}
          title="Lock"
        >
          <Lock className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => unlockElement(selectedIds[0])}
          disabled={selectedIds.length !== 1}
          title="Unlock"
        >
          <Unlock className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => groupElements(selectedIds)}
          disabled={selectedIds.length < 2}
          title="Group"
        >
          <Group className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => ungroupElements(selectedIds[0])}
          disabled={selectedIds.length !== 1}
          title="Ungroup"
        >
          <Ungroup className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setActiveTool("move")}
          className={`hover:bg-accent hover:text-accent-foreground ${
            activeTool === "move" ? "bg-accent text-accent-foreground" : ""
          }`}
          title="Move Tool"
        >
          <Move className="h-4 w-4" />
        </Button>
      </div>
    </>
  )
}

