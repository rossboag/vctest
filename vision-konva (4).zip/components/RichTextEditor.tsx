"use client"

import type React from "react"

import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { ColorPicker } from "@/components/ui/color-picker"

export const RichTextEditor: React.FC = () => {
  const { selectedIds, updateElement } = useEditorStore()
  const [text, setText] = useState("")
  const [fontSize, setFontSize] = useState(16)
  const [fontFamily, setFontFamily] = useState("Arial")
  const [color, setColor] = useState("#000000")
  const [align, setAlign] = useState("left")
  const [decoration, setDecoration] = useState("none")

  const handleUpdateText = () => {
    if (selectedIds.length > 0) {
      updateElement(selectedIds[0], {
        text,
        fontSize,
        fontFamily,
        fill: color,
        align,
        textDecoration: decoration,
      })
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Text Editor</h2>
      <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Enter text" className="mb-2" />
      <Select value={fontFamily} onValueChange={setFontFamily} className="mb-2">
        <option value="Arial">Arial</option>
        <option value="Helvetica">Helvetica</option>
        <option value="Times New Roman">Times New Roman</option>
        <option value="Courier New">Courier New</option>
      </Select>
      <Slider
        value={[fontSize]}
        onValueChange={(value) => setFontSize(value[0])}
        min={8}
        max={72}
        step={1}
        className="mb-2"
      />
      <ColorPicker color={color} onChange={setColor} className="mb-2" />
      <Select value={align} onValueChange={setAlign} className="mb-2">
        <option value="left">Left</option>
        <option value="center">Center</option>
        <option value="right">Right</option>
      </Select>
      <Select value={decoration} onValueChange={setDecoration} className="mb-2">
        <option value="none">None</option>
        <option value="underline">Underline</option>
        <option value="line-through">Strikethrough</option>
      </Select>
      <Button onClick={handleUpdateText}>Update Text</Button>
    </div>
  )
}

