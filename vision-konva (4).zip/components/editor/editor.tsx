"use client"

// Add this import
import { AIPanel } from "@/components/editor/ai-panel"
import { useState } from "react" // Import useState
import { toast } from "react-hot-toast"
import { Wand2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"
// Add this import
import { AnimationPanel } from "@/components/editor/animation-panel"
// Add this import
import { DesignPanel } from "@/components/editor/design-panel"
import { Palette } from "lucide-react"
// Add this import
import { LayoutPanel } from "@/components/editor/layout-panel"
import { Layout } from "lucide-react"

// Add this state
// Initialize showAIPanel at the top level of the component
// to ensure it's always called in the same order
// and to fix the "use before declaration" error.
// This assumes the Editor component is a functional component.
// If it's a class component, this needs to be handled differently.
// For example, if this is a functional component:
// const Editor = () => {
//   const [showAIPanel, setShowAIPanel] = useState(false);
//   ...rest of the component
// }

// Add this to the Editor component
// Inside the return statement, add the AI panel

// Add this button to the toolbar
// Assuming this is inside a toolbar component
// and that the toolbar component is rendered before the AI panel.
// If not, you may need to adjust the order of rendering.

const Editor = ({ project, selectedElement, elements, canvasWidth, canvasHeight }) => {
  const [showAIPanel, setShowAIPanel] = useState(false)
  // Add this state
  const [showAnimationPanel, setShowAnimationPanel] = useState(false)
  // Add this state
  const [showDesignPanel, setShowDesignPanel] = useState(false)
  // Add this state
  const [showLayoutPanel, setShowLayoutPanel] = useState(false)

  // Add this function to get design elements in the required format
  const getDesignElements = () => {
    // Convert your canvas elements to the format expected by the design panel
    // This would depend on your canvas implementation
    return elements.map((element) => ({
      id: element.id,
      type: element.type,
      content: element.text || "",
      style: {
        fontFamily: element.fontFamily || "Arial",
        fontSize: element.fontSize || "16px",
        fontWeight: element.fontWeight || "normal",
        color: element.fill || "#000000",
        // Add other style properties as needed
      },
      position: { x: element.x, y: element.y },
      // Add other properties as needed
    }))
  }

  return (
    <div className="flex-1 flex">
      {/* Existing canvas and tools */}

      {/* Add this */}
      {showAIPanel && (
        <div className="w-80 border-l">
          <AIPanel
            projectId={project.id}
            onApplyLayout={(layout) => {
              // Handle applying layout
              // This would depend on your canvas implementation
              toast.success("Layout applied")
            }}
            onApplyColorPalette={(colors) => {
              // Handle applying color palette
              // This would depend on your canvas implementation
              toast.success("Color palette applied")
            }}
            onInsertText={(text) => {
              // Handle inserting text
              // This would depend on your canvas implementation
              toast.success("Text inserted")
            }}
            onInsertImage={(imageUrl) => {
              // Handle inserting image
              // This would depend on your canvas implementation
              toast.success("Image inserted")
            }}
          />
        </div>
      )}
      {/* Add this */}
      {showAnimationPanel && (
        <div className="w-80 border-l">
          <AnimationPanel
            projectId={project.id}
            selectedElementId={selectedElement?.id}
            selectedElementType={selectedElement?.type}
            onApplyKeyframes={(elementId, keyframes) => {
              // Handle applying keyframes to the element
              // This would depend on your canvas implementation
              toast.success("Animation keyframes applied")
            }}
            onApplyPreset={(elementId, preset) => {
              // Handle applying preset to the element
              // This would depend on your canvas implementation
              toast.success(`Preset "${preset.name}" applied`)
            }}
            onApplySequence={(elementAnimations) => {
              // Handle applying animation sequence
              // This would depend on your canvas implementation
              toast.success("Animation sequence applied")
            }}
          />
        </div>
      )}
      {/* Add this */}
      {showDesignPanel && (
        <div className="w-80 border-l">
          <DesignPanel
            projectId={project.id}
            elements={elements}
            canvasWidth={canvasWidth}
            canvasHeight={canvasHeight}
            onApplySuggestion={(suggestion) => {
              // Handle applying suggestion to the design
              // This would depend on your canvas implementation
              toast.success(`Applied suggestion: ${suggestion.title}`)
            }}
            onApplyPalette={(palette) => {
              // Handle applying color palette to the design
              // This would depend on your canvas implementation
              toast.success("Color palette applied")
            }}
            onApplyTypography={(typography) => {
              // Handle applying typography to the design
              // This would depend on your canvas implementation
              toast.success("Typography applied")
            }}
            onFixAccessibilityIssue={(elementId, recommendation) => {
              // Handle fixing accessibility issue
              // This would depend on your canvas implementation
              toast.success(`Fixed accessibility issue for element ${elementId}`)
            }}
          />
        </div>
      )}
      {showLayoutPanel && (
        <div className="w-80 border-l">
          <LayoutPanel
            projectId={project.id}
            canvasWidth={canvasWidth}
            canvasHeight={canvasHeight}
            elements={elements}
            onApplyLayout={(layout) => {
              // Handle applying layout to the canvas
              // This would update element positions and sizes
              toast.success("Layout applied to canvas")
            }}
            onApplyElements={(optimizedElements) => {
              // Handle applying optimized elements to the canvas
              // This would update element positions and sizes
              toast.success("Optimized elements applied to canvas")
            }}
            onApplyGridSystem={(gridSystem) => {
              // Handle applying grid system to the canvas
              // This might update the grid guides or snap-to-grid behavior
              toast.success("Grid system applied to canvas")
            }}
            onApplySuggestion={(suggestion) => {
              // Handle applying a layout suggestion
              // This would apply the changes from suggestion.after
              toast.success(`Applied suggestion: ${suggestion.title}`)
            }}
          />
        </div>
      )}
      <Button variant="outline" size="sm" onClick={() => setShowAIPanel(!showAIPanel)}>
        <Wand2 className="h-4 w-4 mr-2" />
        AI Assistant
      </Button>
      {/* Add this button to the toolbar */}
      <Button variant="outline" size="sm" onClick={() => setShowAnimationPanel(!showAnimationPanel)}>
        <Play className="h-4 w-4 mr-2" />
        Animation
      </Button>
      {/* Add this button to the toolbar */}
      <Button variant="outline" size="sm" onClick={() => setShowDesignPanel(!showDesignPanel)}>
        <Wand2 className="h-4 w-4 mr-2" />
        Design
      </Button>
      {/* Add this button to the toolbar */}
      <Button variant="outline" size="sm" onClick={() => setShowDesignPanel(!showDesignPanel)}>
        <Palette className="h-4 w-4 mr-2" />
        Design
      </Button>
      {/* Add this button to the toolbar */}
      <Button variant="outline" size="sm" onClick={() => setShowLayoutPanel(!showLayoutPanel)}>
        <Layout className="h-4 w-4 mr-2" />
        Layout
      </Button>
    </div>
  )
}

