"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AIAnimationKeyframesGenerator } from "@/components/ai/ai-animation-keyframes-generator"
import { AnimationPresetBrowser } from "@/components/ai/animation-preset-browser"
import { AIAnimationSuggestions } from "@/components/ai/ai-animation-suggestions"
import { AIAnimationSequenceGenerator } from "@/components/ai/ai-animation-sequence-generator"
import { Play } from "lucide-react"
import { toast } from "sonner"
import type { AnimationKeyframe, AnimationPreset, ElementAnimationConfig } from "@/lib/ai-animation-service"

interface AnimationPanelProps {
  projectId: string
  selectedElementId?: string
  selectedElementType?: string
  onApplyKeyframes?: (elementId: string, keyframes: AnimationKeyframe[]) => void
  onApplyPreset?: (elementId: string, preset: AnimationPreset) => void
  onApplySequence?: (elementAnimations: ElementAnimationConfig[]) => void
}

export function AnimationPanel({
  projectId,
  selectedElementId,
  selectedElementType = "text",
  onApplyKeyframes,
  onApplyPreset,
  onApplySequence,
}: AnimationPanelProps) {
  const [activeTab, setActiveTab] = useState("keyframes")

  const handleKeyframesGenerated = (keyframes: AnimationKeyframe[]) => {
    if (selectedElementId && onApplyKeyframes) {
      onApplyKeyframes(selectedElementId, keyframes)
      toast.success("Animation applied to element")
    } else {
      toast.error("No element selected")
    }
  }

  const handlePresetSelected = (preset: AnimationPreset) => {
    if (selectedElementId && onApplyPreset) {
      onApplyPreset(selectedElementId, preset)
      toast.success(`Preset "${preset.name}" applied to element`)
    } else {
      toast.error("No element selected")
    }
  }

  const handleSuggestionSelected = (suggestion: string) => {
    if (selectedElementId) {
      toast.success("Generating animation from suggestion...")
      // Here you would typically use this suggestion to generate keyframes
      // and then apply them to the selected element
    } else {
      toast.error("No element selected")
    }
  }

  const handleSequenceGenerated = (result: {
    sequenceDescription: string
    elementAnimations: ElementAnimationConfig[]
  }) => {
    if (onApplySequence) {
      onApplySequence(result.elementAnimations)
      toast.success("Animation sequence applied")
    }
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold flex items-center">
          <Play className="h-5 w-5 mr-2" />
          Animation
        </h2>
        {selectedElementId && (
          <div className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">Element: {selectedElementId}</div>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-4">
          <TabsTrigger value="keyframes">Keyframes</TabsTrigger>
          <TabsTrigger value="presets">Presets</TabsTrigger>
          <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
          <TabsTrigger value="sequence">Sequence</TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-auto p-4">
          <TabsContent value="keyframes" className="h-full">
            <AIAnimationKeyframesGenerator
              projectId={projectId}
              onGenerated={handleKeyframesGenerated}
              title="Generate Animation"
              elementType={selectedElementType}
            />
          </TabsContent>

          <TabsContent value="presets" className="h-full">
            <AnimationPresetBrowser onSelectPreset={handlePresetSelected} />
          </TabsContent>

          <TabsContent value="suggestions" className="h-full">
            <AIAnimationSuggestions onSelectSuggestion={handleSuggestionSelected} elementType={selectedElementType} />
          </TabsContent>

          <TabsContent value="sequence" className="h-full">
            <AIAnimationSequenceGenerator
              projectId={projectId}
              onGenerated={handleSequenceGenerated}
              title="Animation Sequence"
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

