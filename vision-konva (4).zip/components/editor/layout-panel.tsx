"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AutoLayoutGenerator } from "@/components/ai/auto-layout-generator"
import { ElementPositioningOptimizer } from "@/components/ai/element-positioning-optimizer"
import { WhitespaceAnalyzer } from "@/components/ai/whitespace-analyzer"
import { GridSystemGenerator } from "@/components/ai/grid-system-generator"
import { AlignmentAnalyzer } from "@/components/ai/alignment-analyzer"
import { LayoutSuggestionGenerator } from "@/components/ai/layout-suggestion-generator"
import { ResponsiveLayoutGenerator } from "@/components/ai/responsive-layout-generator"
import { Layout } from "lucide-react"
import { toast } from "sonner"
import type { LayoutElement, LayoutResult, GridSystem, LayoutSuggestion } from "@/lib/ai-layout-service"

interface LayoutPanelProps {
  projectId: string
  canvasWidth: number
  canvasHeight: number
  elements: LayoutElement[]
  onApplyLayout?: (layout: LayoutResult) => void
  onApplyElements?: (elements: LayoutElement[]) => void
  onApplyGridSystem?: (gridSystem: GridSystem) => void
  onApplySuggestion?: (suggestion: LayoutSuggestion) => void
}

export function LayoutPanel({
  projectId,
  canvasWidth,
  canvasHeight,
  elements,
  onApplyLayout,
  onApplyElements,
  onApplyGridSystem,
  onApplySuggestion,
}: LayoutPanelProps) {
  const [activeTab, setActiveTab] = useState("auto-layout")
  const [gridSystem, setGridSystem] = useState<GridSystem | null>(null)

  const handleLayoutGenerated = (layout: LayoutResult) => {
    if (onApplyLayout) {
      onApplyLayout(layout)
      toast.success("Layout applied")
    }
  }

  const handleElementsOptimized = (optimizedElements: LayoutElement[]) => {
    if (onApplyElements) {
      onApplyElements(optimizedElements)
      toast.success("Element positioning optimized")
    }
  }

  const handleGridGenerated = (grid: GridSystem) => {
    setGridSystem(grid)
    if (onApplyGridSystem) {
      onApplyGridSystem(grid)
      toast.success("Grid system applied")
    }
  }

  const handleApplySuggestion = (suggestion: LayoutSuggestion) => {
    if (onApplySuggestion) {
      onApplySuggestion(suggestion)
      toast.success(`Applied suggestion: ${suggestion.title}`)
    }
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold flex items-center">
          <Layout className="h-5 w-5 mr-2" />
          Layout Assistant
        </h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="px-4 pt-4 flex overflow-x-auto">
          <TabsTrigger value="auto-layout">Auto Layout</TabsTrigger>
          <TabsTrigger value="positioning">Positioning</TabsTrigger>
          <TabsTrigger value="whitespace">Whitespace</TabsTrigger>
          <TabsTrigger value="grid">Grid</TabsTrigger>
          <TabsTrigger value="alignment">Alignment</TabsTrigger>
          <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
          <TabsTrigger value="responsive">Responsive</TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-auto p-4">
          <TabsContent value="auto-layout" className="h-full mt-0">
            <AutoLayoutGenerator
              projectId={projectId}
              initialWidth={canvasWidth}
              initialHeight={canvasHeight}
              onLayoutGenerated={handleLayoutGenerated}
            />
          </TabsContent>

          <TabsContent value="positioning" className="h-full mt-0">
            <ElementPositioningOptimizer
              projectId={projectId}
              canvasSize={{ width: canvasWidth, height: canvasHeight }}
              elements={elements}
              onElementsOptimized={handleElementsOptimized}
            />
          </TabsContent>

          <TabsContent value="whitespace" className="h-full mt-0">
            <WhitespaceAnalyzer
              projectId={projectId}
              canvasSize={{ width: canvasWidth, height: canvasHeight }}
              elements={elements}
              onElementsOptimized={handleElementsOptimized}
            />
          </TabsContent>

          <TabsContent value="grid" className="h-full mt-0">
            <GridSystemGenerator
              projectId={projectId}
              canvasSize={{ width: canvasWidth, height: canvasHeight }}
              onGridGenerated={handleGridGenerated}
            />
          </TabsContent>

          <TabsContent value="alignment" className="h-full mt-0">
            <AlignmentAnalyzer
              projectId={projectId}
              elements={elements}
              gridSystem={gridSystem}
              onElementsOptimized={handleElementsOptimized}
            />
          </TabsContent>

          <TabsContent value="suggestions" className="h-full mt-0">
            <LayoutSuggestionGenerator
              projectId={projectId}
              canvasSize={{ width: canvasWidth, height: canvasHeight }}
              elements={elements}
              onApplySuggestion={handleApplySuggestion}
            />
          </TabsContent>

          <TabsContent value="responsive" className="h-full mt-0">
            <ResponsiveLayoutGenerator
              projectId={projectId}
              elements={elements}
              originalSize={{ width: canvasWidth, height: canvasHeight }}
              onLayoutGenerated={handleLayoutGenerated}
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

