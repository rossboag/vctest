"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DesignAnalyzer } from "@/components/ai/design-analyzer"
import { ColorPaletteGenerator } from "@/components/ai/color-palette-generator"
import { TypographyRecommender } from "@/components/ai/typography-recommender"
import { AccessibilityChecker } from "@/components/ai/accessibility-checker"
import { DesignSuggestionGenerator } from "@/components/ai/design-suggestion-generator"
import { Palette } from "lucide-react"
import { toast } from "sonner"
import type { ColorPalette, TypographyRecommendation } from "@/lib/ai-design-service"

interface DesignPanelProps {
  projectId: string
  designElements: any[]
  canvasSize: { width: number; height: number }
  onApplyColorPalette?: (palette: ColorPalette) => void
  onApplyTypography?: (typography: TypographyRecommendation) => void
  onApplySuggestions?: (suggestions: any) => void
}

export function DesignPanel({
  projectId,
  designElements,
  canvasSize,
  onApplyColorPalette,
  onApplyTypography,
  onApplySuggestions,
}: DesignPanelProps) {
  const [activeTab, setActiveTab] = useState("analyze")

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold flex items-center">
          <Palette className="h-5 w-5 mr-2" />
          Design Assistant
        </h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-5">
          <TabsTrigger value="analyze">Analyze</TabsTrigger>
          <TabsTrigger value="colors">Colors</TabsTrigger>
          <TabsTrigger value="typography">Typography</TabsTrigger>
          <TabsTrigger value="accessibility">Accessibility</TabsTrigger>
          <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-auto p-4">
          <TabsContent value="analyze" className="h-full">
            <DesignAnalyzer
              projectId={projectId}
              designElements={designElements}
              canvasSize={canvasSize}
              onAnalysisComplete={(analysis) => {
                toast.success("Design analysis complete!")
              }}
            />
          </TabsContent>

          <TabsContent value="colors" className="h-full">
            <ColorPaletteGenerator
              projectId={projectId}
              onPaletteGenerated={(palette) => {
                if (onApplyColorPalette) {
                  onApplyColorPalette(palette)
                }
                toast.success("Color palette applied to design!")
              }}
            />
          </TabsContent>

          <TabsContent value="typography" className="h-full">
            <TypographyRecommender
              projectId={projectId}
              onTypographyGenerated={(typography) => {
                if (onApplyTypography) {
                  onApplyTypography(typography)
                }
                toast.success("Typography applied to design!")
              }}
            />
          </TabsContent>

          <TabsContent value="accessibility" className="h-full">
            <AccessibilityChecker
              projectId={projectId}
              designElements={designElements}
              onCheckComplete={(result) => {
                toast.success("Accessibility check complete!")
              }}
            />
          </TabsContent>

          <TabsContent value="suggestions" className="h-full">
            <DesignSuggestionGenerator
              projectId={projectId}
              designElements={designElements}
              canvasSize={canvasSize}
              onSuggestionsGenerated={(suggestions) => {
                if (onApplySuggestions) {
                  onApplySuggestions(suggestions)
                }
                toast.success("Design suggestions applied!")
              }}
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

