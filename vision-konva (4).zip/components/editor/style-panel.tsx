"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BrandStyleExtractor } from "@/components/ai/brand-style-extractor"
import { ThemeFromImageGenerator } from "@/components/ai/theme-from-image-generator"
import { StyleTransferTool } from "@/components/ai/style-transfer-tool"
import { MoodBoardGenerator } from "@/components/ai/mood-board-generator"
import { DesignTrendTool } from "@/components/ai/design-trend-tool"
import { Palette } from "lucide-react"
import { toast } from "sonner"
import type { BrandStyle, ThemeTemplate, MoodBoard } from "@/lib/ai-style-service"

interface StylePanelProps {
  projectId: string
  elements: any[]
  onApplyBrandStyle?: (brandStyle: BrandStyle) => void
  onApplyTheme?: (theme: ThemeTemplate) => void
  onApplyStyleTransfer?: (result: any) => void
  onApplyMoodBoard?: (moodBoard: MoodBoard) => void
  onApplyDesignTrend?: (result: any) => void
}

export function StylePanel({
  projectId,
  elements,
  onApplyBrandStyle,
  onApplyTheme,
  onApplyStyleTransfer,
  onApplyMoodBoard,
  onApplyDesignTrend,
}: StylePanelProps) {
  const [activeTab, setActiveTab] = useState("brand")

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold flex items-center">
          <Palette className="h-5 w-5 mr-2" />
          Style Studio
        </h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-5">
          <TabsTrigger value="brand">Brand</TabsTrigger>
          <TabsTrigger value="theme">Theme</TabsTrigger>
          <TabsTrigger value="transfer">Transfer</TabsTrigger>
          <TabsTrigger value="mood">Mood</TabsTrigger>
          <TabsTrigger value="trend">Trend</TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-auto p-4">
          <TabsContent value="brand" className="h-full">
            <BrandStyleExtractor
              projectId={projectId}
              onBrandStyleExtracted={(brandStyle) => {
                if (onApplyBrandStyle) {
                  onApplyBrandStyle(brandStyle)
                  toast.success("Brand style applied to design!")
                }
              }}
            />
          </TabsContent>

          <TabsContent value="theme" className="h-full">
            <ThemeFromImageGenerator
              projectId={projectId}
              onThemeGenerated={(theme) => {
                if (onApplyTheme) {
                  onApplyTheme(theme)
                  toast.success("Theme applied to design!")
                }
              }}
            />
          </TabsContent>

          <TabsContent value="transfer" className="h-full">
            <StyleTransferTool
              projectId={projectId}
              targetElements={elements}
              onStyleTransferred={(result) => {
                if (onApplyStyleTransfer) {
                  onApplyStyleTransfer(result)
                  toast.success("Style transfer applied to design!")
                }
              }}
            />
          </TabsContent>

          <TabsContent value="mood" className="h-full">
            <MoodBoardGenerator
              projectId={projectId}
              onMoodBoardGenerated={(moodBoard) => {
                if (onApplyMoodBoard) {
                  onApplyMoodBoard(moodBoard)
                  toast.success("Mood board applied to design!")
                }
              }}
            />
          </TabsContent>

          <TabsContent value="trend" className="h-full">
            <DesignTrendTool
              projectId={projectId}
              elements={elements}
              onTrendApplied={(result) => {
                if (onApplyDesignTrend) {
                  onApplyDesignTrend(result)
                  toast.success("Design trend applied to design!")
                }
              }}
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

