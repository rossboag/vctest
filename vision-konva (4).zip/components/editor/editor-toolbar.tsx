// Add these imports
import { ImportAssetDialog } from "@/components/integrations/import-asset-dialog"
import { ExportProjectDialog } from "@/components/integrations/export-project-dialog"
import { Button } from "@/components/ui/button"
import { Upload, Download } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface EditorToolbarProps {
  project: {
    id: string
    name: string
  }
}

const EditorToolbar = ({ project }: EditorToolbarProps) => {
  const { toast } = useToast()

  // Add this to the EditorToolbar component
  // Inside the return statement, add these buttons to the toolbar

  return (
    <>
      <ImportAssetDialog
        onImport={async (asset) => {
          try {
            // Download the file from the cloud storage
            const response = await fetch(`/api/integrations/${asset.provider}/files/${asset.id}?download=true`)

            if (!response.ok) {
              throw new Error("Failed to download file")
            }

            const blob = await response.blob()
            const file = new File([blob], asset.name, {
              type: asset.mimeType || "application/octet-stream",
            })

            // Upload to the project
            const formData = new FormData()
            formData.append("file", file)

            const uploadResponse = await fetch("/api/assets", {
              method: "POST",
              body: formData,
            })

            if (!uploadResponse.ok) {
              throw new Error("Failed to upload asset")
            }

            const assetData = await uploadResponse.json()

            // Add the asset to the project
            // This depends on your project structure
            // For example, you might want to add it as an image element

            toast({
              title: "Asset imported successfully",
            })
          } catch (error) {
            console.error("Error importing asset:", error)
            toast({
              title: "Failed to import asset",
              variant: "destructive",
            })
            throw error
          }
        }}
        trigger={
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Import from Cloud
          </Button>
        }
      />

      <ExportProjectDialog
        projectId={project.id}
        projectName={project.name}
        trigger={
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export to Cloud
          </Button>
        }
      />
    </>
  )
}

export default EditorToolbar

