"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TextEnhancementTool } from "@/components/ai/text-enhancement-tool"
import { ImageEnhancementTool } from "@/components/ai/image-enhancement-tool"
import { VideoSuggestionTool } from "@/components/ai/video-suggestion-tool"
import { ContentAdaptationTool } from "@/components/ai/content-adaptation-tool"
import { ContentLocalizationTool } from "@/components/ai/content-localization-tool"
import { ContentHistory } from "@/components/ai/content-history"
import { FileText, Image, Video, Globe, Share2, History } from "lucide-react"

interface ContentPanelProps {
  projectId: string
  onApplyText?: (text: string) => void
  onApplyImageSuggestions?: (suggestions: any) => void
  onApplyVideoSuggestions?: (suggestions: any) => void
  onApplyAdaptedContent?: (content: string) => void
  onApplyLocalizedContent?: (content: string) => void
  selectedContent?: string
  selectedImage?: string
}

export function ContentPanel({
  projectId,
  onApplyText,
  onApplyImageSuggestions,
  onApplyVideoSuggestions,
  onApplyAdaptedContent,
  onApplyLocalizedContent,
  selectedContent = "",
  selectedImage = "",
}: ContentPanelProps) {
  const [activeTab, setActiveTab] = useState("text")

  const handleHistorySelect = (item: any) => {
    // Handle different types of content history items
    if (item.type === "text") {
      onApplyText?.(item.enhancedContent)
    } else if (item.type === "image") {
      onApplyImageSuggestions?.(item.enhancedContent)
    } else if (item.type === "video") {
      onApplyVideoSuggestions?.(item.enhancedContent)
    } else if (item.type === "adaptation") {
      onApplyAdaptedContent?.(item.enhancedContent)
    } else if (item.type === "localization") {
      onApplyLocalizedContent?.(item.enhancedContent)
    }
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold">Content Enhancement</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-6">
          <TabsTrigger value="text" className="flex flex-col py-2 px-1 h-auto">
            <FileText className="h-4 w-4 mb-1" />
            <span className="text-xs">Text</span>
          </TabsTrigger>
          <TabsTrigger value="image" className="flex flex-col py-2 px-1 h-auto">
            <Image className="h-4 w-4 mb-1" />
            <span className="text-xs">Image</span>
          </TabsTrigger>
          <TabsTrigger value="video" className="flex flex-col py-2 px-1 h-auto">
            <Video className="h-4 w-4 mb-1" />
            <span className="text-xs">Video</span>
          </TabsTrigger>
          <TabsTrigger value="adapt" className="flex flex-col py-2 px-1 h-auto">
            <Share2 className="h-4 w-4 mb-1" />
            <span className="text-xs">Adapt</span>
          </TabsTrigger>
          <TabsTrigger value="localize" className="flex flex-col py-2 px-1 h-auto">
            <Globe className="h-4 w-4 mb-1" />
            <span className="text-xs">Localize</span>
          </TabsTrigger>
          <TabsTrigger value="history" className="flex flex-col py-2 px-1 h-auto">
            <History className="h-4 w-4 mb-1" />
            <span className="text-xs">History</span>
          </TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-auto p-4">
          <TabsContent value="text" className="h-full mt-0">
            <TextEnhancementTool projectId={projectId} onEnhanced={onApplyText} initialContent={selectedContent} />
          </TabsContent>

          <TabsContent value="image" className="h-full mt-0">
            <ImageEnhancementTool
              projectId={projectId}
              onEnhanced={onApplyImageSuggestions}
              initialImageUrl={selectedImage}
            />
          </TabsContent>

          <TabsContent value="video" className="h-full mt-0">
            <VideoSuggestionTool projectId={projectId} onGenerated={onApplyVideoSuggestions} />
          </TabsContent>

          <TabsContent value="adapt" className="h-full mt-0">
            <ContentAdaptationTool
              projectId={projectId}
              onAdapted={onApplyAdaptedContent}
              initialContent={selectedContent}
            />
          </TabsContent>

          <TabsContent value="localize" className="h-full mt-0">
            <ContentLocalizationTool
              projectId={projectId}
              onLocalized={onApplyLocalizedContent}
              initialContent={selectedContent}
            />
          </TabsContent>

          <TabsContent value="history" className="h-full mt-0">
            <ContentHistory projectId={projectId} onSelect={handleHistorySelect} />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

