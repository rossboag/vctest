"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AITextGenerator } from "@/components/ai/ai-text-generator"
import { AIImageGenerator } from "@/components/ai/ai-image-generator"
import { AIColorPaletteGenerator } from "@/components/ai/ai-color-palette-generator"
import { AILayoutGenerator } from "@/components/ai/ai-layout-generator"
import { Wand2 } from "lucide-react"

interface AIPanelProps {
  projectId: string
  onApplyLayout?: (layout: any) => void
  onApplyColorPalette?: (colors: string[]) => void
  onInsertText?: (text: string) => void
  onInsertImage?: (imageUrl: string) => void
}

export function AIPanel({ projectId, onApplyLayout, onApplyColorPalette, onInsertText, onInsertImage }: AIPanelProps) {
  const [activeTab, setActiveTab] = useState("text")

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold flex items-center">
          <Wand2 className="h-5 w-5 mr-2" />
          AI Assistant
        </h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-4">
          <TabsTrigger value="text">Text</TabsTrigger>
          <TabsTrigger value="image">Image</TabsTrigger>
          <TabsTrigger value="colors">Colors</TabsTrigger>
          <TabsTrigger value="layout">Layout</TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-auto p-4">
          <TabsContent value="text" className="h-full">
            <AITextGenerator
              projectId={projectId}
              onGenerated={onInsertText}
              title="Generate Text"
              placeholder="Describe the text you want to generate (e.g., a headline, paragraph, or call to action)..."
            />
          </TabsContent>

          <TabsContent value="image" className="h-full">
            <AIImageGenerator
              projectId={projectId}
              onGenerated={onInsertImage}
              title="Generate Image"
              placeholder="Describe the image you want to generate..."
            />
          </TabsContent>

          <TabsContent value="colors" className="h-full">
            <AIColorPaletteGenerator
              projectId={projectId}
              onGenerated={onApplyColorPalette}
              title="Generate Color Palette"
            />
          </TabsContent>

          <TabsContent value="layout" className="h-full">
            <AILayoutGenerator projectId={projectId} onGenerated={onApplyLayout} title="Generate Layout" />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

