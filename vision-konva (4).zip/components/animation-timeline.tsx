"use client"

import type React from "react"
import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"

export const AnimationTimeline: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const { elements, updateElement } = useEditorStore()

  const duration = 5000 // 5 seconds total duration

  const handleTimeChange = (newTime: number) => {
    setCurrentTime(newTime)
    // Update element positions based on the current time
    elements.forEach((element) => {
      if (element.animation) {
        const progress = newTime / duration
        const newProps = calculateAnimationProps(element, progress)
        updateElement(element.id, newProps)
      }
    })
  }

  const calculateAnimationProps = (element: any, progress: number) => {
    // This is a simplified example. You'd need to implement more complex logic
    // based on your animation system
    const { startX, startY, endX, endY } = element.animation
    return {
      x: startX + (endX - startX) * progress,
      y: startY + (endY - startY) * progress,
    }
  }

  const togglePlayback = () => {
    setIsPlaying(!isPlaying)
    if (!isPlaying) {
      const startTime = Date.now() - currentTime
      const animationFrame = () => {
        const now = Date.now()
        const newTime = now - startTime
        if (newTime < duration) {
          handleTimeChange(newTime)
          requestAnimationFrame(animationFrame)
        } else {
          setIsPlaying(false)
        }
      }
      requestAnimationFrame(animationFrame)
    }
  }

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-semibold">Animation Timeline</h2>
      <Slider min={0} max={duration} step={1} value={currentTime} onValueChange={handleTimeChange} />
      <div className="flex justify-between">
        <span>{formatTime(currentTime)}</span>
        <span>{formatTime(duration)}</span>
      </div>
      <Button onClick={togglePlayback}>{isPlaying ? "Pause" : "Play"}</Button>
    </div>
  )
}

const formatTime = (ms: number) => {
  const seconds = Math.floor(ms / 1000)
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = seconds % 60
  return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
}

