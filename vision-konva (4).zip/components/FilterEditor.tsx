"use client"

import type React from "react"
import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"

export const FilterEditor: React.FC = () => {
  const { selectedIds, applyFilter, removeFilter } = useEditorStore()
  const [filterType, setFilterType] = useState("blur")
  const [filterValue, setFilterValue] = useState(5)

  const handleApplyFilter = () => {
    if (selectedIds.length > 0) {
      applyFilter(selectedIds[0], filterType, { value: filterValue })
    }
  }

  const handleRemoveFilter = () => {
    if (selectedIds.length > 0) {
      removeFilter(selectedIds[0], filterType)
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Filter Editor</h2>
      <Select value={filterType} onValueChange={(value) => setFilterType(value)}>
        <option value="blur">Blur</option>
        <option value="brightness">Brightness</option>
        <option value="contrast">Contrast</option>
      </Select>
      <Input
        type="number"
        value={filterValue}
        onChange={(e) => setFilterValue(Number(e.target.value))}
        className="mt-2"
      />
      <Button onClick={handleApplyFilter} className="mt-2 mr-2">
        Apply Filter
      </Button>
      <Button onClick={handleRemoveFilter} className="mt-2">
        Remove Filter
      </Button>
    </div>
  )
}

