interface AIGeneratedVideoProps {
  src: string
  width: number
  height: number
}

export function AIGeneratedVideo({ src, width, height }: AIGeneratedVideoProps) {
  return (
    <div className="relative">
      <video src={src} width={width} height={height} controls className="rounded-md shadow-md" />
      <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
        AI Generated
      </div>
    </div>
  )
}

