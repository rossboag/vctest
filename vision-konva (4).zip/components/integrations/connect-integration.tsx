"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { signIn } from "next-auth/react"
import { ChromeIcon as Google, DropletIcon as Dropbox, Cloud } from "lucide-react"

interface ConnectIntegrationProps {
  provider: "google" | "dropbox" | "azure-ad"
  title: string
  description: string
  connected: boolean
  onDisconnect: () => Promise<void>
}

export function ConnectIntegration({ provider, title, description, connected, onDisconnect }: ConnectIntegrationProps) {
  const [loading, setLoading] = useState(false)

  const handleConnect = async () => {
    setLoading(true)
    await signIn(provider, { callbackUrl: "/integrations" })
  }

  const handleDisconnect = async () => {
    setLoading(true)
    try {
      await onDisconnect()
    } catch (error) {
      console.error(`Error disconnecting ${provider}:`, error)
    } finally {
      setLoading(false)
    }
  }

  const getIcon = () => {
    switch (provider) {
      case "google":
        return <Google className="h-6 w-6" />
      case "dropbox":
        return <Dropbox className="h-6 w-6" />
      case "azure-ad":
        return <Cloud className="h-6 w-6" />
      default:
        return null
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className="p-2 bg-muted rounded-full">{getIcon()}</div>
          <div>
            <CardTitle>{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm">
          {connected
            ? "Your account is connected. You can now import and export files."
            : "Connect your account to import and export files."}
        </p>
      </CardContent>
      <CardFooter>
        {connected ? (
          <Button variant="destructive" onClick={handleDisconnect} disabled={loading}>
            {loading ? "Disconnecting..." : "Disconnect"}
          </Button>
        ) : (
          <Button onClick={handleConnect} disabled={loading}>
            {loading ? "Connecting..." : "Connect"}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

