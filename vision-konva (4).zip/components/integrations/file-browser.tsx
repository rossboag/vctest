"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { Folder, File, ArrowLeft, Plus, Download, Trash2, Loader2 } from "lucide-react"
import type { IntegrationProvider } from "@/lib/integration-service"

interface FileBrowserProps {
  provider: IntegrationProvider
  onFileSelect?: (file: any) => void
  selectable?: boolean
  showActions?: boolean
}

export function FileBrowser({ provider, onFileSelect, selectable = false, showActions = true }: FileBrowserProps) {
  const [files, setFiles] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [currentFolder, setCurrentFolder] = useState<string | undefined>(undefined)
  const [currentPath, setCurrentPath] = useState<string | undefined>(undefined)
  const [folderHistory, setFolderHistory] = useState<{ id: string; name: string; path?: string }[]>([])
  const [newFolderName, setNewFolderName] = useState("")
  const [isCreatingFolder, setIsCreatingFolder] = useState(false)
  const [showNewFolderDialog, setShowNewFolderDialog] = useState(false)

  // Fetch files
  const fetchFiles = useCallback(
    async (folderId?: string, path?: string) => {
      try {
        setLoading(true)
        const queryParams = new URLSearchParams()
        if (folderId) queryParams.append("folderId", folderId)
        if (path) queryParams.append("path", path)

        const response = await fetch(`/api/integrations/${provider}/files?${queryParams.toString()}`)

        if (!response.ok) {
          throw new Error("Failed to fetch files")
        }

        const data = await response.json()
        setFiles(data)
      } catch (error) {
        console.error("Error fetching files:", error)
        toast.error("Failed to fetch files")
      } finally {
        setLoading(false)
      }
    },
    [provider],
  )

  // Initial fetch
  useEffect(() => {
    fetchFiles(currentFolder, currentPath)
  }, [fetchFiles, currentFolder, currentPath])

  // Handle folder click
  const handleFolderClick = (folder: any) => {
    setFolderHistory([
      ...folderHistory,
      {
        id: currentFolder || "root",
        name: folder.name,
        path: currentPath,
      },
    ])
    setCurrentFolder(folder.id)
    setCurrentPath(folder.path)
    fetchFiles(folder.id, folder.path)
  }

  // Handle file click
  const handleFileClick = (file: any) => {
    if (selectable && onFileSelect) {
      onFileSelect(file)
    }
  }

  // Handle back button click
  const handleBackClick = () => {
    if (folderHistory.length > 0) {
      const previousFolder = folderHistory[folderHistory.length - 1]
      setFolderHistory(folderHistory.slice(0, -1))
      setCurrentFolder(previousFolder.id === "root" ? undefined : previousFolder.id)
      setCurrentPath(previousFolder.path)
      fetchFiles(previousFolder.id === "root" ? undefined : previousFolder.id, previousFolder.path)
    }
  }

  // Create new folder
  const createFolder = async () => {
    if (!newFolderName.trim()) {
      toast.error("Folder name is required")
      return
    }

    try {
      setIsCreatingFolder(true)
      const response = await fetch(`/api/integrations/${provider}/folders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: newFolderName,
          parentId: currentFolder,
          path: currentPath,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create folder")
      }

      toast.success("Folder created successfully")
      setNewFolderName("")
      setShowNewFolderDialog(false)
      fetchFiles(currentFolder, currentPath)
    } catch (error) {
      console.error("Error creating folder:", error)
      toast.error("Failed to create folder")
    } finally {
      setIsCreatingFolder(false)
    }
  }

  // Download file
  const downloadFile = async (file: any) => {
    try {
      window.open(`/api/integrations/${provider}/files/${file.id}?download=true`, "_blank")
    } catch (error) {
      console.error("Error downloading file:", error)
      toast.error("Failed to download file")
    }
  }

  // Delete file or folder
  const deleteFile = async (file: any) => {
    if (!confirm(`Are you sure you want to delete ${file.name}?`)) {
      return
    }

    try {
      const response = await fetch(`/api/integrations/${provider}/files/${file.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete file")
      }

      toast.success("File deleted successfully")
      fetchFiles(currentFolder, currentPath)
    } catch (error) {
      console.error("Error deleting file:", error)
      toast.error("Failed to delete file")
    }
  }

  // Format file size
  const formatFileSize = (bytes?: number) => {
    if (bytes === undefined) return "Unknown"
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>{provider.charAt(0).toUpperCase() + provider.slice(1)} Files</CardTitle>
            <CardDescription>Browse and manage your files from {provider}</CardDescription>
          </div>
          {showActions && (
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={handleBackClick} disabled={folderHistory.length === 0}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowNewFolderDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                New Folder
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : files.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">No files found in this folder</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Size</TableHead>
                {showActions && <TableHead>Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {files.map((file) => (
                <TableRow
                  key={file.id}
                  className={selectable && file.type === "file" ? "cursor-pointer hover:bg-muted/50" : ""}
                  onClick={() => (file.type === "folder" ? handleFolderClick(file) : handleFileClick(file))}
                >
                  <TableCell className="flex items-center space-x-2">
                    {file.type === "folder" ? (
                      <Folder className="h-5 w-5 text-blue-500" />
                    ) : (
                      <File className="h-5 w-5 text-gray-500" />
                    )}
                    <span>{file.name}</span>
                  </TableCell>
                  <TableCell>{file.type === "folder" ? "Folder" : file.mimeType || "File"}</TableCell>
                  <TableCell>{file.type === "folder" ? "-" : formatFileSize(file.size)}</TableCell>
                  {showActions && (
                    <TableCell>
                      <div className="flex space-x-2">
                        {file.type === "file" && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation()
                              downloadFile(file)
                            }}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteFile(file)
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}

        <Dialog open={showNewFolderDialog} onOpenChange={setShowNewFolderDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Folder</DialogTitle>
              <DialogDescription>Enter a name for your new folder</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Folder Name</Label>
                <Input
                  id="name"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  placeholder="New Folder"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowNewFolderDialog(false)}>
                Cancel
              </Button>
              <Button onClick={createFolder} disabled={isCreatingFolder || !newFolderName.trim()}>
                {isCreatingFolder ? "Creating..." : "Create Folder"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

