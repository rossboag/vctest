"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "sonner"
import { Upload, Loader2 } from "lucide-react"
import type { IntegrationProvider } from "@/lib/integration-service"

interface FileUploaderProps {
  provider: IntegrationProvider
  folderId?: string
  path?: string
  onUploadComplete?: () => void
}

export function FileUploader({ provider, folderId, path, onUploadComplete }: FileUploaderProps) {
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setUploading(true)
    setProgress(0)

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        const formData = new FormData()
        formData.append("file", file)
        if (folderId) formData.append("folderId", folderId)
        if (path) formData.append("path", path)

        const response = await fetch(`/api/integrations/${provider}/files`, {
          method: "POST",
          body: formData,
        })

        if (!response.ok) {
          throw new Error(`Failed to upload ${file.name}`)
        }

        // Update progress
        setProgress(((i + 1) / files.length) * 100)
      }

      toast.success("Files uploaded successfully")
      if (onUploadComplete) onUploadComplete()
    } catch (error) {
      console.error("Error uploading files:", error)
      toast.error("Failed to upload files")
    } finally {
      setUploading(false)
      setProgress(0)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Files</CardTitle>
        <CardDescription>
          Upload files to your {provider.charAt(0).toUpperCase() + provider.slice(1)} account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center space-y-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleUpload}
            className="hidden"
            multiple
            disabled={uploading}
          />
          <Button
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="w-full h-24 border-dashed"
          >
            {uploading ? (
              <div className="flex flex-col items-center">
                <Loader2 className="h-6 w-6 animate-spin mb-2" />
                <span>Uploading... {Math.round(progress)}%</span>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <Upload className="h-6 w-6 mb-2" />
                <span>Click to select files</span>
              </div>
            )}
          </Button>
          {uploading && (
            <div className="w-full bg-muted rounded-full h-2.5">
              <div className="bg-primary h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

