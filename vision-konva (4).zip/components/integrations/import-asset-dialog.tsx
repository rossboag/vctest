"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileBrowser } from "@/components/integrations/file-browser"
import { toast } from "sonner"
import type { IntegrationProvider } from "@/lib/integration-service"

interface ImportAssetDialogProps {
  onImport: (asset: any) => Promise<void>
  trigger?: React.ReactNode
}

export function ImportAssetDialog({ onImport, trigger }: ImportAssetDialogProps) {
  const [open, setOpen] = useState(false)
  const [selectedFile, setSelectedFile] = useState<any | null>(null)
  const [importing, setImporting] = useState(false)
  const [activeTab, setActiveTab] = useState<IntegrationProvider>("google")

  const handleFileSelect = (file: any) => {
    if (file.type === "file") {
      setSelectedFile(file)
    }
  }

  const handleImport = async () => {
    if (!selectedFile) {
      toast.error("Please select a file to import")
      return
    }

    try {
      setImporting(true)
      await onImport(selectedFile)
      toast.success("Asset imported successfully")
      setOpen(false)
    } catch (error) {
      console.error("Error importing asset:", error)
      toast.error("Failed to import asset")
    } finally {
      setImporting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger || <Button variant="outline">Import from Cloud</Button>}</DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Import Asset from Cloud Storage</DialogTitle>
          <DialogDescription>Select a file from your connected cloud storage services</DialogDescription>
        </DialogHeader>

        <Tabs
          defaultValue="google"
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as IntegrationProvider)}
        >
          <TabsList className="mb-4">
            <TabsTrigger value="google">Google Drive</TabsTrigger>
            <TabsTrigger value="dropbox">Dropbox</TabsTrigger>
            <TabsTrigger value="onedrive">OneDrive</TabsTrigger>
          </TabsList>

          <TabsContent value="google">
            <FileBrowser provider="google" onFileSelect={handleFileSelect} selectable={true} showActions={false} />
          </TabsContent>

          <TabsContent value="dropbox">
            <FileBrowser provider="dropbox" onFileSelect={handleFileSelect} selectable={true} showActions={false} />
          </TabsContent>

          <TabsContent value="onedrive">
            <FileBrowser provider="onedrive" onFileSelect={handleFileSelect} selectable={true} showActions={false} />
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <div className="flex justify-between items-center w-full">
            <div>
              {selectedFile && (
                <p className="text-sm">
                  Selected: <strong>{selectedFile.name}</strong>
                </p>
              )}
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleImport} disabled={importing || !selectedFile}>
                {importing ? "Importing..." : "Import"}
              </Button>
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

