"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileBrowser } from "@/components/integrations/file-browser"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import type { IntegrationProvider } from "@/lib/integration-service"

interface ExportProjectDialogProps {
  projectId: string
  projectName: string
  trigger?: React.ReactNode
}

export function ExportProjectDialog({ projectId, projectName, trigger }: ExportProjectDialogProps) {
  const [open, setOpen] = useState(false)
  const [selectedFolder, setSelectedFolder] = useState<any | null>(null)
  const [filename, setFilename] = useState(`${projectName}.mp4`)
  const [exporting, setExporting] = useState(false)
  const [activeTab, setActiveTab] = useState<IntegrationProvider>("google")

  const handleFolderSelect = (folder: any) => {
    if (folder.type === "folder") {
      setSelectedFolder(folder)
    }
  }

  const handleExport = async () => {
    if (!selectedFolder) {
      toast.error("Please select a folder to export to")
      return
    }

    if (!filename) {
      toast.error("Please enter a filename")
      return
    }

    try {
      setExporting(true)

      // First, generate the export
      const exportResponse = await fetch(`/api/projects/${projectId}/export`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          format: "mp4",
        }),
      })

      if (!exportResponse.ok) {
        throw new Error("Failed to generate export")
      }

      const exportData = await exportResponse.json()
      const exportUrl = exportData.url

      // Download the export file
      const fileResponse = await fetch(exportUrl)
      if (!fileResponse.ok) {
        throw new Error("Failed to download export file")
      }

      const fileBlob = await fileResponse.blob()
      const file = new File([fileBlob], filename, {
        type: "video/mp4",
      })

      // Upload to the selected cloud storage
      const formData = new FormData()
      formData.append("file", file)

      if (activeTab === "dropbox") {
        formData.append("path", selectedFolder.path || "")
      } else {
        formData.append("folderId", selectedFolder.id)
      }

      formData.append("filename", filename)

      const uploadResponse = await fetch(`/api/integrations/${activeTab}/files`, {
        method: "POST",
        body: formData,
      })

      if (!uploadResponse.ok) {
        throw new Error("Failed to upload to cloud storage")
      }

      toast.success(`Project exported to ${activeTab} successfully`)
      setOpen(false)
    } catch (error) {
      console.error("Error exporting project:", error)
      toast.error("Failed to export project")
    } finally {
      setExporting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger || <Button variant="outline">Export to Cloud</Button>}</DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Export Project to Cloud Storage</DialogTitle>
          <DialogDescription>Select a destination folder in your connected cloud storage services</DialogDescription>
        </DialogHeader>

        <Tabs
          defaultValue="google"
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as IntegrationProvider)}
        >
          <TabsList className="mb-4">
            <TabsTrigger value="google">Google Drive</TabsTrigger>
            <TabsTrigger value="dropbox">Dropbox</TabsTrigger>
            <TabsTrigger value="onedrive">OneDrive</TabsTrigger>
          </TabsList>

          <TabsContent value="google">
            <FileBrowser provider="google" onFileSelect={handleFolderSelect} selectable={true} showActions={false} />
          </TabsContent>

          <TabsContent value="dropbox">
            <FileBrowser provider="dropbox" onFileSelect={handleFolderSelect} selectable={true} showActions={false} />
          </TabsContent>

          <TabsContent value="onedrive">
            <FileBrowser provider="onedrive" onFileSelect={handleFolderSelect} selectable={true} showActions={false} />
          </TabsContent>
        </Tabs>

        <div className="space-y-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="filename">Filename</Label>
            <Input
              id="filename"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="project.mp4"
            />
          </div>
        </div>

        <DialogFooter>
          <div className="flex justify-between items-center w-full">
            <div>
              {selectedFolder && (
                <p className="text-sm">
                  Selected folder: <strong>{selectedFolder.name}</strong>
                </p>
              )}
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleExport} disabled={exporting || !selectedFolder || !filename}>
                {exporting ? "Exporting..." : "Export"}
              </Button>
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

