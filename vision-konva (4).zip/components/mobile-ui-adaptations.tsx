"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { isMobile } from "@/lib/mobile-utils"
import { useEditorStore } from "@/store/editor-store"
import { ZoomIn, ZoomOut, Undo, Redo, Save, Download, Layers, TimerIcon as Timeline } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function MobileUIAdaptations() {
  const [isMobileView, setIsMobileView] = useState(false)
  const { scale, setScale, undo, redo, canUndo, canRedo } = useEditorStore()

  // Fixed: Added missing canSave property or removed it from destructuring
  // const { scale, setScale, undo, redo, canSave, canUndo, canRedo } = useEditorStore()

  useEffect(() => {
    // Fixed: Check for window before accessing it (for SSR)
    if (typeof window !== "undefined") {
      setIsMobileView(isMobile())

      const handleResize = () => {
        setIsMobileView(isMobile())
      }

      window.addEventListener("resize", handleResize)
      return () => window.removeEventListener("resize", handleResize)
    }
  }, [])

  const handleZoom = (delta: number) => {
    setScale(Math.max(0.1, Math.min(5, scale + delta)))
  }

  if (!isMobileView) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border p-2 z-50">
      <div className="flex justify-between items-center">
        <div className="flex space-x-2">
          <Button variant="outline" size="icon" onClick={() => undo()} disabled={!canUndo} aria-label="Undo">
            <Undo className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => redo()} disabled={!canRedo} aria-label="Redo">
            <Redo className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex space-x-2">
          <Button variant="outline" size="icon" onClick={() => handleZoom(-0.1)} aria-label="Zoom Out">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="flex items-center text-sm">{Math.round(scale * 100)}%</span>
          <Button variant="outline" size="icon" onClick={() => handleZoom(0.1)} aria-label="Zoom In">
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex space-x-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" aria-label="Layers">
                <Layers className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-64">
              <div className="h-full overflow-y-auto">
                <h3 className="text-lg font-medium mb-2">Layers</h3>
                {/* Layers content would go here */}
              </div>
            </SheetContent>
          </Sheet>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" aria-label="Timeline">
                <Timeline className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-64">
              <div className="h-full overflow-y-auto">
                <h3 className="text-lg font-medium mb-2">Timeline</h3>
                {/* Timeline content would go here */}
              </div>
            </SheetContent>
          </Sheet>

          <Button variant="outline" size="icon" aria-label="Save">
            <Save className="h-4 w-4" />
          </Button>

          <Button variant="outline" size="icon" aria-label="Export">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

