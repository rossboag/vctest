"use client"

import { useEffect, useState, useRef } from "react"
import { isTouch } from "@/lib/mobile-utils"
import { useEditorStore } from "@/store/editor-store"

interface TouchPoint {
  id: number
  x: number
  y: number
}

export function TouchInteractions() {
  const [isTouchDevice, setIsTouchDevice] = useState(false)
  const { scale, setScale, position, setPosition } = useEditorStore()
  const touchPointsRef = useRef<TouchPoint[]>([])
  const previousDistanceRef = useRef<number | null>(null)
  const canvasRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    setIsTouchDevice(isTouch())

    const handleResize = () => {
      setIsTouchDevice(isTouch())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    if (!isTouchDevice) return

    // Fixed: Use a more reliable way to get the canvas element
    const canvas = document.getElementById("konva-canvas") || document.querySelector(".konva-container")
    if (canvas) {
      canvasRef.current = canvas as HTMLDivElement

      const handleTouchStart = (e: TouchEvent) => {
        // Store touch points
        touchPointsRef.current = Array.from(e.touches).map((touch) => ({
          id: touch.identifier,
          x: touch.clientX,
          y: touch.clientY,
        }))

        // If two fingers, prepare for pinch-zoom
        if (touchPointsRef.current.length === 2) {
          const distance = getDistance(
            touchPointsRef.current[0].x,
            touchPointsRef.current[0].y,
            touchPointsRef.current[1].x,
            touchPointsRef.current[1].y,
          )
          previousDistanceRef.current = distance
        }
      }

      const handleTouchMove = (e: TouchEvent) => {
        // Only prevent default for our specific gestures to avoid breaking other interactions
        if (e.touches.length === 2 || (e.touches.length === 1 && touchPointsRef.current.length === 1)) {
          e.preventDefault()
        }

        // Handle pinch-zoom with two fingers
        if (e.touches.length === 2 && touchPointsRef.current.length === 2) {
          const touch1 = e.touches[0]
          const touch2 = e.touches[1]

          const distance = getDistance(touch1.clientX, touch1.clientY, touch2.clientX, touch2.clientY)

          if (previousDistanceRef.current !== null) {
            const delta = distance - previousDistanceRef.current
            // Fixed: Smoother zoom with better constraints
            const scaleFactor = 0.005 // Reduced for smoother zooming
            const newScale = Math.max(0.1, Math.min(5, scale + delta * scaleFactor))
            setScale(newScale)
          }

          previousDistanceRef.current = distance
        }

        // Handle pan with one finger
        else if (e.touches.length === 1 && touchPointsRef.current.length === 1) {
          const touch = e.touches[0]
          const prevTouch = touchPointsRef.current[0]

          const dx = touch.clientX - prevTouch.x
          const dy = touch.clientY - prevTouch.y

          setPosition({
            x: position.x + dx / scale,
            y: position.y + dy / scale,
          })

          // Update the stored touch point
          touchPointsRef.current = [
            {
              id: touch.identifier,
              x: touch.clientX,
              y: touch.clientY,
            },
          ]
        }
      }

      const handleTouchEnd = (e: TouchEvent) => {
        // Reset touch points that are no longer active
        touchPointsRef.current = touchPointsRef.current.filter((point) =>
          Array.from(e.touches).some((touch) => touch.identifier === point.id),
        )

        // Reset previous distance if we don't have two fingers anymore
        if (touchPointsRef.current.length !== 2) {
          previousDistanceRef.current = null
        }
      }

      // Fixed: Use passive: false only for touchmove to prevent browser warnings
      canvas.addEventListener("touchstart", handleTouchStart)
      canvas.addEventListener("touchmove", handleTouchMove, { passive: false })
      canvas.addEventListener("touchend", handleTouchEnd)
      canvas.addEventListener("touchcancel", handleTouchEnd)

      return () => {
        canvas.removeEventListener("touchstart", handleTouchStart)
        canvas.removeEventListener("touchmove", handleTouchMove)
        canvas.removeEventListener("touchend", handleTouchEnd)
        canvas.removeEventListener("touchcancel", handleTouchEnd)
      }
    }
  }, [isTouchDevice, scale, position, setScale, setPosition])

  // Helper function to calculate distance between two points
  const getDistance = (x1: number, y1: number, x2: number, y2: number): number => {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2))
  }

  // This component doesn't render anything visible
  return null
}

