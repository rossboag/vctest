"use client"

import type React from "react"

interface ColorSwatchProps {
  colors: string[]
  onClick: () => void
  isSelected: boolean
}

export const ColorSwatch: React.FC<ColorSwatchProps> = ({ colors, onClick, isSelected }) => {
  return (
    <button
      onClick={onClick}
      className={`relative w-12 h-12 rounded-md overflow-hidden shadow-sm transition-transform hover:scale-105 ${
        isSelected ? "ring-2 ring-primary" : ""
      }`}
    >
      <div className="absolute inset-0 grid grid-cols-2">
        {colors.slice(0, 4).map((color, index) => (
          <div key={index} style={{ backgroundColor: color }} className="w-full h-full"></div>
        ))}
      </div>
    </button>
  )
}

