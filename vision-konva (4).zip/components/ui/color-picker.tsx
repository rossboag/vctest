"use client"
import { useCallback, useEffect, useState } from "react"
import { HexColorPicker } from "react-colorful"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"

interface ColorPickerProps {
  color: string
  onChange: (color: string) => void
}

export function ColorPicker({ color, onChange }: ColorPickerProps) {
  const [internalColor, setInternalColor] = useState(color)

  useEffect(() => {
    setInternalColor(color)
  }, [color])

  const handleChange = useCallback(
    (newColor: string) => {
      setInternalColor(newColor)
      onChange(newColor)
    },
    [onChange],
  )

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-[65px] h-[35px] p-0" style={{ backgroundColor: internalColor }} />
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <HexColorPicker color={internalColor} onChange={handleChange} />
      </PopoverContent>
    </Popover>
  )
}

