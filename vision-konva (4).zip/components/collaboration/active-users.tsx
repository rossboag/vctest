import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Badge } from "@/components/ui/badge"

type ActiveUser = {
  userId: string
  name: string
  cursor?: { x: number; y: number }
}

type ActiveUsersProps = {
  users: ActiveUser[]
}

export function ActiveUsers({ users }: ActiveUsersProps) {
  if (!users.length) return null

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className="flex flex-col gap-2">
        <Badge variant="outline" className="mb-2">
          {users.length} active {users.length === 1 ? "user" : "users"}
        </Badge>
        <div className="flex -space-x-2">
          {users.map((user) => (
            <TooltipProvider key={user.userId}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Avatar className="border-2 border-background">
                    <AvatarFallback>
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                    <AvatarImage src={`https://avatar.vercel.sh/${user.userId}`} />
                  </Avatar>
                </TooltipTrigger>
                <TooltipContent side="bottom">
                  <p>{user.name}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </div>
    </div>
  )
}

