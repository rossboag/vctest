"use client"
import { motion } from "framer-motion"

type RemoteCursorProps = {
  userId: string
  name: string
  position: { x: number; y: number }
  color?: string
}

export function RemoteCursor({ userId, name, position, color = "#3b82f6" }: RemoteCursorProps) {
  return (
    <motion.div
      className="absolute pointer-events-none z-50"
      initial={{ opacity: 0 }}
      animate={{
        opacity: 1,
        x: position.x,
        y: position.y,
      }}
      transition={{ duration: 0.1 }}
    >
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ color }}>
        <path
          d="M5.65376 12.3673H5.46026L5.31717 12.4976L0.94001 16.4976L0.586548 16.8172V17.25V23.25V23.6431L0.904578 23.8111L4.40458 25.5611L4.64784 25.6815L4.90458 25.6016L12.0225 23.4016L12.2572 23.3281L12.4445 23.1716L16.4445 19.9216L16.75 19.6716V19.25V17.25V16.8562L16.4281 16.6031L15.1173 15.5031L14.9554 15.3654L14.7536 15.3031L5.65376 12.3673Z"
          fill={color}
          stroke="white"
        />
      </svg>
      <div
        className="absolute left-4 top-0 rounded px-2 py-1 text-xs font-medium text-white"
        style={{ backgroundColor: color }}
      >
        {name}
      </div>
    </motion.div>
  )
}

