"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { useEditorStore } from "@/store/editor-store"
import { aiService } from "@/lib/ai-service"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"

interface AIToolMenuProps {
  tool: "generate" | "enhance" | "analyze" | "assistant" | "chat" | "colorize" | "layout" | "text" | "image" | "video"
  onClose: () => void
}

export function AIToolMenu({ tool, onClose }: AIToolMenuProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [prompt, setPrompt] = useState("")
  const [generationType, setGenerationType] = useState<"text" | "image" | "layout" | "animation">("text")
  const [textLength, setTextLength] = useState(100)
  const [imageSize, setImageSize] = useState<"256x256" | "512x512" | "1024x1024">("512x512")
  const [animationDuration, setAnimationDuration] = useState(5)
  const [style, setStyle] = useState("")
  const { toast } = useToast()
  const { elements, addElement, updateElements } = useEditorStore()

  const handleGenerate = async () => {
    setIsLoading(true)
    try {
      const result = await aiService.generateContent(prompt, {
        type: generationType,
        style,
        length: textLength,
        imageSize,
        animationDuration,
        elements,
      })

      switch (generationType) {
        case "text":
          addElement({
            type: "text",
            text: result as string,
            x: 100,
            y: 100,
            width: 300,
            height: 100,
            fill: "black",
            fontSize: 16,
            fontFamily: "Arial",
            layerId: "default",
          })
          break
        case "image":
          addElement({
            type: "image",
            src: result as string,
            x: 100,
            y: 100,
            width: Number.parseInt(imageSize.split("x")[0]),
            height: Number.parseInt(imageSize.split("x")[1]),
            layerId: "default",
          })
          break
        case "layout":
          if (Array.isArray(result)) {
            result.forEach((element) => addElement(element))
          }
          break
        case "animation":
          if (Array.isArray(result)) {
            updateElements(
              elements.map((el) => el.id),
              result,
            )
          }
          break
      }

      toast({
        title: "AI Generation Completed",
        description: `The ${generationType} has been successfully generated and added to your project.`,
      })
    } catch (error) {
      console.error(`Error in AI generation:`, error)
      toast({
        title: "Error",
        description: `An error occurred during the AI generation. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-80 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Generate</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <Tabs defaultValue="text" onValueChange={(value) => setGenerationType(value as any)}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="text">Text</TabsTrigger>
            <TabsTrigger value="image">Image</TabsTrigger>
            <TabsTrigger value="layout">Layout</TabsTrigger>
            <TabsTrigger value="animation">Animation</TabsTrigger>
          </TabsList>
          <TabsContent value="text" className="space-y-4">
            <Slider
              id="textLength"
              min={10}
              max={500}
              step={10}
              value={[textLength]}
              onValueChange={([value]) => setTextLength(value)}
            />
            <Label htmlFor="textLength">Text Length: {textLength} words</Label>
          </TabsContent>
          <TabsContent value="image" className="space-y-4">
            <Select onValueChange={(value: "256x256" | "512x512" | "1024x1024") => setImageSize(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select image size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="256x256">256x256</SelectItem>
                <SelectItem value="512x512">512x512</SelectItem>
                <SelectItem value="1024x1024">1024x1024</SelectItem>
              </SelectContent>
            </Select>
          </TabsContent>
          <TabsContent value="animation" className="space-y-4">
            <Slider
              id="animationDuration"
              min={1}
              max={10}
              step={1}
              value={[animationDuration]}
              onValueChange={([value]) => setAnimationDuration(value)}
            />
            <Label htmlFor="animationDuration">Animation Duration: {animationDuration} seconds</Label>
          </TabsContent>
        </Tabs>
        <Input
          placeholder="Enter style (e.g., minimalist, retro, futuristic)"
          value={style}
          onChange={(e) => setStyle(e.target.value)}
        />
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter your generation prompt..."
          className="min-h-[100px]"
        />
        <Button onClick={handleGenerate} disabled={isLoading}>
          {isLoading ? "Generating..." : `Generate ${generationType}`}
        </Button>
      </div>
    </div>
  )
}

