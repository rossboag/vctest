import type React from "react"
import { useEditorStore } from "@/store/editor-store"
import { Select } from "@/components/ui/select"

const blendModes: GlobalCompositeOperation[] = [
  "source-over",
  "source-in",
  "source-out",
  "source-atop",
  "destination-over",
  "destination-in",
  "destination-out",
  "destination-atop",
  "lighter",
  "copy",
  "xor",
  "multiply",
  "screen",
  "overlay",
  "darken",
  "lighten",
  "color-dodge",
  "color-burn",
  "hard-light",
  "soft-light",
  "difference",
  "exclusion",
  "hue",
  "saturation",
  "color",
  "luminosity",
]

export const BlendModeSelector: React.FC = () => {
  const { selectedIds, setBlendMode } = useEditorStore()

  const handleBlendModeChange = (mode: GlobalCompositeOperation) => {
    if (selectedIds.length > 0) {
      setBlendMode(selectedIds[0], mode)
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Blend Mode</h2>
      <Select
        onValueChange={(value) => handleBlendModeChange(value as GlobalCompositeOperation)}
        disabled={selectedIds.length === 0}
      >
        {blendModes.map((mode) => (
          <option key={mode} value={mode}>
            {mode}
          </option>
        ))}
      </Select>
    </div>
  )
}

