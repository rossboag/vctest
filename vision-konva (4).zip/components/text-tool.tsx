"use client"

import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select } from "@/components/ui/select"
import { ColorPicker } from "@/components/ui/color-picker"

const fontOptions = [
  "Arial",
  "Helvetica",
  "Times New Roman",
  "Courier",
  "Verdana",
  "Georgia",
  "Palatino",
  "Garamond",
  "Bookman",
  "Comic Sans MS",
  "Trebuchet MS",
  "Arial Black",
  "Impact",
]

export function TextTool() {
  const { addElement, updateElement, selectedIds } = useEditorStore()
  const [text, setText] = useState("")
  const [fontSize, setFontSize] = useState(16)
  const [fontFamily, setFontFamily] = useState("Arial")
  const [color, setColor] = useState("#000000")

  const handleAddText = () => {
    if (text) {
      addElement({
        type: "text",
        text,
        fontSize,
        fontFamily,
        fill: color,
        x: 100,
        y: 100,
      })
      setText("")
    }
  }

  const handleUpdateText = () => {
    if (selectedIds.length === 1) {
      updateElement(selectedIds[0], {
        text,
        fontSize,
        fontFamily,
        fill: color,
      })
    }
  }

  return (
    <div className="p-4 space-y-4">
      <Input type="text" placeholder="Enter text" value={text} onChange={(e) => setText(e.target.value)} />
      <div className="flex space-x-2">
        <Input
          type="number"
          min={1}
          value={fontSize}
          onChange={(e) => setFontSize(Number(e.target.value))}
          className="w-20"
        />
        <Select value={fontFamily} onValueChange={setFontFamily}>
          {fontOptions.map((font) => (
            <option key={font} value={font}>
              {font}
            </option>
          ))}
        </Select>
        <ColorPicker color={color} onChange={setColor} />
      </div>
      <div className="flex space-x-2">
        <Button onClick={handleAddText}>Add Text</Button>
        <Button onClick={handleUpdateText} disabled={selectedIds.length !== 1}>
          Update Text
        </Button>
      </div>
    </div>
  )
}

