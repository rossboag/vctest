import type React from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { saveAs } from "file-saver"

export const ProjectManager: React.FC = () => {
  const { elements, layers, canvasSize, exportProject, importProject } = useEditorStore()

  const handleExport = () => {
    const projectData = exportProject()
    const blob = new Blob([JSON.stringify(projectData)], { type: "application/json;charset=utf-8" })
    saveAs(blob, "vision-konva-project.json")
  }

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result
        if (typeof content === "string") {
          try {
            const projectData = JSON.parse(content)
            importProject(projectData)
          } catch (error) {
            console.error("Error importing project:", error)
            // You might want to show an error message to the user here
          }
        }
      }
      reader.readAsText(file)
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Project Management</h2>
      <div className="space-y-2">
        <Button onClick={handleExport}>Export Project</Button>
        <div>
          <input type="file" accept=".json" onChange={handleImport} className="hidden" id="import-project" />
          <label htmlFor="import-project">
            <Button as="span">Import Project</Button>
          </label>
        </div>
      </div>
    </div>
  )
}

