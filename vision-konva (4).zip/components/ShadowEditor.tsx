"use client"

import type React from "react"
import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export const ShadowEditor: React.FC = () => {
  const { selectedIds, applyShadow, removeShadow } = useEditorStore()
  const [shadowColor, setShadowColor] = useState("#000000")
  const [shadowBlur, setShadowBlur] = useState(5)
  const [shadowOffsetX, setShadowOffsetX] = useState(5)
  const [shadowOffsetY, setShadowOffsetY] = useState(5)

  const handleApplyShadow = () => {
    if (selectedIds.length > 0) {
      applyShadow(selectedIds[0], {
        color: shadowColor,
        blur: shadowBlur,
        offsetX: shadowOffsetX,
        offsetY: shadowOffsetY,
      })
    }
  }

  const handleRemoveShadow = () => {
    if (selectedIds.length > 0) {
      removeShadow(selectedIds[0])
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Shadow Editor</h2>
      <Input type="color" value={shadowColor} onChange={(e) => setShadowColor(e.target.value)} className="mb-2" />
      <Input
        type="number"
        value={shadowBlur}
        onChange={(e) => setShadowBlur(Number(e.target.value))}
        placeholder="Blur"
        className="mb-2"
      />
      <Input
        type="number"
        value={shadowOffsetX}
        onChange={(e) => setShadowOffsetX(Number(e.target.value))}
        placeholder="Offset X"
        className="mb-2"
      />
      <Input
        type="number"
        value={shadowOffsetY}
        onChange={(e) => setShadowOffsetY(Number(e.target.value))}
        placeholder="Offset Y"
        className="mb-2"
      />
      <Button onClick={handleApplyShadow} className="mr-2">
        Apply Shadow
      </Button>
      <Button onClick={handleRemoveShadow} variant="secondary">
        Remove Shadow
      </Button>
    </div>
  )
}

