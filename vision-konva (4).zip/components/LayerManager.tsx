"use client"

import type React from "react"
import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"
import { Eye, EyeOff, Lock, Unlock, Trash2, Plus } from "lucide-react"

export const LayerManager: React.FC = () => {
  const { layers, updateLayer, reorderLayers, removeLayer, addLayer } = useEditorStore()
  const [newLayerName, setNewLayerName] = useState("")

  const onDragEnd = (result) => {
    if (!result.destination) return
    reorderLayers(result.source.index, result.destination.index)
  }

  const handleAddLayer = () => {
    if (newLayerName) {
      addLayer(newLayerName)
      setNewLayerName("")
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Layers</h2>
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="layers">
          {(provided) => (
            <ul {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
              {layers.map((layer, index) => (
                <Draggable key={layer.id} draggableId={layer.id} index={index}>
                  {(provided) => (
                    <li
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className="flex items-center justify-between p-2 bg-card rounded-md"
                    >
                      <span>{layer.name}</span>
                      <div className="flex space-x-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => updateLayer(layer.id, { visible: !layer.visible })}
                        >
                          {layer.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => updateLayer(layer.id, { locked: !layer.locked })}
                        >
                          {layer.locked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => removeLayer(layer.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </li>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </ul>
          )}
        </Droppable>
      </DragDropContext>
      <div className="mt-4 flex space-x-2">
        <Input
          type="text"
          placeholder="New layer name"
          value={newLayerName}
          onChange={(e) => setNewLayerName(e.target.value)}
        />
        <Button onClick={handleAddLayer}>
          <Plus className="h-4 w-4 mr-2" />
          Add Layer
        </Button>
      </div>
    </div>
  )
}

