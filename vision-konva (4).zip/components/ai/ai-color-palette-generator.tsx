"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAIColorPalette } from "@/hooks/use-ai-color-palette"
import { Loader2, Copy } from "lucide-react"
import { toast } from "sonner"

interface AIColorPaletteGeneratorProps {
  projectId?: string
  onGenerated?: (colors: string[]) => void
  title?: string
}

export function AIColorPaletteGenerator({
  projectId,
  onGenerated,
  title = "AI Color Palette Generator",
}: AIColorPaletteGeneratorProps) {
  const [prompt, setPrompt] = useState("")
  const [count, setCount] = useState(5)
  const [mode, setMode] = useState<"analogous" | "complementary" | "triadic" | "monochromatic" | "custom">("custom")
  const [generatedColors, setGeneratedColors] = useState<string[]>([])

  const { generateColorPalette, loading } = useAIColorPalette({
    onSuccess: (data) => {
      const colors = data.result.colors
      setGeneratedColors(colors)
      if (onGenerated) {
        onGenerated(colors)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    await generateColorPalette(prompt, projectId, { count, mode })
  }

  const copyColor = (color: string) => {
    navigator.clipboard.writeText(color)
    toast.success(`Copied ${color} to clipboard`)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Describe the color palette you want (e.g., sunset, ocean, forest...)"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Number of Colors</label>
              <Input
                type="number"
                min={2}
                max={10}
                value={count}
                onChange={(e) => setCount(Number.parseInt(e.target.value))}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Color Harmony</label>
              <Select value={mode} onValueChange={(value) => setMode(value as any)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select harmony" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="custom">Custom</SelectItem>
                  <SelectItem value="analogous">Analogous</SelectItem>
                  <SelectItem value="complementary">Complementary</SelectItem>
                  <SelectItem value="triadic">Triadic</SelectItem>
                  <SelectItem value="monochromatic">Monochromatic</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={loading || !prompt.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Palette"
            )}
          </Button>
        </form>

        {generatedColors.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2">Generated Palette:</h3>
            <div className="flex flex-wrap gap-2">
              {generatedColors.map((color, index) => (
                <div key={index} className="relative group">
                  <div
                    className="w-16 h-16 rounded-md cursor-pointer"
                    style={{ backgroundColor: color }}
                    onClick={() => copyColor(color)}
                  />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 rounded-md">
                    <Copy className="h-4 w-4 text-white" />
                  </div>
                  <div className="mt-1 text-xs text-center">{color}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

