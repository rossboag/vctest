"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLayoutSuggestions } from "@/hooks/use-layout-suggestions"
import { Loader2, Check } from "lucide-react"
import type { LayoutElement, LayoutSuggestion } from "@/lib/ai-layout-service"

interface LayoutSuggestionGeneratorProps {
  projectId?: string
  canvasSize: { width: number; height: number }
  elements: LayoutElement[]
  onApplySuggestion?: (suggestion: LayoutSuggestion) => void
}

export function LayoutSuggestionGenerator({
  projectId,
  canvasSize,
  elements,
  onApplySuggestion,
}: LayoutSuggestionGeneratorProps) {
  const { generateSuggestions, loading, suggestions } = useLayoutSuggestions({
    onSuccess: (data) => {
      // Handle successful suggestions generation
    },
  })

  const handleGenerate = async () => {
    await generateSuggestions(elements, canvasSize, projectId)
  }

  const handleApplySuggestion = (suggestion: LayoutSuggestion) => {
    if (onApplySuggestion) {
      onApplySuggestion(suggestion)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Layout Suggestions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Generate AI-powered suggestions to improve your layout. These suggestions consider design principles,
            balance, alignment, hierarchy, and whitespace.
          </p>

          <Button onClick={handleGenerate} disabled={loading || elements.length === 0} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating Suggestions...
              </>
            ) : (
              "Generate Layout Suggestions"
            )}
          </Button>

          {suggestions && suggestions.length > 0 && (
            <div className="mt-4 space-y-4">
              <h3 className="text-sm font-medium">Suggestions:</h3>
              <div className="space-y-3">
                {suggestions.map((suggestion) => (
                  <Card key={suggestion.id} className="overflow-hidden">
                    <div className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-sm font-medium">{suggestion.title}</h4>
                          <div className="flex items-center mt-1">
                            <span
                              className={`text-xs px-2 py-0.5 rounded-full ${
                                suggestion.impact === "high"
                                  ? "bg-red-100 text-red-800"
                                  : suggestion.impact === "medium"
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-blue-100 text-blue-800"
                              }`}
                            >
                              {suggestion.impact.charAt(0).toUpperCase() + suggestion.impact.slice(1)} Impact
                            </span>
                          </div>
                        </div>
                        <Button size="sm" onClick={() => handleApplySuggestion(suggestion)} className="h-8">
                          <Check className="h-4 w-4 mr-1" /> Apply
                        </Button>
                      </div>
                      <p className="text-sm mt-2">{suggestion.description}</p>
                    </div>
                    <div className="grid grid-cols-2 border-t">
                      <div className="p-3 border-r">
                        <h5 className="text-xs font-medium mb-1">Before</h5>
                        <div className="h-[100px] overflow-auto bg-muted rounded-md p-2">
                          <pre className="text-[10px]">{JSON.stringify(suggestion.before, null, 1)}</pre>
                        </div>
                      </div>
                      <div className="p-3">
                        <h5 className="text-xs font-medium mb-1">After</h5>
                        <div className="h-[100px] overflow-auto bg-muted rounded-md p-2">
                          <pre className="text-[10px]">{JSON.stringify(suggestion.after, null, 1)}</pre>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {suggestions && suggestions.length === 0 && (
            <div className="p-4 bg-muted rounded-md text-center text-sm">
              No layout suggestions found. Your layout looks great!
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

