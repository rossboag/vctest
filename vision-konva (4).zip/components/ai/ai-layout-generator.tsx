"use client"

import type React from "react"

import { useState } from "react"
import { useAILayout, type LayoutGenerationInput, type LayoutElement } from "@/hooks/use-ai-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, LayoutIcon } from "lucide-react"
import { AIErrorMessage } from "./ai-error-message"

interface AILayoutGeneratorProps {
  onGenerated?: (layout: LayoutElement[]) => void
  defaultPrompt?: string
  defaultWidth?: number
  defaultHeight?: number
  defaultStyle?: string
}

export function AILayoutGenerator({
  onGenerated,
  defaultPrompt = "",
  defaultWidth = 1920,
  defaultHeight = 1080,
  defaultStyle = "modern",
}: AILayoutGeneratorProps) {
  const [prompt, setPrompt] = useState(defaultPrompt)
  const [width, setWidth] = useState(defaultWidth)
  const [height, setHeight] = useState(defaultHeight)
  const [style, setStyle] = useState(defaultStyle)
  const [elements, setElements] = useState<string[]>([])
  const [newElement, setNewElement] = useState("")

  const { execute, status, data, error, reset } = useAILayout({
    onSuccess: (data) => {
      onGenerated?.(data.layout)
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const input: LayoutGenerationInput = {
      prompt,
      elements: elements.length > 0 ? elements : undefined,
      width,
      height,
      style,
    }

    await execute(input)
  }

  const addElement = () => {
    if (newElement.trim()) {
      setElements([...elements, newElement.trim()])
      setNewElement("")
    }
  }

  const removeElement = (index: number) => {
    setElements(elements.filter((_, i) => i !== index))
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <LayoutIcon className="h-5 w-5" />
          AI Layout Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt">Prompt</Label>
            <Input
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the layout you want to generate..."
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="width">Width (px)</Label>
              <Input
                id="width"
                type="number"
                min={320}
                max={3840}
                value={width}
                onChange={(e) => setWidth(Number(e.target.value))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="height">Height (px)</Label>
              <Input
                id="height"
                type="number"
                min={320}
                max={2160}
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="style">Style</Label>
            <select
              id="style"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2"
            >
              <option value="modern">Modern</option>
              <option value="minimal">Minimal</option>
              <option value="corporate">Corporate</option>
              <option value="creative">Creative</option>
              <option value="bold">Bold</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label>Required Elements (Optional)</Label>
            <div className="flex gap-2">
              <Input
                value={newElement}
                onChange={(e) => setNewElement(e.target.value)}
                placeholder="Add element (e.g., header, image)"
              />
              <Button type="button" variant="outline" onClick={addElement}>
                Add
              </Button>
            </div>

            {elements.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {elements.map((element, index) => (
                  <div key={index} className="flex items-center gap-1 rounded-full bg-secondary px-3 py-1 text-sm">
                    {element}
                    <button
                      type="button"
                      onClick={() => removeElement(index)}
                      className="ml-1 rounded-full bg-secondary-foreground/10 p-1 hover:bg-secondary-foreground/20"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button type="submit" className="w-full" disabled={status === "loading"}>
            {status === "loading" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Layout...
              </>
            ) : (
              "Generate Layout"
            )}
          </Button>
        </form>

        {error && <AIErrorMessage error={error} onRetry={handleSubmit} />}

        {data && (
          <div className="mt-4">
            <h3 className="font-medium">Generated Layout:</h3>
            <div className="mt-2 rounded-md bg-muted p-3">
              <div
                className="relative border border-dashed border-border"
                style={{
                  width: "100%",
                  height: "200px",
                  position: "relative",
                }}
              >
                {data.layout.map((element, index) => (
                  <div
                    key={index}
                    className="absolute border border-primary bg-primary/10"
                    style={{
                      left: `${(element.x / width) * 100}%`,
                      top: `${(element.y / height) * 100}%`,
                      width: `${(element.width / width) * 100}%`,
                      height: `${(element.height / height) * 100}%`,
                    }}
                  >
                    <div className="p-1 text-xs">{element.type}</div>
                  </div>
                ))}
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={reset} className="mt-2">
              Reset
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

