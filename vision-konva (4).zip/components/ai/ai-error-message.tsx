import type React from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { AIServiceError } from "@/lib/errors"
import { AlertCircle, RefreshCw } from "lucide-react"

interface AIErrorMessageProps {
  error: Error
  onRetry?: (e: React.MouseEvent) => void
}

export function AIErrorMessage({ error, onRetry }: AIErrorMessageProps) {
  const isAIServiceError = error instanceof AIServiceError

  let title = "Error"
  let description = error.message || "An unknown error occurred"

  if (isAIServiceError) {
    const aiError = error as AIServiceError

    switch (aiError.code) {
      case "RATE_LIMIT_EXCEEDED":
        title = "Rate Limit Exceeded"
        description = "You have exceeded the allowed number of requests. Please try again later."
        break
      case "CONTENT_POLICY_VIOLATION":
        title = "Content Policy Violation"
        description = "Your request contains content that violates our content policy."
        break
      case "INVALID_API_KEY":
        title = "Authentication Error"
        description = "There was an issue with the API authentication. Please contact support."
        break
      case "SERVICE_UNAVAILABLE":
        title = "Service Unavailable"
        description = "The AI service is currently unavailable. Please try again later."
        break
      default:
        if (aiError.status >= 500) {
          title = "Server Error"
          description = "There was a problem with the server. Please try again later."
        } else if (aiError.status >= 400) {
          title = "Request Error"
          description = aiError.message || "There was a problem with your request."
        }
    }
  }

  return (
    <Alert variant="destructive" className="mt-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>{title}</AlertTitle>
      <AlertDescription className="mt-2">
        <p>{description}</p>
        {onRetry && (
          <Button variant="outline" size="sm" onClick={onRetry} className="mt-2">
            <RefreshCw className="mr-2 h-3 w-3" />
            Try Again
          </Button>
        )}
      </AlertDescription>
    </Alert>
  )
}

