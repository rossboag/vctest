"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useDesignSuggestions } from "@/hooks/use-design-suggestions"
import { Loader2, Sparkles, ArrowRight, Lightbulb } from "lucide-react"
import type { DesignElement, DesignSuggestion } from "@/lib/ai-design-service"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

interface DesignSuggestionsProps {
  projectId?: string
  elements: DesignElement[]
  canvasWidth: number
  canvasHeight: number
  onApplySuggestion?: (suggestion: DesignSuggestion) => void
}

export function DesignSuggestions({
  projectId,
  elements,
  canvasWidth,
  canvasHeight,
  onApplySuggestion,
}: DesignSuggestionsProps) {
  const [focusArea, setFocusArea] = useState<string | undefined>(undefined)

  const { generateSuggestions, loading, suggestions } = useDesignSuggestions()

  const handleGenerate = async () => {
    await generateSuggestions(elements, canvasWidth, canvasHeight, focusArea, projectId)
  }

  const getImpactColor = (impact: "low" | "medium" | "high") => {
    switch (impact) {
      case "high":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getComplexityColor = (complexity: "easy" | "medium" | "complex") => {
    switch (complexity) {
      case "easy":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "complex":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Lightbulb className="h-5 w-5 mr-2" />
          Design Suggestions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Focus Area (Optional)</label>
            <Select value={focusArea} onValueChange={setFocusArea}>
              <SelectTrigger>
                <SelectValue placeholder="All areas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All areas</SelectItem>
                <SelectItem value="color">Color</SelectItem>
                <SelectItem value="typography">Typography</SelectItem>
                <SelectItem value="layout">Layout</SelectItem>
                <SelectItem value="accessibility">Accessibility</SelectItem>
                <SelectItem value="balance">Balance</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerate} disabled={loading || elements.length === 0} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Suggestions
              </>
            )}
          </Button>

          {suggestions.length > 0 && (
            <div className="space-y-4 mt-6">
              <h3 className="text-sm font-medium">Suggestions:</h3>
              <div className="space-y-3">
                {suggestions.map((suggestion) => (
                  <Card key={suggestion.id} className="overflow-hidden">
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{suggestion.title}</h4>
                        <div className="flex gap-2">
                          <Badge variant="outline" className={getImpactColor(suggestion.impact)}>
                            {suggestion.impact} impact
                          </Badge>
                          <Badge variant="outline" className={getComplexityColor(suggestion.implementationComplexity)}>
                            {suggestion.implementationComplexity}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{suggestion.description}</p>

                      {(suggestion.before || suggestion.after) && (
                        <div className="flex items-center gap-2 mb-3">
                          {suggestion.before && (
                            <div className="flex-1 p-2 border rounded-md">
                              <p className="text-xs text-muted-foreground mb-1">Before</p>
                              <div className="text-xs overflow-auto max-h-20">
                                <pre>{JSON.stringify(suggestion.before, null, 2)}</pre>
                              </div>
                            </div>
                          )}

                          {suggestion.before && suggestion.after && (
                            <ArrowRight className="h-4 w-4 text-muted-foreground" />
                          )}

                          {suggestion.after && (
                            <div className="flex-1 p-2 border rounded-md">
                              <p className="text-xs text-muted-foreground mb-1">After</p>
                              <div className="text-xs overflow-auto max-h-20">
                                <pre>{JSON.stringify(suggestion.after, null, 2)}</pre>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => onApplySuggestion && onApplySuggestion(suggestion)}
                      >
                        Apply Suggestion
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

