"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAIAnimationSuggestions } from "@/hooks/use-ai-animation-suggestions"
import { Loader2, Sparkles } from "lucide-react"

interface AIAnimationSuggestionsProps {
  onSelectSuggestion?: (suggestion: string) => void
  elementType?: string
}

export function AIAnimationSuggestions({
  onSelectSuggestion,
  elementType: initialElementType = "text",
}: AIAnimationSuggestionsProps) {
  const [elementType, setElementType] = useState(initialElementType)
  const [elementContent, setElementContent] = useState("")
  const [projectContext, setProjectContext] = useState("")
  const [count, setCount] = useState(3)

  const { generateSuggestions, loading, suggestions } = useAIAnimationSuggestions()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!elementType.trim()) return

    await generateSuggestions(elementType, elementContent, projectContext, count)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Animation Suggestions</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Element Type</label>
            <Input
              placeholder="text, image, shape, etc."
              value={elementType}
              onChange={(e) => setElementType(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Element Content (optional)</label>
            <Input
              placeholder="What does this element contain?"
              value={elementContent}
              onChange={(e) => setElementContent(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Project Context (optional)</label>
            <Textarea
              placeholder="Describe the project or scene this element is part of"
              value={projectContext}
              onChange={(e) => setProjectContext(e.target.value)}
              rows={2}
              className="resize-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Number of Suggestions</label>
            <Input
              type="number"
              min={1}
              max={10}
              value={count}
              onChange={(e) => setCount(Number.parseInt(e.target.value))}
              required
            />
          </div>

          <Button type="submit" disabled={loading || !elementType.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Get Suggestions
              </>
            )}
          </Button>
        </form>

        {suggestions.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2">Suggestions:</h3>
            <div className="space-y-2">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="p-3 border rounded-md hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={() => onSelectSuggestion && onSelectSuggestion(suggestion)}
                >
                  <p className="text-sm">{suggestion}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

