"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAIAnimationKeyframes } from "@/hooks/use-ai-animation-keyframes"
import { Loader2 } from "lucide-react"
import type { AnimationKeyframe } from "@/lib/ai-animation-service"

interface AIAnimationKeyframesGeneratorProps {
  projectId?: string
  onGenerated?: (keyframes: AnimationKeyframe[]) => void
  title?: string
  elementType?: string
}

export function AIAnimationKeyframesGenerator({
  projectId,
  onGenerated,
  title = "AI Animation Generator",
  elementType: initialElementType = "text",
}: AIAnimationKeyframesGeneratorProps) {
  const [prompt, setPrompt] = useState("")
  const [elementType, setElementType] = useState(initialElementType)
  const [duration, setDuration] = useState(2)
  const [generatedKeyframes, setGeneratedKeyframes] = useState<AnimationKeyframe[]>([])

  const { generateKeyframes, loading } = useAIAnimationKeyframes({
    onSuccess: (keyframes) => {
      setGeneratedKeyframes(keyframes)
      if (onGenerated) {
        onGenerated(keyframes)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim() || !elementType) return

    await generateKeyframes(prompt, elementType, duration, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="Describe the animation you want (e.g., fade in and slide from left, bounce in and rotate)"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            className="resize-none"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Element Type</label>
              <Input
                placeholder="text, image, shape, etc."
                value={elementType}
                onChange={(e) => setElementType(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Duration (seconds)</label>
              <Input
                type="number"
                min={0.5}
                max={10}
                step={0.1}
                value={duration}
                onChange={(e) => setDuration(Number.parseFloat(e.target.value))}
              />
            </div>
          </div>

          <Button type="submit" disabled={loading || !prompt.trim() || !elementType}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Animation"
            )}
          </Button>
        </form>

        {generatedKeyframes.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2">Generated Keyframes:</h3>
            <div className="p-4 bg-muted rounded-md overflow-auto max-h-96">
              <pre className="text-xs">{JSON.stringify(generatedKeyframes, null, 2)}</pre>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => {
                if (onGenerated) {
                  onGenerated(generatedKeyframes)
                }
              }}
            >
              Apply Animation
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

