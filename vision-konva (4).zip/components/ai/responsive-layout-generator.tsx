"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useResponsiveLayout } from "@/hooks/use-responsive-layout"
import { Loader2 } from "lucide-react"
import type { LayoutElement, LayoutResult } from "@/lib/ai-layout-service"

interface ResponsiveLayoutGeneratorProps {
  projectId?: string
  elements: LayoutElement[]
  originalSize: { width: number; height: number }
  onLayoutGenerated?: (layout: LayoutResult) => void
}

export function ResponsiveLayoutGenerator({
  projectId,
  elements,
  originalSize,
  onLayoutGenerated,
}: ResponsiveLayoutGeneratorProps) {
  const [targetDevice, setTargetDevice] = useState("mobile")
  const [customWidth, setCustomWidth] = useState(375)
  const [customHeight, setCustomHeight] = useState(667)

  const { generateResponsiveVariant, loading, responsiveLayout } = useResponsiveLayout({
    onSuccess: (layout) => {
      if (onLayoutGenerated) {
        onLayoutGenerated(layout)
      }
    },
  })

  const getTargetSize = () => {
    switch (targetDevice) {
      case "mobile":
        return { width: 375, height: 667 }
      case "tablet":
        return { width: 768, height: 1024 }
      case "desktop":
        return { width: 1280, height: 800 }
      case "custom":
        return { width: customWidth, height: customHeight }
      default:
        return { width: 375, height: 667 }
    }
  }

  const handleGenerate = async () => {
    const targetSize = getTargetSize()
    await generateResponsiveVariant(elements, originalSize, targetSize, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Generate Responsive Layout</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Generate a responsive variant of your layout for different screen sizes. This will adapt your design while
            maintaining its integrity.
          </p>

          <div className="space-y-2">
            <label className="text-sm font-medium">Target Device</label>
            <Select value={targetDevice} onValueChange={setTargetDevice}>
              <SelectTrigger>
                <SelectValue placeholder="Select target device" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mobile">Mobile (375×667)</SelectItem>
                <SelectItem value="tablet">Tablet (768×1024)</SelectItem>
                <SelectItem value="desktop">Desktop (1280×800)</SelectItem>
                <SelectItem value="custom">Custom Size</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {targetDevice === "custom" && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Width (px)</label>
                <Input
                  type="number"
                  min={100}
                  value={customWidth}
                  onChange={(e) => setCustomWidth(Number(e.target.value))}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Height (px)</label>
                <Input
                  type="number"
                  min={100}
                  value={customHeight}
                  onChange={(e) => setCustomHeight(Number(e.target.value))}
                />
              </div>
            </div>
          )}

          <div className="p-3 bg-muted rounded-md text-sm">
            <p>
              <strong>Original Size:</strong> {originalSize.width}×{originalSize.height}px
            </p>
            <p>
              <strong>Target Size:</strong> {getTargetSize().width}×{getTargetSize().height}px
            </p>
          </div>

          <Button onClick={handleGenerate} disabled={loading || elements.length === 0} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating...
              </>
            ) : (
              "Generate Responsive Layout"
            )}
          </Button>

          {responsiveLayout && (
            <div className="mt-4">
              <h3 className="text-sm font-medium mb-2">Responsive Layout:</h3>
              <div className="h-[200px] overflow-auto p-4 bg-muted rounded-md">
                <pre className="text-xs">{JSON.stringify(responsiveLayout, null, 2)}</pre>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="mt-2"
                onClick={() => onLayoutGenerated && onLayoutGenerated(responsiveLayout)}
              >
                Apply Responsive Layout
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

