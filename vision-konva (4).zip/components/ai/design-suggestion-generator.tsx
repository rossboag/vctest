"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useDesignSuggestions } from "@/hooks/use-design-suggestions"
import { Loader2, Lightbulb } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

interface DesignSuggestionGeneratorProps {
  projectId?: string
  designElements: any[]
  canvasSize: { width: number; height: number }
  onSuggestionsGenerated?: (suggestions: any) => void
}

export function DesignSuggestionGenerator({
  projectId,
  designElements,
  canvasSize,
  onSuggestionsGenerated,
}: DesignSuggestionGeneratorProps) {
  const [focusArea, setFocusArea] = useState<"composition" | "color" | "typography" | "accessibility" | "all">("all")

  const { generateSuggestions, loading, suggestions } = useDesignSuggestions({
    onSuccess: (result) => {
      if (onSuggestionsGenerated) {
        onSuggestionsGenerated(result)
      }
    },
  })

  const handleGenerate = async () => {
    await generateSuggestions(designElements, canvasSize, focusArea, projectId)
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Lightbulb className="h-5 w-5 mr-2" />
          Design Suggestions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Focus Area</label>
            <Select value={focusArea} onValueChange={(value) => setFocusArea(value as any)}>
              <SelectTrigger>
                <SelectValue placeholder="Select focus area" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Aspects</SelectItem>
                <SelectItem value="composition">Composition</SelectItem>
                <SelectItem value="color">Color</SelectItem>
                <SelectItem value="typography">Typography</SelectItem>
                <SelectItem value="accessibility">Accessibility</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerate} disabled={loading || designElements.length === 0}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Suggestions"
            )}
          </Button>
        </div>

        {suggestions && (
          <div className="mt-6 space-y-4">
            <div className="p-4 bg-muted rounded-md">
              <h4 className="font-medium mb-2">Summary</h4>
              <p className="text-sm">{suggestions.summary}</p>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Suggestions ({suggestions.suggestions.length})</h4>

              {suggestions.suggestions.map((suggestion: any, index: number) => (
                <div key={index} className="p-3 border rounded-md">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium capitalize">{suggestion.category}</span>
                    <Badge className={getPriorityColor(suggestion.priority)}>
                      <span className="capitalize">{suggestion.priority} Priority</span>
                    </Badge>
                  </div>
                  <p className="text-sm">{suggestion.suggestion}</p>

                  {suggestion.before && suggestion.after && (
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      <div className="p-2 bg-muted rounded-md">
                        <span className="text-xs font-medium">Before</span>
                        <div className="mt-1 text-xs overflow-auto max-h-20">
                          <pre>{JSON.stringify(suggestion.before, null, 2)}</pre>
                        </div>
                      </div>
                      <div className="p-2 bg-muted rounded-md">
                        <span className="text-xs font-medium">After</span>
                        <div className="mt-1 text-xs overflow-auto max-h-20">
                          <pre>{JSON.stringify(suggestion.after, null, 2)}</pre>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                if (onSuggestionsGenerated && suggestions) {
                  onSuggestionsGenerated(suggestions)
                }
              }}
            >
              Apply Suggestions
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

