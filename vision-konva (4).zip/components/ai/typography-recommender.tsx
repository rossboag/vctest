"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTypographyRecommendations } from "@/hooks/use-typography-recommendations"
import { Loader2, Type, Copy } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import type { TypographyRecommendation } from "@/lib/ai-design-service"

interface TypographyRecommenderProps {
  projectId?: string
  onTypographyGenerated?: (typography: TypographyRecommendation) => void
}

const STYLES = [
  "Modern",
  "Classic",
  "Minimalist",
  "Bold",
  "Elegant",
  "Playful",
  "Futuristic",
  "Vintage",
  "Corporate",
  "Creative",
]

const PURPOSES = [
  "Website",
  "Mobile App",
  "Presentation",
  "Print",
  "Social Media",
  "Blog",
  "E-commerce",
  "Portfolio",
  "Dashboard",
  "Marketing",
]

export function TypographyRecommender({ projectId, onTypographyGenerated }: TypographyRecommenderProps) {
  const [style, setStyle] = useState("")
  const [purpose, setPurpose] = useState("")
  const [customStyle, setCustomStyle] = useState("")
  const [customPurpose, setCustomPurpose] = useState("")

  const { generateTypography, loading, typography } = useTypographyRecommendations({
    onSuccess: (result) => {
      if (onTypographyGenerated) {
        onTypographyGenerated(result)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const finalStyle = style === "custom" ? customStyle : style
    const finalPurpose = purpose === "custom" ? customPurpose : purpose
    await generateTypography(finalStyle, finalPurpose, projectId)
  }

  const copyTypographyCSS = (type: "heading" | "subheading" | "body" | "caption") => {
    if (!typography) return

    let css = ""
    const item = typography[type]

    css = `font-family: ${item.fontFamily};\n`
    css += `font-size: ${item.fontSize};\n`
    css += `font-weight: ${item.fontWeight};\n`
    css += `line-height: ${item.lineHeight};`

    navigator.clipboard.writeText(css)
    toast.success(`Copied ${type} CSS to clipboard`)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Type className="h-5 w-5 mr-2" />
          Typography Recommender
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Style</label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger>
                <SelectValue placeholder="Select style" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {STYLES.map((s) => (
                  <SelectItem key={s} value={s.toLowerCase()}>
                    {s}
                  </SelectItem>
                ))}
                <SelectItem value="custom">Custom...</SelectItem>
              </SelectContent>
            </Select>

            {style === "custom" && (
              <Input
                placeholder="Enter custom style"
                value={customStyle}
                onChange={(e) => setCustomStyle(e.target.value)}
                className="mt-2"
              />
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Purpose</label>
            <Select value={purpose} onValueChange={setPurpose}>
              <SelectTrigger>
                <SelectValue placeholder="Select purpose" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {PURPOSES.map((p) => (
                  <SelectItem key={p} value={p.toLowerCase()}>
                    {p}
                  </SelectItem>
                ))}
                <SelectItem value="custom">Custom...</SelectItem>
              </SelectContent>
            </Select>

            {purpose === "custom" && (
              <Input
                placeholder="Enter custom purpose"
                value={customPurpose}
                onChange={(e) => setCustomPurpose(e.target.value)}
                className="mt-2"
              />
            )}
          </div>

          <Button type="submit" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Typography"
            )}
          </Button>
        </form>

        {typography && (
          <div className="mt-6 space-y-4">
            <h3 className="font-medium">Typography Recommendations</h3>

            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-md relative group">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">Heading</h4>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => copyTypographyCSS("heading")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p
                  className="mt-2"
                  style={{
                    fontFamily: typography.heading.fontFamily,
                    fontSize: typography.heading.fontSize,
                    fontWeight: typography.heading.fontWeight,
                    lineHeight: typography.heading.lineHeight,
                  }}
                >
                  Sample Heading Text
                </p>
                <div className="mt-2 text-xs text-muted-foreground">
                  <p>Font: {typography.heading.fontFamily}</p>
                  <p>Size: {typography.heading.fontSize}</p>
                  <p>Weight: {typography.heading.fontWeight}</p>
                  <p>Line Height: {typography.heading.lineHeight}</p>
                </div>
              </div>

              <div className="p-4 bg-muted rounded-md relative group">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">Subheading</h4>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => copyTypographyCSS("subheading")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p
                  className="mt-2"
                  style={{
                    fontFamily: typography.subheading.fontFamily,
                    fontSize: typography.subheading.fontSize,
                    fontWeight: typography.subheading.fontWeight,
                    lineHeight: typography.subheading.lineHeight,
                  }}
                >
                  Sample Subheading Text
                </p>
                <div className="mt-2 text-xs text-muted-foreground">
                  <p>Font: {typography.subheading.fontFamily}</p>
                  <p>Size: {typography.subheading.fontSize}</p>
                  <p>Weight: {typography.subheading.fontWeight}</p>
                  <p>Line Height: {typography.subheading.lineHeight}</p>
                </div>
              </div>

              <div className="p-4 bg-muted rounded-md relative group">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">Body</h4>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => copyTypographyCSS("body")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p
                  className="mt-2"
                  style={{
                    fontFamily: typography.body.fontFamily,
                    fontSize: typography.body.fontSize,
                    fontWeight: typography.body.fontWeight,
                    lineHeight: typography.body.lineHeight,
                  }}
                >
                  Sample body text. This is what your main content will look like. It should be easy to read and have
                  good contrast with the background.
                </p>
                <div className="mt-2 text-xs text-muted-foreground">
                  <p>Font: {typography.body.fontFamily}</p>
                  <p>Size: {typography.body.fontSize}</p>
                  <p>Weight: {typography.body.fontWeight}</p>
                  <p>Line Height: {typography.body.lineHeight}</p>
                </div>
              </div>

              <div className="p-4 bg-muted rounded-md relative group">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">Caption</h4>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => copyTypographyCSS("caption")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p
                  className="mt-2"
                  style={{
                    fontFamily: typography.caption.fontFamily,
                    fontSize: typography.caption.fontSize,
                    fontWeight: typography.caption.fontWeight,
                    lineHeight: typography.caption.lineHeight,
                  }}
                >
                  Sample caption text for images or small notes
                </p>
                <div className="mt-2 text-xs text-muted-foreground">
                  <p>Font: {typography.caption.fontFamily}</p>
                  <p>Size: {typography.caption.fontSize}</p>
                  <p>Weight: {typography.caption.fontWeight}</p>
                  <p>Line Height: {typography.caption.lineHeight}</p>
                </div>
              </div>
            </div>

            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Recommended Font Pairings</h4>
              <ul className="list-disc pl-5 text-sm">
                {typography.pairings.map((pair, index) => (
                  <li key={index}>{pair}</li>
                ))}
              </ul>
            </div>

            <div className="mt-4 p-4 bg-muted rounded-md">
              <h4 className="text-sm font-medium mb-2">Feedback</h4>
              <p className="text-sm">{typography.feedback}</p>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                if (onTypographyGenerated && typography) {
                  onTypographyGenerated(typography)
                }
              }}
            >
              Apply Typography to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

