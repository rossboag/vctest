"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useDesignAnalysis } from "@/hooks/use-design-analysis"
import { Loader2, BarChart, AlertTriangle, CheckCircle } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import type { DesignAnalysisResult } from "@/lib/ai-design-service"

interface DesignAnalyzerProps {
  projectId?: string
  designElements: any[]
  canvasSize: { width: number; height: number }
  onAnalysisComplete?: (analysis: DesignAnalysisResult) => void
}

export function DesignAnalyzer({ projectId, designElements, canvasSize, onAnalysisComplete }: DesignAnalyzerProps) {
  const { analyzeDesign, loading, analysis } = useDesignAnalysis({
    onSuccess: (result) => {
      if (onAnalysisComplete) {
        onAnalysisComplete(result)
      }
    },
  })

  const handleAnalyze = async () => {
    await analyzeDesign(designElements, canvasSize, projectId)
  }

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-500"
    if (score >= 6) return "text-yellow-500"
    return "text-red-500"
  }

  const getProgressColor = (score: number) => {
    if (score >= 8) return "bg-green-500"
    if (score >= 6) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart className="h-5 w-5 mr-2" />
          Design Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!analysis ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Analyze your design to get feedback on composition, color harmony, typography, and accessibility.
            </p>
            <Button onClick={handleAnalyze} disabled={loading || designElements.length === 0}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                "Analyze Design"
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Overall Score</h3>
              <span className={`text-2xl font-bold ${getScoreColor(analysis.overallScore)}`}>
                {analysis.overallScore}/10
              </span>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Composition</h4>
                  <span className={`font-medium ${getScoreColor(analysis.composition.score)}`}>
                    {analysis.composition.score}/10
                  </span>
                </div>
                <Progress
                  value={analysis.composition.score * 10}
                  className={getProgressColor(analysis.composition.score)}
                />
                <p className="text-sm text-muted-foreground">{analysis.composition.feedback}</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Color Harmony</h4>
                  <span className={`font-medium ${getScoreColor(analysis.colorHarmony.score)}`}>
                    {analysis.colorHarmony.score}/10
                  </span>
                </div>
                <Progress
                  value={analysis.colorHarmony.score * 10}
                  className={getProgressColor(analysis.colorHarmony.score)}
                />
                <p className="text-sm text-muted-foreground">{analysis.colorHarmony.feedback}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {analysis.colorHarmony.palette.map((color, index) => (
                    <div
                      key={index}
                      className="w-8 h-8 rounded-full border"
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Typography</h4>
                  <span className={`font-medium ${getScoreColor(analysis.typography.score)}`}>
                    {analysis.typography.score}/10
                  </span>
                </div>
                <Progress
                  value={analysis.typography.score * 10}
                  className={getProgressColor(analysis.typography.score)}
                />
                <p className="text-sm text-muted-foreground">{analysis.typography.feedback}</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Accessibility</h4>
                  <span className={`font-medium ${getScoreColor(analysis.accessibility.score)}`}>
                    {analysis.accessibility.score}/10
                  </span>
                </div>
                <Progress
                  value={analysis.accessibility.score * 10}
                  className={getProgressColor(analysis.accessibility.score)}
                />
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-sm">Color Contrast:</span>
                  {analysis.accessibility.colorContrast ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                  )}
                  <span className="text-sm ml-2">Text Size:</span>
                  {analysis.accessibility.textSize ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{analysis.accessibility.feedback}</p>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Suggestions</h3>
              <ul className="space-y-2">
                {analysis.suggestions.map((suggestion, index) => (
                  <li key={index} className="text-sm bg-muted p-2 rounded-md">
                    {suggestion}
                  </li>
                ))}
              </ul>
            </div>

            <Button onClick={handleAnalyze} variant="outline">
              Re-analyze Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

