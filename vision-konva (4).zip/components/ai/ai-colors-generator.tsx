"use client"

import type React from "react"

import { useState } from "react"
import { useAIColors, type ColorPaletteInput } from "@/hooks/use-ai-colors"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, PaletteIcon } from "lucide-react"
import { AIErrorMessage } from "./ai-error-message"

interface AIColorsGeneratorProps {
  onGenerated?: (colors: string[]) => void
  defaultPrompt?: string
  defaultNumberOfColors?: number
  defaultBaseColor?: string
}

export function AIColorsGenerator({
  onGenerated,
  defaultPrompt = "",
  defaultNumberOfColors = 5,
  defaultBaseColor = "",
}: AIColorsGeneratorProps) {
  const [prompt, setPrompt] = useState(defaultPrompt)
  const [numberOfColors, setNumberOfColors] = useState(defaultNumberOfColors)
  const [baseColor, setBaseColor] = useState(defaultBaseColor)

  const { execute, status, data, error, reset } = useAIColors({
    onSuccess: (data) => {
      onGenerated?.(data.colors)
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const input: ColorPaletteInput = {
      prompt,
      numberOfColors,
      baseColor: baseColor || undefined,
    }

    await execute(input)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PaletteIcon className="h-5 w-5" />
          AI Color Palette Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt">Prompt</Label>
            <Input
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the color palette you want..."
              required
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="numberOfColors">Number of Colors: {numberOfColors}</Label>
            </div>
            <Slider
              id="numberOfColors"
              min={3}
              max={10}
              step={1}
              value={[numberOfColors]}
              onValueChange={(value) => setNumberOfColors(value[0])}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="baseColor">Base Color (Optional)</Label>
            <div className="flex gap-2">
              <Input
                id="baseColor"
                type="text"
                value={baseColor}
                onChange={(e) => setBaseColor(e.target.value)}
                placeholder="#RRGGBB or color name"
                className="flex-1"
              />
              <Input
                type="color"
                value={baseColor.startsWith("#") ? baseColor : "#ffffff"}
                onChange={(e) => setBaseColor(e.target.value)}
                className="w-12 p-1"
              />
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={status === "loading"}>
            {status === "loading" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Colors...
              </>
            ) : (
              "Generate Color Palette"
            )}
          </Button>
        </form>

        {error && <AIErrorMessage error={error} onRetry={handleSubmit} />}

        {data && data.colors.length > 0 && (
          <div className="mt-4">
            <h3 className="font-medium">Generated Color Palette:</h3>
            <div className="mt-2 flex flex-wrap gap-2">
              {data.colors.map((color, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div className="h-12 w-12 rounded-md border border-border" style={{ backgroundColor: color }} />
                  <span className="mt-1 text-xs">{color}</span>
                </div>
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={reset} className="mt-2">
              Reset
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

