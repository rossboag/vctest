"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTypographySystem } from "@/hooks/use-typography-system"
import { Loader2, Type, Copy } from "lucide-react"
import type { TypographySystem } from "@/lib/ai-design-service"
import { toast } from "sonner"

interface TypographySystemGeneratorProps {
  projectId?: string
  onApplyTypography?: (typography: TypographySystem) => void
}

export function TypographySystemGenerator({ projectId, onApplyTypography }: TypographySystemGeneratorProps) {
  const [prompt, setPrompt] = useState("")

  const { generateTypographySystem, loading, typographySystem } = useTypographySystem()

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    await generateTypographySystem(prompt, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Type className="h-5 w-5 mr-2" />
          Typography System Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleGenerate} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Describe your typography needs</label>
            <Input
              placeholder="e.g., Modern and clean, professional for finance, playful for children's content"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </div>

          <Button type="submit" disabled={loading || !prompt.trim()} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Type className="mr-2 h-4 w-4" />
                Generate Typography
              </>
            )}
          </Button>
        </form>

        {typographySystem && (
          <div className="mt-6 space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Font Pairing:</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border rounded-md">
                  <h4 className="text-sm font-medium mb-1">Heading Font</h4>
                  <p className="text-xl" style={{ fontFamily: typographySystem.headingFont }}>
                    {typographySystem.headingFont}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2"
                    onClick={() => {
                      navigator.clipboard.writeText(typographySystem.headingFont)
                      toast.success("Heading font copied to clipboard")
                    }}
                  >
                    <Copy className="h-3 w-3 mr-1" />
                    Copy
                  </Button>
                </div>
                <div className="p-4 border rounded-md">
                  <h4 className="text-sm font-medium mb-1">Body Font</h4>
                  <p className="text-base" style={{ fontFamily: typographySystem.bodyFont }}>
                    {typographySystem.bodyFont}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2"
                    onClick={() => {
                      navigator.clipboard.writeText(typographySystem.bodyFont)
                      toast.success("Body font copied to clipboard")
                    }}
                  >
                    <Copy className="h-3 w-3 mr-1" />
                    Copy
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Font Sizes:</h3>
              <div className="space-y-3 p-4 border rounded-md">
                <div>
                  <h4 className="text-sm font-medium mb-1">H1</h4>
                  <p
                    style={{
                      fontSize: `${typographySystem.sizes.h1}px`,
                      fontFamily: typographySystem.headingFont,
                      fontWeight: typographySystem.weights.heading,
                      lineHeight: typographySystem.lineHeights.heading,
                    }}
                  >
                    Heading 1 Example
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {typographySystem.sizes.h1}px / Weight: {typographySystem.weights.heading} / Line Height:{" "}
                    {typographySystem.lineHeights.heading}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">H2</h4>
                  <p
                    style={{
                      fontSize: `${typographySystem.sizes.h2}px`,
                      fontFamily: typographySystem.headingFont,
                      fontWeight: typographySystem.weights.heading,
                      lineHeight: typographySystem.lineHeights.heading,
                    }}
                  >
                    Heading 2 Example
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {typographySystem.sizes.h2}px / Weight: {typographySystem.weights.heading} / Line Height:{" "}
                    {typographySystem.lineHeights.heading}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">H3</h4>
                  <p
                    style={{
                      fontSize: `${typographySystem.sizes.h3}px`,
                      fontFamily: typographySystem.headingFont,
                      fontWeight: typographySystem.weights.heading,
                      lineHeight: typographySystem.lineHeights.heading,
                    }}
                  >
                    Heading 3 Example
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {typographySystem.sizes.h3}px / Weight: {typographySystem.weights.heading} / Line Height:{" "}
                    {typographySystem.lineHeights.heading}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Body</h4>
                  <p
                    style={{
                      fontSize: `${typographySystem.sizes.body}px`,
                      fontFamily: typographySystem.bodyFont,
                      fontWeight: typographySystem.weights.body,
                      lineHeight: typographySystem.lineHeights.body,
                    }}
                  >
                    This is an example of body text. It should be readable and comfortable for longer passages of
                    content. The line height should provide enough spacing between lines.
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {typographySystem.sizes.body}px / Weight: {typographySystem.weights.body} / Line Height:{" "}
                    {typographySystem.lineHeights.body}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium mb-1">Small</h4>
                  <p
                    style={{
                      fontSize: `${typographySystem.sizes.small}px`,
                      fontFamily: typographySystem.bodyFont,
                      fontWeight: typographySystem.weights.body,
                      lineHeight: typographySystem.lineHeights.body,
                    }}
                  >
                    This is small text, used for captions, footnotes, and other secondary information.
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {typographySystem.sizes.small}px / Weight: {typographySystem.weights.body} / Line Height:{" "}
                    {typographySystem.lineHeights.body}
                  </p>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => onApplyTypography && onApplyTypography(typographySystem)}
            >
              Apply Typography to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

