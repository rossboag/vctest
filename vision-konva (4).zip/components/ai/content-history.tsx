"use client"

import { useState, useEffect } from "react"
import { useContentHistory } from "@/hooks/use-content-history"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Clock, RefreshCw } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface ContentHistoryProps {
  projectId?: string
  onSelect?: (content: any) => void
}

export function ContentHistory({ projectId, onSelect }: ContentHistoryProps) {
  const [activeTab, setActiveTab] = useState("all")
  const [limit, setLimit] = useState(10)

  const { history, loading, fetchHistory } = useContentHistory({
    projectId,
    limit,
    type: activeTab !== "all" ? activeTab : undefined,
    autoFetch: true,
  })

  useEffect(() => {
    fetchHistory({
      type: activeTab !== "all" ? activeTab : undefined,
    })
  }, [activeTab, fetchHistory])

  const handleRefresh = () => {
    fetchHistory({
      type: activeTab !== "all" ? activeTab : undefined,
    })
  }

  const getContentPreview = (item: any) => {
    if (item.type === "text" || item.type === "localization" || item.type === "adaptation") {
      return item.enhancedContent?.substring(0, 100) + "..."
    } else if (item.type === "image") {
      return "Image enhancement suggestions"
    } else if (item.type === "video") {
      return item.enhancedContent?.title || "Video content plan"
    }
    return "Content enhancement"
  }

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true })
    } catch (e) {
      return "Unknown date"
    }
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Content Enhancement History</CardTitle>
        <Button variant="outline" size="sm" onClick={handleRefresh}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="text">Text</TabsTrigger>
              <TabsTrigger value="image">Image</TabsTrigger>
              <TabsTrigger value="video">Video</TabsTrigger>
              <TabsTrigger value="adaptation">Adaptation</TabsTrigger>
              <TabsTrigger value="localization">Localization</TabsTrigger>
            </TabsList>

            <Select value={limit.toString()} onValueChange={(value) => setLimit(Number.parseInt(value))}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Show" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">Show 5</SelectItem>
                <SelectItem value="10">Show 10</SelectItem>
                <SelectItem value="20">Show 20</SelectItem>
                <SelectItem value="50">Show 50</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <TabsContent value={activeTab} className="mt-0">
            {loading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : history.length > 0 ? (
              <div className="space-y-4">
                {history.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 border rounded-lg hover:bg-accent/50 cursor-pointer transition-colors"
                    onClick={() => onSelect && onSelect(item)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-medium capitalize">{item.type} Enhancement</div>
                      <div className="text-sm text-muted-foreground flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {formatDate(item.createdAt)}
                      </div>
                    </div>
                    <div className="text-sm line-clamp-2">{getContentPreview(item)}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">No content enhancement history found</div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

