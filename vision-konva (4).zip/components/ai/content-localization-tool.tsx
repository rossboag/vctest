"use client"

import type React from "react"

import { useState } from "react"
import { useContentLocalization } from "@/hooks/use-content-localization"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Loader2 } from "lucide-react"
import type { LocalizationOptions } from "@/lib/ai-content-service"

interface ContentLocalizationToolProps {
  projectId?: string
  onLocalized?: (localizedContent: string) => void
  initialContent?: string
}

export function ContentLocalizationTool({ projectId, onLocalized, initialContent = "" }: ContentLocalizationToolProps) {
  const [content, setContent] = useState(initialContent)
  const [localizedContent, setLocalizedContent] = useState("")
  const [options, setOptions] = useState<LocalizationOptions>({
    targetLanguage: "es",
    targetRegion: "",
    preserveFormatting: true,
    adaptCulturalReferences: true,
  })

  const { localizeContent, loading } = useContentLocalization({
    onSuccess: (data) => {
      setLocalizedContent(data.localizedContent)
      if (onLocalized) {
        onLocalized(data.localizedContent)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim()) return
    await localizeContent(content, options, projectId)
  }

  const languages = [
    { code: "es", name: "Spanish" },
    { code: "fr", name: "French" },
    { code: "de", name: "German" },
    { code: "it", name: "Italian" },
    { code: "pt", name: "Portuguese" },
    { code: "zh", name: "Chinese" },
    { code: "ja", name: "Japanese" },
    { code: "ko", name: "Korean" },
    { code: "ar", name: "Arabic" },
    { code: "ru", name: "Russian" },
    { code: "hi", name: "Hindi" },
  ]

  const regions = {
    es: [
      { code: "ES", name: "Spain" },
      { code: "MX", name: "Mexico" },
      { code: "AR", name: "Argentina" },
      { code: "CO", name: "Colombia" },
    ],
    fr: [
      { code: "FR", name: "France" },
      { code: "CA", name: "Canada" },
      { code: "BE", name: "Belgium" },
      { code: "CH", name: "Switzerland" },
    ],
    pt: [
      { code: "PT", name: "Portugal" },
      { code: "BR", name: "Brazil" },
    ],
    zh: [
      { code: "CN", name: "China" },
      { code: "TW", name: "Taiwan" },
      { code: "HK", name: "Hong Kong" },
    ],
    en: [
      { code: "US", name: "United States" },
      { code: "GB", name: "United Kingdom" },
      { code: "AU", name: "Australia" },
      { code: "CA", name: "Canada" },
    ],
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Content Localization</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="content">Original Content</Label>
            <Textarea
              id="content"
              placeholder="Enter the content you want to localize..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={5}
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="target-language">Target Language</Label>
              <Select
                value={options.targetLanguage}
                onValueChange={(value) =>
                  setOptions({
                    ...options,
                    targetLanguage: value,
                    targetRegion: "", // Reset region when language changes
                  })
                }
              >
                <SelectTrigger id="target-language">
                  <SelectValue placeholder="Select target language" />
                </SelectTrigger>
                <SelectContent>
                  {languages.map((language) => (
                    <SelectItem key={language.code} value={language.code}>
                      {language.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="target-region">Target Region (Optional)</Label>
              <Select
                value={options.targetRegion || ""}
                onValueChange={(value) => setOptions({ ...options, targetRegion: value })}
              >
                <SelectTrigger id="target-region">
                  <SelectValue placeholder="Select target region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {regions[options.targetLanguage as keyof typeof regions]?.map((region) => (
                    <SelectItem key={region.code} value={region.code}>
                      {region.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="preserve-formatting"
                checked={options.preserveFormatting}
                onCheckedChange={(checked) => setOptions({ ...options, preserveFormatting: checked as boolean })}
              />
              <Label htmlFor="preserve-formatting">Preserve original formatting</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="adapt-cultural"
                checked={options.adaptCulturalReferences}
                onCheckedChange={(checked) => setOptions({ ...options, adaptCulturalReferences: checked as boolean })}
              />
              <Label htmlFor="adapt-cultural">Adapt cultural references for target language/region</Label>
            </div>
          </div>

          <Button type="submit" disabled={loading || !content.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Localizing...
              </>
            ) : (
              "Localize Content"
            )}
          </Button>
        </form>

        {localizedContent && (
          <div className="mt-6">
            <Label htmlFor="localized-content">Localized Content</Label>
            <div className="mt-2 p-4 bg-muted rounded-md whitespace-pre-wrap">{localizedContent}</div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => {
                if (onLocalized) {
                  onLocalized(localizedContent)
                }
              }}
            >
              Use This Content
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

