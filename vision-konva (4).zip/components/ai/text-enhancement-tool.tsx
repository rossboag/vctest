"use client"

import type React from "react"

import { useState } from "react"
import { useTextEnhancement } from "@/hooks/use-text-enhancement"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"
import type { ContentEnhancementOptions } from "@/lib/ai-content-service"

interface TextEnhancementToolProps {
  projectId?: string
  onEnhanced?: (enhancedText: string) => void
  initialContent?: string
}

export function TextEnhancementTool({ projectId, onEnhanced, initialContent = "" }: TextEnhancementToolProps) {
  const [content, setContent] = useState(initialContent)
  const [enhancedContent, setEnhancedContent] = useState("")
  const [options, setOptions] = useState<ContentEnhancementOptions>({
    tone: "professional",
    purpose: "informational",
    targetAudience: "general",
    length: "medium",
    format: "paragraph",
  })

  const { enhanceText, loading } = useTextEnhancement({
    onSuccess: (data) => {
      setEnhancedContent(data.enhancedContent)
      if (onEnhanced) {
        onEnhanced(data.enhancedContent)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await enhanceText(content, options, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>AI Text Enhancement</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="content">Original Text</Label>
            <Textarea
              id="content"
              placeholder="Enter text to enhance or describe what you want to generate..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={5}
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tone">Tone</Label>
              <Select value={options.tone} onValueChange={(value) => setOptions({ ...options, tone: value as any })}>
                <SelectTrigger id="tone">
                  <SelectValue placeholder="Select tone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="persuasive">Persuasive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="purpose">Purpose</Label>
              <Select
                value={options.purpose}
                onValueChange={(value) => setOptions({ ...options, purpose: value as any })}
              >
                <SelectTrigger id="purpose">
                  <SelectValue placeholder="Select purpose" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="informational">Informational</SelectItem>
                  <SelectItem value="educational">Educational</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="technical">Technical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="format">Format</Label>
              <Select
                value={options.format}
                onValueChange={(value) => setOptions({ ...options, format: value as any })}
              >
                <SelectTrigger id="format">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="paragraph">Paragraph</SelectItem>
                  <SelectItem value="bullet">Bullet Points</SelectItem>
                  <SelectItem value="numbered">Numbered List</SelectItem>
                  <SelectItem value="headline">Headline</SelectItem>
                  <SelectItem value="slogan">Slogan</SelectItem>
                  <SelectItem value="quote">Quote</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="length">Length</Label>
              <Select
                value={options.length as string}
                onValueChange={(value) => setOptions({ ...options, length: value as any })}
              >
                <SelectTrigger id="length">
                  <SelectValue placeholder="Select length" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Short</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="long">Long</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={loading || !content.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enhancing...
              </>
            ) : (
              "Enhance Text"
            )}
          </Button>
        </form>

        {enhancedContent && (
          <div className="mt-6">
            <Label htmlFor="enhanced-content">Enhanced Text</Label>
            <div className="mt-2 p-4 bg-muted rounded-md whitespace-pre-wrap">{enhancedContent}</div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => {
                if (onEnhanced) {
                  onEnhanced(enhancedContent)
                }
              }}
            >
              Use This Text
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

