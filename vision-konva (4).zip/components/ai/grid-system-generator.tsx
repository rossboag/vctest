"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useGridSystem } from "@/hooks/use-grid-system"
import { Loader2 } from "lucide-react"
import type { GridSystem } from "@/lib/ai-layout-service"

interface GridSystemGeneratorProps {
  projectId?: string
  canvasSize: { width: number; height: number }
  onGridGenerated?: (gridSystem: GridSystem) => void
}

export function GridSystemGenerator({ projectId, canvasSize, onGridGenerated }: GridSystemGeneratorProps) {
  const [complexity, setComplexity] = useState<"simple" | "standard" | "complex">("standard")

  const { generateGridSystem, loading, gridSystem } = useGridSystem({
    onSuccess: (grid) => {
      if (onGridGenerated) {
        onGridGenerated(grid)
      }
    },
  })

  const handleGenerate = async () => {
    await generateGridSystem(canvasSize, complexity, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Generate Grid System</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Generate a grid system for your design based on the canvas size. This will provide a foundation for
            alignment and layout structure.
          </p>

          <div className="space-y-2">
            <label className="text-sm font-medium">Complexity</label>
            <Select value={complexity} onValueChange={(value) => setComplexity(value as any)}>
              <SelectTrigger>
                <SelectValue placeholder="Select complexity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="simple">Simple</SelectItem>
                <SelectItem value="standard">Standard</SelectItem>
                <SelectItem value="complex">Complex</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {complexity === "simple" && "Simple: Basic grid with fewer columns and consistent spacing."}
              {complexity === "standard" && "Standard: Balanced grid system with moderate complexity."}
              {complexity === "complex" && "Complex: Advanced grid with more columns and varied spacing."}
            </p>
          </div>

          <Button onClick={handleGenerate} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating Grid...
              </>
            ) : (
              "Generate Grid System"
            )}
          </Button>

          {gridSystem && (
            <div className="mt-4 space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Generated Grid System:</h3>
                <div className="p-4 bg-muted rounded-md">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="font-medium">Columns:</span> {gridSystem.columns}
                    </div>
                    {gridSystem.rows && (
                      <div>
                        <span className="font-medium">Rows:</span> {gridSystem.rows}
                      </div>
                    )}
                    <div>
                      <span className="font-medium">Column Gap:</span> {gridSystem.columnGap}px
                    </div>
                    {gridSystem.rowGap && (
                      <div>
                        <span className="font-medium">Row Gap:</span> {gridSystem.rowGap}px
                      </div>
                    )}
                    <div>
                      <span className="font-medium">Margin:</span> {gridSystem.margin}px
                    </div>
                    <div>
                      <span className="font-medium">Padding:</span> {gridSystem.padding}px
                    </div>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => onGridGenerated && onGridGenerated(gridSystem)}
              >
                Apply Grid System
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

