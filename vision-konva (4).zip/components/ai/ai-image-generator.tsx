"use client"

import type React from "react"

import { useState } from "react"
import { useAIImage, type ImageGenerationInput } from "@/hooks/use-ai-image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ImageIcon } from "lucide-react"
import { AIErrorMessage } from "./ai-error-message"
import Image from "next/image"

interface AIImageGeneratorProps {
  onGenerated?: (images: string[]) => void
  defaultPrompt?: string
  defaultWidth?: number
  defaultHeight?: number
  defaultStyle?: string
  defaultNumberOfImages?: number
}

export function AIImageGenerator({
  onGenerated,
  defaultPrompt = "",
  defaultWidth = 512,
  defaultHeight = 512,
  defaultStyle = "realistic",
  defaultNumberOfImages = 1,
}: AIImageGeneratorProps) {
  const [prompt, setPrompt] = useState(defaultPrompt)
  const [width, setWidth] = useState(defaultWidth)
  const [height, setHeight] = useState(defaultHeight)
  const [style, setStyle] = useState(defaultStyle)
  const [numberOfImages, setNumberOfImages] = useState(defaultNumberOfImages)

  const { execute, status, data, error, reset } = useAIImage({
    onSuccess: (data) => {
      onGenerated?.(data.images)
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const input: ImageGenerationInput = {
      prompt,
      width,
      height,
      style,
      numberOfImages,
    }

    await execute(input)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ImageIcon className="h-5 w-5" />
          AI Image Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt">Prompt</Label>
            <Input
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the image you want to generate..."
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="width">Width: {width}px</Label>
              <Slider
                id="width"
                min={256}
                max={1024}
                step={64}
                value={[width]}
                onValueChange={(value) => setWidth(value[0])}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="height">Height: {height}px</Label>
              <Slider
                id="height"
                min={256}
                max={1024}
                step={64}
                value={[height]}
                onValueChange={(value) => setHeight(value[0])}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="style">Style</Label>
            <select
              id="style"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2"
            >
              <option value="realistic">Realistic</option>
              <option value="cartoon">Cartoon</option>
              <option value="3d">3D Render</option>
              <option value="sketch">Sketch</option>
              <option value="painting">Painting</option>
            </select>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="numberOfImages">Number of Images: {numberOfImages}</Label>
            </div>
            <Slider
              id="numberOfImages"
              min={1}
              max={4}
              step={1}
              value={[numberOfImages]}
              onValueChange={(value) => setNumberOfImages(value[0])}
            />
          </div>

          <Button type="submit" className="w-full" disabled={status === "loading"}>
            {status === "loading" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Image"
            )}
          </Button>
        </form>

        {error && <AIErrorMessage error={error} onRetry={handleSubmit} />}

        {data && data.images.length > 0 && (
          <div className="mt-4">
            <h3 className="font-medium">Generated Images:</h3>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {data.images.map((imageUrl, index) => (
                <div key={index} className="relative aspect-square overflow-hidden rounded-md">
                  <Image
                    src={imageUrl || "/placeholder.svg"}
                    alt={`Generated image ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={reset} className="mt-2">
              Reset
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

