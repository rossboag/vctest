"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAnimationPresets } from "@/hooks/use-animation-presets"
import { Loader2 } from "lucide-react"
import type { AnimationPreset } from "@/lib/ai-animation-service"

interface AIAnimationPresetCreatorProps {
  projectId?: string
  onCreated?: (preset: AnimationPreset) => void
  title?: string
}

export function AIAnimationPresetCreator({
  projectId,
  onCreated,
  title = "Create Animation Preset",
}: AIAnimationPresetCreatorProps) {
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("general")
  const [duration, setDuration] = useState(2)

  const { createPreset, loading } = useAnimationPresets()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !description.trim() || !category.trim()) return

    const preset = await createPreset(name, description, category, duration, projectId)

    if (onCreated) {
      onCreated(preset)
    }

    // Reset form
    setName("")
    setDescription("")
    setCategory("general")
    setDuration(2)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Name</label>
            <Input placeholder="Preset name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Description</label>
            <Textarea
              placeholder="Describe what this animation does"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="resize-none"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <Input
                placeholder="Category (e.g., entrance, exit, emphasis)"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Duration (seconds)</label>
              <Input
                type="number"
                min={0.5}
                max={10}
                step={0.1}
                value={duration}
                onChange={(e) => setDuration(Number.parseFloat(e.target.value))}
                required
              />
            </div>
          </div>

          <Button type="submit" disabled={loading || !name.trim() || !description.trim() || !category.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Preset"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

