"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useDesignTrend } from "@/hooks/use-design-trend"
import { Loader2, TrendingUp } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

interface DesignTrendToolProps {
  projectId?: string
  elements?: any[]
  onTrendApplied?: (result: any) => void
}

const POPULAR_TRENDS = [
  "Neomorphism",
  "Glassmorphism",
  "Brutalism",
  "Minimalism",
  "Maximalism",
  "Retro",
  "Y2K",
  "Cyberpunk",
  "Memphis",
  "Flat Design",
  "Material Design",
  "Neumorphism",
  "Claymorphism",
  "Dark Mode",
  "Gradient 2.0",
]

export function DesignTrendTool({ projectId, elements, onTrendApplied }: DesignTrendToolProps) {
  const [trendName, setTrendName] = useState("")
  const [customTrend, setCustomTrend] = useState("")
  const [year, setYear] = useState<number | undefined>(undefined)
  const [adaptationLevel, setAdaptationLevel] = useState<"subtle" | "moderate" | "full">("moderate")

  const { getDesignTrend, applyDesignTrend, loading, trend } = useDesignTrend({
    onSuccess: (result) => {
      toast.success("Design trend information retrieved!")
    },
  })

  const handleGetTrend = async () => {
    const finalTrendName = trendName === "custom" ? customTrend : trendName
    if (!finalTrendName) {
      toast.error("Please select or enter a design trend")
      return
    }

    await getDesignTrend(finalTrendName, year, projectId)
  }

  const handleApplyTrend = async () => {
    if (!elements || elements.length === 0) {
      toast.error("No elements available to apply trend")
      return
    }

    const finalTrendName = trendName === "custom" ? customTrend : trendName
    if (!finalTrendName) {
      toast.error("Please select or enter a design trend")
      return
    }

    const result = await applyDesignTrend(elements, finalTrendName, adaptationLevel, projectId)

    if (onTrendApplied) {
      onTrendApplied(result)
    }

    toast.success("Design trend applied successfully!")
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="h-5 w-5 mr-2" />
          Design Trend Tool
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Design Trend</label>
            <div className="grid grid-cols-3 gap-2">
              {POPULAR_TRENDS.slice(0, 9).map((trend) => (
                <Button
                  key={trend}
                  type="button"
                  variant={trendName === trend.toLowerCase() ? "default" : "outline"}
                  className="h-auto py-2"
                  onClick={() => {
                    setTrendName(trend.toLowerCase())
                    setCustomTrend("")
                  }}
                >
                  {trend}
                </Button>
              ))}
              <Button
                type="button"
                variant={trendName === "custom" ? "default" : "outline"}
                className="h-auto py-2"
                onClick={() => setTrendName("custom")}
              >
                Custom
              </Button>
            </div>

            {trendName === "custom" && (
              <Input
                placeholder="Enter custom trend name"
                value={customTrend}
                onChange={(e) => setCustomTrend(e.target.value)}
                className="mt-2"
              />
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Year (optional)</label>
            <Input
              type="number"
              placeholder="e.g., 2023"
              value={year || ""}
              onChange={(e) => setYear(e.target.value ? Number(e.target.value) : undefined)}
            />
          </div>

          <Button
            type="button"
            variant="outline"
            onClick={handleGetTrend}
            disabled={loading || !trendName || (trendName === "custom" && !customTrend)}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              "Get Trend Information"
            )}
          </Button>

          {trend && (
            <div className="mt-4 space-y-4">
              <div>
                <h3 className="font-medium text-lg">{trend.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {trend.year ? `${trend.year} • ` : ""}
                  {trend.id}
                </p>
              </div>

              <p className="text-sm">{trend.description}</p>

              <div>
                <h4 className="text-sm font-medium mb-2">Characteristics</h4>
                <div className="flex flex-wrap gap-1">
                  {trend.characteristics.map((char, index) => (
                    <span key={index} className="bg-muted px-2 py-1 rounded-full text-xs">
                      {char}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Colors</h4>
                  <div className="flex flex-wrap gap-1">
                    {trend.colors.map((color, index) => (
                      <div
                        key={index}
                        className="w-8 h-8 rounded-md"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">Typography</h4>
                  <div className="flex flex-wrap gap-1">
                    {trend.typography.map((font, index) => (
                      <span key={index} className="bg-muted px-2 py-1 rounded-md text-xs">
                        {font}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {elements && elements.length > 0 && (
                <div className="space-y-4 pt-4 border-t">
                  <h4 className="font-medium">Apply This Trend</h4>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Adaptation Level</label>
                    <RadioGroup
                      value={adaptationLevel}
                      onValueChange={(value) => setAdaptationLevel(value as "subtle" | "moderate" | "full")}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="subtle" id="subtle" />
                        <Label htmlFor="subtle">Subtle</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="moderate" id="moderate" />
                        <Label htmlFor="moderate">Moderate</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="full" id="full" />
                        <Label htmlFor="full">Full</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <Button onClick={handleApplyTrend} disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Applying...
                      </>
                    ) : (
                      "Apply Trend to Design"
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

