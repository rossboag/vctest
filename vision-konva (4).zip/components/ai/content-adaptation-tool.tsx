"use client"

import type React from "react"

import { useState } from "react"
import { useContentAdaptation } from "@/hooks/use-content-adaptation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Loader2 } from "lucide-react"
import type { ContentAdaptationOptions } from "@/lib/ai-content-service"

interface ContentAdaptationToolProps {
  projectId?: string
  onAdapted?: (adaptedContent: string) => void
  initialContent?: string
}

export function ContentAdaptationTool({ projectId, onAdapted, initialContent = "" }: ContentAdaptationToolProps) {
  const [content, setContent] = useState(initialContent)
  const [adaptedContent, setAdaptedContent] = useState("")
  const [options, setOptions] = useState<ContentAdaptationOptions>({
    platform: "social",
    specificPlatform: "",
    constraints: {
      maxLength: 0,
      format: "",
      tone: "",
    },
  })

  const { adaptContent, loading } = useContentAdaptation({
    onSuccess: (data) => {
      setAdaptedContent(data.adaptedContent)
      if (onAdapted) {
        onAdapted(data.adaptedContent)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim()) return
    await adaptContent(content, options, projectId)
  }

  const platformOptions = [
    { value: "social", label: "Social Media" },
    { value: "web", label: "Website" },
    { value: "print", label: "Print" },
    { value: "email", label: "Email" },
    { value: "presentation", label: "Presentation" },
  ]

  const specificPlatformOptions = {
    social: [
      { value: "instagram", label: "Instagram" },
      { value: "twitter", label: "Twitter" },
      { value: "facebook", label: "Facebook" },
      { value: "linkedin", label: "LinkedIn" },
      { value: "tiktok", label: "TikTok" },
    ],
    web: [
      { value: "blog", label: "Blog" },
      { value: "landing", label: "Landing Page" },
      { value: "product", label: "Product Page" },
      { value: "about", label: "About Page" },
    ],
    print: [
      { value: "brochure", label: "Brochure" },
      { value: "flyer", label: "Flyer" },
      { value: "poster", label: "Poster" },
      { value: "magazine", label: "Magazine" },
    ],
    email: [
      { value: "newsletter", label: "Newsletter" },
      { value: "promotional", label: "Promotional" },
      { value: "transactional", label: "Transactional" },
      { value: "welcome", label: "Welcome Email" },
    ],
    presentation: [
      { value: "slides", label: "Slides" },
      { value: "pitch", label: "Pitch Deck" },
      { value: "training", label: "Training" },
    ],
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Content Adaptation</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="content">Original Content</Label>
            <Textarea
              id="content"
              placeholder="Enter the content you want to adapt..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={5}
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="platform">Platform Type</Label>
              <Select
                value={options.platform}
                onValueChange={(value) =>
                  setOptions({
                    ...options,
                    platform: value as any,
                    specificPlatform: "", // Reset specific platform when platform changes
                  })
                }
              >
                <SelectTrigger id="platform">
                  <SelectValue placeholder="Select platform type" />
                </SelectTrigger>
                <SelectContent>
                  {platformOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="specific-platform">Specific Platform</Label>
              <Select
                value={options.specificPlatform}
                onValueChange={(value) =>
                  setOptions({
                    ...options,
                    specificPlatform: value,
                  })
                }
              >
                <SelectTrigger id="specific-platform">
                  <SelectValue placeholder="Select specific platform" />
                </SelectTrigger>
                <SelectContent>
                  {options.platform &&
                    specificPlatformOptions[options.platform as keyof typeof specificPlatformOptions]?.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Constraints</Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="max-length">Max Length (chars, 0 = no limit)</Label>
                <Input
                  id="max-length"
                  type="number"
                  min={0}
                  value={options.constraints?.maxLength || 0}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      constraints: {
                        ...options.constraints,
                        maxLength: Number.parseInt(e.target.value) || 0,
                      },
                    })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="format">Format</Label>
                <Input
                  id="format"
                  placeholder="e.g., caption, headline..."
                  value={options.constraints?.format || ""}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      constraints: {
                        ...options.constraints,
                        format: e.target.value,
                      },
                    })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="tone">Tone</Label>
                <Input
                  id="tone"
                  placeholder="e.g., casual, professional..."
                  value={options.constraints?.tone || ""}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      constraints: {
                        ...options.constraints,
                        tone: e.target.value,
                      },
                    })
                  }
                />
              </div>
            </div>
          </div>

          <Button type="submit" disabled={loading || !content.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adapting...
              </>
            ) : (
              "Adapt Content"
            )}
          </Button>
        </form>

        {adaptedContent && (
          <div className="mt-6">
            <Label htmlFor="adapted-content">Adapted Content</Label>
            <div className="mt-2 p-4 bg-muted rounded-md whitespace-pre-wrap">{adaptedContent}</div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => {
                if (onAdapted) {
                  onAdapted(adaptedContent)
                }
              }}
            >
              Use This Content
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

