"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useElementPositioning } from "@/hooks/use-element-positioning"
import { Loader2 } from "lucide-react"
import type { LayoutElement } from "@/lib/ai-layout-service"

interface ElementPositioningOptimizerProps {
  projectId?: string
  canvasSize: { width: number; height: number }
  elements: LayoutElement[]
  onElementsOptimized?: (elements: LayoutElement[]) => void
}

export function ElementPositioningOptimizer({
  projectId,
  canvasSize,
  elements,
  onElementsOptimized,
}: ElementPositioningOptimizerProps) {
  const { optimizePositioning, loading, optimizedElements } = useElementPositioning({
    onSuccess: (elements) => {
      if (onElementsOptimized) {
        onElementsOptimized(elements)
      }
    },
  })

  const handleOptimize = async () => {
    await optimizePositioning(elements, canvasSize, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Optimize Element Positioning</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Optimize the positioning of elements to improve the overall layout. This will adjust element positions
            according to design principles such as balance, proximity, and visual hierarchy.
          </p>

          <Button onClick={handleOptimize} disabled={loading || elements.length === 0} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Optimizing...
              </>
            ) : (
              "Optimize Positioning"
            )}
          </Button>

          {optimizedElements && (
            <div className="mt-4">
              <h3 className="text-sm font-medium mb-2">Optimized Elements:</h3>
              <div className="h-[200px] overflow-auto p-4 bg-muted rounded-md">
                <pre className="text-xs">{JSON.stringify(optimizedElements, null, 2)}</pre>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="mt-2"
                onClick={() => onElementsOptimized && onElementsOptimized(optimizedElements)}
              >
                Apply Optimization
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

