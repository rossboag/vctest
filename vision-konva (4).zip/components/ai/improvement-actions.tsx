"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useImprovementActions } from "@/hooks/use-improvement-actions"
import { Loader2, Wand2, ArrowRight } from "lucide-react"
import type { DesignAnalysisResult, DesignElement } from "@/lib/ai-design-service"

interface ImprovementAction {
  elementId?: string
  action: string
  property?: string
  currentValue?: any
  suggestedValue?: any
  reason: string
  priority: number
}

interface ImprovementActionsProps {
  projectId?: string
  analysisResult: DesignAnalysisResult
  elements: DesignElement[]
  canvasWidth: number
  canvasHeight: number
  onApplyAction?: (action: ImprovementAction) => void
  onApplyAllActions?: (actions: ImprovementAction[]) => void
}

export function ImprovementActions({
  projectId,
  analysisResult,
  elements,
  canvasWidth,
  canvasHeight,
  onApplyAction,
  onApplyAllActions,
}: ImprovementActionsProps) {
  const { generateActions, loading, actions } = useImprovementActions()

  const handleGenerate = async () => {
    await generateActions(analysisResult, elements, canvasWidth, canvasHeight, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Wand2 className="h-5 w-5 mr-2" />
          Improvement Actions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Generate specific actions to improve your design based on the analysis.
          </p>

          <Button
            onClick={handleGenerate}
            disabled={loading || !analysisResult || elements.length === 0}
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Wand2 className="mr-2 h-4 w-4" />
                Generate Improvement Actions
              </>
            )}
          </Button>

          {actions.length > 0 && (
            <div className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium">Actions ({actions.length}):</h3>
                <Button variant="outline" size="sm" onClick={() => onApplyAllActions && onApplyAllActions(actions)}>
                  Apply All
                </Button>
              </div>

              <div className="space-y-3">
                {actions
                  .sort((a, b) => b.priority - a.priority)
                  .map((action, index) => (
                    <Card key={index} className="overflow-hidden">
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium flex items-center">
                            <span className="bg-primary text-primary-foreground w-5 h-5 rounded-full flex items-center justify-center text-xs mr-2">
                              {action.priority}
                            </span>
                            {action.action}
                          </h4>
                          {action.elementId && (
                            <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                              Element: {action.elementId}
                            </span>
                          )}
                        </div>

                        <p className="text-sm text-muted-foreground mb-3">{action.reason}</p>

                        {action.property &&
                          (action.currentValue !== undefined || action.suggestedValue !== undefined) && (
                            <div className="flex items-center gap-2 mb-3 p-2 bg-muted rounded-md">
                              {action.currentValue !== undefined && (
                                <div className="flex-1">
                                  <p className="text-xs text-muted-foreground">Current {action.property}:</p>
                                  <div className="text-sm font-medium">
                                    {typeof action.currentValue === "object"
                                      ? JSON.stringify(action.currentValue)
                                      : String(action.currentValue)}
                                  </div>
                                </div>
                              )}

                              {action.currentValue !== undefined && action.suggestedValue !== undefined && (
                                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                              )}

                              {action.suggestedValue !== undefined && (
                                <div className="flex-1">
                                  <p className="text-xs text-muted-foreground">Suggested {action.property}:</p>
                                  <div className="text-sm font-medium">
                                    {typeof action.suggestedValue === "object"
                                      ? JSON.stringify(action.suggestedValue)
                                      : String(action.suggestedValue)}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => onApplyAction && onApplyAction(action)}
                        >
                          Apply Action
                        </Button>
                      </div>
                    </Card>
                  ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

