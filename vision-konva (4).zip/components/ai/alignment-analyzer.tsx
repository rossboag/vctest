"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAlignment } from "@/hooks/use-alignment"
import { Loader2 } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { LayoutElement, GridSystem } from "@/lib/ai-layout-service"

interface AlignmentAnalyzerProps {
  projectId?: string
  elements: LayoutElement[]
  gridSystem?: GridSystem
  onElementsOptimized?: (elements: LayoutElement[]) => void
}

export function AlignmentAnalyzer({ projectId, elements, gridSystem, onElementsOptimized }: AlignmentAnalyzerProps) {
  const { analyzeAlignment, optimizeAlignment, analyzing, optimizing, analysis, optimizedElements } = useAlignment({
    onAnalysisSuccess: (data) => {
      // Handle successful analysis
    },
    onOptimizationSuccess: (elements) => {
      if (onElementsOptimized) {
        onElementsOptimized(elements)
      }
    },
  })

  const [activeTab, setActiveTab] = useState("analyze")

  const handleAnalyze = async () => {
    await analyzeAlignment(elements, projectId)
  }

  const handleOptimize = async () => {
    await optimizeAlignment(elements, gridSystem, projectId)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Alignment Analysis & Optimization</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="analyze">Analyze</TabsTrigger>
            <TabsTrigger value="optimize">Optimize</TabsTrigger>
          </TabsList>

          <TabsContent value="analyze" className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Analyze the alignment of elements in your layout to identify misalignments and inconsistencies. This will
              check for horizontal and vertical alignment issues.
            </p>

            <Button onClick={handleAnalyze} disabled={analyzing || elements.length === 0} className="w-full">
              {analyzing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...
                </>
              ) : (
                "Analyze Alignment"
              )}
            </Button>

            {analysis && (
              <div className="mt-4 space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-sm font-medium">Alignment Score</h3>
                    <span className="text-sm">{analysis.score}/10</span>
                  </div>
                  <Progress value={analysis.score * 10} className="h-2" />
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">Overall Feedback</h3>
                  <p className="text-sm p-3 bg-muted rounded-md">{analysis.overallFeedback}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">Issues</h3>
                  <div className="space-y-2">
                    {analysis.issues.map((issue, index) => (
                      <div key={index} className="p-3 bg-muted rounded-md">
                        <div className="flex items-start justify-between">
                          <h4 className="text-sm font-medium">Elements: {issue.elements.join(", ")}</h4>
                        </div>
                        <p className="text-sm mt-1">{issue.issue}</p>
                        <p className="text-sm mt-1 text-primary">Suggestion: {issue.suggestion}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="optimize" className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Automatically optimize the alignment of elements in your layout. This will adjust element positions to
              ensure proper alignment with each other and with the grid (if provided).
            </p>

            <Button onClick={handleOptimize} disabled={optimizing || elements.length === 0} className="w-full">
              {optimizing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Optimizing...
                </>
              ) : (
                "Optimize Alignment"
              )}
            </Button>

            {optimizedElements && (
              <div className="mt-4">
                <h3 className="text-sm font-medium mb-2">Optimized Elements:</h3>
                <div className="h-[200px] overflow-auto p-4 bg-muted rounded-md">
                  <pre className="text-xs">{JSON.stringify(optimizedElements, null, 2)}</pre>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2"
                  onClick={() => onElementsOptimized && onElementsOptimized(optimizedElements)}
                >
                  Apply Optimization
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

