"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useThemeFromImage } from "@/hooks/use-theme-from-image"
import { Loader2, Image, Copy } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import type { ThemeTemplate } from "@/lib/ai-style-service"

interface ThemeFromImageGeneratorProps {
  projectId?: string
  onThemeGenerated?: (theme: ThemeTemplate) => void
}

const STYLE_PREFERENCES = [
  "Modern",
  "Minimalist",
  "Bold",
  "Elegant",
  "Playful",
  "Corporate",
  "Vintage",
  "Futuristic",
  "Natural",
  "Artistic",
]

export function ThemeFromImageGenerator({ projectId, onThemeGenerated }: ThemeFromImageGeneratorProps) {
  const [imageUrl, setImageUrl] = useState("")
  const [themeName, setThemeName] = useState("")
  const [stylePreference, setStylePreference] = useState("")
  const [previewImage, setPreviewImage] = useState("")

  const { generateThemeFromImage, loading, theme } = useThemeFromImage({
    onSuccess: (result) => {
      if (onThemeGenerated) {
        onThemeGenerated(result)
      }
      toast.success("Theme generated successfully!")
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!imageUrl) {
      toast.error("Please provide an image URL")
      return
    }

    await generateThemeFromImage(imageUrl, themeName, stylePreference, projectId)
  }

  const handleImageUrlChange = (url: string) => {
    setImageUrl(url)
    setPreviewImage(url)
  }

  const copyValue = (value: string) => {
    navigator.clipboard.writeText(value)
    toast.success(`Copied to clipboard`)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Image className="h-5 w-5 mr-2" />
          Theme from Image
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Image URL</label>
            <Input
              placeholder="https://example.com/image.jpg"
              value={imageUrl}
              onChange={(e) => handleImageUrlChange(e.target.value)}
            />

            {previewImage && (
              <div className="mt-2 relative aspect-video rounded-md overflow-hidden bg-muted">
                <img
                  src={previewImage || "/placeholder.svg"}
                  alt="Preview"
                  className="object-cover w-full h-full"
                  onError={() => setPreviewImage("")}
                />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Theme Name (optional)</label>
            <Input
              placeholder="Summer Vibes, Corporate Blue, etc."
              value={themeName}
              onChange={(e) => setThemeName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Style Preference (optional)</label>
            <Select value={stylePreference} onValueChange={setStylePreference}>
              <SelectTrigger>
                <SelectValue placeholder="Select style preference" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {STYLE_PREFERENCES.map((style) => (
                  <SelectItem key={style} value={style.toLowerCase()}>
                    {style}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button type="submit" disabled={loading || !imageUrl}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Theme"
            )}
          </Button>
        </form>

        {theme && (
          <div className="mt-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{theme.name}</h3>
              <span className="text-xs text-muted-foreground">{theme.id}</span>
            </div>

            <p className="text-sm">{theme.description}</p>

            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-2">Colors</h4>
                <div className="grid grid-cols-5 gap-2">
                  {Object.entries(theme.colors).map(([key, color]) => (
                    <div
                      key={key}
                      className="p-2 rounded-md flex flex-col items-center justify-center h-16 relative group cursor-pointer"
                      style={{
                        backgroundColor: color,
                        color: ["background", "surface"].includes(key) ? "black" : "white",
                      }}
                      onClick={() => copyValue(color)}
                    >
                      <span className="font-medium text-xs capitalize">{key}</span>
                      <span className="text-xs opacity-90">{color}</span>
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 rounded-md">
                        <Copy className="h-4 w-4 text-white" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Typography</h4>
                <div className="space-y-1 bg-muted p-3 rounded-md">
                  <div className="flex justify-between">
                    <span className="text-sm">Heading Font:</span>
                    <span
                      className="text-sm font-medium cursor-pointer hover:underline"
                      onClick={() => copyValue(theme.typography.headingFont)}
                    >
                      {theme.typography.headingFont}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Body Font:</span>
                    <span
                      className="text-sm font-medium cursor-pointer hover:underline"
                      onClick={() => copyValue(theme.typography.bodyFont)}
                    >
                      {theme.typography.bodyFont}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Mono Font:</span>
                    <span
                      className="text-sm font-medium cursor-pointer hover:underline"
                      onClick={() => copyValue(theme.typography.monoFont)}
                    >
                      {theme.typography.monoFont}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Base Font Size:</span>
                    <span className="text-sm font-medium">{theme.typography.baseFontSize}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Scale Ratio:</span>
                    <span className="text-sm font-medium">{theme.typography.scaleRatio}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Spacing</h4>
                  <div className="bg-muted p-3 rounded-md">
                    <div className="flex justify-between">
                      <span className="text-sm">Base Unit:</span>
                      <span className="text-sm font-medium">{theme.spacing.baseUnit}</span>
                    </div>
                    <div className="mt-1">
                      <span className="text-sm">Scale:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {theme.spacing.scale.map((value, index) => (
                          <span key={index} className="text-xs bg-background px-2 py-1 rounded-full">
                            {value}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">Border Radius</h4>
                  <div className="bg-muted p-3 rounded-md space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm">Small:</span>
                      <span className="text-sm font-medium">{theme.borderRadius.small}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Medium:</span>
                      <span className="text-sm font-medium">{theme.borderRadius.medium}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Large:</span>
                      <span className="text-sm font-medium">{theme.borderRadius.large}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Pill:</span>
                      <span className="text-sm font-medium">{theme.borderRadius.pill}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                if (onThemeGenerated && theme) {
                  onThemeGenerated(theme)
                }
              }}
            >
              Apply Theme to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

