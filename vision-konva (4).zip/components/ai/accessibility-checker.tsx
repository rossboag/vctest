"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAccessibilityCheck } from "@/hooks/use-accessibility-check"
import { Loader2, Accessibility, AlertTriangle, CheckCircle, AlertCircle } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

interface AccessibilityCheckerProps {
  projectId?: string
  designElements: any[]
  onCheckComplete?: (result: any) => void
}

export function AccessibilityChecker({ projectId, designElements, onCheckComplete }: AccessibilityCheckerProps) {
  const { checkAccessibility, loading, result } = useAccessibilityCheck({
    onSuccess: (data) => {
      if (onCheckComplete) {
        onCheckComplete(data)
      }
    },
  })

  const handleCheck = async () => {
    await checkAccessibility(designElements, projectId)
  }

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-500"
    if (score >= 6) return "text-yellow-500"
    return "text-red-500"
  }

  const getProgressColor = (score: number) => {
    if (score >= 8) return "bg-green-500"
    if (score >= 6) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high":
        return <AlertCircle className="h-4 w-4" />
      case "medium":
        return <AlertTriangle className="h-4 w-4" />
      case "low":
        return <AlertCircle className="h-4 w-4" />
      default:
        return null
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Accessibility className="h-5 w-5 mr-2" />
          Accessibility Checker
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!result ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Check your design for accessibility issues to ensure it's usable by everyone.
            </p>
            <Button onClick={handleCheck} disabled={loading || designElements.length === 0}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Checking...
                </>
              ) : (
                "Check Accessibility"
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Accessibility Score</h3>
              <span className={`text-2xl font-bold ${getScoreColor(result.score)}`}>{result.score}/10</span>
            </div>

            <Progress value={result.score * 10} className={getProgressColor(result.score)} />

            <div className="p-4 bg-muted rounded-md">
              <h4 className="font-medium mb-2">Overall Feedback</h4>
              <p className="text-sm">{result.overallFeedback}</p>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Issues Found ({result.issues.length})</h4>

              {result.issues.length === 0 ? (
                <div className="flex items-center justify-center p-4 bg-green-50 text-green-700 rounded-md">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span>No accessibility issues found!</span>
                </div>
              ) : (
                <div className="space-y-2">
                  {result.issues.map((issue: any, index: number) => (
                    <div key={index} className="p-3 border rounded-md">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{issue.element}</span>
                        <Badge className={getSeverityColor(issue.severity)}>
                          <span className="flex items-center">
                            {getSeverityIcon(issue.severity)}
                            <span className="ml-1 capitalize">{issue.severity}</span>
                          </span>
                        </Badge>
                      </div>
                      <p className="text-sm mb-1">{issue.issue}</p>
                      <p className="text-sm text-muted-foreground">
                        <span className="font-medium">Suggestion:</span> {issue.suggestion}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Button onClick={handleCheck} variant="outline">
              Re-check Accessibility
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

