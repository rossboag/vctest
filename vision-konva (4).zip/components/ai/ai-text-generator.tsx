"use client"

import type React from "react"

import { useState } from "react"
import { useAIText, type TextGenerationInput } from "@/hooks/use-ai-text"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Sparkles } from "lucide-react"
import { AIErrorMessage } from "./ai-error-message"

interface AITextGeneratorProps {
  onGenerated?: (text: string) => void
  defaultPrompt?: string
  defaultMaxLength?: number
  defaultTemperature?: number
  defaultStyle?: string
}

export function AITextGenerator({
  onGenerated,
  defaultPrompt = "",
  defaultMaxLength = 100,
  defaultTemperature = 0.7,
  defaultStyle = "creative",
}: AITextGeneratorProps) {
  const [prompt, setPrompt] = useState(defaultPrompt)
  const [maxLength, setMaxLength] = useState(defaultMaxLength)
  const [temperature, setTemperature] = useState(defaultTemperature)
  const [style, setStyle] = useState(defaultStyle)

  const { execute, status, data, error, reset } = useAIText({
    onSuccess: (data) => {
      onGenerated?.(data.text)
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const input: TextGenerationInput = {
      prompt,
      maxLength,
      temperature,
      style,
    }

    await execute(input)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          AI Text Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt">Prompt</Label>
            <Input
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the text you want to generate..."
              required
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="maxLength">Max Length: {maxLength}</Label>
            </div>
            <Slider
              id="maxLength"
              min={10}
              max={500}
              step={10}
              value={[maxLength]}
              onValueChange={(value) => setMaxLength(value[0])}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="temperature">Creativity: {temperature.toFixed(1)}</Label>
            </div>
            <Slider
              id="temperature"
              min={0}
              max={1}
              step={0.1}
              value={[temperature]}
              onValueChange={(value) => setTemperature(value[0])}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="style">Style</Label>
            <select
              id="style"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2"
            >
              <option value="creative">Creative</option>
              <option value="professional">Professional</option>
              <option value="casual">Casual</option>
              <option value="technical">Technical</option>
            </select>
          </div>

          <Button type="submit" className="w-full" disabled={status === "loading"}>
            {status === "loading" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Text"
            )}
          </Button>
        </form>

        {error && <AIErrorMessage error={error} onRetry={handleSubmit} />}

        {data && (
          <div className="mt-4">
            <h3 className="font-medium">Generated Text:</h3>
            <div className="mt-2 rounded-md bg-muted p-3">{data.text}</div>
            <Button variant="outline" size="sm" onClick={reset} className="mt-2">
              Reset
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

