"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useStyleTransfer } from "@/hooks/use-style-transfer"
import { Loader2, Wand2 } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "sonner"
import type { StyleTransferResult } from "@/lib/ai-style-service"

interface StyleTransferToolProps {
  projectId?: string
  sourceElements?: any[]
  targetElements?: any[]
  onStyleTransferred?: (result: StyleTransferResult) => void
}

const STYLE_ASPECTS = [
  { id: "colors", label: "Colors" },
  { id: "typography", label: "Typography" },
  { id: "spacing", label: "Spacing" },
  { id: "shapes", label: "Shapes" },
  { id: "effects", label: "Effects" },
]

export function StyleTransferTool({
  projectId,
  sourceElements: initialSourceElements,
  targetElements: initialTargetElements,
  onStyleTransferred,
}: StyleTransferToolProps) {
  const [sourceElements, setSourceElements] = useState<any[]>(initialSourceElements || [])
  const [targetElements, setTargetElements] = useState<any[]>(initialTargetElements || [])
  const [selectedAspects, setSelectedAspects] = useState<string[]>([])

  const { transferStyle, loading, result } = useStyleTransfer({
    onSuccess: (result) => {
      if (onStyleTransferred) {
        onStyleTransferred(result)
      }
      toast.success("Style transferred successfully!")
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (sourceElements.length === 0 || targetElements.length === 0) {
      toast.error("Please provide source and target elements")
      return
    }

    await transferStyle(
      sourceElements,
      targetElements,
      selectedAspects.length > 0 ? selectedAspects : undefined,
      projectId,
    )
  }

  const toggleAspect = (aspect: string) => {
    setSelectedAspects((prev) => (prev.includes(aspect) ? prev.filter((a) => a !== aspect) : [...prev, aspect]))
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Wand2 className="h-5 w-5 mr-2" />
          Style Transfer Tool
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Style Aspects to Transfer</label>
            <div className="grid grid-cols-2 gap-2">
              {STYLE_ASPECTS.map((aspect) => (
                <div key={aspect.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={aspect.id}
                    checked={selectedAspects.includes(aspect.id)}
                    onCheckedChange={() => toggleAspect(aspect.id)}
                  />
                  <label htmlFor={aspect.id} className="text-sm cursor-pointer">
                    {aspect.label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <Button type="submit" disabled={loading || sourceElements.length === 0 || targetElements.length === 0}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Transferring Style...
              </>
            ) : (
              "Transfer Style"
            )}
          </Button>
        </form>

        {result && (
          <div className="mt-6 space-y-4">
            <h3 className="font-medium">Style Transfer Results</h3>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Before</h4>
                  <div className="bg-muted p-3 rounded-md space-y-2">
                    <div>
                      <span className="text-xs font-medium">Colors:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {result.before.colors.map((color, index) => (
                          <div
                            key={index}
                            className="w-6 h-6 rounded-md"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-xs font-medium">Typography:</span>
                      <div className="text-xs mt-1">{result.before.typography.join(", ")}</div>
                    </div>
                    <div>
                      <span className="text-xs font-medium">Spacing:</span>
                      <div className="text-xs mt-1">{result.before.spacing}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">After</h4>
                  <div className="bg-muted p-3 rounded-md space-y-2">
                    <div>
                      <span className="text-xs font-medium">Colors:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {result.after.colors.map((color, index) => (
                          <div
                            key={index}
                            className="w-6 h-6 rounded-md"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-xs font-medium">Typography:</span>
                      <div className="text-xs mt-1">{result.after.typography.join(", ")}</div>
                    </div>
                    <div>
                      <span className="text-xs font-medium">Spacing:</span>
                      <div className="text-xs mt-1">{result.after.spacing}</div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Transformations</h4>
                <div className="space-y-2">
                  {result.transformations.map((transformation, index) => (
                    <div key={index} className="bg-muted p-3 rounded-md">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{transformation.type}</span>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                          {transformation.elements.length} elements
                        </span>
                      </div>
                      <p className="text-sm mt-1">{transformation.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                if (onStyleTransferred && result) {
                  onStyleTransferred(result)
                }
              }}
            >
              Apply Style Transfer to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

