"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useAnimationPresets } from "@/hooks/use-animation-presets"
import { Loader2, Search, Clock, Tag } from "lucide-react"
import type { AnimationPreset } from "@/lib/ai-animation-service"

interface AnimationPresetBrowserProps {
  onSelectPreset?: (preset: AnimationPreset) => void
  initialCategory?: string
}

export function AnimationPresetBrowser({ onSelectPreset, initialCategory }: AnimationPresetBrowserProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState(initialCategory || "")
  const [categories, setCategories] = useState<string[]>([])

  const { presets, loading, fetchPresets, searchPresets } = useAnimationPresets({
    category: initialCategory,
    initialLoad: true,
  })

  // Extract unique categories from presets
  useEffect(() => {
    if (presets.length > 0) {
      const uniqueCategories = Array.from(new Set(presets.map((preset) => preset.category)))
      setCategories(uniqueCategories)
    }
  }, [presets])

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      await searchPresets(searchQuery)
    } else {
      await fetchPresets(selectedCategory)
    }
  }

  const handleCategoryChange = async (category: string) => {
    setSelectedCategory(category)
    setSearchQuery("")
    await fetchPresets(category)
  }

  return (
    <div className="space-y-4">
      <form onSubmit={handleSearch} className="flex gap-2">
        <Input
          placeholder="Search animation presets..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
        <Button type="submit" disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
        </Button>
      </form>

      {categories.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedCategory === "" ? "default" : "outline"}
            size="sm"
            onClick={() => handleCategoryChange("")}
          >
            All
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => handleCategoryChange(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : presets.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">No animation presets found</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {presets.map((preset) => (
            <Card
              key={preset.id}
              className="cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => onSelectPreset && onSelectPreset(preset)}
            >
              <CardContent className="p-4">
                <h3 className="font-medium">{preset.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{preset.description}</p>
                <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                  <div className="flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {preset.duration}s
                  </div>
                  <div className="flex items-center">
                    <Tag className="h-3 w-3 mr-1" />
                    {preset.category}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

