"use client"

import type React from "react"

import { useState } from "react"
import { useAIAnimation, type AnimationGenerationInput, type KeyframeData } from "@/hooks/use-ai-animation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, PlayIcon } from "lucide-react"
import { AIErrorMessage } from "./ai-error-message"

interface AIAnimationGeneratorProps {
  onGenerated?: (keyframes: KeyframeData[], duration: number) => void
  elementId: string
  elementType?: string
  defaultDuration?: number
}

export function AIAnimationGenerator({
  onGenerated,
  elementId,
  elementType = "element",
  defaultDuration = 1000,
}: AIAnimationGeneratorProps) {
  const [animationType, setAnimationType] = useState<"fade" | "slide" | "bounce" | "custom">("fade")
  const [duration, setDuration] = useState(defaultDuration)
  const [customPrompt, setCustomPrompt] = useState("")

  const { execute, status, data, error, reset } = useAIAnimation({
    onSuccess: (data) => {
      onGenerated?.(data.keyframes, data.duration)
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const input: AnimationGenerationInput = {
      elementId,
      animationType,
      duration,
      customPrompt: animationType === "custom" ? customPrompt : undefined,
    }

    await execute(input)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PlayIcon className="h-5 w-5" />
          AI Animation Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="animationType">Animation Type</Label>
            <select
              id="animationType"
              value={animationType}
              onChange={(e) => setAnimationType(e.target.value as any)}
              className="w-full rounded-md border border-input bg-background px-3 py-2"
            >
              <option value="fade">Fade</option>
              <option value="slide">Slide</option>
              <option value="bounce">Bounce</option>
              <option value="custom">Custom</option>
            </select>
          </div>

          {animationType === "custom" && (
            <div className="space-y-2">
              <Label htmlFor="customPrompt">Custom Animation Description</Label>
              <Input
                id="customPrompt"
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="Describe the animation you want..."
                required={animationType === "custom"}
              />
            </div>
          )}

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="duration">Duration: {duration}ms</Label>
            </div>
            <Slider
              id="duration"
              min={100}
              max={5000}
              step={100}
              value={[duration]}
              onValueChange={(value) => setDuration(value[0])}
            />
          </div>

          <Button type="submit" className="w-full" disabled={status === "loading"}>
            {status === "loading" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Animation...
              </>
            ) : (
              "Generate Animation"
            )}
          </Button>
        </form>

        {error && <AIErrorMessage error={error} onRetry={handleSubmit} />}

        {data && (
          <div className="mt-4">
            <h3 className="font-medium">Generated Animation:</h3>
            <div className="mt-2 rounded-md bg-muted p-3">
              <p>Duration: {data.duration}ms</p>
              <p>Keyframes: {data.keyframes.length}</p>
              <div className="mt-2 max-h-40 overflow-y-auto">
                <pre className="text-xs">{JSON.stringify(data.keyframes, null, 2)}</pre>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={reset} className="mt-2">
              Reset
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

