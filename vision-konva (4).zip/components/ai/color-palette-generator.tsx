"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useColorPalette } from "@/hooks/use-color-palette"
import { Loader2, Palette, Copy } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import type { ColorPalette } from "@/lib/ai-design-service"

interface ColorPaletteGeneratorProps {
  projectId?: string
  onPaletteGenerated?: (palette: ColorPalette) => void
}

const MOODS = [
  "Calm",
  "Energetic",
  "Professional",
  "Playful",
  "Elegant",
  "Minimalist",
  "Bold",
  "Vintage",
  "Futuristic",
  "Natural",
]

const STYLES = [
  "Corporate",
  "Creative",
  "Tech",
  "Fashion",
  "Food",
  "Health",
  "Education",
  "Entertainment",
  "Travel",
  "Sports",
]

export function ColorPaletteGenerator({ projectId, onPaletteGenerated }: ColorPaletteGeneratorProps) {
  const [baseColor, setBaseColor] = useState("")
  const [mood, setMood] = useState("")
  const [style, setStyle] = useState("")

  const { generateColorPalette, loading, palette } = useColorPalette({
    onSuccess: (result) => {
      if (onPaletteGenerated) {
        onPaletteGenerated(result)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await generateColorPalette(baseColor, mood, style, projectId)
  }

  const copyColor = (color: string) => {
    navigator.clipboard.writeText(color)
    toast.success(`Copied ${color} to clipboard`)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Palette className="h-5 w-5 mr-2" />
          Color Palette Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Base Color (optional)</label>
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="#4285F4 or blue"
                value={baseColor}
                onChange={(e) => setBaseColor(e.target.value)}
                className="flex-1"
              />
              <Input
                type="color"
                value={baseColor.startsWith("#") ? baseColor : "#4285F4"}
                onChange={(e) => setBaseColor(e.target.value)}
                className="w-12 p-1 h-10"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Mood (optional)</label>
              <Select value={mood} onValueChange={setMood}>
                <SelectTrigger>
                  <SelectValue placeholder="Select mood" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {MOODS.map((m) => (
                    <SelectItem key={m} value={m.toLowerCase()}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Style (optional)</label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger>
                  <SelectValue placeholder="Select style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {STYLES.map((s) => (
                    <SelectItem key={s} value={s.toLowerCase()}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Palette"
            )}
          </Button>
        </form>

        {palette && (
          <div className="mt-6 space-y-4">
            <h3 className="font-medium">Generated Palette</h3>

            <div className="grid grid-cols-2 gap-2">
              <div
                className="p-4 rounded-md flex flex-col items-center justify-center h-24 text-white relative group"
                style={{ backgroundColor: palette.primary }}
              >
                <span className="font-medium">Primary</span>
                <span className="text-xs opacity-90">{palette.primary}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white/20 text-white"
                  onClick={() => copyColor(palette.primary)}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>

              <div
                className="p-4 rounded-md flex flex-col items-center justify-center h-24 text-white relative group"
                style={{ backgroundColor: palette.secondary }}
              >
                <span className="font-medium">Secondary</span>
                <span className="text-xs opacity-90">{palette.secondary}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white/20 text-white"
                  onClick={() => copyColor(palette.secondary)}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>

              <div
                className="p-4 rounded-md flex flex-col items-center justify-center h-24 text-white relative group"
                style={{ backgroundColor: palette.accent }}
              >
                <span className="font-medium">Accent</span>
                <span className="text-xs opacity-90">{palette.accent}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white/20 text-white"
                  onClick={() => copyColor(palette.accent)}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>

              <div
                className="p-4 rounded-md flex flex-col items-center justify-center h-24 relative group"
                style={{ backgroundColor: palette.background, color: palette.text }}
              >
                <span className="font-medium">Background</span>
                <span className="text-xs opacity-90">{palette.background}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-black/20"
                  onClick={() => copyColor(palette.background)}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>

            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Additional Colors</h4>
              <div className="flex flex-wrap gap-2">
                {palette.additional.map((color, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 rounded-md border relative group cursor-pointer"
                    style={{ backgroundColor: color }}
                    onClick={() => copyColor(color)}
                    title={color}
                  >
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 rounded-md">
                      <Copy className="h-4 w-4 text-white" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                if (onPaletteGenerated && palette) {
                  onPaletteGenerated(palette)
                }
              }}
            >
              Apply Palette to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

