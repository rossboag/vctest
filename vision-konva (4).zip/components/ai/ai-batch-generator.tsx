"use client"

import type React from "react"
import { useAIBatch, type BatchJobInput } from "@/hooks/use-ai-batch"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Layers } from "lucide-react"
import { AIErrorMessage } from "./ai-error-message"
import { Progress } from "@/components/ui/progress"

interface AIBatchGeneratorProps {
  onCompleted?: (results: Record<string, any>[]) => void
  operations: {
    type: "text" | "image" | "layout" | "animation" | "colors"
    params: Record<string, any>
    label: string
  }[]
}

export function AIBatchGenerator({ onCompleted, operations }: AIBatchGeneratorProps) {
  const { submitBatchJob, status, jobStatus, error, progress, reset } = useAIBatch({
    onSuccess: (data) => {
      if (data.results) {
        onCompleted?.(data.results)
      }
    },
    pollingInterval: 2000,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const input: BatchJobInput = {
      operations: operations.map((op) => ({
        type: op.type,
        params: op.params,
      })),
    }

    await submitBatchJob(input)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Layers className="h-5 w-5" />
          AI Batch Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <h3 className="text-sm font-medium">Operations to Run:</h3>
          <ul className="mt-2 space-y-1">
            {operations.map((op, index) => (
              <li key={index} className="text-sm">
                {index + 1}. {op.label}
              </li>
            ))}
          </ul>
        </div>

        {(status === "idle" || status === "error") && (
          <Button onClick={handleSubmit} className="w-full" disabled={operations.length === 0}>
            Start Batch Generation
          </Button>
        )}

        {(status === "submitting" || status === "polling") && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm">{status === "submitting" ? "Submitting job..." : "Processing..."}</div>
              <div className="text-sm font-medium">{Math.round(progress)}%</div>
            </div>
            <Progress value={progress} className="h-2 w-full" />

            {status === "polling" && jobStatus && (
              <div className="rounded-md bg-muted p-3 text-sm">
                <p>Job ID: {jobStatus.jobId}</p>
                <p>Status: {jobStatus.status}</p>
                {jobStatus.error && <p className="text-destructive">Error: {jobStatus.error}</p>}
              </div>
            )}
          </div>
        )}

        {status === "completed" && jobStatus?.results && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-green-600">Completed Successfully</div>
              <div className="text-sm font-medium">100%</div>
            </div>
            <Progress value={100} className="h-2 w-full" />

            <div className="rounded-md bg-muted p-3">
              <p className="text-sm font-medium">Results:</p>
              <div className="mt-2 max-h-40 overflow-y-auto">
                <pre className="text-xs">{JSON.stringify(jobStatus.results, null, 2)}</pre>
              </div>
            </div>

            <Button variant="outline" size="sm" onClick={reset} className="w-full">
              Reset
            </Button>
          </div>
        )}

        {error && <AIErrorMessage error={error} onRetry={handleSubmit} />}
      </CardContent>
    </Card>
  )
}

