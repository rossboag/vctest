"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAIAnimationSequence } from "@/hooks/use-ai-animation-sequence"
import { Loader2, Plus, X } from "lucide-react"
import type { ElementAnimationConfig } from "@/lib/ai-animation-service"

interface AIAnimationSequenceGeneratorProps {
  projectId?: string
  onGenerated?: (result: { sequenceDescription: string; elementAnimations: ElementAnimationConfig[] }) => void
  title?: string
  initialElements?: Array<{
    id: string
    type: string
    content?: string
  }>
}

export function AIAnimationSequenceGenerator({
  projectId,
  onGenerated,
  title = "Animation Sequence Generator",
  initialElements = [],
}: AIAnimationSequenceGeneratorProps) {
  const [elements, setElements] = useState(initialElements)
  const [newElement, setNewElement] = useState({
    id: "",
    type: "text",
    content: "",
  })
  const [sequenceType, setSequenceType] = useState<"sequential" | "parallel" | "staggered" | "custom">("sequential")
  const [duration, setDuration] = useState(5)
  const [description, setDescription] = useState("")

  const { generateSequence, loading, result } = useAIAnimationSequence({
    onSuccess: (data) => {
      if (onGenerated) {
        onGenerated(data)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (elements.length === 0 || !description.trim()) return

    await generateSequence(elements, sequenceType, duration, description, projectId)
  }

  const addElement = () => {
    if (newElement.id && newElement.type) {
      setElements([...elements, { ...newElement }])
      setNewElement({
        id: "",
        type: "text",
        content: "",
      })
    }
  }

  const removeElement = (index: number) => {
    setElements(elements.filter((_, i) => i !== index))
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Elements to Animate</label>

            <div className="flex flex-col space-y-2">
              {elements.map((element, index) => (
                <div key={index} className="flex items-center space-x-2 p-2 bg-muted rounded-md">
                  <div className="flex-1">
                    <span className="font-medium">{element.type}</span>
                    <span className="ml-2 text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                      ID: {element.id}
                    </span>
                    {element.content && <span className="ml-2 text-sm text-muted-foreground">"{element.content}"</span>}
                  </div>
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeElement(index)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>

            <div className="flex flex-col space-y-2 p-3 border rounded-md">
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs">Element ID</label>
                  <Input
                    placeholder="Unique ID"
                    value={newElement.id}
                    onChange={(e) => setNewElement({ ...newElement, id: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs">Element Type</label>
                  <Input
                    placeholder="text, image, etc."
                    value={newElement.type}
                    onChange={(e) => setNewElement({ ...newElement, type: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs">Content (optional)</label>
                <Input
                  placeholder="Element content"
                  value={newElement.content || ""}
                  onChange={(e) => setNewElement({ ...newElement, content: e.target.value })}
                />
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addElement}
                disabled={!newElement.id || !newElement.type}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Element
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Sequence Type</label>
              <Select value={sequenceType} onValueChange={(value) => setSequenceType(value as any)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sequence type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sequential">Sequential (One after another)</SelectItem>
                  <SelectItem value="parallel">Parallel (All at once)</SelectItem>
                  <SelectItem value="staggered">Staggered (Overlapping)</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Total Duration (seconds)</label>
              <Input
                type="number"
                min={1}
                max={30}
                step={0.5}
                value={duration}
                onChange={(e) => setDuration(Number.parseFloat(e.target.value))}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Sequence Description</label>
            <Textarea
              placeholder="Describe how you want the elements to animate (e.g., elements fade in one by one, then move to their final positions)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="resize-none"
            />
          </div>

          <Button type="submit" disabled={loading || elements.length === 0 || !description.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Animation Sequence"
            )}
          </Button>
        </form>

        {result && (
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2">Generated Sequence:</h3>
            <div className="p-4 bg-muted rounded-md overflow-auto max-h-96">
              <p className="text-sm mb-2">{result.sequenceDescription}</p>
              <pre className="text-xs">{JSON.stringify(result.elementAnimations, null, 2)}</pre>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => {
                if (onGenerated) {
                  onGenerated(result)
                }
              }}
            >
              Apply Sequence
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

