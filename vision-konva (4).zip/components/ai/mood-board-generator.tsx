"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useMoodBoard } from "@/hooks/use-mood-board"
import { Loader2, Palette, X } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import type { MoodBoard } from "@/lib/ai-style-service"

interface MoodBoardGeneratorProps {
  projectId?: string
  onMoodBoardGenerated?: (moodBoard: MoodBoard) => void
}

const MOODS = [
  "Calm",
  "Energetic",
  "Professional",
  "Playful",
  "Elegant",
  "Minimalist",
  "Bold",
  "Vintage",
  "Futuristic",
  "Natural",
  "Luxurious",
  "Rustic",
  "Vibrant",
  "Serene",
  "Mysterious",
]

const INDUSTRIES = [
  "Technology",
  "Healthcare",
  "Education",
  "Finance",
  "Retail",
  "Food & Beverage",
  "Entertainment",
  "Travel",
  "Fashion",
  "Real Estate",
  "Sports",
  "Art & Design",
  "Manufacturing",
  "Automotive",
  "Non-profit",
]

export function MoodBoardGenerator({ projectId, onMoodBoardGenerated }: MoodBoardGeneratorProps) {
  const [mood, setMood] = useState("")
  const [industry, setIndustry] = useState("")
  const [keywords, setKeywords] = useState<string[]>([])
  const [newKeyword, setNewKeyword] = useState("")

  const { generateMoodBoard, loading, moodBoard } = useMoodBoard({
    onSuccess: (result) => {
      if (onMoodBoardGenerated) {
        onMoodBoardGenerated(result)
      }
      toast.success("Mood board generated successfully!")
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!mood) {
      toast.error("Please select a mood")
      return
    }

    await generateMoodBoard(mood, industry || undefined, keywords.length > 0 ? keywords : undefined, projectId)
  }

  const addKeyword = () => {
    if (!newKeyword.trim()) return
    if (keywords.includes(newKeyword.trim())) {
      toast.error("Keyword already added")
      return
    }
    setKeywords([...keywords, newKeyword.trim()])
    setNewKeyword("")
  }

  const removeKeyword = (keyword: string) => {
    setKeywords(keywords.filter((k) => k !== keyword))
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Palette className="h-5 w-5 mr-2" />
          Mood Board Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Mood</label>
            <Select value={mood} onValueChange={setMood} required>
              <SelectTrigger>
                <SelectValue placeholder="Select mood" />
              </SelectTrigger>
              <SelectContent>
                {MOODS.map((m) => (
                  <SelectItem key={m} value={m.toLowerCase()}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Industry (optional)</label>
            <Select value={industry} onValueChange={setIndustry}>
              <SelectTrigger>
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {INDUSTRIES.map((ind) => (
                  <SelectItem key={ind} value={ind.toLowerCase()}>
                    {ind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Additional Keywords (optional)</label>
            <div className="flex gap-2">
              <Input
                placeholder="Enter keyword"
                value={newKeyword}
                onChange={(e) => setNewKeyword(e.target.value)}
                className="flex-1"
              />
              <Button type="button" variant="outline" onClick={addKeyword}>
                Add
              </Button>
            </div>

            {keywords.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {keywords.map((keyword) => (
                  <div key={keyword} className="bg-muted px-2 py-1 rounded-full text-xs flex items-center gap-1">
                    {keyword}
                    <button
                      type="button"
                      onClick={() => removeKeyword(keyword)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button type="submit" disabled={loading || !mood}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Mood Board"
            )}
          </Button>
        </form>

        {moodBoard && (
          <div className="mt-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{moodBoard.name}</h3>
              <span className="text-xs text-muted-foreground">{moodBoard.id}</span>
            </div>

            <p className="text-sm">{moodBoard.description}</p>

            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-2">Colors</h4>
                <div className="flex flex-wrap gap-2">
                  {moodBoard.colors.map((color, index) => (
                    <div
                      key={index}
                      className="w-10 h-10 rounded-md"
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Typography</h4>
                <div className="flex flex-wrap gap-2">
                  {moodBoard.typography.map((font, index) => (
                    <div key={index} className="bg-muted px-3 py-2 rounded-md text-sm">
                      {font}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Keywords</h4>
                <div className="flex flex-wrap gap-1">
                  {moodBoard.keywords.map((keyword, index) => (
                    <span key={index} className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs">
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>

              {moodBoard.inspirationImages.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Inspiration Images</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {moodBoard.inspirationImages.map((imageUrl, index) => (
                      <div key={index} className="aspect-square bg-muted rounded-md overflow-hidden">
                        <img
                          src={imageUrl || "/placeholder.svg"}
                          alt={`Inspiration ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                if (onMoodBoardGenerated && moodBoard) {
                  onMoodBoardGenerated(moodBoard)
                }
              }}
            >
              Apply Mood Board to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

