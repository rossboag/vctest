"use client"

import type React from "react"

import { useState } from "react"
import { useVideoSuggestions } from "@/hooks/use-video-suggestions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Loader2 } from "lucide-react"
import type { VideoSuggestionOptions } from "@/lib/ai-content-service"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface VideoSuggestionToolProps {
  projectId?: string
  onGenerated?: (suggestions: any) => void
}

export function VideoSuggestionTool({ projectId, onGenerated }: VideoSuggestionToolProps) {
  const [topic, setTopic] = useState("")
  const [options, setOptions] = useState<VideoSuggestionOptions>({
    duration: 60,
    style: "modern",
    purpose: "informational",
    targetAudience: "general",
    platform: "general",
  })
  const [suggestions, setSuggestions] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("overview")

  const { generateVideoSuggestions, loading } = useVideoSuggestions({
    onSuccess: (data) => {
      setSuggestions(data.suggestions)
      if (onGenerated) {
        onGenerated(data.suggestions)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!topic.trim()) return
    await generateVideoSuggestions(topic, options, projectId)
  }

  const renderSuggestionContent = () => {
    if (!suggestions) return null

    return (
      <div className="mt-6">
        <h3 className="text-lg font-medium mb-4">Video Content Plan</h3>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="scenes">Scenes</TabsTrigger>
            <TabsTrigger value="visuals">Visuals</TabsTrigger>
            <TabsTrigger value="audio">Audio</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            <div>
              <h4 className="font-medium">Title</h4>
              <p className="text-lg">{suggestions.title}</p>
            </div>

            <div>
              <h4 className="font-medium">Description</h4>
              <p>{suggestions.description}</p>
            </div>

            <div>
              <h4 className="font-medium">Key Messages</h4>
              <ul className="list-disc pl-5 space-y-1">
                {Array.isArray(suggestions.keyMessages) ? (
                  suggestions.keyMessages.map((message: string, index: number) => <li key={index}>{message}</li>)
                ) : (
                  <li>{suggestions.keyMessages}</li>
                )}
              </ul>
            </div>

            <div>
              <h4 className="font-medium">Call to Action</h4>
              <p>{suggestions.callToAction}</p>
            </div>
          </TabsContent>

          <TabsContent value="scenes" className="mt-4">
            <div className="space-y-4">
              <h4 className="font-medium">Scene Breakdown</h4>
              {Array.isArray(suggestions.scenes) ? (
                suggestions.scenes.map((scene: any, index: number) => (
                  <div key={index} className="p-3 border rounded-md">
                    <div className="flex justify-between">
                      <h5 className="font-medium">Scene {index + 1}</h5>
                      <span className="text-sm text-muted-foreground">{scene.timing || "N/A"}</span>
                    </div>
                    <p>{scene.description}</p>
                  </div>
                ))
              ) : (
                <p>{suggestions.scenes || "No scene breakdown available"}</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="visuals" className="mt-4">
            <div className="space-y-4">
              <h4 className="font-medium">Visual Suggestions</h4>
              {Array.isArray(suggestions.visualSuggestions) ? (
                suggestions.visualSuggestions.map((suggestion: string, index: number) => (
                  <div key={index} className="p-3 border rounded-md">
                    <p>{suggestion}</p>
                  </div>
                ))
              ) : (
                <p>{suggestions.visualSuggestions || "No visual suggestions available"}</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="audio" className="mt-4">
            <div className="space-y-4">
              <h4 className="font-medium">Audio/Music Suggestions</h4>
              {Array.isArray(suggestions.audioSuggestions) ? (
                suggestions.audioSuggestions.map((suggestion: string, index: number) => (
                  <div key={index} className="p-3 border rounded-md">
                    <p>{suggestion}</p>
                  </div>
                ))
              ) : (
                <p>{suggestions.audioSuggestions || "No audio suggestions available"}</p>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <Button
          variant="outline"
          size="sm"
          className="mt-4"
          onClick={() => {
            if (onGenerated) {
              onGenerated(suggestions)
            }
          }}
        >
          Use This Plan
        </Button>
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>AI Video Content Planner</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="topic">Video Topic</Label>
            <Input
              id="topic"
              placeholder="Enter the topic or subject of your video..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (seconds)</Label>
              <Input
                id="duration"
                type="number"
                min={5}
                max={600}
                value={options.duration}
                onChange={(e) => setOptions({ ...options, duration: Number.parseInt(e.target.value) || 60 })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="platform">Platform</Label>
              <Select
                value={options.platform}
                onValueChange={(value) => setOptions({ ...options, platform: value as any })}
              >
                <SelectTrigger id="platform">
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General</SelectItem>
                  <SelectItem value="youtube">YouTube</SelectItem>
                  <SelectItem value="tiktok">TikTok</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="purpose">Purpose</Label>
              <Select
                value={options.purpose}
                onValueChange={(value) => setOptions({ ...options, purpose: value as any })}
              >
                <SelectTrigger id="purpose">
                  <SelectValue placeholder="Select purpose" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="informational">Informational</SelectItem>
                  <SelectItem value="educational">Educational</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="style">Style</Label>
              <Input
                id="style"
                placeholder="e.g., modern, cinematic, animated..."
                value={options.style}
                onChange={(e) => setOptions({ ...options, style: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="target-audience">Target Audience</Label>
              <Input
                id="target-audience"
                placeholder="e.g., professionals, students, parents..."
                value={options.targetAudience}
                onChange={(e) => setOptions({ ...options, targetAudience: e.target.value })}
              />
            </div>
          </div>

          <Button type="submit" disabled={loading || !topic.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Video Plan"
            )}
          </Button>
        </form>

        {renderSuggestionContent()}
      </CardContent>
    </Card>
  )
}

