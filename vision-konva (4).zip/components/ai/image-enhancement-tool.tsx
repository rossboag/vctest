"use client"

import type React from "react"

import { useState } from "react"
import { useImageEnhancement } from "@/hooks/use-image-enhancement"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Loader2, ImageIcon } from "lucide-react"
import type { ImageEnhancementOptions } from "@/lib/ai-content-service"
import Image from "next/image"

interface ImageEnhancementToolProps {
  projectId?: string
  onEnhanced?: (suggestions: any) => void
  initialImageUrl?: string
}

export function ImageEnhancementTool({ projectId, onEnhanced, initialImageUrl = "" }: ImageEnhancementToolProps) {
  const [imageUrl, setImageUrl] = useState(initialImageUrl)
  const [options, setOptions] = useState<ImageEnhancementOptions>({
    enhancementType: "all",
    strength: 50,
    style: "",
  })
  const [suggestions, setSuggestions] = useState<any>(null)

  const { enhanceImage, loading } = useImageEnhancement({
    onSuccess: (data) => {
      setSuggestions(data.suggestions)
      if (onEnhanced) {
        onEnhanced(data.suggestions)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!imageUrl) return
    await enhanceImage(imageUrl, options, projectId)
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setImageUrl(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>AI Image Enhancement</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="image-upload">Upload Image</Label>
            <div className="flex items-center gap-4">
              <Button type="button" variant="outline" onClick={() => document.getElementById("image-upload")?.click()}>
                <ImageIcon className="mr-2 h-4 w-4" />
                Select Image
              </Button>
              <input id="image-upload" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              <input
                type="text"
                placeholder="Or enter image URL..."
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="flex-1 px-3 py-2 border border-input rounded-md"
              />
            </div>
          </div>

          {imageUrl && (
            <div className="relative aspect-video w-full max-h-[300px] overflow-hidden rounded-md">
              <Image src={imageUrl || "/placeholder.svg"} alt="Image to enhance" fill className="object-contain" />
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="enhancement-type">Enhancement Type</Label>
              <Select
                value={options.enhancementType}
                onValueChange={(value) => setOptions({ ...options, enhancementType: value as any })}
              >
                <SelectTrigger id="enhancement-type">
                  <SelectValue placeholder="Select enhancement type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Aspects</SelectItem>
                  <SelectItem value="quality">Quality</SelectItem>
                  <SelectItem value="color">Color</SelectItem>
                  <SelectItem value="composition">Composition</SelectItem>
                  <SelectItem value="lighting">Lighting</SelectItem>
                  <SelectItem value="detail">Detail</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="style">Style (Optional)</Label>
              <input
                id="style"
                type="text"
                placeholder="e.g., minimalist, vintage, modern..."
                value={options.style}
                onChange={(e) => setOptions({ ...options, style: e.target.value })}
                className="w-full px-3 py-2 border border-input rounded-md"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="strength">Enhancement Strength</Label>
              <span>{options.strength}%</span>
            </div>
            <Slider
              id="strength"
              min={0}
              max={100}
              step={1}
              value={[options.strength || 50]}
              onValueChange={(value) => setOptions({ ...options, strength: value[0] })}
            />
          </div>

          <Button type="submit" disabled={loading || !imageUrl}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              "Generate Enhancement Suggestions"
            )}
          </Button>
        </form>

        {suggestions && (
          <div className="mt-6 space-y-4">
            <h3 className="text-lg font-medium">Enhancement Suggestions</h3>

            {typeof suggestions === "object" ? (
              Object.entries(suggestions).map(([category, items]: [string, any]) => (
                <div key={category} className="space-y-2">
                  <h4 className="font-medium capitalize">{category}</h4>
                  {Array.isArray(items) ? (
                    <ul className="list-disc pl-5 space-y-1">
                      {items.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  ) : (
                    <p>{items}</p>
                  )}
                </div>
              ))
            ) : (
              <p>{suggestions}</p>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (onEnhanced) {
                  onEnhanced(suggestions)
                }
              }}
            >
              Apply Suggestions
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

