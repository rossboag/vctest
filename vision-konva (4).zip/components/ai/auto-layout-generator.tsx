"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAutoLayout } from "@/hooks/use-auto-layout"
import { Plus, X, Loader2 } from "lucide-react"
import type { LayoutResult } from "@/lib/ai-layout-service"

interface AutoLayoutGeneratorProps {
  projectId?: string
  initialWidth?: number
  initialHeight?: number
  onLayoutGenerated?: (layout: LayoutResult) => void
}

interface ContentElement {
  type: string
  content?: string
  importance: "high" | "medium" | "low"
}

export function AutoLayoutGenerator({
  projectId,
  initialWidth = 1920,
  initialHeight = 1080,
  onLayoutGenerated,
}: AutoLayoutGeneratorProps) {
  const [width, setWidth] = useState(initialWidth)
  const [height, setHeight] = useState(initialHeight)
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState<string | undefined>()
  const [contentElements, setContentElements] = useState<ContentElement[]>([])
  const [newElement, setNewElement] = useState<ContentElement>({
    type: "text",
    content: "",
    importance: "medium",
  })

  const { generateLayout, loading, layout } = useAutoLayout({
    onSuccess: (generatedLayout) => {
      if (onLayoutGenerated) {
        onLayoutGenerated(generatedLayout)
      }
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    await generateLayout(
      prompt,
      { width, height },
      contentElements.length > 0 ? contentElements : undefined,
      style,
      projectId,
    )
  }

  const addContentElement = () => {
    if (newElement.type) {
      setContentElements([...contentElements, { ...newElement }])
      setNewElement({
        type: "text",
        content: "",
        importance: "medium",
      })
    }
  }

  const removeContentElement = (index: number) => {
    setContentElements(contentElements.filter((_, i) => i !== index))
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>AI Auto Layout Generator</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Layout Description</label>
            <Textarea
              placeholder="Describe the layout you want (e.g., 'Create a landing page with a hero section, features section, and footer')"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Width (px)</label>
              <Input type="number" min={100} value={width} onChange={(e) => setWidth(Number(e.target.value))} />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Height (px)</label>
              <Input type="number" min={100} value={height} onChange={(e) => setHeight(Number(e.target.value))} />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Style (Optional)</label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger>
                <SelectValue placeholder="Select a style" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="minimalist">Minimalist</SelectItem>
                <SelectItem value="corporate">Corporate</SelectItem>
                <SelectItem value="creative">Creative</SelectItem>
                <SelectItem value="modern">Modern</SelectItem>
                <SelectItem value="retro">Retro</SelectItem>
                <SelectItem value="geometric">Geometric</SelectItem>
                <SelectItem value="flat">Flat</SelectItem>
                <SelectItem value="material">Material Design</SelectItem>
                <SelectItem value="brutalist">Brutalist</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Content Elements (Optional)</label>
            <div className="flex flex-col space-y-2">
              {contentElements.map((element, index) => (
                <div key={index} className="flex items-center space-x-2 p-2 bg-muted rounded-md">
                  <div className="flex-1">
                    <span className="font-medium">{element.type}</span>
                    {element.content && <span className="ml-2 text-sm text-muted-foreground">"{element.content}"</span>}
                    <span className="ml-2 text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                      {element.importance}
                    </span>
                  </div>
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeContentElement(index)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>

            <div className="flex flex-col space-y-2 p-3 border rounded-md">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs">Type</label>
                  <Select
                    value={newElement.type}
                    onValueChange={(value) => setNewElement({ ...newElement, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Element type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">Text</SelectItem>
                      <SelectItem value="heading">Heading</SelectItem>
                      <SelectItem value="paragraph">Paragraph</SelectItem>
                      <SelectItem value="image">Image</SelectItem>
                      <SelectItem value="button">Button</SelectItem>
                      <SelectItem value="form">Form</SelectItem>
                      <SelectItem value="video">Video</SelectItem>
                      <SelectItem value="gallery">Gallery</SelectItem>
                      <SelectItem value="testimonial">Testimonial</SelectItem>
                      <SelectItem value="feature">Feature</SelectItem>
                      <SelectItem value="hero">Hero Section</SelectItem>
                      <SelectItem value="footer">Footer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs">Importance</label>
                  <Select
                    value={newElement.importance}
                    onValueChange={(value) =>
                      setNewElement({
                        ...newElement,
                        importance: value as "high" | "medium" | "low",
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Importance" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <label className="text-xs">Content (optional)</label>
                <Input
                  placeholder="Content"
                  value={newElement.content || ""}
                  onChange={(e) => setNewElement({ ...newElement, content: e.target.value })}
                />
              </div>
              <Button type="button" variant="outline" size="sm" onClick={addContentElement} className="w-full">
                <Plus className="h-4 w-4 mr-2" /> Add Element
              </Button>
            </div>
          </div>

          <Button type="submit" disabled={loading || !prompt.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating Layout...
              </>
            ) : (
              "Generate Layout"
            )}
          </Button>
        </form>

        {layout && (
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2">Generated Layout:</h3>
            <div className="h-[300px] overflow-auto p-4 bg-muted rounded-md">
              <pre className="text-xs">{JSON.stringify(layout, null, 2)}</pre>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={() => onLayoutGenerated && onLayoutGenerated(layout)}
            >
              Apply Layout
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

