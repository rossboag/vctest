"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useBrandStyle } from "@/hooks/use-brand-style"
import { Loader2, Palette, Upload } from "lucide-react"
import { toast } from "sonner"
import type { BrandStyle } from "@/lib/ai-style-service"

interface BrandStyleExtractorProps {
  projectId?: string
  onBrandStyleExtracted?: (brandStyle: BrandStyle) => void
}

export function BrandStyleExtractor({ projectId, onBrandStyleExtracted }: BrandStyleExtractorProps) {
  const [description, setDescription] = useState("")
  const [imageUrls, setImageUrls] = useState<string[]>([])
  const [newImageUrl, setNewImageUrl] = useState("")

  const { extractBrandStyle, loading, brandStyle } = useBrandStyle({
    onSuccess: (result) => {
      if (onBrandStyleExtracted) {
        onBrandStyleExtracted(result)
      }
      toast.success("Brand style extracted successfully!")
    },
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!description && imageUrls.length === 0) {
      toast.error("Please provide a description or at least one image URL")
      return
    }

    await extractBrandStyle(undefined, description, imageUrls, projectId)
  }

  const addImageUrl = () => {
    if (!newImageUrl) return
    setImageUrls([...imageUrls, newImageUrl])
    setNewImageUrl("")
  }

  const removeImageUrl = (index: number) => {
    const newUrls = [...imageUrls]
    newUrls.splice(index, 1)
    setImageUrls(newUrls)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Palette className="h-5 w-5 mr-2" />
          Brand Style Extractor
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Brand Description</label>
            <Textarea
              placeholder="Describe your brand's personality, values, target audience, and industry..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Reference Images (URLs)</label>
            <div className="flex gap-2">
              <Input
                placeholder="https://example.com/image.jpg"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                className="flex-1"
              />
              <Button type="button" variant="outline" onClick={addImageUrl}>
                <Upload className="h-4 w-4 mr-2" />
                Add
              </Button>
            </div>

            {imageUrls.length > 0 && (
              <div className="mt-2 space-y-2">
                {imageUrls.map((url, index) => (
                  <div key={index} className="flex items-center justify-between bg-muted p-2 rounded-md">
                    <div className="text-sm truncate flex-1">{url}</div>
                    <Button type="button" variant="ghost" size="sm" onClick={() => removeImageUrl(index)}>
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button type="submit" disabled={loading || (!description && imageUrls.length === 0)}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Extracting...
              </>
            ) : (
              "Extract Brand Style"
            )}
          </Button>
        </form>

        {brandStyle && (
          <div className="mt-6 space-y-4">
            <h3 className="font-medium">Extracted Brand Style</h3>

            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-2">Colors</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div
                    className="p-2 rounded-md flex flex-col items-center justify-center h-16 text-white"
                    style={{ backgroundColor: brandStyle.colors.primary }}
                  >
                    <span className="font-medium">Primary</span>
                    <span className="text-xs">{brandStyle.colors.primary}</span>
                  </div>
                  <div
                    className="p-2 rounded-md flex flex-col items-center justify-center h-16 text-white"
                    style={{ backgroundColor: brandStyle.colors.secondary }}
                  >
                    <span className="font-medium">Secondary</span>
                    <span className="text-xs">{brandStyle.colors.secondary}</span>
                  </div>
                </div>

                <div className="mt-2">
                  <h5 className="text-xs font-medium">Accent Colors</h5>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {brandStyle.colors.accent.map((color, index) => (
                      <div
                        key={index}
                        className="w-8 h-8 rounded-md"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>

                <div className="mt-2">
                  <h5 className="text-xs font-medium">Neutral Colors</h5>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {brandStyle.colors.neutral.map((color, index) => (
                      <div
                        key={index}
                        className="w-8 h-8 rounded-md"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Typography</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-sm">Heading Font:</span>
                    <span className="text-sm font-medium">{brandStyle.typography.headingFont}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Body Font:</span>
                    <span className="text-sm font-medium">{brandStyle.typography.bodyFont}</span>
                  </div>
                  <div className="mt-2">
                    <h5 className="text-xs font-medium">Font Pairings</h5>
                    <ul className="text-xs mt-1 space-y-1">
                      {brandStyle.typography.fontPairings.map((pair, index) => (
                        <li key={index}>{pair}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Imagery</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-sm">Style:</span>
                    <span className="text-sm font-medium">{brandStyle.imagery.style}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Composition:</span>
                    <span className="text-sm font-medium">{brandStyle.imagery.composition}</span>
                  </div>
                  <div className="mt-2">
                    <h5 className="text-xs font-medium">Filters</h5>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {brandStyle.imagery.filters.map((filter, index) => (
                        <span key={index} className="text-xs bg-muted px-2 py-1 rounded-full">
                          {filter}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Overall</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-sm">Industry:</span>
                    <span className="text-sm font-medium">{brandStyle.overall.industry}</span>
                  </div>
                  <div className="mt-2">
                    <h5 className="text-xs font-medium">Mood</h5>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {brandStyle.overall.mood.map((mood, index) => (
                        <span key={index} className="text-xs bg-muted px-2 py-1 rounded-full">
                          {mood}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="mt-2">
                    <h5 className="text-xs font-medium">Personality</h5>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {brandStyle.overall.personality.map((trait, index) => (
                        <span key={index} className="text-xs bg-muted px-2 py-1 rounded-full">
                          {trait}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                if (onBrandStyleExtracted && brandStyle) {
                  onBrandStyleExtracted(brandStyle)
                }
              }}
            >
              Apply Brand Style to Design
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

