"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"
import { isMobile } from "@/lib/mobile-utils"
import { useEffect, useState } from "react"

interface SlideOutMenuProps {
  title: string
  onClose: () => void
  children: React.ReactNode
  side?: "left" | "right"
}

export function SlideOutMenu({ title, onClose, children, side = "left" }: SlideOutMenuProps) {
  const [isMobileView, setIsMobileView] = useState(false)

  useEffect(() => {
    setIsMobileView(isMobile())

    const handleResize = () => {
      setIsMobileView(isMobile())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const positionClass = isMobileView
    ? side === "left"
      ? "left-0 top-12 w-full"
      : "right-0 top-12 w-full"
    : side === "left"
      ? "left-16 top-12 w-64"
      : "right-16 top-12 w-64"

  return (
    <div
      className={`fixed ${positionClass} bottom-[200px] bg-card border-${side} border-border z-20 flex flex-col text-sm overflow-hidden`}
    >
      <div className="flex justify-between items-center p-2 border-b border-border bg-card">
        <h2 className="text-base font-semibold text-card-foreground">{title}</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 bg-background text-foreground">{children}</div>
    </div>
  )
}

