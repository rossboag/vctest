"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/components/ui/use-toast"
import { Search, Filter, Image, FileText, Music, Video, File, Trash2, Download, Loader2 } from "lucide-react"
import { AssetUploader } from "./asset-uploader"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent } from "@/components/ui/card"

interface Asset {
  id: string
  name: string
  type: string
  url: string
  thumbnailUrl?: string
  mimeType: string
  size: number
  width?: number
  height?: number
  createdAt: string
  updatedAt: string
}

interface AssetGalleryProps {
  projectId?: string
  onSelectAsset?: (asset: Asset) => void
  selectable?: boolean
  showUploader?: boolean
}

export function AssetGallery({ projectId, onSelectAsset, selectable = false, showUploader = true }: AssetGalleryProps) {
  const [assets, setAssets] = useState<Asset[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [type, setType] = useState<string>("all")
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [uploaderOpen, setUploaderOpen] = useState(false)
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const { ref, inView } = useInView()

  const fetchAssets = useCallback(
    async (reset = false) => {
      try {
        const currentPage = reset ? 1 : page
        const queryParams = new URLSearchParams({
          page: currentPage.toString(),
          limit: "20",
        })

        if (search) {
          queryParams.append("search", search)
        }

        if (type && type !== "all") {
          queryParams.append("type", type)
        }

        if (projectId) {
          queryParams.append("projectId", projectId)
        }

        const response = await fetch(`/api/assets?${queryParams.toString()}`)

        if (!response.ok) {
          throw new Error("Failed to fetch assets")
        }

        const data = await response.json()

        if (reset) {
          setAssets(data.data.assets)
        } else {
          setAssets((prev) => [...prev, ...data.data.assets])
        }

        setHasMore(data.data.assets.length === 20)
        setPage(currentPage + 1)
      } catch (error) {
        console.error("Error fetching assets:", error)
        toast({
          title: "Error",
          description: "Failed to load assets",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    },
    [page, search, type, projectId],
  )

  useEffect(() => {
    fetchAssets(true)
  }, [fetchAssets])

  useEffect(() => {
    if (inView && hasMore && !loading) {
      fetchAssets()
    }
  }, [inView, hasMore, loading, fetchAssets])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchAssets(true)
  }

  const handleAssetClick = (asset: Asset) => {
    if (selectable && onSelectAsset) {
      onSelectAsset(asset)
    } else {
      setSelectedAsset(asset)
    }
  }

  const handleDeleteAsset = async () => {
    if (!selectedAsset) return

    setDeleting(true)
    try {
      const response = await fetch(`/api/assets/${selectedAsset.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete asset")
      }

      setAssets((prev) => prev.filter((a) => a.id !== selectedAsset.id))
      setSelectedAsset(null)
      setDeleteDialogOpen(false)

      toast({
        title: "Asset deleted",
        description: "The asset has been successfully deleted",
      })
    } catch (error) {
      console.error("Error deleting asset:", error)
      toast({
        title: "Error",
        description: "Failed to delete asset",
        variant: "destructive",
      })
    } finally {
      setDeleting(false)
    }
  }

  const handleDownloadAsset = async () => {
    if (!selectedAsset) return

    try {
      const response = await fetch(`/api/assets/${selectedAsset.id}/signed-url`)

      if (!response.ok) {
        throw new Error("Failed to get download URL")
      }

      const { data } = await response.json()

      // Create a temporary link and trigger download
      const link = document.createElement("a")
      link.href = data.signedUrl
      link.download = selectedAsset.name
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error("Error downloading asset:", error)
      toast({
        title: "Error",
        description: "Failed to download asset",
        variant: "destructive",
      })
    }
  }

  const getAssetIcon = (type: string) => {
    switch (type) {
      case "image":
        return <Image className="h-5 w-5" />
      case "document":
        return <FileText className="h-5 w-5" />
      case "audio":
        return <Music className="h-5 w-5" />
      case "video":
        return <Video className="h-5 w-5" />
      default:
        return <File className="h-5 w-5" />
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Assets</h2>
        {showUploader && <Button onClick={() => setUploaderOpen(true)}>Upload Assets</Button>}
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <form onSubmit={handleSearch} className="flex-1 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search assets..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8"
            />
          </div>
          <Button type="submit">Search</Button>
        </form>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              <SelectItem value="image">Images</SelectItem>
              <SelectItem value="video">Videos</SelectItem>
              <SelectItem value="audio">Audio</SelectItem>
              <SelectItem value="document">Documents</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading && assets.length === 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-32 w-full rounded-md" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/2" />
            </div>
          ))}
        </div>
      ) : assets.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No assets found</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {assets.map((asset) => (
            <Card
              key={asset.id}
              className={`overflow-hidden cursor-pointer transition-all hover:ring-2 hover:ring-primary/50 ${
                selectedAsset?.id === asset.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => handleAssetClick(asset)}
            >
              <div className="aspect-square relative bg-gray-100 flex items-center justify-center">
                {asset.type === "image" && asset.thumbnailUrl ? (
                  <img
                    src={asset.thumbnailUrl || "/placeholder.svg"}
                    alt={asset.name}
                    className="object-cover w-full h-full"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full w-full">{getAssetIcon(asset.type)}</div>
                )}
              </div>
              <CardContent className="p-2">
                <p className="text-sm font-medium truncate" title={asset.name}>
                  {asset.name}
                </p>
                <p className="text-xs text-gray-500">{formatFileSize(asset.size)}</p>
              </CardContent>
            </Card>
          ))}
          {hasMore && (
            <div ref={ref} className="col-span-full flex justify-center p-4">
              <Skeleton className="h-8 w-8 rounded-full" />
            </div>
          )}
        </div>
      )}

      {/* Asset Uploader Dialog */}
      <Dialog open={uploaderOpen} onOpenChange={setUploaderOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Assets</DialogTitle>
          </DialogHeader>
          <AssetUploader
            projectId={projectId}
            onUploadComplete={(newAssets) => {
              setUploaderOpen(false)
              fetchAssets(true)
              toast({
                title: "Upload complete",
                description: "Assets have been uploaded successfully",
              })
            }}
            multiple
          />
        </DialogContent>
      </Dialog>

      {/* Asset Details Dialog */}
      <Dialog open={!!selectedAsset} onOpenChange={(open) => !open && setSelectedAsset(null)}>
        {selectedAsset && (
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Asset Details</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="aspect-video relative bg-gray-100 flex items-center justify-center rounded-md overflow-hidden">
                {selectedAsset.type === "image" ? (
                  <img
                    src={selectedAsset.url || "/placeholder.svg"}
                    alt={selectedAsset.name}
                    className="object-contain max-h-full max-w-full"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full w-full">
                    {getAssetIcon(selectedAsset.type)}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div>
                  <p className="text-sm font-medium">Name</p>
                  <p className="text-sm">{selectedAsset.name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Type</p>
                  <p className="text-sm">{selectedAsset.mimeType}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Size</p>
                  <p className="text-sm">{formatFileSize(selectedAsset.size)}</p>
                </div>
                {selectedAsset.width && selectedAsset.height && (
                  <div>
                    <p className="text-sm font-medium">Dimensions</p>
                    <p className="text-sm">
                      {selectedAsset.width} × {selectedAsset.height}
                    </p>
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium">Created</p>
                  <p className="text-sm">{new Date(selectedAsset.createdAt).toLocaleString()}</p>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button variant="outline" className="flex-1" onClick={handleDownloadAsset}>
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
                <Button variant="destructive" className="flex-1" onClick={() => setDeleteDialogOpen(true)}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </DialogContent>
        )}
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Asset</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to delete this asset? This action cannot be undone.</p>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAsset} disabled={deleting}>
              {deleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

