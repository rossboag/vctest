"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Upload, X } from "lucide-react"

interface AssetUploaderProps {
  onUploadComplete?: (asset: any) => void
  projectId?: string
  maxSize?: number // in bytes
  acceptedFileTypes?: string[]
  multiple?: boolean
}

export function AssetUploader({
  onUploadComplete,
  projectId,
  maxSize = 10 * 1024 * 1024, // 10MB default
  acceptedFileTypes,
  multiple = false,
}: AssetUploaderProps) {
  const [files, setFiles] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [isPublic, setIsPublic] = useState(false)
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState("")

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (multiple) {
        setFiles((prev) => [...prev, ...acceptedFiles])
      } else {
        setFiles(acceptedFiles.slice(0, 1))
      }
    },
    [multiple],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxSize,
    accept: acceptedFileTypes
      ? acceptedFileTypes.reduce(
          (acc, type) => {
            acc[type] = []
            return acc
          },
          {} as Record<string, string[]>,
        )
      : undefined,
    multiple,
  })

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags((prev) => [...prev, tagInput.trim()])
      setTagInput("")
    }
  }

  const removeTag = (tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag))
  }

  const uploadFiles = async () => {
    if (files.length === 0) return

    setUploading(true)
    setProgress(0)

    const totalFiles = files.length
    let completedFiles = 0
    const uploadedAssets = []

    try {
      for (const file of files) {
        const formData = new FormData()
        formData.append("file", file)
        formData.append("name", file.name)
        formData.append("type", getFileType(file.type))

        if (projectId) {
          formData.append("projectId", projectId)
        }

        formData.append("isPublic", isPublic.toString())

        if (tags.length > 0) {
          formData.append("tags", JSON.stringify(tags))
        }

        const response = await fetch("/api/assets", {
          method: "POST",
          body: formData,
        })

        if (!response.ok) {
          throw new Error(`Upload failed: ${response.statusText}`)
        }

        const asset = await response.json()
        uploadedAssets.push(asset.data)

        completedFiles++
        setProgress(Math.round((completedFiles / totalFiles) * 100))
      }

      toast({
        title: "Upload complete",
        description: `Successfully uploaded ${uploadedAssets.length} file(s)`,
      })

      if (onUploadComplete) {
        onUploadComplete(multiple ? uploadedAssets : uploadedAssets[0])
      }

      setFiles([])
    } catch (error) {
      console.error("Upload error:", error)
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  const getFileType = (mimeType: string): string => {
    if (mimeType.startsWith("image/")) return "image"
    if (mimeType.startsWith("video/")) return "video"
    if (mimeType.startsWith("audio/")) return "audio"
    if (mimeType.includes("font")) return "font"
    if (mimeType.includes("pdf") || mimeType.includes("document")) return "document"
    return "other"
  }

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
          isDragActive ? "border-primary bg-primary/10" : "border-gray-300 hover:border-primary"
        }`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center justify-center space-y-2">
          <Upload className="h-8 w-8 text-gray-500" />
          <p className="text-sm text-gray-500">
            {isDragActive ? "Drop the files here..." : `Drag & drop files here, or click to select files`}
          </p>
          <p className="text-xs text-gray-400">
            {acceptedFileTypes ? `Accepted file types: ${acceptedFileTypes.join(", ")}` : "All file types accepted"}
          </p>
          <p className="text-xs text-gray-400">Max size: {(maxSize / (1024 * 1024)).toFixed(0)}MB</p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium">Selected Files</h3>
          <ul className="space-y-2">
            {files.map((file, index) => (
              <li key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                <div className="flex items-center space-x-2 truncate">
                  <span className="text-sm truncate">{file.name}</span>
                  <span className="text-xs text-gray-500">({(file.size / 1024).toFixed(0)} KB)</span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => removeFile(index)} disabled={uploading}>
                  <X className="h-4 w-4" />
                </Button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="isPublic"
            checked={isPublic}
            onCheckedChange={(checked) => setIsPublic(checked === true)}
            disabled={uploading}
          />
          <Label htmlFor="isPublic">Make assets public</Label>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags</Label>
        <div className="flex space-x-2">
          <Input
            id="tags"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault()
                addTag()
              }
            }}
            placeholder="Add tags..."
            disabled={uploading}
          />
          <Button onClick={addTag} disabled={uploading || !tagInput.trim()}>
            Add
          </Button>
        </div>
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {tags.map((tag) => (
              <div key={tag} className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm">
                <span>{tag}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-4 w-4 ml-1 p-0"
                  onClick={() => removeTag(tag)}
                  disabled={uploading}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {uploading && (
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-center text-gray-500">{progress}% complete</p>
        </div>
      )}

      <Button onClick={uploadFiles} disabled={files.length === 0 || uploading} className="w-full">
        {uploading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Uploading...
          </>
        ) : (
          "Upload"
        )}
      </Button>
    </div>
  )
}

