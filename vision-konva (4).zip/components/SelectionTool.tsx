"use client"

import type React from "react"
import { useState, useRef, useCallback } from "react"
import { useEditorStore } from "@/store/editor-store"

export const SelectionTool: React.FC = () => {
  const { setSelectedIds, elements, getShapesInRegion } = useEditorStore()
  const [isSelecting, setIsSelecting] = useState(false)
  const [selectionRect, setSelectionRect] = useState({ x: 0, y: 0, width: 0, height: 0 })
  const startPos = useRef({ x: 0, y: 0 })

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsSelecting(true)
    const { clientX, clientY } = e
    startPos.current = { x: clientX, y: clientY }
    setSelectionRect({ x: clientX, y: clientY, width: 0, height: 0 })
  }, [])

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isSelecting) return

      const { clientX, clientY } = e
      const width = clientX - startPos.current.x
      const height = clientY - startPos.current.y

      setSelectionRect({
        x: width > 0 ? startPos.current.x : clientX,
        y: height > 0 ? startPos.current.y : clientY,
        width: Math.abs(width),
        height: Math.abs(height),
      })
    },
    [isSelecting],
  )

  const handleMouseUp = useCallback(() => {
    if (!isSelecting) return

    setIsSelecting(false)
    const selectedShapes = getShapesInRegion(
      selectionRect.x,
      selectionRect.y,
      selectionRect.width,
      selectionRect.height,
    )
    const selectedIds = selectedShapes.map((shape) => shape.id())
    setSelectedIds(selectedIds)
  }, [isSelecting, getShapesInRegion, selectionRect, setSelectedIds])

  return (
    <div
      className="absolute inset-0 cursor-crosshair"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {isSelecting && (
        <div
          className="absolute border-2 border-blue-500 bg-blue-200 bg-opacity-20"
          style={{
            left: selectionRect.x,
            top: selectionRect.y,
            width: selectionRect.width,
            height: selectionRect.height,
          }}
        />
      )}
    </div>
  )
}

