"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

interface SystemSettings {
  siteName: string
  siteDescription: string
  maxUploadSize: number
  maxProjectSize: number
  defaultLanguage: string
  userRegistration: boolean
  requireEmailVerification: boolean
  allowSocialLogin: boolean
  maintenanceMode: boolean
  analyticsEnabled: boolean
  defaultTheme: "light" | "dark" | "system"
  maxProjectsPerUser: number
  maxCollaboratorsPerProject: number
  autoSaveInterval: number
  allowPublicProjects: boolean
  customCssEnabled: boolean
  customJsEnabled: boolean
  customCss: string
  customJs: string
  footerText: string
  apiRateLimit: number
}

export function SystemSettings() {
  const [settings, setSettings] = useState<SystemSettings>({
    siteName: "Vision Konva",
    siteDescription: "AI-powered design and animation tool",
    maxUploadSize: 10,
    maxProjectSize: 100,
    defaultLanguage: "en",
    userRegistration: true,
    requireEmailVerification: true,
    allowSocialLogin: true,
    maintenanceMode: false,
    analyticsEnabled: true,
    defaultTheme: "light",
    maxProjectsPerUser: 10,
    maxCollaboratorsPerProject: 5,
    autoSaveInterval: 5,
    allowPublicProjects: true,
    customCssEnabled: false,
    customJsEnabled: false,
    customCss: "",
    customJs: "",
    footerText: "© 2023 Vision Konva. All rights reserved.",
    apiRateLimit: 1000,
  })

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    // Fetch settings from API
    const fetchSettings = async () => {
      try {
        setLoading(true)
        const response = await fetch("/api/admin/settings")

        if (!response.ok) {
          throw new Error("Failed to fetch settings")
        }

        const data = await response.json()
        setSettings(data.settings)
      } catch (error) {
        console.error("Error fetching settings:", error)
        toast({
          title: "Error",
          description: "Failed to fetch system settings",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchSettings()
  }, [])

  const handleChange = (key: keyof SystemSettings, value: any) => {
    setSettings({ ...settings, [key]: value })
  }

  const handleSave = async () => {
    try {
      setSaving(true)
      const response = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settings),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to save settings")
      }

      toast({
        title: "Success",
        description: "System settings saved successfully",
      })
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save settings",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>System Settings</CardTitle>
        <CardDescription>Configure global application settings</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="siteName">Site Name</Label>
          <Input id="siteName" value={settings.siteName} onChange={(e) => handleChange("siteName", e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="siteDescription">Site Description</Label>
          <Textarea
            id="siteDescription"
            value={settings.siteDescription}
            onChange={(e) => handleChange("siteDescription", e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="maxUploadSize">Max Upload Size (MB)</Label>
          <Input
            id="maxUploadSize"
            type="number"
            value={settings.maxUploadSize}
            onChange={(e) => handleChange("maxUploadSize", Number.parseInt(e.target.value))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="maxProjectSize">Max Project Size (MB)</Label>
          <Input
            id="maxProjectSize"
            type="number"
            value={settings.maxProjectSize}
            onChange={(e) => handleChange("maxProjectSize", Number.parseInt(e.target.value))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="defaultLanguage">Default Language</Label>
          <Select value={settings.defaultLanguage} onValueChange={(value) => handleChange("defaultLanguage", value)}>
            <SelectTrigger id="defaultLanguage">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="es">Spanish</SelectItem>
              <SelectItem value="fr">French</SelectItem>
              <SelectItem value="de">German</SelectItem>
              <SelectItem value="zh">Chinese</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="userRegistration"
            checked={settings.userRegistration}
            onCheckedChange={(checked) => handleChange("userRegistration", checked)}
          />
          <Label htmlFor="userRegistration">Allow User Registration</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="requireEmailVerification"
            checked={settings.requireEmailVerification}
            onCheckedChange={(checked) => handleChange("requireEmailVerification", checked)}
          />
          <Label htmlFor="requireEmailVerification">Require Email Verification</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="allowSocialLogin"
            checked={settings.allowSocialLogin}
            onCheckedChange={(checked) => handleChange("allowSocialLogin", checked)}
          />
          <Label htmlFor="allowSocialLogin">Allow Social Login</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="maintenanceMode"
            checked={settings.maintenanceMode}
            onCheckedChange={(checked) => handleChange("maintenanceMode", checked)}
          />
          <Label htmlFor="maintenanceMode">Maintenance Mode</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="analyticsEnabled"
            checked={settings.analyticsEnabled}
            onCheckedChange={(checked) => handleChange("analyticsEnabled", checked)}
          />
          <Label htmlFor="analyticsEnabled">Enable Analytics</Label>
        </div>
        <div className="space-y-2">
          <Label htmlFor="defaultTheme">Default Theme</Label>
          <Select
            value={settings.defaultTheme}
            onValueChange={(value: "light" | "dark" | "system") => handleChange("defaultTheme", value)}
          >
            <SelectTrigger id="defaultTheme">
              <SelectValue placeholder="Select theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Light</SelectItem>
              <SelectItem value="dark">Dark</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="maxProjectsPerUser">Max Projects Per User</Label>
          <Input
            id="maxProjectsPerUser"
            type="number"
            value={settings.maxProjectsPerUser}
            onChange={(e) => handleChange("maxProjectsPerUser", Number.parseInt(e.target.value))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="maxCollaboratorsPerProject">Max Collaborators Per Project</Label>
          <Input
            id="maxCollaboratorsPerProject"
            type="number"
            value={settings.maxCollaboratorsPerProject}
            onChange={(e) => handleChange("maxCollaboratorsPerProject", Number.parseInt(e.target.value))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="autoSaveInterval">Auto-Save Interval (minutes)</Label>
          <Slider
            id="autoSaveInterval"
            min={1}
            max={30}
            step={1}
            value={[settings.autoSaveInterval]}
            onValueChange={(value) => handleChange("autoSaveInterval", value[0])}
          />
          <div className="text-sm text-muted-foreground">{settings.autoSaveInterval} minutes</div>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="allowPublicProjects"
            checked={settings.allowPublicProjects}
            onCheckedChange={(checked) => handleChange("allowPublicProjects", checked)}
          />
          <Label htmlFor="allowPublicProjects">Allow Public Projects</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="customCssEnabled"
            checked={settings.customCssEnabled}
            onCheckedChange={(checked) => handleChange("customCssEnabled", checked)}
          />
          <Label htmlFor="customCssEnabled">Enable Custom CSS</Label>
        </div>
        {settings.customCssEnabled && (
          <div className="space-y-2">
            <Label htmlFor="customCss">Custom CSS</Label>
            <Textarea
              id="customCss"
              value={settings.customCss}
              onChange={(e) => handleChange("customCss", e.target.value)}
              placeholder="Enter custom CSS here"
            />
          </div>
        )}
        <div className="flex items-center space-x-2">
          <Switch
            id="customJsEnabled"
            checked={settings.customJsEnabled}
            onCheckedChange={(checked) => handleChange("customJsEnabled", checked)}
          />
          <Label htmlFor="customJsEnabled">Enable Custom JavaScript</Label>
        </div>
        {settings.customJsEnabled && (
          <div className="space-y-2">
            <Label htmlFor="customJs">Custom JavaScript</Label>
            <Textarea
              id="customJs"
              value={settings.customJs}
              onChange={(e) => handleChange("customJs", e.target.value)}
              placeholder="Enter custom JavaScript here"
            />
          </div>
        )}
        <div className="space-y-2">
          <Label htmlFor="footerText">Footer Text</Label>
          <Input
            id="footerText"
            value={settings.footerText}
            onChange={(e) => handleChange("footerText", e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="apiRateLimit">API Rate Limit (requests per hour)</Label>
          <Input
            id="apiRateLimit"
            type="number"
            value={settings.apiRateLimit}
            onChange={(e) => handleChange("apiRateLimit", Number.parseInt(e.target.value))}
          />
        </div>
        <Button onClick={handleSave} disabled={saving}>
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save Settings
        </Button>
      </CardContent>
    </Card>
  )
}

