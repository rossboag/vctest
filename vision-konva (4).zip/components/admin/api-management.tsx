"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ApiKey = {
  id: string
  name: string
  key: string
  createdAt: string
  lastUsed: string
}

export function ApiManagement() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([
    { id: "1", name: "Production API Key", key: "prod_api_123456", createdAt: "2023-06-01", lastUsed: "2023-06-15" },
    { id: "2", name: "Development API Key", key: "dev_api_789012", createdAt: "2023-06-05", lastUsed: "2023-06-14" },
  ])

  const [newKeyName, setNewKeyName] = useState("")

  const handleCreateKey = () => {
    if (newKeyName) {
      const newKey: ApiKey = {
        id: Date.now().toString(),
        name: newKeyName,
        key: `api_${Math.random().toString(36).substr(2, 9)}`,
        createdAt: new Date().toISOString().split("T")[0],
        lastUsed: "-",
      }
      setApiKeys([...apiKeys, newKey])
      setNewKeyName("")
    }
  }

  const handleDeleteKey = (id: string) => {
    setApiKeys(apiKeys.filter((key) => key.id !== id))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Management</CardTitle>
        <CardDescription>Manage your API keys and access</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex items-center space-x-2">
          <Input placeholder="New API Key Name" value={newKeyName} onChange={(e) => setNewKeyName(e.target.value)} />
          <Button onClick={handleCreateKey}>Create New Key</Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>API Key</TableHead>
              <TableHead>Created At</TableHead>
              <TableHead>Last Used</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {apiKeys.map((apiKey) => (
              <TableRow key={apiKey.id}>
                <TableCell>{apiKey.name}</TableCell>
                <TableCell>{apiKey.key}</TableCell>
                <TableCell>{apiKey.createdAt}</TableCell>
                <TableCell>{apiKey.lastUsed}</TableCell>
                <TableCell>
                  <Button variant="destructive" onClick={() => handleDeleteKey(apiKey.id)}>
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

