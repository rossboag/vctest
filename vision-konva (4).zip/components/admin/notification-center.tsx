"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function NotificationCenter() {
  const [users, setUsers] = useState<any[]>([])
  const [templates, setTemplates] = useState<any[]>([])
  const [selectedUser, setSelectedUser] = useState("")
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [title, setTitle] = useState("")
  const [message, setMessage] = useState("")
  const [link, setLink] = useState("")
  const [type, setType] = useState("info")
  const [sending, setSending] = useState(false)
  const [loadingUsers, setLoadingUsers] = useState(true)
  const [loadingTemplates, setLoadingTemplates] = useState(true)

  // Fetch users
  const fetchUsers = useCallback(async () => {
    try {
      setLoadingUsers(true)
      const response = await fetch("/api/admin/users")
      const data = await response.json()

      if (response.ok) {
        setUsers(data)
      }
    } catch (error) {
      console.error("Error fetching users:", error)
      toast.error("Failed to load users")
    } finally {
      setLoadingUsers(false)
    }
  }, [])

  // Fetch notification templates
  const fetchTemplates = useCallback(async () => {
    try {
      setLoadingTemplates(true)
      const response = await fetch("/api/admin/notification-templates")
      const data = await response.json()

      if (response.ok) {
        setTemplates(data)
      }
    } catch (error) {
      console.error("Error fetching notification templates:", error)
      toast.error("Failed to load notification templates")
    } finally {
      setLoadingTemplates(false)
    }
  }, [])

  // Send notification
  const sendNotification = async () => {
    if (!selectedUser) {
      toast.error("Please select a user")
      return
    }

    if (!title || !message) {
      toast.error("Please enter a title and message")
      return
    }

    try {
      setSending(true)
      const response = await fetch("/api/notifications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: selectedUser,
          type,
          title,
          message,
          link: link || undefined,
        }),
      })

      if (response.ok) {
        toast.success("Notification sent successfully")
        // Reset form
        setTitle("")
        setMessage("")
        setLink("")
        setType("info")
      } else {
        toast.error("Failed to send notification")
      }
    } catch (error) {
      console.error("Error sending notification:", error)
      toast.error("Failed to send notification")
    } finally {
      setSending(false)
    }
  }

  // Send notification to all users
  const sendNotificationToAll = async () => {
    if (!title || !message) {
      toast.error("Please enter a title and message")
      return
    }

    try {
      setSending(true)
      const response = await fetch("/api/admin/notifications/broadcast", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type,
          title,
          message,
          link: link || undefined,
        }),
      })

      if (response.ok) {
        toast.success("Notification sent to all users")
        // Reset form
        setTitle("")
        setMessage("")
        setLink("")
        setType("info")
      } else {
        toast.error("Failed to send notification to all users")
      }
    } catch (error) {
      console.error("Error sending notification to all users:", error)
      toast.error("Failed to send notification to all users")
    } finally {
      setSending(false)
    }
  }

  // Handle template selection
  const handleTemplateChange = (value: string) => {
    setSelectedTemplate(value)

    if (value) {
      const template = templates.find((t) => t.id === value)
      if (template) {
        setTitle(template.title)
        setMessage(template.message)
        setType(template.type)
      }
    }
  }

  // Fetch data on mount
  useEffect(() => {
    fetchUsers()
    fetchTemplates()
  }, [fetchUsers, fetchTemplates])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Notification Center</CardTitle>
        <CardDescription>Send notifications to users or manage notification templates</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="send">
          <TabsList className="mb-4">
            <TabsTrigger value="send">Send Notifications</TabsTrigger>
            <TabsTrigger value="templates">Notification Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="send">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="user">Recipient</Label>
                <Select value={selectedUser} onValueChange={setSelectedUser} disabled={loadingUsers}>
                  <SelectTrigger id="user">
                    <SelectValue placeholder="Select a user" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name || user.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="template">Template (Optional)</Label>
                <Select value={selectedTemplate} onValueChange={handleTemplateChange} disabled={loadingTemplates}>
                  <SelectTrigger id="template">
                    <SelectValue placeholder="Select a template" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger id="type">
                    <SelectValue placeholder="Select a type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Notification title"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Notification message"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="link">Link (Optional)</Label>
                <Input
                  id="link"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  placeholder="https://example.com"
                />
              </div>

              <div className="flex space-x-2">
                <Button onClick={sendNotification} disabled={sending || !selectedUser} className="flex-1">
                  {sending ? "Sending..." : "Send Notification"}
                </Button>
                <Button onClick={sendNotificationToAll} disabled={sending} variant="outline" className="flex-1">
                  Send to All Users
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="templates">
            <div className="space-y-4">
              <Button>Add New Template</Button>

              {loadingTemplates ? (
                <div className="text-center py-4">Loading templates...</div>
              ) : templates.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">No templates found</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Message</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {templates.map((template) => (
                      <TableRow key={template.id}>
                        <TableCell>{template.title}</TableCell>
                        <TableCell>{template.type}</TableCell>
                        <TableCell className="max-w-xs truncate">{template.message}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                          <Button variant="ghost" size="sm">
                            Delete
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

