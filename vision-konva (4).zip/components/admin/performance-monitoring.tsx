"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Cpu, MemoryStickIcon as Memory, Clock, Server } from "lucide-react"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface PerformanceMetric {
  id: string
  timestamp: string
  cpuUsage: number
  memoryUsage: number
  requestsPerSecond: number
  responseTime: number
}

interface ApiResponseTime {
  endpoint: string
  avgResponseTime: number
  maxResponseTime: number
  minResponseTime: number
}

interface CurrentMetrics {
  cpuUsage: {
    user: number
    system: number
  }
  memoryUsage: {
    rss: number
    heapTotal: number
    heapUsed: number
    external: number
  }
  systemMemory: {
    total: number
    free: number
  }
  uptime: number
  loadAverage: number[]
}

interface PerformanceData {
  historicalMetrics: PerformanceMetric[]
  currentMetrics: CurrentMetrics
  apiResponseTimes: ApiResponseTime[]
}

export function PerformanceMonitoring() {
  const [period, setPeriod] = useState("1h")
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<PerformanceData>({
    historicalMetrics: [],
    currentMetrics: {
      cpuUsage: { user: 0, system: 0 },
      memoryUsage: { rss: 0, heapTotal: 0, heapUsed: 0, external: 0 },
      systemMemory: { total: 0, free: 0 },
      uptime: 0,
      loadAverage: [0, 0, 0],
    },
    apiResponseTimes: [],
  })

  const fetchPerformanceData = async (selectedPeriod: string) => {
    try {
      setLoading(true)
      const response = await fetch(`/api/admin/performance?period=${selectedPeriod}`)

      if (!response.ok) {
        throw new Error("Failed to fetch performance data")
      }

      const performanceData = await response.json()
      setData(performanceData)
    } catch (error) {
      console.error("Error fetching performance data:", error)
      toast({
        title: "Error",
        description: "Failed to fetch performance data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPerformanceData(period)

    // Set up polling for real-time updates
    const interval = setInterval(() => {
      fetchPerformanceData(period)
    }, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [period])

  // Format timestamp for display
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString()
  }

  // Format bytes to human-readable format
  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return "0 Bytes"

    const k = 1024
    const dm = decimals < 0 ? 0 : decimals
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"]

    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
  }

  // Calculate memory usage percentage
  const memoryUsagePercent =
    data.currentMetrics.systemMemory.total > 0
      ? 100 - (data.currentMetrics.systemMemory.free / data.currentMetrics.systemMemory.total) * 100
      : 0

  // Calculate CPU usage percentage (simplified)
  const cpuUsagePercent = (data.currentMetrics.cpuUsage.user + data.currentMetrics.cpuUsage.system) / 100

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Performance Monitoring</h2>
        <Select value={period} onValueChange={(value) => setPeriod(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1h">Last Hour</SelectItem>
            <SelectItem value="6h">Last 6 Hours</SelectItem>
            <SelectItem value="24h">Last 24 Hours</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
                <Cpu className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-2">{cpuUsagePercent.toFixed(2)}%</div>
                <Progress value={cpuUsagePercent} className="h-2" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                <Memory className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-2">{memoryUsagePercent.toFixed(2)}%</div>
                <Progress value={memoryUsagePercent} className="h-2" />
                <div className="text-xs text-muted-foreground mt-1">
                  {formatBytes(data.currentMetrics.systemMemory.total - data.currentMetrics.systemMemory.free)} /{" "}
                  {formatBytes(data.currentMetrics.systemMemory.total)}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Uptime</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.floor(data.currentMetrics.uptime / 86400)}d{" "}
                  {Math.floor((data.currentMetrics.uptime % 86400) / 3600)}h{" "}
                  {Math.floor((data.currentMetrics.uptime % 3600) / 60)}m
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Load Average</CardTitle>
                <Server className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.currentMetrics.loadAverage[0].toFixed(2)}</div>
                <div className="text-xs text-muted-foreground">
                  1m: {data.currentMetrics.loadAverage[0].toFixed(2)}, 5m:{" "}
                  {data.currentMetrics.loadAverage[1].toFixed(2)}, 15m: {data.currentMetrics.loadAverage[2].toFixed(2)}
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="system">
            <TabsList>
              <TabsTrigger value="system">System</TabsTrigger>
              <TabsTrigger value="memory">Memory</TabsTrigger>
              <TabsTrigger value="api">API Performance</TabsTrigger>
            </TabsList>

            <TabsContent value="system">
              <Card>
                <CardHeader>
                  <CardTitle>CPU Usage Over Time</CardTitle>
                  <CardDescription>CPU utilization for the selected period</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ChartContainer
                      config={{
                        cpuUsage: {
                          label: "CPU Usage (%)",
                          color: "hsl(var(--chart-1))",
                        },
                      }}
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data.historicalMetrics}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="timestamp" tickFormatter={formatTimestamp} />
                          <YAxis />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="cpuUsage"
                            stroke="var(--color-cpuUsage)"
                            name="CPU Usage (%)"
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="memory">
              <Card>
                <CardHeader>
                  <CardTitle>Memory Usage Over Time</CardTitle>
                  <CardDescription>Memory utilization for the selected period</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ChartContainer
                      config={{
                        memoryUsage: {
                          label: "Memory Usage (%)",
                          color: "hsl(var(--chart-2))",
                        },
                      }}
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data.historicalMetrics}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="timestamp" tickFormatter={formatTimestamp} />
                          <YAxis />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Legend />
                          <Area
                            type="monotone"
                            dataKey="memoryUsage"
                            stroke="var(--color-memoryUsage)"
                            fill="var(--color-memoryUsage)"
                            fillOpacity={0.3}
                            name="Memory Usage (%)"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="api">
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>API Response Times</CardTitle>
                    <CardDescription>Average response times by endpoint</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ChartContainer
                        config={{
                          avgResponseTime: {
                            label: "Avg Response Time (ms)",
                            color: "hsl(var(--chart-3))",
                          },
                        }}
                      >
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={data.apiResponseTimes}
                            layout="vertical"
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" />
                            <YAxis
                              type="category"
                              dataKey="endpoint"
                              width={100}
                              tickFormatter={(value) => (value.length > 15 ? `${value.substring(0, 15)}...` : value)}
                            />
                            <ChartTooltip content={<ChartTooltipContent />} />
                            <Legend />
                            <Bar
                              dataKey="avgResponseTime"
                              fill="var(--color-avgResponseTime)"
                              name="Avg Response Time (ms)"
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </ChartContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>API Response Time Details</CardTitle>
                    <CardDescription>Min, max, and average response times</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Endpoint</TableHead>
                          <TableHead>Avg (ms)</TableHead>
                          <TableHead>Min (ms)</TableHead>
                          <TableHead>Max (ms)</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.apiResponseTimes.map((item) => (
                          <TableRow key={item.endpoint}>
                            <TableCell className="font-medium">
                              {item.endpoint.length > 20 ? `${item.endpoint.substring(0, 20)}...` : item.endpoint}
                            </TableCell>
                            <TableCell>{item.avgResponseTime.toFixed(2)}</TableCell>
                            <TableCell>{item.minResponseTime.toFixed(2)}</TableCell>
                            <TableCell>{item.maxResponseTime.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}

