"use client"

import { useEffect, useState } from "react"
import { useOrientation } from "@/hooks/use-orientation"
import { RotateCcw } from "lucide-react"

export function OrientationHandler() {
  const orientation = useOrientation()
  const [showWarning, setShowWarning] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    // Check if we're on a mobile device
    if (typeof window !== "undefined") {
      const checkMobile = () => {
        setIsMobile(window.innerWidth < 768)
      }

      checkMobile()
      window.addEventListener("resize", checkMobile)
      return () => window.removeEventListener("resize", checkMobile)
    }
  }, [])

  useEffect(() => {
    // Only show warning on mobile devices in portrait mode
    setShowWarning(isMobile && orientation === "portrait")
  }, [isMobile, orientation])

  if (!showWarning) return null

  return (
    <div className="fixed inset-0 bg-background/95 z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-lg p-6 max-w-md text-center shadow-lg">
        <div className="flex justify-center mb-4">
          <RotateCcw className="h-12 w-12 text-primary animate-spin-slow" />
        </div>
        <h2 className="text-xl font-bold mb-2">Rotate Your Device</h2>
        <p className="text-muted-foreground mb-4">
          For the best editing experience, please rotate your device to landscape orientation.
        </p>
        <button
          onClick={() => setShowWarning(false)}
          className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
        >
          Continue Anyway
        </button>
      </div>
    </div>
  )
}

