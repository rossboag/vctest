"use client"

import type React from "react"

import { useCallback, useEffect, useRef, useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { konvaWrapper } from "@/lib/konva-wrapper"
import ErrorBoundary from "./error-boundary"
import { TextTool } from "./text-tool"
import { debounce } from "@/lib/utils"
import { isTouch } from "@/lib/mobile-utils"

const CANVAS_ID = "konva-canvas"
const BACKGROUND_COLOR = "#ffffff"

export default function EditorCanvas() {
  const canvasRef = useRef<HTMLDivElement>(null)
  const [isStageReady, setIsStageReady] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const { elements, canvasSize, scale, position, setPosition, activeTool } = useEditorStore()
  const [isPanning, setIsPanning] = useState(false)
  const [lastPointerPosition, setLastPointerPosition] = useState({ x: 0, y: 0 })
  const [isTouchDevice, setIsTouchDevice] = useState(false)
  const [touchStartPosition, setTouchStartPosition] = useState({ x: 0, y: 0 })

  const debouncedEnableCaching = debounce((id: string) => {
    konvaWrapper.enableCaching(id)
  }, 300)

  useEffect(() => {
    console.log("EditorCanvas: Component mounted")
    if (canvasRef.current) {
      try {
        const { width, height } = canvasRef.current.getBoundingClientRect()
        console.log(`EditorCanvas: Initializing stage with width: ${width}, height: ${height}`)
        konvaWrapper.initStage(CANVAS_ID, width, height)
        konvaWrapper.setBackground(BACKGROUND_COLOR)
        konvaWrapper.drawCanvas(canvasSize.width, canvasSize.height)
        setIsStageReady(true)
        console.log("EditorCanvas: Stage initialized successfully")
      } catch (err) {
        console.error("Error initializing stage:", err)
        setError(err instanceof Error ? err : new Error("Unknown error occurred"))
      }
    }
  }, [canvasSize.width, canvasSize.height])

  useEffect(() => {
    if (isStageReady) {
      try {
        console.log(`EditorCanvas: Updating stage with scale: ${scale}, position: ${JSON.stringify(position)}`)
        konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, position.x, position.y)
      } catch (err) {
        console.error("Error updating stage:", err)
        setError(err instanceof Error ? err : new Error("Unknown error occurred"))
      }
    }
  }, [isStageReady, canvasSize, scale, position])

  useEffect(() => {
    if (isStageReady) {
      try {
        console.log("EditorCanvas: Rendering elements", elements)
        konvaWrapper.clear()
        konvaWrapper.drawCanvas(canvasSize.width, canvasSize.height)
        elements.forEach((element) => {
          konvaWrapper.addElement(element)
          if (
            element.type === "text" ||
            element.type === "custom" ||
            (element.type === "image" && element.width * element.height > 10000)
          ) {
            debouncedEnableCaching(element.id)
          }
        })
      } catch (err) {
        console.error("Error rendering elements:", err)
        setError(err instanceof Error ? err : new Error("Unknown error occurred"))
      }
    }
  }, [isStageReady, elements, canvasSize, debouncedEnableCaching])

  const handleCanvasClick = useCallback(
    (e: React.MouseEvent) => {
      console.log("Canvas clicked, active tool:", activeTool)
    },
    [activeTool],
  )

  const handleCanvasMouseDown = useCallback(
    (e: React.MouseEvent) => {
      if (activeTool === "pan") {
        setIsPanning(true)
        setLastPointerPosition({ x: e.clientX, y: e.clientY })
      }
    },
    [activeTool],
  )

  const handleCanvasMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (isPanning && activeTool === "pan") {
        const dx = e.clientX - lastPointerPosition.x
        const dy = e.clientY - lastPointerPosition.y

        const newPosition = {
          x: position.x + dx / scale,
          y: position.y + dy / scale,
        }

        setPosition(newPosition)
        konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, newPosition.x, newPosition.y)
        setLastPointerPosition({ x: e.clientX, y: e.clientY })
      }
    },
    [isPanning, activeTool, position, scale, setPosition, canvasSize, lastPointerPosition.x, lastPointerPosition.y],
  )

  const handleCanvasMouseUp = useCallback(() => {
    setIsPanning(false)
  }, [])

  useEffect(() => {
    const handleGlobalMouseUp = () => {
      setIsPanning(false)
    }

    document.addEventListener("mouseup", handleGlobalMouseUp)
    return () => {
      document.removeEventListener("mouseup", handleGlobalMouseUp)
    }
  }, [])

  useEffect(() => {
    setIsTouchDevice(isTouch())

    const handleResize = () => {
      setIsTouchDevice(isTouch())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      if (activeTool === "pan") {
        setIsPanning(true)
        const touch = e.touches[0]
        setTouchStartPosition({ x: touch.clientX, y: touch.clientY })
        setLastPointerPosition({ x: touch.clientX, y: touch.clientY })
      }
    },
    [activeTool],
  )

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (isPanning && activeTool === "pan") {
        const touch = e.touches[0]
        const dx = touch.clientX - lastPointerPosition.x
        const dy = touch.clientY - lastPointerPosition.y

        const newPosition = {
          x: position.x + dx / scale,
          y: position.y + dy / scale,
        }

        setPosition(newPosition)
        konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, newPosition.x, newPosition.y)
        setLastPointerPosition({ x: touch.clientX, y: touch.clientY })
      }
    },
    [isPanning, activeTool, position, scale, setPosition, canvasSize, lastPointerPosition.x, lastPointerPosition.y],
  )

  const handleTouchEnd = useCallback(() => {
    setIsPanning(false)
  }, [])

  if (error) {
    return (
      <div className="error-message p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        <h2 className="text-lg font-bold mb-2">Error in Editor Canvas</h2>
        <p>{error.message}</p>
      </div>
    )
  }

  return (
    <ErrorBoundary>
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden bg-gray-800">
        <div
          ref={canvasRef}
          id={CANVAS_ID}
          className="w-full h-full bg-white border-2 border-gray-300"
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          style={{
            width: `${canvasSize.width}px`,
            height: `${canvasSize.height}px`,
            transform: `scale(${scale})`,
            transformOrigin: "center",
            cursor: activeTool === "pan" ? (isPanning ? "grabbing" : "grab") : "default",
            touchAction: activeTool === "pan" ? "none" : "auto", // Prevent browser gestures when panning
          }}
        >
          <TextTool />
        </div>
      </div>
    </ErrorBoundary>
  )
}

