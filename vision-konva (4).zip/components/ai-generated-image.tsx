import Image from "next/image"

interface AIGeneratedImageProps {
  src: string
  alt: string
  width: number
  height: number
}

export function AIGeneratedImage({ src, alt, width, height }: AIGeneratedImageProps) {
  return (
    <div className="relative">
      <Image src={src || "/placeholder.svg"} alt={alt} width={width} height={height} className="rounded-md shadow-md" />
      <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
        AI Generated
      </div>
    </div>
  )
}

