import type React from "react"
import { Button } from "@/components/ui/button"
import { useEditorStore } from "@/store/editor-store"
import { ZoomIn, ZoomOut, Maximize } from "lucide-react"

export const ZoomControls: React.FC = () => {
  const { scale, setScale, zoomToSelection, resetView } = useEditorStore()

  const handleZoomIn = () => setScale(scale * 1.2)
  const handleZoomOut = () => setScale(scale / 1.2)

  return (
    <div className="absolute bottom-4 right-4 flex space-x-2">
      <Button variant="outline" size="sm" onClick={handleZoomOut}>
        <ZoomOut className="h-4 w-4" />
      </Button>
      <Button variant="outline" size="sm" onClick={handleZoomIn}>
        <ZoomIn className="h-4 w-4" />
      </Button>
      <Button variant="outline" size="sm" onClick={zoomToSelection}>
        <Maximize className="h-4 w-4" />
      </Button>
      <Button variant="outline" size="sm" onClick={resetView}>
        Reset
      </Button>
      <span className="px-2 py-1 bg-background text-foreground rounded">{Math.round(scale * 100)}%</span>
    </div>
  )
}

