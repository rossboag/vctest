"use client"

import React, { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Wand2, Layout, Sparkles, Search, Palette, Brush } from "lucide-react"
import { useEditorStore } from "@/store/editor-store"
import { AIGenerateMenu } from "./ai-tools/ai-generate-menu"
import { AILayoutMenu } from "./ai-tools/ai-layout-menu"
import { AIEnhanceMenu } from "./ai-tools/ai-enhance-menu"
import { AIAnalyzeMenu } from "./ai-tools/ai-analyze-menu"
import { AIColorizeMenu } from "./ai-tools/ai-colorize-menu"
import { AIThemeMenu } from "./ai-tools/ai-theme-menu"
import { isMobile } from "@/lib/mobile-utils"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

const tools = [
  { id: "generate", icon: Wand2, tooltip: "AI Generate", component: AIGenerateMenu },
  { id: "layout", icon: Layout, tooltip: "AI Layout", component: AILayoutMenu },
  { id: "enhance", icon: Sparkles, tooltip: "AI Enhance", component: AIEnhanceMenu },
  { id: "analyze", icon: Search, tooltip: "AI Analyze", component: AIAnalyzeMenu },
  { id: "colorize", icon: Palette, tooltip: "AI Colorize", component: AIColorizeMenu },
  { id: "theme", icon: Brush, tooltip: "AI Theme Generator", component: AIThemeMenu },
] as const

export function RightToolbar() {
  const { activeAITool, setActiveAITool } = useEditorStore()
  const [isMobileView, setIsMobileView] = useState(false)

  useEffect(() => {
    setIsMobileView(isMobile())

    const handleResize = () => {
      setIsMobileView(isMobile())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <TooltipProvider>
      {isMobileView ? (
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="fixed right-2 top-16 z-50 bg-background shadow-md"
              aria-label="Open AI Tools Menu"
            >
              <Wand2 className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-64 p-0">
            <div className="flex flex-col items-start py-2 space-y-2 px-4">
              <h3 className="text-sm font-medium mb-2">AI Tools</h3>
              {tools.map((tool) => (
                <Button
                  key={tool.id}
                  variant="ghost"
                  size="sm"
                  onClick={() => setActiveAITool(tool.id)}
                  className={`w-full justify-start ${
                    activeAITool === tool.id ? "bg-accent text-accent-foreground" : ""
                  }`}
                >
                  <tool.icon className="h-4 w-4 mr-2" />
                  <span>{tool.tooltip}</span>
                </Button>
              ))}
            </div>
          </SheetContent>
        </Sheet>
      ) : (
        <div className="fixed right-0 top-12 bottom-[200px] w-16 bg-background border-l border-border flex flex-col items-center py-2 space-y-2 z-10">
          {tools.map((tool) => (
            <Tooltip key={tool.id}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setActiveAITool(tool.id)}
                  className={`hover:bg-accent hover:text-accent-foreground ${
                    activeAITool === tool.id ? "bg-accent text-accent-foreground" : ""
                  }`}
                >
                  <tool.icon className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>{tool.tooltip}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>
      )}
      {activeAITool &&
        React.createElement(tools.find((tool) => tool.id === activeAITool)?.component || AIGenerateMenu, {
          onClose: () => setActiveAITool(null),
        })}
    </TooltipProvider>
  )
}

