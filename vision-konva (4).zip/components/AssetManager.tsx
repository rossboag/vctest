"use client"

import { useState, useEffect } from "react"
import { useAssetStore } from "@/store/asset-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"

export const AssetManager = () => {
  const { assets, setAssets, addAsset, removeAsset } = useAssetStore()
  const [name, setName] = useState("")
  const [type, setType] = useState<"image" | "video" | "font" | "audio">("image")
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Fetch assets on component mount
  useEffect(() => {
    const fetchAssets = async () => {
      try {
        const response = await fetch("/api/assets")
        if (!response.ok) {
          throw new Error("Failed to fetch assets")
        }
        const data = await response.json()
        setAssets(data.assets)
      } catch (error) {
        console.error("Error fetching assets:", error)
        toast.error("Failed to load assets")
      } finally {
        setIsLoading(false)
      }
    }

    fetchAssets()
  }, [setAssets])

  const handleUpload = async () => {
    if (!file) {
      toast.error("Please select a file")
      return
    }

    if (!name) {
      toast.error("Please enter a name for the asset")
      return
    }

    setIsUploading(true)

    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("type", type)
      formData.append("name", name)

      const response = await fetch("/api/assets/upload", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to upload asset")
      }

      const newAsset = await response.json()
      addAsset(newAsset)

      setName("")
      setFile(null)
      toast.success("Asset uploaded successfully")
    } catch (error) {
      console.error("Error uploading asset:", error)
      toast.error(error instanceof Error ? error.message : "Failed to upload asset")
    } finally {
      setIsUploading(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/assets/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to delete asset")
      }

      removeAsset(id)
      toast.success("Asset deleted successfully")
    } catch (error) {
      console.error("Error deleting asset:", error)
      toast.error(error instanceof Error ? error.message : "Failed to delete asset")
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Asset Manager</h2>
      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Asset name" className="mb-2" />
      <select
        value={type}
        onChange={(e) => setType(e.target.value as "image" | "video" | "font" | "audio")}
        className="mb-2 w-full p-2 border rounded"
      >
        <option value="image">Image</option>
        <option value="video">Video</option>
        <option value="font">Font</option>
        <option value="audio">Audio</option>
      </select>
      <Input
        type="file"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
        className="mb-2"
        accept={
          type === "image"
            ? "image/*"
            : type === "video"
              ? "video/*"
              : type === "font"
                ? ".ttf,.otf,.woff,.woff2"
                : "audio/*"
        }
      />
      <Button onClick={handleUpload} disabled={isUploading}>
        {isUploading ? "Uploading..." : "Upload Asset"}
      </Button>

      <div className="mt-4">
        <h3 className="text-md font-semibold mb-2">Uploaded Assets</h3>
        {isLoading ? (
          <p>Loading assets...</p>
        ) : assets.length === 0 ? (
          <p>No assets found</p>
        ) : (
          <ul className="space-y-2">
            {assets.map((asset) => (
              <li key={asset.id} className="flex justify-between items-center p-2 border rounded">
                <div className="flex items-center">
                  {asset.type === "image" && (
                    <img
                      src={asset.url || "/placeholder.svg"}
                      alt={asset.name}
                      className="w-10 h-10 object-cover mr-2"
                    />
                  )}
                  <span>{asset.name}</span>
                </div>
                <Button onClick={() => handleDelete(asset.id)} variant="destructive" size="sm">
                  Remove
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

