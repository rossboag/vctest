"use client"

import type React from "react"
import { useCallback, useEffect, useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { konvaWrapper } from "@/lib/konva-wrapper"
import Konva from "konva"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { ColorPicker } from "@/components/ui/color-picker"
import { Slider } from "@/components/ui/slider"

export const TextTool: React.FC = () => {
  const { addElement, setSelectedIds, enableTextTransformer, activeTool, updateElement, selectedIds } = useEditorStore()
  const [isEditing, setIsEditing] = useState(false)
  const [textProps, setTextProps] = useState({
    fontSize: 20,
    fontFamily: "Arial",
    fill: "#000000",
    align: "left" as const,
    fontStyle: "normal",
    textDecoration: "",
    letterSpacing: 0,
    lineHeight: 1,
    wrap: "word" as const,
    width: 200,
    padding: 5,
    stroke: "",
    strokeWidth: 0,
    shadowColor: "",
    shadowBlur: 0,
    shadowOffsetX: 0,
    shadowOffsetY: 0,
  })

  useEffect(() => {
    if (selectedIds.length === 1) {
      const selectedElement = konvaWrapper.getElement(selectedIds[0])
      if (selectedElement instanceof Konva.Text) {
        setTextProps({
          fontSize: selectedElement.fontSize(),
          fontFamily: selectedElement.fontFamily(),
          fill: selectedElement.fill(),
          align: selectedElement.align(),
          fontStyle: selectedElement.fontStyle(),
          textDecoration: selectedElement.textDecoration(),
          letterSpacing: selectedElement.letterSpacing(),
          lineHeight: selectedElement.lineHeight(),
          wrap: selectedElement.wrap(),
          width: selectedElement.width(),
          padding: selectedElement.padding(),
          stroke: selectedElement.stroke(),
          strokeWidth: selectedElement.strokeWidth(),
          shadowColor: selectedElement.shadowColor(),
          shadowBlur: selectedElement.shadowBlur(),
          shadowOffsetX: selectedElement.shadowOffsetX(),
          shadowOffsetY: selectedElement.shadowOffsetY(),
        })
      }
    }
  }, [selectedIds])

  const handleClick = useCallback(
    (e: MouseEvent) => {
      if (activeTool !== "text" || isEditing) return

      const stage = konvaWrapper.getStage()
      if (!stage) return

      const pos = stage.getPointerPosition()
      if (!pos) return

      const newElement = addElement({
        type: "text",
        x: pos.x,
        y: pos.y,
        text: "Double-click to edit",
        ...textProps,
        layerId: "default",
      })

      if (newElement) {
        setSelectedIds([newElement.id])
        enableTextTransformer(newElement.id)
      }
    },
    [addElement, setSelectedIds, enableTextTransformer, activeTool, isEditing, textProps],
  )

  const handleDoubleClick = useCallback(
    (e: MouseEvent) => {
      const stage = konvaWrapper.getStage()
      if (!stage) return

      const clickedOn = stage.getIntersection(stage.getPointerPosition())
      if (clickedOn && clickedOn.getType() === "Text") {
        setIsEditing(true)
        const textNode = clickedOn as Konva.Text
        const textPosition = textNode.absolutePosition()

        const areaPosition = {
          x: textPosition.x,
          y: textPosition.y,
        }

        const textarea = document.createElement("textarea")
        document.body.appendChild(textarea)

        textarea.value = textNode.text()
        textarea.style.position = "absolute"
        textarea.style.top = `${areaPosition.y}px`
        textarea.style.left = `${areaPosition.x}px`
        textarea.style.width = `${textNode.width() - textNode.padding() * 2}px`
        textarea.style.height = `${textNode.height() - textNode.padding() * 2 + 5}px`
        textarea.style.fontSize = `${textNode.fontSize()}px`
        textarea.style.border = "none"
        textarea.style.padding = "0px"
        textarea.style.margin = "0px"
        textarea.style.overflow = "hidden"
        textarea.style.background = "none"
        textarea.style.outline = "none"
        textarea.style.resize = "none"
        textarea.style.lineHeight = textNode.lineHeight().toString()
        textarea.style.fontFamily = textNode.fontFamily()
        textarea.style.transformOrigin = "left top"
        textarea.style.textAlign = textNode.align()
        textarea.style.color = textNode.fill()

        setTimeout(() => {
          textarea.focus()
        })

        const handleOutsideClick = (e: MouseEvent) => {
          if (e.target !== textarea) {
            textNode.text(textarea.value)
            document.body.removeChild(textarea)
            window.removeEventListener("click", handleOutsideClick)
            setIsEditing(false)
            updateElement(textNode.id(), { text: textarea.value })
          }
        }

        const handleEnterKey = (e: KeyboardEvent) => {
          if (e.key === "Enter" && !e.shiftKey) {
            textNode.text(textarea.value)
            document.body.removeChild(textarea)
            window.removeEventListener("keydown", handleEnterKey)
            setIsEditing(false)
            updateElement(textNode.id(), { text: textarea.value })
          }
        }

        textarea.addEventListener("keydown", handleEnterKey)
        window.addEventListener("click", handleOutsideClick)
      }
    },
    [updateElement],
  )

  useEffect(() => {
    if (activeTool === "text") {
      document.addEventListener("click", handleClick)
      document.addEventListener("dblclick", handleDoubleClick)
    }

    return () => {
      document.removeEventListener("click", handleClick)
      document.removeEventListener("dblclick", handleDoubleClick)
    }
  }, [activeTool, handleClick, handleDoubleClick])

  const handleTextPropChange = (prop: string, value: string | number) => {
    setTextProps((prev) => ({ ...prev, [prop]: value }))
    if (selectedIds.length === 1) {
      const selectedElement = konvaWrapper.getElement(selectedIds[0])
      if (selectedElement instanceof Konva.Text) {
        selectedElement[prop](value)
        konvaWrapper.getLayer()?.batchDraw()
        updateElement(selectedIds[0], { [prop]: value })
      }
    }
  }

  if (activeTool !== "text" && selectedIds.length !== 1) return null

  return (
    <div className="absolute top-4 left-4 bg-background p-4 rounded-lg shadow-lg w-64">
      <h3 className="text-lg font-semibold mb-4">Text Properties</h3>
      <div className="space-y-4">
        <div>
          <Label htmlFor="fontSize">Font Size</Label>
          <Input
            id="fontSize"
            type="number"
            value={textProps.fontSize}
            onChange={(e) => handleTextPropChange("fontSize", Number.parseInt(e.target.value))}
          />
        </div>
        <div>
          <Label htmlFor="fontFamily">Font Family</Label>
          <Select
            id="fontFamily"
            value={textProps.fontFamily}
            onValueChange={(value) => handleTextPropChange("fontFamily", value)}
          >
            <option value="Arial">Arial</option>
            <option value="Helvetica">Helvetica</option>
            <option value="Times New Roman">Times New Roman</option>
            <option value="Courier New">Courier New</option>
          </Select>
        </div>
        <div>
          <Label htmlFor="textColor">Text Color</Label>
          <ColorPicker
            id="textColor"
            color={textProps.fill}
            onChange={(color) => handleTextPropChange("fill", color)}
          />
        </div>
        <div>
          <Label htmlFor="textAlign">Text Align</Label>
          <Select
            id="textAlign"
            value={textProps.align}
            onValueChange={(value) => handleTextPropChange("align", value)}
          >
            <option value="left">Left</option>
            <option value="center">Center</option>
            <option value="right">Right</option>
          </Select>
        </div>
        <div className="flex space-x-2">
          <Button
            variant={textProps.fontStyle.includes("bold") ? "default" : "outline"}
            onClick={() => handleTextPropChange("fontStyle", textProps.fontStyle.includes("bold") ? "normal" : "bold")}
          >
            B
          </Button>
          <Button
            variant={textProps.fontStyle.includes("italic") ? "default" : "outline"}
            onClick={() =>
              handleTextPropChange("fontStyle", textProps.fontStyle.includes("italic") ? "normal" : "italic")
            }
          >
            I
          </Button>
          <Button
            variant={textProps.textDecoration === "underline" ? "default" : "outline"}
            onClick={() =>
              handleTextPropChange("textDecoration", textProps.textDecoration === "underline" ? "" : "underline")
            }
          >
            U
          </Button>
        </div>
        <div>
          <Label htmlFor="letterSpacing">Letter Spacing</Label>
          <Slider
            id="letterSpacing"
            min={-5}
            max={20}
            step={0.1}
            value={[textProps.letterSpacing]}
            onValueChange={(value) => handleTextPropChange("letterSpacing", value[0])}
          />
        </div>
        <div>
          <Label htmlFor="lineHeight">Line Height</Label>
          <Slider
            id="lineHeight"
            min={0.5}
            max={2}
            step={0.1}
            value={[textProps.lineHeight]}
            onValueChange={(value) => handleTextPropChange("lineHeight", value[0])}
          />
        </div>
        <div>
          <Label htmlFor="wrap">Text Wrap</Label>
          <Select id="wrap" value={textProps.wrap} onValueChange={(value) => handleTextPropChange("wrap", value)}>
            <option value="word">Word</option>
            <option value="char">Character</option>
            <option value="none">None</option>
          </Select>
        </div>
        <div>
          <Label htmlFor="width">Width</Label>
          <Input
            id="width"
            type="number"
            value={textProps.width}
            onChange={(e) => handleTextPropChange("width", Number.parseInt(e.target.value))}
          />
        </div>
        <div>
          <Label htmlFor="padding">Padding</Label>
          <Input
            id="padding"
            type="number"
            value={textProps.padding}
            onChange={(e) => handleTextPropChange("padding", Number.parseInt(e.target.value))}
          />
        </div>
        <div>
          <Label htmlFor="stroke">Stroke Color</Label>
          <ColorPicker
            id="stroke"
            color={textProps.stroke}
            onChange={(color) => handleTextPropChange("stroke", color)}
          />
        </div>
        <div>
          <Label htmlFor="strokeWidth">Stroke Width</Label>
          <Slider
            id="strokeWidth"
            min={0}
            max={20}
            step={1}
            value={[textProps.strokeWidth]}
            onValueChange={(value) => handleTextPropChange("strokeWidth", value[0])}
          />
        </div>
        <div>
          <Label htmlFor="shadowColor">Shadow Color</Label>
          <ColorPicker
            id="shadowColor"
            color={textProps.shadowColor}
            onChange={(color) => handleTextPropChange("shadowColor", color)}
          />
        </div>
        <div>
          <Label htmlFor="shadowBlur">Shadow Blur</Label>
          <Slider
            id="shadowBlur"
            min={0}
            max={20}
            step={1}
            value={[textProps.shadowBlur]}
            onValueChange={(value) => handleTextPropChange("shadowBlur", value[0])}
          />
        </div>
        <div>
          <Label htmlFor="shadowOffsetX">Shadow Offset X</Label>
          <Slider
            id="shadowOffsetX"
            min={-20}
            max={20}
            step={1}
            value={[textProps.shadowOffsetX]}
            onValueChange={(value) => handleTextPropChange("shadowOffsetX", value[0])}
          />
        </div>
        <div>
          <Label htmlFor="shadowOffsetY">Shadow Offset Y</Label>
          <Slider
            id="shadowOffsetY"
            min={-20}
            max={20}
            step={1}
            value={[textProps.shadowOffsetY]}
            onValueChange={(value) => handleTextPropChange("shadowOffsetY", value[0])}
          />
        </div>
      </div>
    </div>
  )
}

