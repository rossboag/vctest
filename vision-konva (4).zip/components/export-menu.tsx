"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { useElementStore } from "@/store/elementStore"
import { FileImage, FileVideo, Loader2 } from "lucide-react"

export function ExportMenu() {
  const { toast } = useToast()
  const elements = useElementStore((state) => state.elements)
  const [isExporting, setIsExporting] = useState(false)
  const [exportSettings, setExportSettings] = useState({
    width: 1920,
    height: 1080,
    format: "png",
    quality: 90,
    fps: 30,
    duration: 5,
    background: "#ffffff",
  })

  const handleExport = async () => {
    try {
      setIsExporting(true)

      const response = await fetch("/api/exports", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          ...exportSettings,
        }),
      })

      if (!response.ok) {
        throw new Error("Export failed")
      }

      const data = await response.json()

      // Create a download link
      const link = document.createElement("a")
      link.href = data.url
      link.download = data.filename
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Export successful",
        description: `Your design has been exported as ${exportSettings.format.toUpperCase()}`,
      })
    } catch (error) {
      console.error("Export error:", error)
      toast({
        title: "Export failed",
        description: "There was an error exporting your design. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const handleSettingChange = (key: string, value: any) => {
    setExportSettings((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const isAnimatedFormat = exportSettings.format === "gif" || exportSettings.format === "mp4"

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Export Design</CardTitle>
        <CardDescription>Configure your export settings</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="format">Format</Label>
          <Select
            value={exportSettings.format}
            onValueChange={(value) => handleSettingChange("format", value)}
            disabled={isExporting}
          >
            <SelectTrigger id="format">
              <SelectValue placeholder="Select format" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="png">PNG</SelectItem>
              <SelectItem value="jpeg">JPEG</SelectItem>
              <SelectItem value="svg">SVG</SelectItem>
              <SelectItem value="gif">GIF</SelectItem>
              <SelectItem value="mp4">MP4</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="width">Width (px)</Label>
            <Input
              id="width"
              type="number"
              value={exportSettings.width}
              onChange={(e) => handleSettingChange("width", Number.parseInt(e.target.value) || 1)}
              min={1}
              max={10000}
              disabled={isExporting}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="height">Height (px)</Label>
            <Input
              id="height"
              type="number"
              value={exportSettings.height}
              onChange={(e) => handleSettingChange("height", Number.parseInt(e.target.value) || 1)}
              min={1}
              max={10000}
              disabled={isExporting}
            />
          </div>
        </div>

        {exportSettings.format === "jpeg" && (
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="quality">Quality</Label>
              <span className="text-sm text-gray-500">{exportSettings.quality}%</span>
            </div>
            <Slider
              id="quality"
              min={1}
              max={100}
              step={1}
              value={[exportSettings.quality]}
              onValueChange={(value) => handleSettingChange("quality", value[0])}
              disabled={isExporting}
            />
          </div>
        )}

        {isAnimatedFormat && (
          <>
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="fps">Frame Rate (FPS)</Label>
                <span className="text-sm text-gray-500">{exportSettings.fps}</span>
              </div>
              <Slider
                id="fps"
                min={1}
                max={60}
                step={1}
                value={[exportSettings.fps]}
                onValueChange={(value) => handleSettingChange("fps", value[0])}
                disabled={isExporting}
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="duration">Duration (seconds)</Label>
                <span className="text-sm text-gray-500">{exportSettings.duration}s</span>
              </div>
              <Slider
                id="duration"
                min={1}
                max={60}
                step={1}
                value={[exportSettings.duration]}
                onValueChange={(value) => handleSettingChange("duration", value[0])}
                disabled={isExporting}
              />
            </div>
          </>
        )}

        <div className="space-y-2">
          <Label htmlFor="background">Background Color</Label>
          <div className="flex gap-2">
            <Input
              id="background"
              type="color"
              value={exportSettings.background}
              onChange={(e) => handleSettingChange("background", e.target.value)}
              className="w-12 h-10 p-1"
              disabled={isExporting}
            />
            <Input
              type="text"
              value={exportSettings.background}
              onChange={(e) => handleSettingChange("background", e.target.value)}
              className="flex-1"
              disabled={isExporting}
            />
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleExport} disabled={isExporting} className="w-full">
          {isExporting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              {isAnimatedFormat ? <FileVideo className="mr-2 h-4 w-4" /> : <FileImage className="mr-2 h-4 w-4" />}
              Export {exportSettings.format.toUpperCase()}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

