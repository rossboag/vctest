"use client"

import type React from "react"
import { useCallback, useState, useEffect, useRef } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Play, Pause, SkipBack } from "lucide-react"
import { FixedSizeList as List } from "react-window"
import { isMobile } from "@/lib/mobile-utils"

const TIMELINE_HEIGHT = 200
const LAYER_HEIGHT = 24 // Reduced from 30 to 24
const TIME_SCALE = 50 // pixels per second
const SECOND_INDICATOR_HEIGHT = 4 // Height of the small boxes for seconds
const TIMELINE_HEADER_HEIGHT = 24 // Height of the timeline header

export function TimelinePanel() {
  const {
    elements,
    layers,
    currentTime,
    setCurrentTime,
    duration,
    isPlaying,
    togglePlayback,
    updateElement,
    updateLayer,
    selectedIds,
    setSelectedIds,
  } = useEditorStore()

  const [expandedLayers, setExpandedLayers] = useState<string[]>([])
  const timelineRef = useRef<HTMLDivElement>(null)
  const [draggingElement, setDraggingElement] = useState<string | null>(null)
  const [draggingEdge, setDraggingEdge] = useState<"start" | "end" | null>(null)
  const [isMobileView, setIsMobileView] = useState(false)

  useEffect(() => {
    setIsMobileView(isMobile())

    const handleResize = () => {
      setIsMobileView(isMobile())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    if (isPlaying) {
      const animate = () => {
        setCurrentTime((prevTime) => {
          const newTime = prevTime + 1 / 60 // Assuming 60 FPS
          return newTime >= duration ? 0 : newTime
        })
        requestAnimationFrame(animate)
      }
      const animationId = requestAnimationFrame(animate)
      return () => cancelAnimationFrame(animationId)
    }
  }, [isPlaying, duration, setCurrentTime])

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    const frames = Math.floor((time % 1) * 30)
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}:${frames
      .toString()
      .padStart(2, "0")}`
  }

  const toggleLayerExpansion = (id: string) => {
    setExpandedLayers((prev) => (prev.includes(id) ? prev.filter((layerId) => layerId !== id) : [...prev, id]))
  }

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (timelineRef.current) {
      const rect = timelineRef.current.getBoundingClientRect()
      const clickX = e.clientX - rect.left
      const newTime = clickX / TIME_SCALE
      setCurrentTime(Math.max(0, Math.min(newTime, duration)))
    }
  }

  const handleLayerDragStart = (id: string, edge: "start" | "end" | null) => {
    setDraggingElement(id)
    setDraggingEdge(edge)
  }

  const handleLayerDrag = (e: React.MouseEvent, id: string) => {
    if (draggingElement === id && timelineRef.current) {
      const rect = timelineRef.current.getBoundingClientRect()
      const dragX = e.clientX - rect.left
      const newTime = Math.max(0, Math.min(dragX / TIME_SCALE, duration))

      const element = elements.find((el) => el.id === id)
      if (element) {
        if (draggingEdge === "start") {
          updateElement(id, { startTime: Math.min(newTime, element.endTime) })
        } else if (draggingEdge === "end") {
          updateElement(id, { endTime: Math.max(newTime, element.startTime) })
        } else {
          const duration = element.endTime - element.startTime
          updateElement(id, {
            startTime: Math.max(0, newTime),
            endTime: Math.min(duration, newTime + duration),
          })
        }
      }
    }
  }

  const handleLayerDragEnd = () => {
    setDraggingElement(null)
    setDraggingEdge(null)
  }

  const toggleLayerVisibility = (id: string) => {
    const layer = layers.find((l) => l.id === id)
    if (layer) {
      updateLayer(id, { visible: !layer.visible })
    }
  }

  const toggleLayerLock = (id: string) => {
    const layer = layers.find((l) => l.id === id)
    if (layer) {
      updateLayer(id, { locked: !layer.locked })
    }
  }

  const renderRow = useCallback(
    ({ index, style }) => {
      const element = elements[index]
      return (
        <div style={style}>
          <div
            style={{
              position: "absolute",
              left: `${(element.startTime / duration) * 100}%`,
              width: `${((element.endTime - element.startTime) / duration) * 100}%`,
              height: "20px",
              backgroundColor: "blue",
            }}
          >
            {element.id}
          </div>
        </div>
      )
    },
    [elements, duration],
  )

  return (
    <div className="h-full bg-card text-card-foreground">
      <div className="flex items-center justify-between p-2 border-b border-border">
        <div className="flex space-x-2">
          <Button variant="outline" size="icon" onClick={() => setCurrentTime(0)}>
            <SkipBack className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={togglePlayback}>
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
        </div>
        <div className="text-sm font-mono">{formatTime(currentTime)}</div>
      </div>
      <div style={{ height: isMobileView ? "150px" : "200px", width: "100%" }}>
        <List
          height={isMobileView ? 150 : 200}
          itemCount={elements.length}
          itemSize={isMobileView ? 24 : 30}
          width="100%"
        >
          {renderRow}
        </List>
        <div
          style={{
            position: "absolute",
            left: `${(currentTime / duration) * 100}%`,
            top: 0,
            bottom: 0,
            width: "2px",
            backgroundColor: "red",
          }}
        />
      </div>
    </div>
  )
}

