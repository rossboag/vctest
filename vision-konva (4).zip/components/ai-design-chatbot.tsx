"use client"

import type React from "react"
import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import OpenAI from "openai"

const openai = new OpenAI({
  apiKey: process.env.NEXT_PUBLIC_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true,
})

export const AIDesignChatbot: React.FC = () => {
  const [input, setInput] = useState("")
  const [conversation, setConversation] = useState<{ role: "user" | "assistant"; content: string }[]>([])
  const { elements, canvasSize } = useEditorStore()

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage = { role: "user" as const, content: input }
    setConversation((prev) => [...prev, userMessage])
    setInput("")

    const canvasDescription = elements.map((el) => `${el.type} at (${el.x}, ${el.y})`).join(", ")
    const response = await openai.completions.create({
      model: "gpt-3.5-turbo-instruct",
      prompt: `Canvas: ${canvasSize.width}x${canvasSize.height}, Elements: ${canvasDescription}\n\nUser query: ${input}`,
      max_tokens: 150,
    })

    const assistantMessage = { role: "assistant" as const, content: response.choices[0].text }
    setConversation((prev) => [...prev, assistantMessage])
  }

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-semibold">AI Design Chatbot</h2>
      <div className="h-64 overflow-y-auto border rounded p-2">
        {conversation.map((message, index) => (
          <div key={index} className={`mb-2 ${message.role === "user" ? "text-right" : "text-left"}`}>
            <span className={`inline-block p-2 rounded ${message.role === "user" ? "bg-blue-100" : "bg-gray-100"}`}>
              {message.content}
            </span>
          </div>
        ))}
      </div>
      <div className="flex space-x-2">
        <Input
          type="text"
          placeholder="Ask about your design..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
        />
        <Button onClick={handleSendMessage}>Send</Button>
      </div>
    </div>
  )
}

