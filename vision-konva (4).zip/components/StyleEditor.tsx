"use client"

import type React from "react"
import { useState } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"

export const StyleEditor: React.FC = () => {
  const { selectedIds, applyLinearGradient, applyRadialGradient, applyPattern } = useEditorStore()
  const [gradientType, setGradientType] = useState<"linear" | "radial">("linear")
  const [colorStop1, setColorStop1] = useState("#000000")
  const [colorStop2, setColorStop2] = useState("#ffffff")
  const [patternUrl, setPatternUrl] = useState("")

  const handleApplyGradient = () => {
    if (selectedIds.length > 0) {
      const colorStops: Array<[number, string]> = [
        [0, colorStop1],
        [1, colorStop2],
      ]
      if (gradientType === "linear") {
        applyLinearGradient(selectedIds[0], colorStops)
      } else {
        applyRadialGradient(selectedIds[0], colorStops)
      }
    }
  }

  const handleApplyPattern = () => {
    if (selectedIds.length > 0 && patternUrl) {
      const img = new Image()
      img.onload = () => {
        applyPattern(selectedIds[0], img)
      }
      img.src = patternUrl
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Style Editor</h2>
      <Select value={gradientType} onValueChange={(value) => setGradientType(value as "linear" | "radial")}>
        <option value="linear">Linear Gradient</option>
        <option value="radial">Radial Gradient</option>
      </Select>
      <Input type="color" value={colorStop1} onChange={(e) => setColorStop1(e.target.value)} className="mt-2" />
      <Input type="color" value={colorStop2} onChange={(e) => setColorStop2(e.target.value)} className="mt-2" />
      <Button onClick={handleApplyGradient} className="mt-2">
        Apply Gradient
      </Button>
      <Input
        type="text"
        value={patternUrl}
        onChange={(e) => setPatternUrl(e.target.value)}
        placeholder="Pattern Image URL"
        className="mt-4"
      />
      <Button onClick={handleApplyPattern} className="mt-2">
        Apply Pattern
      </Button>
    </div>
  )
}

