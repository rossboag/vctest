"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useEditorStore } from "@/store/editor-store"
import { ColorPicker } from "@/components/ui/color-picker"
import { Button } from "@/components/ui/button"

const MAX_RECENT_COLORS = 10

export const ColorPickerWithPalette: React.FC<{
  color: string
  onChange: (color: string) => void
}> = ({ color, onChange }) => {
  const [recentColors, setRecentColors] = useState<string[]>([])
  const { addRecentColor, getRecentColors, selectedColor, setSelectedColor } = useEditorStore()

  useEffect(() => {
    setRecentColors(getRecentColors())
  }, [getRecentColors])

  const handleColorChange = (newColor: string) => {
    onChange(newColor)
    addRecentColor(newColor)
    setRecentColors(getRecentColors())
  }

  return (
    <div className="space-y-4">
      <ColorPicker color={color} onChange={handleColorChange} />
      <div className="grid grid-cols-5 gap-2">
        {recentColors.map((recentColor, index) => (
          <Button
            key={index}
            className="w-8 h-8 p-0"
            style={{ backgroundColor: recentColor }}
            onClick={() => onChange(recentColor)}
          />
        ))}
      </div>
    </div>
  )
}

