"use client"
import { motion } from "framer-motion"

interface AIGeneratedAnimationProps {
  elements: any[]
  duration: number
}

export function AIGeneratedAnimation({ elements, duration }: AIGeneratedAnimationProps) {
  return (
    <div className="relative w-full h-full">
      {elements.map((element, index) => (
        <motion.div
          key={index}
          initial={element.initial}
          animate={element.animate}
          transition={{ duration: duration }}
          className="absolute"
          style={{
            width: element.width,
            height: element.height,
            backgroundColor: element.fill,
          }}
        />
      ))}
      <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
        AI Generated Animation
      </div>
    </div>
  )
}

