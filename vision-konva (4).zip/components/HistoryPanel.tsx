import type React from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

export const HistoryPanel: React.FC = () => {
  const { history, historyIndex, undo, redo } = useEditorStore()

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">History</h2>
      <ScrollArea className="h-64">
        <ul className="space-y-2">
          {history.map((_, index) => (
            <li
              key={index}
              className={`p-2 rounded ${
                index === historyIndex ? "bg-accent text-accent-foreground" : "bg-card hover:bg-accent/50"
              }`}
            >
              Action {index + 1}
            </li>
          ))}
        </ul>
      </ScrollArea>
      <div className="flex justify-between mt-4">
        <Button onClick={undo} disabled={historyIndex === 0}>
          Undo
        </Button>
        <Button onClick={redo} disabled={historyIndex === history.length - 1}>
          Redo
        </Button>
      </div>
    </div>
  )
}

