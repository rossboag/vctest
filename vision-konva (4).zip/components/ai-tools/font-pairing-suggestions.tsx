const fontPairings = [
  { heading: "Roboto", body: "Open Sans" },
  { heading: "Playfair Display", body: "Source Sans Pro" },
  { heading: "Montserrat", body: "Merriweather" },
  { heading: "Lora", body: "Raleway" },
]

export function FontPairingSuggestions({ headingFont, bodyFont }: { headingFont: string; bodyFont: string }) {
  return (
    <div>
      <h3 className="font-semibold mb-2">Font Pairing Suggestions</h3>
      <p className="mb-2">
        Current pairing: {headingFont} (heading) with {bodyFont} (body)
      </p>
      <ul className="list-disc pl-5">
        {fontPairings.map((pair, index) => (
          <li key={index}>
            {pair.heading} (heading) with {pair.body} (body)
          </li>
        ))}
      </ul>
    </div>
  )
}

