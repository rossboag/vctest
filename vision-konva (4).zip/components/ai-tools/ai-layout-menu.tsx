"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { aiService } from "@/lib/ai-service"

interface AILayoutMenuProps {
  onClose: () => void
  onLayoutGenerated: (layout: any) => void
}

interface LayoutOption {
  name: string
  icon: React.ReactNode
  description: string
}

export function AILayoutMenu({ onClose, onLayoutGenerated }: AILayoutMenuProps) {
  const [selectedLayout, setSelectedLayout] = useState<string | null>(null)
  const [prompt, setPrompt] = useState("")
  const [creativity, setCreativity] = useState(50)
  const [isGenerating, setIsGenerating] = useState(false)

  const layoutOptions: LayoutOption[] = [
    {
      name: "Grid",
      icon: (
        <div className="w-8 h-8 grid grid-cols-3 gap-1 border border-primary rounded">
          {[...Array(9)].map((_, i) => (
            <div key={i} className="bg-primary/20"></div>
          ))}
        </div>
      ),
      description: "Organize elements in a structured grid pattern",
    },
    {
      name: "Column",
      icon: (
        <div className="w-8 h-8 flex space-x-1 border border-primary rounded">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex-1 bg-primary/20"></div>
          ))}
        </div>
      ),
      description: "Arrange content in vertical columns",
    },
    {
      name: "Asymmetric",
      icon: (
        <div className="w-8 h-8 grid grid-cols-3 grid-rows-3 gap-1 border border-primary rounded">
          <div className="col-span-2 row-span-2 bg-primary/20"></div>
          <div className="bg-primary/20"></div>
          <div className="col-span-2 bg-primary/20"></div>
          <div className="bg-primary/20"></div>
        </div>
      ),
      description: "Create dynamic layouts with varied element sizes",
    },
    {
      name: "Radial",
      icon: (
        <div className="w-8 h-8 flex items-center justify-center border border-primary rounded">
          <div className="w-4 h-4 bg-primary/20 rounded-full"></div>
        </div>
      ),
      description: "Arrange elements in a circular pattern",
    },
    {
      name: "Diagonal",
      icon: (
        <div className="w-8 h-8 relative border border-primary rounded overflow-hidden">
          <div className="absolute inset-0 bg-primary/20 transform -skew-y-12"></div>
        </div>
      ),
      description: "Create dynamic layouts with diagonal elements",
    },
    {
      name: "Z-Pattern",
      icon: (
        <div className="w-8 h-8 flex flex-col justify-between border border-primary rounded">
          <div className="w-full h-1 bg-primary/20"></div>
          <div className="w-full h-1 bg-primary/20 self-end"></div>
          <div className="w-full h-1 bg-primary/20"></div>
        </div>
      ),
      description: "Guide the eye in a Z-shaped pattern",
    },
    {
      name: "F-Pattern",
      icon: (
        <div className="w-8 h-8 flex flex-col justify-between border border-primary rounded">
          <div className="w-full h-1 bg-primary/20"></div>
          <div className="w-3/4 h-1 bg-primary/20"></div>
          <div className="w-full h-1 bg-primary/20"></div>
        </div>
      ),
      description: "Arrange content to follow the natural F-shaped reading pattern",
    },
    {
      name: "Single-Column",
      icon: (
        <div className="w-8 h-8 flex justify-center border border-primary rounded">
          <div className="w-1/2 h-full bg-primary/20"></div>
        </div>
      ),
      description: "Focus on a single column of content",
    },
  ]

  const handleGenerate = async () => {
    if (!selectedLayout) return

    setIsGenerating(true)
    try {
      const layout = await aiService.generateLayout(
        [],
        `Generate a ${selectedLayout} layout. ${prompt}`,
        creativity / 100,
      )
      onLayoutGenerated(layout)
    } catch (error) {
      console.error("Error generating layout:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-80 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Layout</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div>
          <Label className="text-sm font-medium mb-2 block">Select Layout Style</Label>
          <div className="grid grid-cols-2 gap-2">
            {layoutOptions.map((option) => (
              <Button
                key={option.name}
                variant={selectedLayout === option.name ? "default" : "outline"}
                className="flex flex-col items-center justify-center h-24 p-2"
                onClick={() => setSelectedLayout(option.name)}
              >
                {option.icon}
                <span className="mt-2 text-xs">{option.name}</span>
              </Button>
            ))}
          </div>
        </div>
        {selectedLayout && (
          <div>
            <Label htmlFor="prompt" className="text-sm font-medium mb-2 block">
              Customization Prompt
            </Label>
            <Input
              id="prompt"
              placeholder="Enter additional layout instructions..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </div>
        )}
        <div>
          <Label htmlFor="creativity" className="text-sm font-medium mb-2 block">
            Creativity: {creativity}%
          </Label>
          <Slider
            id="creativity"
            min={0}
            max={100}
            step={1}
            value={[creativity]}
            onValueChange={(value) => setCreativity(value[0])}
          />
        </div>
        <Button onClick={handleGenerate} disabled={!selectedLayout || isGenerating} className="w-full">
          {isGenerating ? "Generating..." : "Generate Layout"}
        </Button>
      </div>
    </div>
  )
}

