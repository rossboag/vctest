import { Button } from "@/components/ui/button"

interface AIAssistantMenuProps {
  onClose: () => void
}

export function AIAssistantMenu({ onClose }: AIAssistantMenuProps) {
  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-80 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Assistant</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        <p>AI Assistant functionality coming soon...</p>
      </div>
    </div>
  )
}

