"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { useEditorStore } from "@/store/editor-store"
import { aiService } from "@/lib/ai-service"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Target,
  Grid,
  Columns,
  Layout,
  Circle,
  Slash,
  ZoomIn,
  AlignLeft,
  AlignJustify,
} from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Switch } from "@/components/ui/switch"

interface AIGenerateMenuProps {
  onClose: () => void
}

const generateOptions = ["text", "image", "video", "layout", "animation"] as const
type GenerationType = (typeof generateOptions)[number]

// Define image styles
const imageStyles = [
  "Minimalist",
  "Retro",
  "Futuristic",
  "Vintage",
  "Abstract",
  "Realistic",
  "Cartoon",
  "Watercolor",
  "Pop Art",
  "Surrealism",
  "Cyberpunk",
  "Steampunk",
  "Impressionist",
  "Cubism",
  "Art Deco",
  "Gothic",
]

// Define video styles
const videoStyles = [
  "Vibrant",
  "Moody",
  "Retro",
  "Realistic",
  "Cartoon",
  "Cinematic",
  "Minimalist",
  "Surreal",
  "Neon",
  "Pastel",
  "Vintage",
  "Futuristic",
  "Noir",
  "Watercolor",
  "Glitch",
  "Abstract",
]

// Add this after the videoStyles array
const animationStyles = [
  "Smooth",
  "Bouncy",
  "Elastic",
  "Explosive",
  "Liquid",
  "Robotic",
  "Glitch",
  "Particle",
  "Morphing",
  "Slow Motion",
  "Time Lapse",
  "Hand-drawn",
  "Origami",
  "Neon",
  "Retro",
  "Futuristic",
]

const layoutOptions = [
  { name: "Grid", icon: Grid, description: "Organize elements in a structured grid pattern" },
  { name: "Column", icon: Columns, description: "Arrange content in vertical columns" },
  { name: "Asymmetric", icon: Layout, description: "Create an unbalanced, dynamic layout" },
  { name: "Radial", icon: Circle, description: "Arrange elements in a circular pattern" },
  { name: "Diagonal", icon: Slash, description: "Organize content along diagonal lines" },
  { name: "Z-Pattern", icon: ZoomIn, description: "Layout following the natural eye movement in a Z shape" },
  { name: "F-Pattern", icon: AlignLeft, description: "Mimic the F-shaped reading pattern for text-heavy layouts" },
  { name: "Single-Column", icon: AlignJustify, description: "Simple, focused single-column layout" },
]

function getImageStyleBackground(style: string): string {
  switch (style.toLowerCase()) {
    case "minimalist":
      return "bg-gradient-to-br from-gray-100 to-gray-300"
    case "retro":
      return "bg-gradient-to-br from-yellow-400 via-orange-500 to-pink-500"
    case "futuristic":
      return "bg-gradient-to-br from-cyan-500 via-blue-500 to-purple-500"
    case "vintage":
      return "bg-gradient-to-br from-yellow-200 via-green-200 to-blue-200"
    case "abstract":
      return "bg-gradient-to-br from-red-400 via-yellow-400 to-blue-400"
    case "realistic":
      return "bg-gradient-to-br from-green-400 to-blue-500"
    case "cartoon":
      return "bg-gradient-to-br from-yellow-300 via-green-400 to-blue-500"
    case "watercolor":
      return "bg-gradient-to-br from-blue-300 via-green-300 to-yellow-300"
    case "pop art":
      return "bg-gradient-to-br from-pink-500 via-yellow-500 to-cyan-500"
    case "surrealism":
      return "bg-gradient-to-br from-purple-400 via-pink-500 to-red-500"
    case "cyberpunk":
      return "bg-gradient-to-br from-purple-600 via-pink-600 to-yellow-400"
    case "steampunk":
      return "bg-gradient-to-br from-yellow-700 via-red-700 to-gray-800"
    case "impressionist":
      return "bg-gradient-to-br from-blue-400 via-green-400 to-yellow-400"
    case "cubism":
      return "bg-gradient-to-br from-red-500 via-blue-500 to-green-500"
    case "art deco":
      return "bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600"
    case "gothic":
      return "bg-gradient-to-br from-gray-900 via-purple-900 to-gray-800"
    default:
      return "bg-gray-400"
  }
}

function getVideoStyleBackground(style: string): string {
  switch (style.toLowerCase()) {
    case "vibrant":
      return "bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500"
    case "moody":
      return "bg-gradient-to-br from-gray-900 via-gray-700 to-gray-800"
    case "retro":
      return "bg-gradient-to-br from-yellow-400 via-orange-500 to-pink-500"
    case "realistic":
      return "bg-gradient-to-br from-green-400 to-blue-500"
    case "cartoon":
      return "bg-gradient-to-br from-yellow-300 via-green-400 to-blue-500"
    case "cinematic":
      return "bg-gradient-to-br from-gray-900 via-gray-700 to-gray-800"
    case "minimalist":
      return "bg-gradient-to-br from-gray-100 to-gray-300"
    case "surreal":
      return "bg-gradient-to-br from-purple-400 via-pink-500 to-red-500"
    case "neon":
      return "bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500"
    case "pastel":
      return "bg-gradient-to-br from-pink-300 via-purple-300 to-indigo-300"
    case "vintage":
      return "bg-gradient-to-br from-yellow-200 via-green-200 to-blue-200"
    case "futuristic":
      return "bg-gradient-to-br from-cyan-500 via-blue-500 to-purple-500"
    case "noir":
      return "bg-gradient-to-br from-gray-900 to-gray-600"
    case "watercolor":
      return "bg-gradient-to-br from-blue-300 via-green-300 to-yellow-300"
    case "glitch":
      return "bg-gradient-to-br from-red-500 via-purple-500 to-blue-500"
    case "abstract":
      return "bg-gradient-to-br from-red-400 via-yellow-400 to-blue-400"
    default:
      return "bg-gray-400"
  }
}

// Add this after the getVideoStyleBackground function
function getAnimationStyleBackground(style: string): string {
  switch (style.toLowerCase()) {
    case "smooth":
      return "bg-gradient-to-br from-blue-300 to-green-300"
    case "bouncy":
      return "bg-gradient-to-br from-yellow-300 to-orange-400"
    case "elastic":
      return "bg-gradient-to-br from-purple-300 to-pink-400"
    case "explosive":
      return "bg-gradient-to-br from-red-500 to-yellow-500"
    case "liquid":
      return "bg-gradient-to-br from-blue-400 to-cyan-300"
    case "robotic":
      return "bg-gradient-to-br from-gray-500 to-blue-500"
    case "glitch":
      return "bg-gradient-to-br from-red-400 via-blue-500 to-green-400"
    case "particle":
      return "bg-gradient-to-br from-purple-400 to-pink-300"
    case "morphing":
      return "bg-gradient-to-br from-indigo-400 to-purple-300"
    case "slow motion":
      return "bg-gradient-to-br from-blue-200 to-indigo-300"
    case "time lapse":
      return "bg-gradient-to-br from-orange-300 to-red-400"
    case "hand-drawn":
      return "bg-gradient-to-br from-yellow-100 to-orange-200"
    case "origami":
      return "bg-gradient-to-br from-green-200 to-blue-200"
    case "neon":
      return "bg-gradient-to-br from-pink-500 to-purple-500"
    case "retro":
      return "bg-gradient-to-br from-yellow-400 to-orange-500"
    case "futuristic":
      return "bg-gradient-to-br from-cyan-400 to-blue-500"
    default:
      return "bg-gray-400"
  }
}

export function AIGenerateMenu({ onClose }: AIGenerateMenuProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [prompt, setPrompt] = useState("")
  const [currentOptionIndex, setCurrentOptionIndex] = useState(0)
  const [textLength, setTextLength] = useState(100)
  const [imageSize, setImageSize] = useState<"256x256" | "512x512" | "1024x1024">("512x512")
  const [videoDuration, setVideoDuration] = useState(5)
  const [animationDuration, setAnimationDuration] = useState(5)
  const [selectedImageStyle, setSelectedImageStyle] = useState("")
  const [selectedVideoStyle, setSelectedVideoStyle] = useState("")
  const { toast } = useToast()
  const { elements, addElement, updateElements } = useEditorStore()
  const [videoOrientation, setVideoOrientation] = useState<"landscape" | "portrait" | "square">("landscape")
  // ... (keep existing state variables)
  const [selectedAnimationStyle, setSelectedAnimationStyle] = useState("")
  const [animationIn, setAnimationIn] = useState(true)
  const [animationOut, setAnimationOut] = useState(true)
  const [directionLeft, setDirectionLeft] = useState(false)
  const [directionRight, setDirectionRight] = useState(false)
  const [directionUp, setDirectionUp] = useState(false)
  const [directionDown, setDirectionDown] = useState(false)
  const [directionCenter, setDirectionCenter] = useState(false)
  const [selectedLayout, setSelectedLayout] = useState("")

  const generationType = generateOptions[currentOptionIndex]

  const handlePrevious = () => {
    setCurrentOptionIndex((prev) => (prev === 0 ? generateOptions.length - 1 : prev - 1))
  }

  const handleNext = () => {
    setCurrentOptionIndex((prev) => (prev === generateOptions.length - 1 ? 0 : prev + 1))
  }

  const renderOptionContent = () => {
    switch (generationType) {
      case "text":
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Slider
                id="textLength"
                min={10}
                max={500}
                step={10}
                value={[textLength]}
                onValueChange={([value]) => setTextLength(value)}
              />
              <Label htmlFor="textLength" className="block text-sm text-muted-foreground">
                Text Length: {textLength} words
              </Label>
            </div>
          </div>
        )
      case "image":
        return (
          <div className="space-y-6">
            <Select onValueChange={(value: "256x256" | "512x512" | "1024x1024") => setImageSize(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select image size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="256x256">256x256</SelectItem>
                <SelectItem value="512x512">512x512</SelectItem>
                <SelectItem value="1024x1024">1024x1024</SelectItem>
              </SelectContent>
            </Select>
            <div className="grid grid-cols-4 gap-2">
              {imageStyles.map((style) => (
                <div
                  key={style}
                  className={`relative aspect-square cursor-pointer overflow-hidden rounded-md ${
                    selectedImageStyle === style ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setSelectedImageStyle(style)}
                >
                  <div
                    className={`absolute inset-0 flex items-center justify-center ${getImageStyleBackground(style)}`}
                  >
                    <span className="text-xs font-medium text-white">{style}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )
      case "video":
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Slider
                id="videoDuration"
                min={1}
                max={30}
                step={1}
                value={[videoDuration]}
                onValueChange={([value]) => setVideoDuration(value)}
              />
              <Label htmlFor="videoDuration" className="block text-sm text-muted-foreground">
                Video Duration: {videoDuration} seconds
              </Label>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Video Orientation</Label>
              <RadioGroup
                defaultValue="landscape"
                value={videoOrientation}
                onValueChange={(value: "landscape" | "portrait" | "square") => setVideoOrientation(value)}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="landscape" id="landscape" />
                  <Label htmlFor="landscape">Landscape</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="portrait" id="portrait" />
                  <Label htmlFor="portrait">Portrait</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="square" id="square" />
                  <Label htmlFor="square">Square</Label>
                </div>
              </RadioGroup>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {videoStyles.map((style) => (
                <div
                  key={style}
                  className={`relative cursor-pointer overflow-hidden rounded-md ${
                    selectedVideoStyle === style ? "ring-2 ring-primary" : ""
                  } ${
                    videoOrientation === "landscape"
                      ? "aspect-video"
                      : videoOrientation === "portrait"
                        ? "aspect-[9/16]"
                        : "aspect-square"
                  }`}
                  onClick={() => setSelectedVideoStyle(style)}
                >
                  <div
                    className={`absolute inset-0 flex items-center justify-center ${getVideoStyleBackground(style)}`}
                  >
                    <span className="text-xs font-medium text-white">{style}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )
      case "layout":
        return (
          <div className="space-y-6">
            <p className="text-sm text-muted-foreground">Select a layout style to start with:</p>
            <div className="grid grid-cols-2 gap-2">
              {layoutOptions.map((option) => (
                <Button
                  key={option.name}
                  variant={selectedLayout === option.name ? "default" : "outline"}
                  className="flex flex-col items-center justify-center h-24 text-center"
                  onClick={() => setSelectedLayout(option.name)}
                >
                  <option.icon className="h-8 w-8 mb-2" />
                  <span className="text-xs">{option.name}</span>
                </Button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              {layoutOptions.find((o) => o.name === selectedLayout)?.description ||
                "Select a layout to see its description"}
            </p>
          </div>
        )
      case "animation":
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Slider
                id="animationDuration"
                min={1}
                max={10}
                step={1}
                value={[animationDuration]}
                onValueChange={([value]) => setAnimationDuration(value)}
              />
              <Label htmlFor="animationDuration" className="block text-sm text-muted-foreground">
                Animation Duration: {animationDuration} seconds
              </Label>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Animation Type</Label>
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <Switch id="animationIn" checked={animationIn} onCheckedChange={setAnimationIn} />
                  <Label htmlFor="animationIn">In</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="animationOut" checked={animationOut} onCheckedChange={setAnimationOut} />
                  <Label htmlFor="animationOut">Out</Label>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Animation Direction</Label>
              <div className="flex justify-between gap-2">
                <Button
                  variant={directionLeft ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDirectionLeft(!directionLeft)}
                  className="flex-1 items-center justify-center"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant={directionRight ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDirectionRight(!directionRight)}
                  className="flex-1 items-center justify-center"
                >
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button
                  variant={directionUp ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDirectionUp(!directionUp)}
                  className="flex-1 items-center justify-center"
                >
                  <ArrowUp className="h-4 w-4" />
                </Button>
                <Button
                  variant={directionDown ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDirectionDown(!directionDown)}
                  className="flex-1 items-center justify-center"
                >
                  <ArrowDown className="h-4 w-4" />
                </Button>
                <Button
                  variant={directionCenter ? "default" : "outline"}
                  size="sm"
                  onClick={() => setDirectionCenter(!directionCenter)}
                  className="flex-1 items-center justify-center"
                >
                  <Target className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {animationStyles.map((style) => (
                <div
                  key={style}
                  className={`relative aspect-square cursor-pointer overflow-hidden rounded-md ${
                    selectedAnimationStyle === style ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setSelectedAnimationStyle(style)}
                >
                  <div
                    className={`absolute inset-0 flex items-center justify-center ${getAnimationStyleBackground(style)}`}
                  >
                    <span className="text-xs font-medium text-white text-center">{style}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )
    }
  }

  const getAnimationType = () => {
    if (animationIn && animationOut) return "both"
    if (animationIn) return "in"
    if (animationOut) return "out"
    return "both" // Default to both if neither is selected
  }

  const getAnimationDirections = () => {
    const directions = []
    if (directionLeft) directions.push("left")
    if (directionRight) directions.push("right")
    if (directionUp) directions.push("up")
    if (directionDown) directions.push("down")
    if (directionCenter) directions.push("center")
    return directions.length > 0 ? directions : ["center"] // Default to center if no direction is selected
  }

  const handleGenerate = async () => {
    setIsLoading(true)
    try {
      const result = await aiService.generateContent(prompt, {
        type: generationType,
        style:
          generationType === "image"
            ? selectedImageStyle
            : generationType === "video"
              ? selectedVideoStyle
              : generationType === "layout"
                ? selectedLayout
                : selectedAnimationStyle,
        length: textLength,
        imageSize,
        videoDuration,
        videoOrientation,
        animationDuration,
        animationType: getAnimationType(),
        animationDirections: getAnimationDirections(),
        elements,
      })

      // Handle the result based on the generation type
      switch (generationType) {
        case "text":
          addElement({
            type: "text",
            text: result as string,
            x: 100,
            y: 100,
            width: 300,
            height: 100,
            fill: "black",
            fontSize: 16,
            fontFamily: "Arial",
            layerId: "default",
          })
          break
        case "image":
          addElement({
            type: "image",
            src: result as string,
            x: 100,
            y: 100,
            width: Number.parseInt(imageSize.split("x")[0]),
            height: Number.parseInt(imageSize.split("x")[1]),
            layerId: "default",
          })
          break
        case "video":
          addElement({
            type: "video",
            src: result as string,
            x: 100,
            y: 100,
            width: 320,
            height: 240,
            layerId: "default",
          })
          break
        case "layout":
          if (Array.isArray(result)) {
            result.forEach((element) => addElement(element))
          }
          break
        case "animation":
          if (Array.isArray(result)) {
            updateElements(
              elements.map((el) => el.id),
              result,
            )
          }
          break
      }

      toast({
        title: "AI Generation Completed",
        description: `The ${generationType} has been successfully generated and added to your project.`,
      })
    } catch (error) {
      console.error(`Error in AI generation:`, error)
      toast({
        title: "Error",
        description: `An error occurred during the AI generation. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getAnimationPromptPlaceholder = () => {
    const type = getAnimationType()
    const directions = getAnimationDirections()
    const directionText =
      directions.length > 1 ? directions.slice(0, -1).join(", ") + " and " + directions.slice(-1) : directions[0]

    switch (type) {
      case "in":
        return `E.g., Animate a colorful butterfly flying into the scene from the ${directionText}, with smooth wing flaps and a slight bobbing motion.`
      case "out":
        return `E.g., Animate a colorful butterfly flying out of the scene towards the ${directionText}, with smooth wing flaps and a slight bobbing motion.`
      default:
        return `E.g., Animate a colorful butterfly flying in a pattern that moves ${directionText}, with smooth wing flaps and a slight bobbing motion.`
    }
  }

  const getPromptPlaceholder = () => {
    switch (generationType) {
      case "animation":
        return getAnimationPromptPlaceholder()
      case "layout":
        return `E.g., Create a ${selectedLayout.toLowerCase()} layout for a product landing page with a hero section, features list, and call-to-action button.`
      default:
        return "Enter your generation prompt..."
    }
  }

  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-80 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Generate</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={handlePrevious}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h3 className="text-lg font-semibold capitalize">{generationType}</h3>
          <Button variant="ghost" size="icon" onClick={handleNext}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="min-h-[100px]">{renderOptionContent()}</div>
        {generationType === "layout" && (
          <div className="text-sm text-muted-foreground mb-2">
            <p>For best results, include details such as:</p>
            <ul className="list-disc list-inside ml-2">
              <li>Purpose of the layout (e.g., landing page, blog post)</li>
              <li>Key sections or components to include</li>
              <li>Desired color scheme or style</li>
              <li>Any specific alignment or spacing preferences</li>
              <li>Target audience or industry</li>
            </ul>
          </div>
        )}
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder={getPromptPlaceholder()}
          className="min-h-[100px]"
        />
        <Button
          onClick={handleGenerate}
          disabled={isLoading || (generationType === "layout" && !selectedLayout)}
          className="w-full"
        >
          {isLoading ? "Generating..." : `Generate ${generationType}`}
        </Button>
      </div>
    </div>
  )
}

