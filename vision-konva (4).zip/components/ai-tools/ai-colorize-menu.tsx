"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useEditorStore } from "@/store/editor-store"
import { aiService } from "@/lib/ai-service"
import { ColorSwatch } from "@/components/ui/color-swatch"

interface ColorScheme {
  primary: string
  secondary: string
  accent: string
  background: string
  text: string
}

export function AIColorizeMenu({ onClose }: { onClose: () => void }) {
  const [theme, setTheme] = useState("")
  const [colorSchemes, setColorSchemes] = useState<ColorScheme[]>([])
  const [selectedSchemeIndex, setSelectedSchemeIndex] = useState(0)
  const [brightness, setBrightness] = useState(100)
  const [saturation, setSaturation] = useState(100)
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { elements, updateElements, selectedIds } = useEditorStore()

  const handleGenerateColors = async () => {
    setIsGenerating(true)
    setError(null)
    try {
      const schemes = await aiService.generateColorSchemes(theme, 5)
      setColorSchemes(schemes)
      setSelectedSchemeIndex(0)
    } catch (err) {
      setError("Failed to generate color schemes. Please try again.")
      console.error(err)
    }
    setIsGenerating(false)
  }

  const handleApplyColors = () => {
    if (colorSchemes.length === 0 || selectedIds.length === 0) return

    const selectedScheme = colorSchemes[selectedSchemeIndex]
    const updatedElements = elements.map((el) => {
      if (selectedIds.includes(el.id)) {
        return {
          ...el,
          fill: el.type === "text" ? selectedScheme.text : selectedScheme.primary,
          stroke: selectedScheme.accent,
        }
      }
      return el
    })

    updateElements(selectedIds, updatedElements)
  }

  const adjustColors = (scheme: ColorScheme): ColorScheme => {
    const adjust = (color: string) => {
      const hsl = hexToHSL(color)
      hsl.l = (hsl.l * brightness) / 100
      hsl.s = (hsl.s * saturation) / 100
      return hslToHex(hsl)
    }

    return {
      primary: adjust(scheme.primary),
      secondary: adjust(scheme.secondary),
      accent: adjust(scheme.accent),
      background: adjust(scheme.background),
      text: adjust(scheme.text),
    }
  }

  const checkAccessibility = (scheme: ColorScheme) => {
    const contrastRatio = getContrastRatio(scheme.text, scheme.background)
    return contrastRatio >= 4.5 // WCAG AA standard for normal text
  }

  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-80 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Colorize</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div>
          <Label htmlFor="theme">Theme or Mood</Label>
          <Input
            id="theme"
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
            placeholder="e.g., Vibrant summer, Calm winter"
          />
        </div>
        <Button onClick={handleGenerateColors} disabled={isGenerating || !theme}>
          {isGenerating ? "Generating..." : "Generate Color Schemes"}
        </Button>
        {error && <p className="text-red-500">{error}</p>}
        {colorSchemes.length > 0 && (
          <div className="space-y-4">
            <div className="flex justify-between">
              {colorSchemes.map((scheme, index) => (
                <ColorSwatch
                  key={index}
                  colors={Object.values(scheme)}
                  onClick={() => setSelectedSchemeIndex(index)}
                  isSelected={index === selectedSchemeIndex}
                />
              ))}
            </div>
            <div>
              <Label>Brightness</Label>
              <Slider
                min={50}
                max={150}
                step={1}
                value={[brightness]}
                onValueChange={(value) => setBrightness(value[0])}
              />
            </div>
            <div>
              <Label>Saturation</Label>
              <Slider
                min={50}
                max={150}
                step={1}
                value={[saturation]}
                onValueChange={(value) => setSaturation(value[0])}
              />
            </div>
            <div className="flex justify-between">
              {Object.entries(adjustColors(colorSchemes[selectedSchemeIndex])).map(([key, color]) => (
                <div key={key} className="text-center">
                  <div className="w-8 h-8 rounded-full mx-auto mb-1" style={{ backgroundColor: color }}></div>
                  <span className="text-xs">{key}</span>
                </div>
              ))}
            </div>
            {!checkAccessibility(colorSchemes[selectedSchemeIndex]) && (
              <p className="text-yellow-500">
                Warning: This color scheme may have poor contrast. Consider adjusting for better accessibility.
              </p>
            )}
            <Button onClick={handleApplyColors} disabled={selectedIds.length === 0}>
              Apply to Selected Elements
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

// Helper functions for color conversions and calculations
function hexToHSL(hex: string) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  if (!result) {
    return { h: 0, s: 0, l: 0 }
  }
  let r = Number.parseInt(result[1], 16)
  let g = Number.parseInt(result[2], 16)
  let b = Number.parseInt(result[3], 16)
  ;(r /= 255), (g /= 255), (b /= 255)
  const max = Math.max(r, g, b),
    min = Math.min(r, g, b)
  let h = 0,
    s = 0,
    l = (max + min) / 2

  if (max == min) {
    h = s = 0 // achromatic
  } else {
    const d = max - min
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0)
        break
      case g:
        h = (b - r) / d + 2
        break
      case b:
        h = (r - g) / d + 4
        break
    }
    h /= 6
  }

  return { h: h * 360, s: s * 100, l: l * 100 }
}

function hslToHex(hsl: { h: number; s: number; l: number }) {
  const h = hsl.h
  const s = hsl.s / 100
  const l = hsl.l / 100

  let c = (1 - Math.abs(2 * l - 1)) * s,
    x = c * (1 - Math.abs(((h / 60) % 2) - 1)),
    m = l - c / 2,
    r = 0,
    g = 0,
    b = 0

  if (0 <= h && h < 60) {
    r = c
    g = x
    b = 0
  } else if (60 <= h && h < 120) {
    r = x
    g = c
    b = 0
  } else if (120 <= h && h < 180) {
    r = 0
    g = c
    b = x
  } else if (180 <= h && h < 240) {
    r = 0
    g = x
    b = c
  } else if (240 <= h && h < 300) {
    r = x
    g = 0
    b = c
  } else if (300 <= h && h < 360) {
    r = c
    g = 0
    b = x
  }
  // Multiply the results by 255
  r = Math.round((r + m) * 255)
  g = Math.round((g + m) * 255)
  b = Math.round((b + m) * 255)

  function componentToHex(c: number) {
    const hex = c.toString(16)
    return hex.length == 1 ? "0" + hex : hex
  }

  return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b)
}

function getContrastRatio(color1: string, color2: string) {
  const lum = (color: string) => {
    color = color.replace("#", "")
    const r = Number.parseInt(color.substring(0, 2), 16) / 255
    const g = Number.parseInt(color.substring(2, 4), 16) / 255
    const b = Number.parseInt(color.substring(4, 6), 16) / 255

    const a = [r, g, b].map((v) => {
      v = v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
      return v
    })
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]
  }

  const luminance1 = lum(color1)
  const luminance2 = lum(color2)
  const brightest = Math.max(luminance1, luminance2)
  const darkest = Math.min(luminance1, luminance2)
  return (brightest + 0.05) / (darkest + 0.05)
}

