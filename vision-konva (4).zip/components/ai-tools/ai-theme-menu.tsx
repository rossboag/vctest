"use client"

import type React from "react"
import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useEditorStore } from "@/store/editor-store"
import { aiService } from "@/lib/ai-service"
import { ColorSwatch } from "@/components/ui/color-swatch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { ThemePreview } from "./theme-preview"
import { ColorHarmonyAnalyzer } from "./color-harmony-analyzer"
import { AccessibilityChecker } from "./accessibility-checker"
import { FontPairingSuggestions } from "./font-pairing-suggestions"
import { useThemeHistory } from "@/hooks/use-theme-history"

interface Theme {
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    text: string
    success: string
    warning: string
    error: string
  }
  typography: {
    headingFont: string
    bodyFont: string
    fontSize: {
      small: string
      medium: string
      large: string
      xlarge: string
    }
    lineHeight: {
      tight: string
      normal: string
      relaxed: string
    }
    fontWeight: {
      normal: string
      bold: string
    }
  }
  spacing: {
    small: string
    medium: string
    large: string
  }
  borderRadius: {
    small: string
    medium: string
    large: string
  }
  shadows: {
    small: string
    medium: string
    large: string
  }
  styleGuide: string
}

export function AIThemeMenu({ onClose }: { onClose: () => void }) {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedTheme, setGeneratedTheme] = useState<Theme | null>(null)
  const [colorMode, setColorMode] = useState<"light" | "dark">("light")
  const [colorPalette, setColorPalette] = useState<"monochromatic" | "analogous" | "complementary" | "triadic">(
    "monochromatic",
  )
  const [styleComplexity, setStyleComplexity] = useState(50)
  const [accessibilityLevel, setAccessibilityLevel] = useState<"AA" | "AAA">("AA")
  const { toast } = useToast()
  const { updateElements, elements, selectedIds } = useEditorStore()
  const { addTheme, undo, redo, canUndo, canRedo } = useThemeHistory()

  const handleGenerateTheme = async () => {
    setIsGenerating(true)
    try {
      const theme = await aiService.generateTheme(prompt, {
        colorMode,
        colorPalette,
        styleComplexity,
        accessibilityLevel,
      })
      setGeneratedTheme(theme)
      addTheme(theme)
      toast({
        title: "Theme Generated",
        description: "Your AI-generated theme is ready to use.",
      })
    } catch (error) {
      console.error("Error generating theme:", error)
      toast({
        title: "Error",
        description: "Failed to generate theme. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleApplyTheme = useCallback(() => {
    if (!generatedTheme) return

    const updatedElements = elements.map((element) => {
      if (selectedIds.includes(element.id)) {
        // Apply theme to selected elements
        return {
          ...element,
          fill: element.type === "text" ? generatedTheme.colors.text : generatedTheme.colors.primary,
          fontFamily: element.type === "text" ? generatedTheme.typography.bodyFont : element.fontFamily,
          fontSize:
            element.type === "text" ? Number.parseInt(generatedTheme.typography.fontSize.medium) : element.fontSize,
          // Add more properties as needed
        }
      }
      return element
    })

    updateElements(updatedElements)
    toast({
      title: "Theme Applied",
      description: "The generated theme has been applied to selected elements.",
    })
  }, [generatedTheme, elements, selectedIds, updateElements, toast])

  const handleColorChange = useCallback(
    (colorKey: keyof Theme["colors"], newColor: string) => {
      if (!generatedTheme) return
      const newTheme = {
        ...generatedTheme,
        colors: {
          ...generatedTheme.colors,
          [colorKey]: newColor,
        },
      }
      setGeneratedTheme(newTheme)
      addTheme(newTheme)
    },
    [generatedTheme, addTheme],
  )

  const handleExportTheme = useCallback(() => {
    if (!generatedTheme) return
    const themeString = JSON.stringify(generatedTheme, null, 2)
    const blob = new Blob([themeString], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "theme.json"
    a.click()
    URL.revokeObjectURL(url)
  }, [generatedTheme])

  const handleImportTheme = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0]
      if (file) {
        const reader = new FileReader()
        reader.onload = (e) => {
          try {
            const importedTheme = JSON.parse(e.target?.result as string)
            setGeneratedTheme(importedTheme)
            addTheme(importedTheme)
            toast({
              title: "Theme Imported",
              description: "The imported theme has been loaded successfully.",
            })
          } catch (error) {
            console.error("Error importing theme:", error)
            toast({
              title: "Error",
              description: "Failed to import theme. Please check the file format.",
              variant: "destructive",
            })
          }
        }
        reader.readAsText(file)
      }
    },
    [addTheme, toast],
  )

  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-96 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Theme Generator</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div>
          <Label htmlFor="theme-prompt">Theme Prompt</Label>
          <Input
            id="theme-prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="E.g., Modern tech startup, Vintage bookstore, Eco-friendly fashion"
          />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="color-mode">Color Mode</Label>
            <Switch
              id="color-mode"
              checked={colorMode === "dark"}
              onCheckedChange={(checked) => setColorMode(checked ? "dark" : "light")}
            />
            <span>{colorMode === "dark" ? "Dark" : "Light"}</span>
          </div>
          <div>
            <Label htmlFor="color-palette">Color Palette</Label>
            <Select value={colorPalette} onValueChange={(value: any) => setColorPalette(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select color palette" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="monochromatic">Monochromatic</SelectItem>
                <SelectItem value="analogous">Analogous</SelectItem>
                <SelectItem value="complementary">Complementary</SelectItem>
                <SelectItem value="triadic">Triadic</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="style-complexity">Style Complexity</Label>
            <Slider
              id="style-complexity"
              min={0}
              max={100}
              step={1}
              value={[styleComplexity]}
              onValueChange={(value) => setStyleComplexity(value[0])}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>Simple</span>
              <span>Complex</span>
            </div>
          </div>
          <div>
            <Label htmlFor="accessibility-level">Accessibility Level</Label>
            <Select value={accessibilityLevel} onValueChange={(value: any) => setAccessibilityLevel(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select accessibility level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AA">AA</SelectItem>
                <SelectItem value="AAA">AAA</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button onClick={handleGenerateTheme} disabled={isGenerating || !prompt}>
            {isGenerating ? "Generating..." : "Generate Theme"}
          </Button>
          <Button onClick={undo} disabled={!canUndo}>
            Undo
          </Button>
          <Button onClick={redo} disabled={!canRedo}>
            Redo
          </Button>
        </div>
        {generatedTheme && (
          <Tabs defaultValue="preview">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="colors">Colors</TabsTrigger>
              <TabsTrigger value="typography">Typography</TabsTrigger>
              <TabsTrigger value="layout">Layout</TabsTrigger>
              <TabsTrigger value="analysis">Analysis</TabsTrigger>
              <TabsTrigger value="export">Export</TabsTrigger>
            </TabsList>
            <TabsContent value="preview">
              <ThemePreview theme={generatedTheme} />
            </TabsContent>
            <TabsContent value="colors">
              <Accordion type="single" collapsible>
                <AccordionItem value="color-scheme">
                  <AccordionTrigger>Color Scheme</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(generatedTheme.colors).map(([key, color]) => (
                        <div key={key} className="flex items-center space-x-2">
                          <ColorSwatch
                            color={color}
                            name={key}
                            onChange={(newColor) => handleColorChange(key as keyof Theme["colors"], newColor)}
                          />
                          <span className="capitalize">{key}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="color-harmony">
                  <AccordionTrigger>Color Harmony</AccordionTrigger>
                  <AccordionContent>
                    <ColorHarmonyAnalyzer colors={generatedTheme.colors} />
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>
            <TabsContent value="typography">
              <Accordion type="single" collapsible>
                <AccordionItem value="fonts">
                  <AccordionTrigger>Fonts</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <div>
                        <Label>Heading Font</Label>
                        <Input value={generatedTheme.typography.headingFont} readOnly />
                      </div>
                      <div>
                        <Label>Body Font</Label>
                        <Input value={generatedTheme.typography.bodyFont} readOnly />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="font-sizes">
                  <AccordionTrigger>Font Sizes</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {Object.entries(generatedTheme.typography.fontSize).map(([size, value]) => (
                        <div key={size}>
                          <Label className="capitalize">{size}</Label>
                          <Input value={value} readOnly />
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="line-heights">
                  <AccordionTrigger>Line Heights</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {Object.entries(generatedTheme.typography.lineHeight).map(([size, value]) => (
                        <div key={size}>
                          <Label className="capitalize">{size}</Label>
                          <Input value={value} readOnly />
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="font-weights">
                  <AccordionTrigger>Font Weights</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {Object.entries(generatedTheme.typography.fontWeight).map(([weight, value]) => (
                        <div key={weight}>
                          <Label className="capitalize">{weight}</Label>
                          <Input value={value} readOnly />
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="font-pairing">
                  <AccordionTrigger>Font Pairing Suggestions</AccordionTrigger>
                  <AccordionContent>
                    <FontPairingSuggestions
                      headingFont={generatedTheme.typography.headingFont}
                      bodyFont={generatedTheme.typography.bodyFont}
                    />
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>
            <TabsContent value="layout">
              <Accordion type="single" collapsible>
                <AccordionItem value="spacing">
                  <AccordionTrigger>Spacing</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {Object.entries(generatedTheme.spacing).map(([size, value]) => (
                        <div key={size}>
                          <Label className="capitalize">{size}</Label>
                          <Input value={value} readOnly />
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="border-radius">
                  <AccordionTrigger>Border Radius</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {Object.entries(generatedTheme.borderRadius).map(([size, value]) => (
                        <div key={size}>
                          <Label className="capitalize">{size}</Label>
                          <Input value={value} readOnly />
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="shadows">
                  <AccordionTrigger>Shadows</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {Object.entries(generatedTheme.shadows).map(([size, value]) => (
                        <div key={size}>
                          <Label className="capitalize">{size}</Label>
                          <Input value={value} readOnly />
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>
            <TabsContent value="analysis">
              <AccessibilityChecker theme={generatedTheme} />
            </TabsContent>
            <TabsContent value="export">
              <div className="space-y-4">
                <Button onClick={handleExportTheme}>Export Theme</Button>
                <div>
                  <Label htmlFor="import-theme">Import Theme</Label>
                  <Input id="import-theme" type="file" accept=".json" onChange={handleImportTheme} />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}
        {generatedTheme && <Button onClick={handleApplyTheme}>Apply Theme to Selected Elements</Button>}
      </div>
    </div>
  )
}

