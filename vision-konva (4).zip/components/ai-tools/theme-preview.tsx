import type { Theme } from "@/types/theme"

export function ThemePreview({ theme }: { theme: Theme }) {
  return (
    <div className="space-y-4">
      <div style={{ backgroundColor: theme.colors.background, padding: "1rem" }}>
        <h1
          style={{
            color: theme.colors.primary,
            fontFamily: theme.typography.headingFont,
            fontSize: theme.typography.fontSize.large,
          }}
        >
          Theme Preview
        </h1>
        <p
          style={{
            color: theme.colors.text,
            fontFamily: theme.typography.bodyFont,
            fontSize: theme.typography.fontSize.medium,
          }}
        >
          This is a preview of your generated theme. It showcases the primary colors, typography, and overall style.
        </p>
        <button
          style={{
            backgroundColor: theme.colors.accent,
            color: theme.colors.background,
            padding: "0.5rem 1rem",
            border: "none",
            borderRadius: theme.borderRadius.medium,
            fontFamily: theme.typography.bodyFont,
            fontSize: theme.typography.fontSize.small,
            cursor: "pointer",
          }}
        >
          Sample Button
        </button>
      </div>
    </div>
  )
}

