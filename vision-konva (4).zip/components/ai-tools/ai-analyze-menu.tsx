"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, ChevronLeft, ChevronRight } from "lucide-react"
import { useEditorStore } from "@/store/editor-store"
import { aiService } from "@/lib/ai-service"

interface AIAnalyzeMenuProps {
  onClose: () => void
}

export function AIAnalyzeMenu({ onClose }: AIAnalyzeMenuProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const elements = useEditorStore((state) => state.elements)
  const updateElements = useEditorStore((state) => state.updateElements)

  const handleAnalyze = async () => {
    setIsAnalyzing(true)
    setSuggestions([])
    setCurrentIndex(0)
    try {
      if (!elements || elements.length === 0) {
        throw new Error("No elements found in the design.")
      }

      const elementData = elements
        .map((element) => {
          if (!element || typeof element !== "object") {
            console.warn("Invalid element found:", element)
            return null
          }
          return {
            type: element.type || "unknown",
            id: element.id,
            x: element.x,
            y: element.y,
            width: element.width,
            height: element.height,
            ...(element.type === "text" && { text: element.text }),
            ...(element.type === "image" && { src: element.src }),
            ...(element.type === "video" && { src: element.src }),
            ...(element.type === "shape" && { shapeType: element.shapeType }),
          }
        })
        .filter(Boolean)

      if (elementData.length === 0) {
        throw new Error("No valid elements found in the design.")
      }

      const result = await aiService.analyzeDesign(elementData)
      if (!Array.isArray(result) || result.length === 0) {
        throw new Error("Invalid response from AI service.")
      }
      setSuggestions(result)
    } catch (error) {
      console.error("Error analyzing design:", error)
      setSuggestions([`An error occurred while analyzing the design: ${error.message}`])
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleApplyChanges = () => {
    // This is a placeholder function. You'll need to implement the actual logic
    // to apply the changes based on the current suggestion.
    console.log("Applying changes based on suggestion:", suggestions[currentIndex])
    // Example: updateElements(newElementsState)
  }

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex < suggestions.length - 1 ? prevIndex + 1 : prevIndex))
  }

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex > 0 ? prevIndex - 1 : prevIndex))
  }

  return (
    <div className="fixed right-16 top-12 bottom-[200px] w-80 bg-background border-l border-border z-20 flex flex-col text-sm overflow-hidden">
      <div className="flex justify-between items-center p-2 border-b border-border">
        <h2 className="text-base font-semibold">AI Analyze</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          X
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <Button onClick={handleAnalyze} disabled={isAnalyzing} className="w-full">
          {isAnalyzing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            "Analyze Design"
          )}
        </Button>
        {suggestions.length > 0 && (
          <div className="space-y-2">
            <h3 className="font-semibold">Analysis Results:</h3>
            <Textarea value={suggestions[currentIndex]} readOnly className="w-full h-[200px] resize-none" />
            <div className="flex justify-between items-center mt-2">
              <Button onClick={handlePrevious} disabled={currentIndex === 0} size="sm">
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <Button onClick={handleApplyChanges} size="sm" className="px-4">
                Apply Changes
              </Button>
              <Button onClick={handleNext} disabled={currentIndex === suggestions.length - 1} size="sm">
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
            <p className="text-center text-sm text-muted-foreground">
              Suggestion {currentIndex + 1} of {suggestions.length}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

