"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { useEditorStore } from "@/store/editor-store"
import { Maximize, Minimize, Move, Home, FileIcon, ZoomIn, ZoomOut } from "lucide-react"
import { useState, useEffect } from "react"
import Link from "next/link"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { isMobile } from "@/lib/mobile-utils"

const CANVAS_PRESETS = {
  Landscape: { width: 1920, height: 1080 },
  Portrait: { width: 1080, height: 1920 },
  Square: { width: 1080, height: 1080 },
  "4K": { width: 3840, height: 2160 },
  "4K Portrait": { width: 2160, height: 3840 },
  Custom: { width: 0, height: 0 },
}

export function TopToolbar() {
  const {
    canvasSize,
    setCanvasSize,
    scale,
    setScale,
    isFitToScreen,
    setIsFitToScreen,
    resetView,
    activeTool,
    setActiveTool,
  } = useEditorStore()

  const [displayWidth, setDisplayWidth] = useState(canvasSize.width.toString())
  const [displayHeight, setDisplayHeight] = useState(canvasSize.height.toString())
  const [selectedPreset, setSelectedPreset] = useState<keyof typeof CANVAS_PRESETS>("Custom")
  const [isMobileView, setIsMobileView] = useState(false)

  useEffect(() => {
    setDisplayWidth(canvasSize.width.toString())
    setDisplayHeight(canvasSize.height.toString())
  }, [canvasSize])

  useEffect(() => {
    setIsMobileView(isMobile())

    const handleResize = () => {
      setIsMobileView(isMobile())
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const handlePresetChange = (preset: keyof typeof CANVAS_PRESETS) => {
    setSelectedPreset(preset)
    if (preset !== "Custom") {
      const newSize = CANVAS_PRESETS[preset]
      setCanvasSize(newSize)
    }
  }

  const handleCanvasSizeChange = (dimension: "width" | "height", value: string) => {
    const numValue = Number.parseInt(value, 10)
    if (!isNaN(numValue)) {
      setCanvasSize({ ...canvasSize, [dimension]: numValue })
      setSelectedPreset("Custom")
    }
    if (dimension === "width") {
      setDisplayWidth(value)
    } else {
      setDisplayHeight(value)
    }
  }

  const handleZoom = (zoomIn: boolean) => {
    setScale(zoomIn ? scale * 1.2 : scale / 1.2)
  }

  const togglePanTool = () => {
    setActiveTool(activeTool === "pan" ? "select" : "pan")
  }

  return (
    <div className="h-12 flex items-center justify-between px-4 bg-card text-card-foreground border-b border-border">
      <div className="flex items-center space-x-2">
        <Link href="/dashboard">
          <Button variant="ghost" size="sm">
            <Home className="h-4 w-4" />
            <span className={isMobileView ? "sr-only" : "ml-2"}>Home</span>
          </Button>
        </Link>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm">
              <FileIcon className="h-4 w-4" />
              <span className={isMobileView ? "sr-only" : "ml-2"}>File</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem>New Project</DropdownMenuItem>
            <DropdownMenuItem>Open Project</DropdownMenuItem>
            <DropdownMenuItem>Save Project</DropdownMenuItem>
            <DropdownMenuItem>Export</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {!isMobileView && (
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm">Canvas:</span>
            <Input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={displayWidth}
              onChange={(e) => handleCanvasSizeChange("width", e.target.value)}
              className="w-16 h-8 text-sm"
            />
            <span>x</span>
            <Input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={displayHeight}
              onChange={(e) => handleCanvasSizeChange("height", e.target.value)}
              className="w-16 h-8 text-sm"
            />
          </div>
          <Select
            value={selectedPreset}
            onValueChange={(value) => handlePresetChange(value as keyof typeof CANVAS_PRESETS)}
          >
            <SelectTrigger className="w-32 h-8 text-sm">
              <SelectValue placeholder="Canvas Presets" />
            </SelectTrigger>
            <SelectContent>
              {Object.keys(CANVAS_PRESETS).map((preset) => (
                <SelectItem key={preset} value={preset}>
                  {preset}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm" onClick={() => handleZoom(false)} title="Zoom Out">
          <ZoomOut className="h-4 w-4" />
        </Button>
        <span className="text-sm">{Math.round(scale * 100)}%</span>
        <Button variant="ghost" size="sm" onClick={() => handleZoom(true)} title="Zoom In">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button
          variant={activeTool === "pan" ? "secondary" : "ghost"}
          size="sm"
          onClick={togglePanTool}
          title="Pan Tool"
        >
          <Move className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setIsFitToScreen(!isFitToScreen)
            resetView()
          }}
          title={isFitToScreen ? "Exit Fit to Screen" : "Fit to Screen"}
        >
          {isFitToScreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  )
}

