"use client"

import { useEffect } from "react"
import { useEditorStore } from "@/store/editor-store"

export function KeyboardShortcuts() {
  const {
    undo,
    redo,
    copySelectedElements,
    pasteElements,
    deleteSelectedElements,
    selectAll,
    groupElements,
    ungroupElements,
    alignElements,
    distributeElements,
    flipElement,
    rotateElement,
    selectedIds,
  } = useEditorStore()

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "z":
            if (e.shiftKey) {
              redo()
            } else {
              undo()
            }
            break
          case "c":
            copySelectedElements()
            break
          case "v":
            pasteElements()
            break
          case "a":
            e.preventDefault()
            selectAll()
            break
          case "g":
            e.preventDefault()
            if (e.shiftKey) {
              ungroupElements(selectedIds[0])
            } else {
              groupElements(selectedIds)
            }
            break
        }
      } else {
        switch (e.key) {
          case "Delete":
            deleteSelectedElements()
            break
          case "ArrowLeft":
            if (e.shiftKey) {
              alignElements(selectedIds, "left")
            } else {
              // Move selected elements left
            }
            break
          case "ArrowRight":
            if (e.shiftKey) {
              alignElements(selectedIds, "right")
            } else {
              // Move selected elements right
            }
            break
          case "ArrowUp":
            if (e.shiftKey) {
              alignElements(selectedIds, "top")
            } else {
              // Move selected elements up
            }
            break
          case "ArrowDown":
            if (e.shiftKey) {
              alignElements(selectedIds, "bottom")
            } else {
              // Move selected elements down
            }
            break
          case "h":
            if (e.shiftKey) {
              distributeElements(selectedIds, "horizontal")
            } else {
              flipElement(selectedIds[0], "horizontal")
            }
            break
          case "v":
            if (e.shiftKey) {
              distributeElements(selectedIds, "vertical")
            } else {
              flipElement(selectedIds[0], "vertical")
            }
            break
          case "r":
            rotateElement(selectedIds[0], 90)
            break
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [
    undo,
    redo,
    copySelectedElements,
    pasteElements,
    deleteSelectedElements,
    selectAll,
    groupElements,
    ungroupElements,
    alignElements,
    distributeElements,
    flipElement,
    rotateElement,
    selectedIds,
  ])

  return null
}

