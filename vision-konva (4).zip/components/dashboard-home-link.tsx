import Link from "next/link"
import { Home } from "lucide-react"
import { Button } from "@/components/ui/button"

export function DashboardHomeLink() {
  return (
    <Link href="/dashboard" className="absolute top-4 left-4">
      <Button variant="outline" size="icon">
        <Home className="h-4 w-4" />
        <span className="sr-only">Back to Dashboard</span>
      </Button>
    </Link>
  )
}

