"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useEditorStore } from "@/store/editor-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Lock, Unlock } from "lucide-react"

export const TransformTools: React.FC = () => {
  const { selectedIds, elements, transformElement, enableTransformer } = useEditorStore()
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [size, setSize] = useState({ width: 0, height: 0 })
  const [rotation, setRotation] = useState(0)
  const [aspectRatioLocked, setAspectRatioLocked] = useState(false)
  const [snapToGrid, setSnapToGrid] = useState(false)
  const [transformMode, setTransformMode] = useState("default")

  useEffect(() => {
    if (selectedIds.length > 0) {
      const selectedElements = elements.filter((el) => selectedIds.includes(el.id))
      if (selectedElements.length > 0) {
        const firstElement = selectedElements[0]
        setPosition({ x: firstElement.x, y: firstElement.y })
        setSize({ width: firstElement.width, height: firstElement.height })
        setRotation(firstElement.rotation || 0)
        setTransformMode(selectedElements.every((el) => el.type === "text") ? "text" : "default")
      }
    }
  }, [selectedIds, elements])

  useEffect(() => {
    const options = {
      keepRatio: aspectRatioLocked,
      enabledAnchors: transformMode === "text" ? ["middle-left", "middle-right"] : undefined,
    }
    enableTransformer(selectedIds, options)
  }, [selectedIds, aspectRatioLocked, transformMode, enableTransformer])

  const handleTransform = (transformProps: any) => {
    selectedIds.forEach((id) => transformElement(id, transformProps))
  }

  const handleSizeChange = (dimension: "width" | "height", value: number) => {
    if (aspectRatioLocked) {
      const aspect = size.width / size.height
      const newSize =
        dimension === "width" ? { width: value, height: value / aspect } : { width: value * aspect, height: value }
      setSize(newSize)
      handleTransform(newSize)
    } else {
      setSize((prev) => ({ ...prev, [dimension]: value }))
      handleTransform({ [dimension]: value })
    }
  }

  return (
    <div className="p-4 bg-background border rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Transform Tools</h2>

      <div className="space-y-4">
        <div className="flex space-x-2">
          <div>
            <Label htmlFor="position-x">X</Label>
            <Input
              id="position-x"
              type="number"
              value={position.x}
              onChange={(e) => {
                const x = Number.parseFloat(e.target.value)
                setPosition((prev) => ({ ...prev, x }))
                handleTransform({ x })
              }}
            />
          </div>
          <div>
            <Label htmlFor="position-y">Y</Label>
            <Input
              id="position-y"
              type="number"
              value={position.y}
              onChange={(e) => {
                const y = Number.parseFloat(e.target.value)
                setPosition((prev) => ({ ...prev, y }))
                handleTransform({ y })
              }}
            />
          </div>
        </div>

        <div className="flex space-x-2">
          <div>
            <Label htmlFor="size-width">Width</Label>
            <Input
              id="size-width"
              type="number"
              value={size.width}
              onChange={(e) => handleSizeChange("width", Number.parseFloat(e.target.value))}
            />
          </div>
          <div>
            <Label htmlFor="size-height">Height</Label>
            <Input
              id="size-height"
              type="number"
              value={size.height}
              onChange={(e) => handleSizeChange("height", Number.parseFloat(e.target.value))}
            />
          </div>
          <div className="flex items-end">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setAspectRatioLocked(!aspectRatioLocked)}
              title={aspectRatioLocked ? "Unlock aspect ratio" : "Lock aspect ratio"}
            >
              {aspectRatioLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <div>
          <Label htmlFor="rotation">Rotation</Label>
          <Slider
            id="rotation"
            min={0}
            max={360}
            step={1}
            value={[rotation]}
            onValueChange={(value) => {
              setRotation(value[0])
              handleTransform({ rotation: value[0] })
            }}
          />
          <span className="text-sm">{rotation}°</span>
        </div>

        <div className="flex items-center space-x-2">
          <Switch id="snap-to-grid" checked={snapToGrid} onCheckedChange={setSnapToGrid} />
          <Label htmlFor="snap-to-grid">Snap to Grid</Label>
        </div>

        {transformMode === "text" && (
          <div>
            <Label htmlFor="font-size">Font Size</Label>
            <Input
              id="font-size"
              type="number"
              value={elements.find((el) => el.id === selectedIds[0])?.fontSize || 16}
              onChange={(e) => handleTransform({ fontSize: Number.parseFloat(e.target.value) })}
            />
          </div>
        )}

        <div className="flex space-x-2">
          <Button onClick={() => handleTransform({ scaleX: 1, scaleY: 1 })}>Reset Scale</Button>
          <Button onClick={() => handleTransform({ rotation: 0 })}>Reset Rotation</Button>
        </div>
      </div>
    </div>
  )
}

