"use client"

import { useState } from "react"
import { FixedSizeList as List } from "react-window"
import { useEditorStore } from "@/store/editor-store"

export function LayersPanel() {
  const { layers, updateLayer, removeLayer } = useEditorStore()
  const [page, setPage] = useState(0)
  const itemsPerPage = 50

  const renderRow = ({ index, style }) => {
    const layer = layers[index + page * itemsPerPage]
    if (!layer) return null

    return (
      <div style={style}>
        <span>{layer.name}</span>
        <button onClick={() => updateLayer(layer.id, { visible: !layer.visible })}>
          {layer.visible ? "Hide" : "Show"}
        </button>
        <button onClick={() => removeLayer(layer.id)}>Remove</button>
      </div>
    )
  }

  return (
    <div>
      <List
        height={400}
        itemCount={Math.min(itemsPerPage, layers.length - page * itemsPerPage)}
        itemSize={35}
        width={300}
      >
        {renderRow}
      </List>
      <div>
        <button onClick={() => setPage(Math.max(0, page - 1))} disabled={page === 0}>
          Previous Page
        </button>
        <button onClick={() => setPage(page + 1)} disabled={(page + 1) * itemsPerPage >= layers.length}>
          Next Page
        </button>
      </div>
    </div>
  )
}

