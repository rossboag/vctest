"use client"

import { useEffect, useState } from "react"
import { getDeviceType } from "@/lib/mobile-utils"
import { EditorToolbar } from "./editor-toolbar"
import { RightToolbar } from "./right-toolbar"
import { TopToolbar } from "./top-toolbar"
import EditorCanvas from "./editor-canvas"
import { TimelinePanel } from "./timeline-panel"
import { MobileUIAdaptations } from "./mobile-ui-adaptations"
import { TouchInteractions } from "./touch-interactions"

export function ResponsiveEditor() {
  const [deviceType, setDeviceType] = useState<"mobile" | "tablet" | "desktop">("desktop")

  useEffect(() => {
    // Fixed: Check for window before accessing it (for SSR)
    if (typeof window !== "undefined") {
      const updateDeviceType = () => {
        setDeviceType(getDeviceType())
      }

      updateDeviceType()
      window.addEventListener("resize", updateDeviceType)
      return () => window.removeEventListener("resize", updateDeviceType)
    }
  }, [])

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden">
      <TopToolbar />

      <div className="flex-1 relative">
        <EditorToolbar />
        <RightToolbar />
        <EditorCanvas />
        <TouchInteractions />
      </div>

      {/* Fixed: Added conditional rendering for timeline panel */}
      {deviceType !== "mobile" && (
        <div className={`${deviceType === "tablet" ? "h-32" : "h-[200px]"} border-t border-border`}>
          <TimelinePanel />
        </div>
      )}

      {deviceType === "mobile" && <MobileUIAdaptations />}
    </div>
  )
}

