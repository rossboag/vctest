"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { aiHelper } from "@/lib/ai-helper"
import { useEditorStore } from "@/store/editor-store"

export function AIDesignAssistant() {
  const [isLoading, setIsLoading] = useState(false)
  const { elements, updateElements } = useEditorStore()

  const handleGenerateLayout = async () => {
    setIsLoading(true)
    try {
      const newLayout = await aiHelper.generateLayoutSuggestion(elements)
      updateElements(newLayout)
    } catch (error) {
      console.error("Error generating layout:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAccessibilityCheck = async () => {
    setIsLoading(true)
    try {
      const report = await aiHelper.generateAccessibilityReport(elements)
      // Display the report to the user (you might want to create a modal or a new panel for this)
      console.log(report)
    } catch (error) {
      console.error("Error generating accessibility report:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleGenerateVariations = async () => {
    setIsLoading(true)
    try {
      const variations = await aiHelper.generateDesignVariations(elements)
      // Display the variations to the user (you might want to create a new panel or modal for this)
      console.log(variations)
    } catch (error) {
      console.error("Error generating design variations:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <Button onClick={handleGenerateLayout} disabled={isLoading}>
        Generate Improved Layout
      </Button>
      <Button onClick={handleAccessibilityCheck} disabled={isLoading}>
        Check Accessibility
      </Button>
      <Button onClick={handleGenerateVariations} disabled={isLoading}>
        Generate Design Variations
      </Button>
    </div>
  )
}

