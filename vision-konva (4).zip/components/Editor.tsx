"use client"

import type React from "react"
import { useEffect, useRef, useCallback } from "react"
import { useEditorStore } from "@/store/editor-store"
import { LayerManager } from "./LayerManager"
import { StyleEditor } from "./StyleEditor"
import { UndoRedoButtons } from "./UndoRedoButtons"
import { SelectionTool } from "./SelectionTool"
import { BlendModeSelector } from "./BlendModeSelector"
import { ShadowEditor } from "./ShadowEditor"
import { FilterEditor } from "./FilterEditor"
import { AnimationEditor } from "./AnimationEditor"
import { TransformTools } from "./TransformTools"
import { GridOverlay } from "./GridOverlay"
import { TextTool } from "./TextTool"
import { RichTextEditor } from "./RichTextEditor"
import { useHotkeys } from "react-hotkeys-hook"
import { HistoryPanel } from "./HistoryPanel"
import { ProjectManager } from "./ProjectManager"
import { TopToolbar } from "./top-toolbar"

export const Editor: React.FC = () => {
  const {
    initStage,
    fitStageIntoParentContainer,
    saveState,
    snapToGrid,
    gridSize,
    selectedIds,
    setSelectedIds,
    elements,
    transformElement,
    undo,
    redo,
    activeTool,
    copySelectedElements,
    pasteElements,
    deleteSelectedElements,
    selectAll,
    zoomToSelection,
  } = useEditorStore()
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      initStage(containerRef.current.id, 800, 600)
      fitStageIntoParentContainer()
      window.addEventListener("resize", fitStageIntoParentContainer)
    }

    return () => {
      window.removeEventListener("resize", fitStageIntoParentContainer)
    }
  }, [initStage, fitStageIntoParentContainer])

  const handleAction = useCallback(
    (action: () => void) => {
      action()
      saveState()
    },
    [saveState],
  )

  // Keyboard shortcuts
  useHotkeys("ctrl+z, cmd+z", () => handleAction(undo), [handleAction, undo])
  useHotkeys("ctrl+shift+z, cmd+shift+z", () => handleAction(redo), [handleAction, redo])
  useHotkeys("ctrl+c, cmd+c", copySelectedElements, [copySelectedElements])
  useHotkeys("ctrl+v, cmd+v", () => handleAction(pasteElements), [handleAction, pasteElements])
  useHotkeys("delete, backspace", () => handleAction(deleteSelectedElements), [handleAction, deleteSelectedElements])
  useHotkeys(
    "ctrl+a, cmd+a",
    (e) => {
      e.preventDefault()
      selectAll()
    },
    [selectAll],
  )
  useHotkeys("ctrl+0, cmd+0", zoomToSelection, [zoomToSelection])

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      const moveDistance = e.shiftKey ? 10 : 1
      switch (e.key) {
        case "ArrowLeft":
          selectedIds.forEach((id) => transformElement(id, { x: -moveDistance }))
          break
        case "ArrowRight":
          selectedIds.forEach((id) => transformElement(id, { x: moveDistance }))
          break
        case "ArrowUp":
          selectedIds.forEach((id) => transformElement(id, { y: -moveDistance }))
          break
        case "ArrowDown":
          selectedIds.forEach((id) => transformElement(id, { y: moveDistance }))
          break
      }
    },
    [selectedIds, transformElement],
  )

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown)
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [handleKeyDown])

  return (
    <div className="flex flex-col h-screen">
      <TopToolbar />
      <div className="flex flex-1 relative">
        <div className="flex-1 overflow-auto bg-gray-800" style={{ height: "calc(100vh - 48px)" }}>
          <div
            id="konva-container"
            ref={containerRef}
            className={`w-full h-full ${activeTool === "text" ? "cursor-text" : ""}`}
          >
            {snapToGrid && <GridOverlay gridSize={gridSize} />}
          </div>
          {activeTool === "select" && <SelectionTool />}
          {activeTool === "text" && <TextTool />}
        </div>
        <div className="w-64 p-4 bg-background border-l border-border overflow-y-auto">
          <LayerManager />
          <StyleEditor />
          <BlendModeSelector />
          <ShadowEditor />
          <FilterEditor />
          <AnimationEditor />
          <TransformTools />
          <UndoRedoButtons />
          <RichTextEditor />
          <HistoryPanel />
          <ProjectManager />
        </div>
      </div>
    </div>
  )
}

