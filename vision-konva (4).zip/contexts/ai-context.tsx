"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback } from "react"
import { toast } from "@/components/ui/use-toast"

type AIServiceType = "text" | "image" | "layout" | "animation" | "colors" | "batch"

interface AIContextState {
  isGenerating: Record<AIServiceType, boolean>
  lastError: Error | null
  usageCount: number
  remainingCredits: number | null
}

interface AIContextValue extends AIContextState {
  startGeneration: (service: AIServiceType) => void
  endGeneration: (service: AIServiceType, success: boolean) => void
  setError: (error: Error | null) => void
  resetError: () => void
  trackUsage: (service: AIServiceType, cost?: number) => void
  updateRemainingCredits: (credits: number) => void
}

const AIContext = createContext<AIContextValue | undefined>(undefined)

export function AIProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AIContextState>({
    isGenerating: {
      text: false,
      image: false,
      layout: false,
      animation: false,
      colors: false,
      batch: false,
    },
    lastError: null,
    usageCount: 0,
    remainingCredits: null,
  })

  const startGeneration = useCallback((service: AIServiceType) => {
    setState((prev) => ({
      ...prev,
      isGenerating: {
        ...prev.isGenerating,
        [service]: true,
      },
    }))
  }, [])

  const endGeneration = useCallback((service: AIServiceType, success: boolean) => {
    setState((prev) => ({
      ...prev,
      isGenerating: {
        ...prev.isGenerating,
        [service]: false,
      },
    }))

    if (success) {
      toast({
        title: "Generation Complete",
        description: `${service.charAt(0).toUpperCase() + service.slice(1)} generation completed successfully.`,
      })
    }
  }, [])

  const setError = useCallback((error: Error | null) => {
    setState((prev) => ({
      ...prev,
      lastError: error,
    }))

    if (error) {
      toast({
        title: "Error",
        description: error.message || "An unknown error occurred",
        variant: "destructive",
      })
    }
  }, [])

  const resetError = useCallback(() => {
    setState((prev) => ({
      ...prev,
      lastError: null,
    }))
  }, [])

  const trackUsage = useCallback((service: AIServiceType, cost = 1) => {
    setState((prev) => ({
      ...prev,
      usageCount: prev.usageCount + 1,
      remainingCredits: prev.remainingCredits !== null ? prev.remainingCredits - cost : null,
    }))
  }, [])

  const updateRemainingCredits = useCallback((credits: number) => {
    setState((prev) => ({
      ...prev,
      remainingCredits: credits,
    }))
  }, [])

  return (
    <AIContext.Provider
      value={{
        ...state,
        startGeneration,
        endGeneration,
        setError,
        resetError,
        trackUsage,
        updateRemainingCredits,
      }}
    >
      {children}
    </AIContext.Provider>
  )
}

export function useAI() {
  const context = useContext(AIContext)
  if (context === undefined) {
    throw new Error("useAI must be used within an AIProvider")
  }
  return context
}

