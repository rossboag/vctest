const { Builder, By, Key, until } = require("selenium-webdriver")
const assert = require("assert")
const browserstack = require("browserstack-local")
const browserstackConfig = require("../browserstack.config")

// Initialize BrowserStack Local
let bsLocal
const startBrowserStackLocal = () => {
  return new Promise((resolve, reject) => {
    bsLocal = new browserstack.Local()
    const bsLocalArgs = {
      key: browserstackConfig.auth.accessKey,
      localIdentifier: browserstackConfig.connection_settings.localIdentifier,
    }
    bsLocal.start(bsLocalArgs, (error) => {
      if (error) return reject(error)
      console.log("BrowserStack Local started")
      resolve()
    })
  })
}

const stopBrowserStackLocal = () => {
  return new Promise((resolve) => {
    if (bsLocal) {
      bsLocal.stop(() => {
        console.log("BrowserStack Local stopped")
        resolve()
      })
    } else {
      resolve()
    }
  })
}

// Test suite
const runTests = async (capabilities) => {
  const driver = await new Builder()
    .usingServer("https://hub-cloud.browserstack.com/wd/hub")
    .withCapabilities({
      ...capabilities,
      "browserstack.user": browserstackConfig.auth.username,
      "browserstack.key": browserstackConfig.auth.accessKey,
      "browserstack.local": browserstackConfig.connection_settings.local,
      "browserstack.localIdentifier": browserstackConfig.connection_settings.localIdentifier,
      "browserstack.debug": true,
      "browserstack.console": "verbose",
      "browserstack.networkLogs": true,
      project: browserstackConfig.run_settings.project,
      build: browserstackConfig.run_settings.build,
      name: `Test on ${capabilities.browser || capabilities.device} ${capabilities.browser_version || capabilities.os_version}`,
    })
    .build()

  try {
    // Test 1: Home page loads correctly
    await driver.get("http://localhost:3000")
    await driver.wait(until.titleContains("Vision Creator"), 10000)
    console.log("✅ Home page loaded successfully")

    // Test 2: Login functionality
    await driver.get("http://localhost:3000/login")
    await driver.findElement(By.name("email")).sendKeys("test@example.com")
    await driver.findElement(By.name("password")).sendKeys("password123")
    await driver.findElement(By.css('button[type="submit"]')).click()
    await driver.wait(until.urlContains("/dashboard"), 10000)
    console.log("✅ Login successful")

    // Test 3: Editor loads correctly
    await driver.get("http://localhost:3000/editor")
    await driver.wait(until.elementLocated(By.css(".konvajs-content")), 15000)
    console.log("✅ Editor loaded successfully")

    // Test 4: Text tool works
    const isMobile = capabilities.device !== undefined
    if (!isMobile) {
      await driver.findElement(By.css('button[aria-label="Text Tool"]')).click()
      await driver.findElement(By.css(".konvajs-content")).click()
      await driver.findElement(By.css(".text-editor-input")).sendKeys("Test Text")
      await driver.findElement(By.css(".text-editor-input")).sendKeys(Key.ESCAPE)
      const textElement = await driver.findElement(By.css(".konvajs-content text"))
      assert(await textElement.isDisplayed(), "Text element should be visible")
      console.log("✅ Text tool works correctly")
    } else {
      console.log("⏩ Skipping text tool test on mobile device")
    }

    // Test 5: Right panel opens
    await driver.findElement(By.css('button[aria-label="Effects"]')).click()
    await driver.wait(until.elementLocated(By.css(".effects-panel")), 5000)
    console.log("✅ Effects panel opens correctly")

    // Test 6: AI Studio loads
    await driver.get("http://localhost:3000/ai-studio")
    await driver.wait(until.elementLocated(By.css(".ai-studio-container")), 10000)
    console.log("✅ AI Studio loaded successfully")

    console.log(
      `All tests passed on ${capabilities.browser || capabilities.device} ${capabilities.browser_version || capabilities.os_version}`,
    )
    return { success: true }
  } catch (error) {
    console.error(
      `❌ Test failed on ${capabilities.browser || capabilities.device} ${capabilities.browser_version || capabilities.os_version}:`,
      error,
    )
    return { success: false, error: error.message }
  } finally {
    await driver.quit()
  }
}

// Main execution
;(async () => {
  try {
    if (browserstackConfig.connection_settings.local) {
      await startBrowserStackLocal()
    }

    const results = []
    for (const browser of browserstackConfig.browsers) {
      const result = await runTests(browser)
      results.push({
        browser: browser.browser || browser.device,
        version: browser.browser_version || browser.os_version,
        success: result.success,
        error: result.error,
      })
    }

    // Print summary
    console.log("\n📊 Cross-Browser Test Summary:")
    console.log("--------------------------------------------------")
    for (const result of results) {
      console.log(`${result.browser} ${result.version}: ${result.success ? "✅ Passed" : "❌ Failed"}`)
      if (!result.success) {
        console.log(`  Error: ${result.error}`)
      }
    }
    console.log("--------------------------------------------------")
    const allPassed = results.every((r) => r.success)
    console.log(`Overall: ${allPassed ? "✅ All tests passed!" : "❌ Some tests failed!"}`)

    process.exit(allPassed ? 0 : 1)
  } catch (error) {
    console.error("❌ Error running tests:", error)
    process.exit(1)
  } finally {
    if (browserstackConfig.connection_settings.local) {
      await stopBrowserStackLocal()
    }
  }
})()

