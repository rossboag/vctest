"use client"

import { useState, useEffect, useCallback } from "react"
import { useSession } from "next-auth/react"

interface Notification {
  id: string
  userId: string
  senderId: string | null
  type: string
  title: string
  message: string
  link: string | null
  isRead: boolean
  createdAt: string
  updatedAt: string
  expiresAt: string | null
  metadata: any
  sender?: {
    id: string
    name: string | null
    image: string | null
  }
}

interface UseNotificationsOptions {
  includeRead?: boolean
  limit?: number
  pollingInterval?: number
}

export function useNotifications(options: UseNotificationsOptions = {}) {
  const { data: session } = useSession()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  const {
    includeRead = false,
    limit = 20,
    pollingInterval = 30000, // 30 seconds
  } = options

  // Fetch notifications
  const fetchNotifications = useCallback(async () => {
    if (!session?.user) return

    try {
      setLoading(true)
      const response = await fetch(`/api/notifications?includeRead=${includeRead}&limit=${limit}`)

      if (!response.ok) {
        throw new Error("Failed to fetch notifications")
      }

      const data = await response.json()
      setNotifications(data.notifications)
      setUnreadCount(data.unreadCount)
      setError(null)
    } catch (err) {
      console.error("Error fetching notifications:", err)
      setError(err instanceof Error ? err : new Error("Unknown error"))
    } finally {
      setLoading(false)
    }
  }, [session, includeRead, limit])

  // Mark a notification as read
  const markAsRead = useCallback(async (id: string) => {
    try {
      const response = await fetch("/api/notifications/read", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id }),
      })

      if (!response.ok) {
        throw new Error("Failed to mark notification as read")
      }

      // Update the local state
      setNotifications((prev) =>
        prev.map((notification) => (notification.id === id ? { ...notification, isRead: true } : notification)),
      )
      setUnreadCount((prev) => Math.max(0, prev - 1))

      return true
    } catch (err) {
      console.error("Error marking notification as read:", err)
      return false
    }
  }, [])

  // Mark all notifications as read
  const markAllAsRead = useCallback(async () => {
    try {
      const response = await fetch("/api/notifications/read", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ all: true }),
      })

      if (!response.ok) {
        throw new Error("Failed to mark all notifications as read")
      }

      // Update the local state
      setNotifications((prev) =>
        prev.map((notification) => ({
          ...notification,
          isRead: true,
        })),
      )
      setUnreadCount(0)

      return true
    } catch (err) {
      console.error("Error marking all notifications as read:", err)
      return false
    }
  }, [])

  // Delete a notification
  const deleteNotification = useCallback(
    async (id: string) => {
      try {
        const response = await fetch("/api/notifications/delete", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ id }),
        })

        if (!response.ok) {
          throw new Error("Failed to delete notification")
        }

        // Update the local state
        const deletedNotification = notifications.find((n) => n.id === id)
        setNotifications((prev) => prev.filter((n) => n.id !== id))

        // Update unread count if the deleted notification was unread
        if (deletedNotification && !deletedNotification.isRead) {
          setUnreadCount((prev) => Math.max(0, prev - 1))
        }

        return true
      } catch (err) {
        console.error("Error deleting notification:", err)
        return false
      }
    },
    [notifications],
  )

  // Delete all notifications
  const deleteAllNotifications = useCallback(async () => {
    try {
      const response = await fetch("/api/notifications/delete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ all: true }),
      })

      if (!response.ok) {
        throw new Error("Failed to delete all notifications")
      }

      // Update the local state
      setNotifications([])
      setUnreadCount(0)

      return true
    } catch (err) {
      console.error("Error deleting all notifications:", err)
      return false
    }
  }, [])

  // Fetch notifications on mount and when session changes
  useEffect(() => {
    if (session?.user) {
      fetchNotifications()
    }
  }, [session, fetchNotifications])

  // Set up polling for new notifications
  useEffect(() => {
    if (!session?.user || pollingInterval <= 0) return

    const intervalId = setInterval(fetchNotifications, pollingInterval)

    return () => {
      clearInterval(intervalId)
    }
  }, [session, fetchNotifications, pollingInterval])

  return {
    notifications,
    unreadCount,
    loading,
    error,
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    deleteAllNotifications,
  }
}

