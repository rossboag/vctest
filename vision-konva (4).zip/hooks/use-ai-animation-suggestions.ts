"use client"

import { useState } from "react"
import { toast } from "sonner"

interface UseAIAnimationSuggestionsOptions {
  onSuccess?: (suggestions: string[]) => void
  onError?: (error: Error) => void
}

export function useAIAnimationSuggestions(options?: UseAIAnimationSuggestionsOptions) {
  const [loading, setLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])

  const generateSuggestions = async (
    elementType: string,
    elementContent?: string,
    projectContext?: string,
    count = 3,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/animations/suggestions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elementType,
          elementContent,
          projectContext,
          count,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate animation suggestions")
      }

      const data = await response.json()
      setSuggestions(data.suggestions)

      if (options?.onSuccess) {
        options.onSuccess(data.suggestions)
      }

      return data.suggestions
    } catch (error) {
      console.error("Error generating animation suggestions:", error)
      toast.error("Failed to generate animation suggestions")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateSuggestions,
    loading,
    suggestions,
  }
}

