import { useAIService } from "./use-ai-service"

export interface AnimationGenerationInput {
  elementId: string
  animationType?: "fade" | "slide" | "bounce" | "custom"
  duration?: number
  customPrompt?: string
}

export interface KeyframeData {
  time: number
  properties: Record<string, any>
}

export interface AnimationGenerationOutput {
  keyframes: KeyframeData[]
  duration: number
  id: string
}

export function useAIAnimation(options = {}) {
  return useAIService<AnimationGenerationInput, AnimationGenerationOutput>("/api/ai/animation", options)
}

