"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { TypographyRecommendation } from "@/lib/ai-design-service"

interface UseTypographyRecommendationsOptions {
  onSuccess?: (typography: TypographyRecommendation) => void
  onError?: (error: Error) => void
}

export function useTypographyRecommendations(options?: UseTypographyRecommendationsOptions) {
  const [loading, setLoading] = useState(false)
  const [typography, setTypography] = useState<TypographyRecommendation | null>(null)

  const generateTypography = async (style?: string, purpose?: string, projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/typography", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          style,
          purpose,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate typography recommendations")
      }

      const data = await response.json()
      setTypography(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating typography recommendations:", error)
      toast.error("Failed to generate typography recommendations")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateTypography,
    loading,
    typography,
  }
}

