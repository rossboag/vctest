"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { ImageEnhancementOptions } from "@/lib/ai-content-service"

interface UseImageEnhancementOptions {
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

export function useImageEnhancement(options?: UseImageEnhancementOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const enhanceImage = async (
    imageUrl: string,
    enhancementOptions: ImageEnhancementOptions = {},
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/content/image/enhance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          imageUrl,
          options: enhancementOptions,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to enhance image")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error enhancing image:", error)
      toast.error("Failed to enhance image")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    enhanceImage,
    loading,
    result,
  }
}

