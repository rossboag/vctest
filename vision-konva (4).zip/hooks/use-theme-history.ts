"use client"

import { useState, useCallback } from "react"
import type { Theme } from "@/types/theme"

export function useThemeHistory() {
  const [history, setHistory] = useState<Theme[]>([])
  const [currentIndex, setCurrentIndex] = useState(-1)

  const addTheme = useCallback(
    (theme: Theme) => {
      setHistory((prevHistory) => [...prevHistory.slice(0, currentIndex + 1), theme])
      setCurrentIndex((prevIndex) => prevIndex + 1)
    },
    [currentIndex],
  )

  const undo = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex((prevIndex) => prevIndex - 1)
    }
  }, [currentIndex])

  const redo = useCallback(() => {
    if (currentIndex < history.length - 1) {
      setCurrentIndex((prevIndex) => prevIndex + 1)
    }
  }, [currentIndex, history.length])

  const canUndo = currentIndex > 0
  const canRedo = currentIndex < history.length - 1

  return {
    addTheme,
    undo,
    redo,
    canUndo,
    canRedo,
    currentTheme: history[currentIndex],
  }
}

