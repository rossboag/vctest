"use client"

import { useState } from "react"
import { toast } from "@/components/ui/use-toast"
import { AIServiceError } from "@/lib/errors"

export type AIRequestStatus = "idle" | "loading" | "success" | "error"

interface UseAIServiceOptions<T> {
  onSuccess?: (data: T) => void
  onError?: (error: Error) => void
  showToast?: boolean
}

export function useAIService<TInput, TOutput>(apiEndpoint: string, options: UseAIServiceOptions<TOutput> = {}) {
  const [status, setStatus] = useState<AIRequestStatus>("idle")
  const [data, setData] = useState<TOutput | null>(null)
  const [error, setError] = useState<Error | null>(null)

  const { onSuccess, onError, showToast = true } = options

  const execute = async (input: TInput): Promise<TOutput | null> => {
    try {
      setStatus("loading")
      setError(null)

      const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(input),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new AIServiceError(
          errorData.message || "An error occurred",
          response.status,
          errorData.code || "UNKNOWN_ERROR",
          errorData.details,
        )
      }

      const result = await response.json()
      setData(result)
      setStatus("success")

      if (showToast) {
        toast({
          title: "Success",
          description: "AI generation completed successfully",
          variant: "default",
        })
      }

      onSuccess?.(result)
      return result
    } catch (err) {
      const error = err instanceof Error ? err : new Error("An unknown error occurred")
      setError(error)
      setStatus("error")

      if (showToast) {
        toast({
          title: "Error",
          description: error.message || "Failed to generate content",
          variant: "destructive",
        })
      }

      onError?.(error)
      return null
    }
  }

  const reset = () => {
    setStatus("idle")
    setData(null)
    setError(null)
  }

  return {
    execute,
    reset,
    status,
    data,
    error,
    isLoading: status === "loading",
    isSuccess: status === "success",
    isError: status === "error",
  }
}

