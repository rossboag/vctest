"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LocalizationOptions } from "@/lib/ai-content-service"

interface UseContentLocalizationOptions {
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

export function useContentLocalization(options?: UseContentLocalizationOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const localizeContent = async (content: string, localizationOptions: LocalizationOptions, projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/content/localize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content,
          options: localizationOptions,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to localize content")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error localizing content:", error)
      toast.error("Failed to localize content")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    localizeContent,
    loading,
    result,
  }
}

