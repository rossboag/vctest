"use client"

import { useState, useEffect, useCallback } from "react"
import { toast } from "sonner"
import type { AnimationPreset } from "@/lib/ai-animation-service"

interface UseAnimationPresetsOptions {
  category?: string
  initialLoad?: boolean
}

export function useAnimationPresets(options?: UseAnimationPresetsOptions) {
  const [loading, setLoading] = useState(false)
  const [presets, setPresets] = useState<AnimationPreset[]>([])
  const [totalCount, setTotalCount] = useState(0)

  const fetchPresets = useCallback(async (category?: string, limit = 20, offset = 0) => {
    try {
      setLoading(true)

      const params = new URLSearchParams()
      if (category) params.append("category", category)
      if (limit) params.append("limit", limit.toString())
      if (offset) params.append("offset", offset.toString())

      const response = await fetch(`/api/animations/presets?${params.toString()}`)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch animation presets")
      }

      const data = await response.json()
      setPresets(data)
      setTotalCount(data.length)

      return data
    } catch (error: any) {
      console.error("Error fetching animation presets:", error)
      toast.error("Failed to fetch animation presets")
      throw error
    } finally {
      setLoading(false)
    }
  }, [])

  const searchPresets = useCallback(async (query: string, limit = 20, offset = 0) => {
    try {
      setLoading(true)

      const params = new URLSearchParams()
      params.append("q", query)
      if (limit) params.append("limit", limit.toString())
      if (offset) params.append("offset", offset.toString())

      const response = await fetch(`/api/animations/presets/search?${params.toString()}`)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to search animation presets")
      }

      const data = await response.json()
      setPresets(data)
      setTotalCount(data.length)

      return data
    } catch (error: any) {
      console.error("Error searching animation presets:", error)
      toast.error("Failed to search animation presets")
      throw error
    } finally {
      setLoading(false)
    }
  }, [])

  const getPresetById = useCallback(async (id: string) => {
    try {
      setLoading(true)

      const response = await fetch(`/api/animations/presets/${id}`)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch animation preset")
      }

      const data = await response.json()
      return data
    } catch (error: any) {
      console.error("Error fetching animation preset:", error)
      toast.error("Failed to fetch animation preset")
      throw error
    } finally {
      setLoading(false)
    }
  }, [])

  const createPreset = useCallback(
    async (name: string, description: string, category: string, duration = 2, projectId?: string) => {
      try {
        setLoading(true)

        const response = await fetch("/api/animations/presets", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name,
            description,
            category,
            duration,
            projectId,
          }),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to create animation preset")
        }

        const data = await response.json()

        // Update the presets list with the new preset
        setPresets((prevPresets) => [data, ...prevPresets])
        setTotalCount((prevCount) => prevCount + 1)

        return data
      } catch (error: any) {
        console.error("Error creating animation preset:", error)
        toast.error("Failed to create animation preset")
        throw error
      } finally {
        setLoading(false)
      }
    },
    [],
  )

  // Load presets on initial render if initialLoad is true
  useEffect(() => {
    if (options?.initialLoad) {
      fetchPresets(options.category)
    }
  }, [options?.category, options?.initialLoad, fetchPresets])

  return {
    presets,
    totalCount,
    loading,
    fetchPresets,
    searchPresets,
    getPresetById,
    createPreset,
  }
}

