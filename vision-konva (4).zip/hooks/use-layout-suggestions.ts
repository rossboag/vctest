"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LayoutElement, LayoutSuggestion } from "@/lib/ai-layout-service"

interface UseLayoutSuggestionsOptions {
  onSuccess?: (suggestions: LayoutSuggestion[]) => void
  onError?: (error: Error) => void
}

export function useLayoutSuggestions(options?: UseLayoutSuggestionsOptions) {
  const [loading, setLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<LayoutSuggestion[] | null>(null)

  const generateSuggestions = async (
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/layout/suggestions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          canvasSize,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate layout suggestions")
      }

      const data = await response.json()
      setSuggestions(data.suggestions)

      if (options?.onSuccess) {
        options.onSuccess(data.suggestions)
      }

      return data.suggestions
    } catch (error) {
      console.error("Error generating layout suggestions:", error)
      toast.error("Failed to generate layout suggestions")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateSuggestions,
    loading,
    suggestions,
  }
}

