"use client"

import { useState } from "react"
import { toast } from "sonner"

interface UseAIColorPaletteOptions {
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

export function useAIColorPalette(options?: UseAIColorPaletteOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const generateColorPalette = async (
    prompt: string,
    projectId?: string,
    paletteOptions?: {
      count?: number
      mode?: "analogous" | "complementary" | "triadic" | "monochromatic" | "custom"
    },
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/ai/color-palette", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          projectId,
          ...paletteOptions,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate color palette")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating color palette:", error)
      toast.error("Failed to generate color palette")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateColorPalette,
    loading,
    result,
  }
}

