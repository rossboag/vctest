"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { AnimationKeyframe } from "@/lib/ai-animation-service"

interface UseAIAnimationAnalysisOptions {
  onSuccess?: (result: { analysis: string; improvedKeyframes: AnimationKeyframe[] }) => void
  onError?: (error: Error) => void
}

export function useAIAnimationAnalysis(options?: UseAIAnimationAnalysisOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ analysis: string; improvedKeyframes: AnimationKeyframe[] } | null>(null)

  const analyzeAnimation = async (
    keyframes: AnimationKeyframe[],
    elementType: string,
    duration: number,
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/animations/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          keyframes,
          elementType,
          duration,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to analyze animation")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error analyzing animation:", error)
      toast.error("Failed to analyze animation")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    analyzeAnimation,
    loading,
    result,
  }
}

