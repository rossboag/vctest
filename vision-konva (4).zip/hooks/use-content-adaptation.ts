"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { ContentAdaptationOptions } from "@/lib/ai-content-service"

interface UseContentAdaptationOptions {
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

export function useContentAdaptation(options?: UseContentAdaptationOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const adaptContent = async (
    content: string,
    adaptationOptions: ContentAdaptationOptions = {},
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/content/adapt", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content,
          options: adaptationOptions,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to adapt content")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error adapting content:", error)
      toast.error("Failed to adapt content")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    adaptContent,
    loading,
    result,
  }
}

