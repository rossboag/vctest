"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LayoutElement, WhitespaceAnalysis } from "@/lib/ai-layout-service"

interface UseWhitespaceOptions {
  onAnalysisSuccess?: (analysis: WhitespaceAnalysis) => void
  onOptimizationSuccess?: (elements: LayoutElement[]) => void
  onError?: (error: Error) => void
}

export function useWhitespace(options?: UseWhitespaceOptions) {
  const [analyzing, setAnalyzing] = useState(false)
  const [optimizing, setOptimizing] = useState(false)
  const [analysis, setAnalysis] = useState<WhitespaceAnalysis | null>(null)
  const [optimizedElements, setOptimizedElements] = useState<LayoutElement[] | null>(null)

  const analyzeWhitespace = async (
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ) => {
    try {
      setAnalyzing(true)

      const response = await fetch("/api/layout/whitespace/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          canvasSize,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to analyze whitespace")
      }

      const data = await response.json()
      setAnalysis(data.analysis)

      if (options?.onAnalysisSuccess) {
        options.onAnalysisSuccess(data.analysis)
      }

      return data.analysis
    } catch (error) {
      console.error("Error analyzing whitespace:", error)
      toast.error("Failed to analyze whitespace")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setAnalyzing(false)
    }
  }

  const optimizeWhitespace = async (
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ) => {
    try {
      setOptimizing(true)

      const response = await fetch("/api/layout/whitespace/optimize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          canvasSize,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to optimize whitespace")
      }

      const data = await response.json()
      setOptimizedElements(data.elements)

      if (options?.onOptimizationSuccess) {
        options.onOptimizationSuccess(data.elements)
      }

      return data.elements
    } catch (error) {
      console.error("Error optimizing whitespace:", error)
      toast.error("Failed to optimize whitespace")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setOptimizing(false)
    }
  }

  return {
    analyzeWhitespace,
    optimizeWhitespace,
    analyzing,
    optimizing,
    analysis,
    optimizedElements,
  }
}

