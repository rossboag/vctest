"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { ContentEnhancementOptions } from "@/lib/ai-content-service"

interface UseTextEnhancementOptions {
  onSuccess?: (result: any) => void
  onError?: (error: Error) => void
}

export function useTextEnhancement(options?: UseTextEnhancementOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const enhanceText = async (
    content: string,
    enhancementOptions: ContentEnhancementOptions = {},
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/content/text/enhance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content,
          options: enhancementOptions,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to enhance text")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error enhancing text:", error)
      toast.error("Failed to enhance text")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    enhanceText,
    loading,
    result,
  }
}

