"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { DesignAnalysisResult, DesignElement } from "@/lib/ai-design-service"

interface ImprovementAction {
  elementId?: string
  action: string
  property?: string
  currentValue?: any
  suggestedValue?: any
  reason: string
  priority: number
}

interface UseImprovementActionsOptions {
  onSuccess?: (actions: ImprovementAction[]) => void
  onError?: (error: Error) => void
}

export function useImprovementActions(options?: UseImprovementActionsOptions) {
  const [loading, setLoading] = useState(false)
  const [actions, setActions] = useState<ImprovementAction[]>([])

  const generateActions = async (
    analysisResult: DesignAnalysisResult,
    elements: DesignElement[],
    canvasWidth: number,
    canvasHeight: number,
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/improvement-actions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          analysisResult,
          elements,
          canvasWidth,
          canvasHeight,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate improvement actions")
      }

      const data = await response.json()
      setActions(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating improvement actions:", error)
      toast.error("Failed to generate improvement actions")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateActions,
    loading,
    actions,
  }
}

