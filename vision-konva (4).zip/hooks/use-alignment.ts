"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LayoutElement, AlignmentAnalysis, GridSystem } from "@/lib/ai-layout-service"

interface UseAlignmentOptions {
  onAnalysisSuccess?: (analysis: AlignmentAnalysis) => void
  onOptimizationSuccess?: (elements: LayoutElement[]) => void
  onError?: (error: Error) => void
}

export function useAlignment(options?: UseAlignmentOptions) {
  const [analyzing, setAnalyzing] = useState(false)
  const [optimizing, setOptimizing] = useState(false)
  const [analysis, setAnalysis] = useState<AlignmentAnalysis | null>(null)
  const [optimizedElements, setOptimizedElements] = useState<LayoutElement[] | null>(null)

  const analyzeAlignment = async (elements: LayoutElement[], projectId?: string) => {
    try {
      setAnalyzing(true)

      const response = await fetch("/api/layout/alignment/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to analyze alignment")
      }

      const data = await response.json()
      setAnalysis(data.analysis)

      if (options?.onAnalysisSuccess) {
        options.onAnalysisSuccess(data.analysis)
      }

      return data.analysis
    } catch (error) {
      console.error("Error analyzing alignment:", error)
      toast.error("Failed to analyze alignment")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setAnalyzing(false)
    }
  }

  const optimizeAlignment = async (elements: LayoutElement[], gridSystem?: GridSystem, projectId?: string) => {
    try {
      setOptimizing(true)

      const response = await fetch("/api/layout/alignment/optimize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          gridSystem,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to optimize alignment")
      }

      const data = await response.json()
      setOptimizedElements(data.elements)

      if (options?.onOptimizationSuccess) {
        options.onOptimizationSuccess(data.elements)
      }

      return data.elements
    } catch (error) {
      console.error("Error optimizing alignment:", error)
      toast.error("Failed to optimize alignment")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setOptimizing(false)
    }
  }

  return {
    analyzeAlignment,
    optimizeAlignment,
    analyzing,
    optimizing,
    analysis,
    optimizedElements,
  }
}

