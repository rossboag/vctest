"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { GridSystem } from "@/lib/ai-layout-service"

interface UseGridSystemOptions {
  onSuccess?: (gridSystem: GridSystem) => void
  onError?: (error: Error) => void
}

export function useGridSystem(options?: UseGridSystemOptions) {
  const [loading, setLoading] = useState(false)
  const [gridSystem, setGridSystem] = useState<GridSystem | null>(null)

  const generateGridSystem = async (
    canvasSize: { width: number; height: number },
    complexity?: "simple" | "standard" | "complex",
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/layout/grid/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          canvasSize,
          complexity,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate grid system")
      }

      const data = await response.json()
      setGridSystem(data.gridSystem)

      if (options?.onSuccess) {
        options.onSuccess(data.gridSystem)
      }

      return data.gridSystem
    } catch (error) {
      console.error("Error generating grid system:", error)
      toast.error("Failed to generate grid system")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateGridSystem,
    loading,
    gridSystem,
  }
}

