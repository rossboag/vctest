"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LayoutElement } from "@/lib/ai-layout-service"

interface UseElementPositioningOptions {
  onSuccess?: (elements: LayoutElement[]) => void
  onError?: (error: Error) => void
}

export function useElementPositioning(options?: UseElementPositioningOptions) {
  const [loading, setLoading] = useState(false)
  const [optimizedElements, setOptimizedElements] = useState<LayoutElement[] | null>(null)

  const optimizePositioning = async (
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/layout/optimize-positioning", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          canvasSize,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to optimize element positioning")
      }

      const data = await response.json()
      setOptimizedElements(data.elements)

      if (options?.onSuccess) {
        options.onSuccess(data.elements)
      }

      return data.elements
    } catch (error) {
      console.error("Error optimizing element positioning:", error)
      toast.error("Failed to optimize element positioning")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    optimizePositioning,
    loading,
    optimizedElements,
  }
}

