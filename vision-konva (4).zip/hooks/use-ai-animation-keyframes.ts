"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { AnimationKeyframe } from "@/lib/ai-animation-service"

interface UseAIAnimationKeyframesOptions {
  onSuccess?: (keyframes: AnimationKeyframe[]) => void
  onError?: (error: Error) => void
}

export function useAIAnimationKeyframes(options?: UseAIAnimationKeyframesOptions) {
  const [loading, setLoading] = useState(false)
  const [keyframes, setKeyframes] = useState<AnimationKeyframe[]>([])

  const generateKeyframes = async (prompt: string, elementType: string, duration = 2, projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/animations/keyframes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          elementType,
          duration,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate animation keyframes")
      }

      const data = await response.json()
      setKeyframes(data.keyframes)

      if (options?.onSuccess) {
        options.onSuccess(data.keyframes)
      }

      return data.keyframes
    } catch (error) {
      console.error("Error generating animation keyframes:", error)
      toast.error("Failed to generate animation keyframes")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateKeyframes,
    loading,
    keyframes,
  }
}

