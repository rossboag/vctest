"use client"

import { useState } from "react"
import { toast } from "@/components/ui/use-toast"

export interface BatchJobInput {
  operations: {
    type: "text" | "image" | "layout" | "animation" | "colors"
    params: Record<string, any>
  }[]
}

export interface BatchJobOutput {
  jobId: string
}

export interface BatchJobStatus {
  jobId: string
  status: "pending" | "processing" | "completed" | "failed"
  progress: number
  results?: Record<string, any>[]
  error?: string
}

export function useAIBatch(
  options: {
    onSuccess?: (data: BatchJobStatus) => void
    onError?: (error: Error) => void
    pollingInterval?: number
  } = {},
) {
  const [jobId, setJobId] = useState<string | null>(null)
  const [status, setStatus] = useState<"idle" | "submitting" | "polling" | "completed" | "error">("idle")
  const [jobStatus, setJobStatus] = useState<BatchJobStatus | null>(null)
  const [error, setError] = useState<Error | null>(null)

  const { onSuccess, onError, pollingInterval = 2000 } = options

  // For polling
  const [pollingId, setPollingId] = useState<NodeJS.Timeout | null>(null)

  const submitBatchJob = async (input: BatchJobInput): Promise<string | null> => {
    try {
      setStatus("submitting")
      setError(null)

      const response = await fetch("/api/ai/batch", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(input),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to submit batch job")
      }

      const result: BatchJobOutput = await response.json()
      setJobId(result.jobId)

      // Start polling
      startPolling(result.jobId)

      return result.jobId
    } catch (err) {
      const error = err instanceof Error ? err : new Error("An unknown error occurred")
      setError(error)
      setStatus("error")

      toast({
        title: "Error",
        description: error.message || "Failed to submit batch job",
        variant: "destructive",
      })

      onError?.(error)
      return null
    }
  }

  const checkJobStatus = async (id: string): Promise<BatchJobStatus | null> => {
    try {
      const response = await fetch(`/api/ai/batch/${id}`, {
        method: "GET",
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to check job status")
      }

      const status: BatchJobStatus = await response.json()
      setJobStatus(status)

      if (status.status === "completed") {
        setStatus("completed")
        stopPolling()

        toast({
          title: "Success",
          description: "Batch AI generation completed successfully",
          variant: "default",
        })

        onSuccess?.(status)
      } else if (status.status === "failed") {
        setStatus("error")
        stopPolling()

        const error = new Error(status.error || "Batch job failed")
        setError(error)

        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        })

        onError?.(error)
      }

      return status
    } catch (err) {
      const error = err instanceof Error ? err : new Error("An unknown error occurred")
      setError(error)
      setStatus("error")
      stopPolling()

      toast({
        title: "Error",
        description: error.message || "Failed to check job status",
        variant: "destructive",
      })

      onError?.(error)
      return null
    }
  }

  const startPolling = (id: string) => {
    setStatus("polling")

    // Clear any existing polling
    if (pollingId) {
      clearInterval(pollingId)
    }

    // Start new polling
    const intervalId = setInterval(() => {
      checkJobStatus(id)
    }, pollingInterval)

    setPollingId(intervalId)
  }

  const stopPolling = () => {
    if (pollingId) {
      clearInterval(pollingId)
      setPollingId(null)
    }
  }

  const reset = () => {
    stopPolling()
    setStatus("idle")
    setJobId(null)
    setJobStatus(null)
    setError(null)
  }

  return {
    submitBatchJob,
    checkJobStatus,
    reset,
    jobId,
    status,
    jobStatus,
    error,
    isSubmitting: status === "submitting",
    isPolling: status === "polling",
    isCompleted: status === "completed",
    isError: status === "error",
    progress: jobStatus?.progress || 0,
  }
}

