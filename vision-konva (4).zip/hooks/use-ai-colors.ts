import { useAIService } from "./use-ai-service"

export interface ColorPaletteInput {
  prompt: string
  numberOfColors?: number
  baseColor?: string
}

export interface ColorPaletteOutput {
  colors: string[]
  id: string
}

export function useAIColors(options = {}) {
  return useAIService<ColorPaletteInput, ColorPaletteOutput>("/api/ai/colors", options)
}

