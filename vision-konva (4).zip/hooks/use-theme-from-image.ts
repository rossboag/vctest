"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { ThemeTemplate } from "@/lib/ai-style-service"

interface UseThemeFromImageOptions {
  onSuccess?: (theme: ThemeTemplate) => void
  onError?: (error: Error) => void
}

export function useThemeFromImage(options?: UseThemeFromImageOptions) {
  const [loading, setLoading] = useState(false)
  const [theme, setTheme] = useState<ThemeTemplate | null>(null)

  const generateThemeFromImage = async (
    imageUrl: string,
    themeName?: string,
    stylePreference?: string,
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/style/theme-from-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          imageUrl,
          themeName,
          stylePreference,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate theme from image")
      }

      const data = await response.json()
      setTheme(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating theme from image:", error)
      toast.error("Failed to generate theme from image")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateThemeFromImage,
    loading,
    theme,
  }
}

