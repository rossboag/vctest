"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { ColorPalette } from "@/lib/ai-design-service"

interface UseColorPaletteOptions {
  onSuccess?: (palette: ColorPalette) => void
  onError?: (error: Error) => void
}

export function useColorPalette(options?: UseColorPaletteOptions) {
  const [loading, setLoading] = useState(false)
  const [palette, setPalette] = useState<ColorPalette | null>(null)

  const generateColorPalette = async (baseColor?: string, mood?: string, style?: string, projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/color-palette", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          baseColor,
          mood,
          style,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate color palette")
      }

      const data = await response.json()
      setPalette(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating color palette:", error)
      toast.error("Failed to generate color palette")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateColorPalette,
    loading,
    palette,
  }
}

