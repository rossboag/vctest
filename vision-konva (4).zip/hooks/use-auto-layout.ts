"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LayoutResult } from "@/lib/ai-layout-service"

interface UseAutoLayoutOptions {
  onSuccess?: (layout: LayoutResult) => void
  onError?: (error: Error) => void
}

export function useAutoLayout(options?: UseAutoLayoutOptions) {
  const [loading, setLoading] = useState(false)
  const [layout, setLayout] = useState<LayoutResult | null>(null)

  const generateLayout = async (
    prompt: string,
    canvasSize: { width: number; height: number },
    contentElements?: Array<{
      type: string
      content?: string
      importance?: "high" | "medium" | "low"
    }>,
    style?: string,
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/layout/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          canvasSize,
          contentElements,
          style,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate layout")
      }

      const data = await response.json()
      setLayout(data.layout)

      if (options?.onSuccess) {
        options.onSuccess(data.layout)
      }

      return data.layout
    } catch (error) {
      console.error("Error generating layout:", error)
      toast.error("Failed to generate layout")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateLayout,
    loading,
    layout,
  }
}

