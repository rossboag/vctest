"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { ElementAnimationConfig } from "@/lib/ai-animation-service"

interface UseAIAnimationSequenceOptions {
  onSuccess?: (result: { sequenceDescription: string; elementAnimations: ElementAnimationConfig[] }) => void
  onError?: (error: Error) => void
}

export function useAIAnimationSequence(options?: UseAIAnimationSequenceOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    sequenceDescription: string
    elementAnimations: ElementAnimationConfig[]
  } | null>(null)

  const generateSequence = async (
    elements: Array<{
      id: string
      type: string
      content?: string
    }>,
    sequenceType: "sequential" | "parallel" | "staggered" | "custom",
    duration: number,
    description: string,
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/animations/sequence", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          sequenceType,
          duration,
          description,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate animation sequence")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating animation sequence:", error)
      toast.error("Failed to generate animation sequence")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateSequence,
    loading,
    result,
  }
}

