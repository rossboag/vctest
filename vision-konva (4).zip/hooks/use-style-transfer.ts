"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { StyleTransferResult } from "@/lib/ai-style-service"

interface UseStyleTransferOptions {
  onSuccess?: (result: StyleTransferResult) => void
  onError?: (error: Error) => void
}

export function useStyleTransfer(options?: UseStyleTransferOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<StyleTransferResult | null>(null)

  const transferStyle = async (
    sourceElements: any[],
    targetElements: any[],
    styleAspects?: string[],
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/style/transfer", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sourceElements,
          targetElements,
          styleAspects,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to transfer style")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error transferring style:", error)
      toast.error("Failed to transfer style")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    transferStyle,
    loading,
    result,
  }
}

