"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { DesignTrend } from "@/lib/ai-style-service"

interface UseDesignTrendOptions {
  onSuccess?: (trend: DesignTrend) => void
  onError?: (error: Error) => void
}

export function useDesignTrend(options?: UseDesignTrendOptions) {
  const [loading, setLoading] = useState(false)
  const [trend, setTrend] = useState<DesignTrend | null>(null)

  const getDesignTrend = async (trendName: string, year?: number, projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/style/trend/info", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          trendName,
          year,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to get design trend")
      }

      const data = await response.json()
      setTrend(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error getting design trend:", error)
      toast.error("Failed to get design trend")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  const applyDesignTrend = async (
    elements: any[],
    trendName: string,
    adaptationLevel?: "subtle" | "moderate" | "full",
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/style/trend/apply", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          trendName,
          adaptationLevel,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to apply design trend")
      }

      const data = await response.json()

      if (options?.onSuccess) {
        options.onSuccess(data.trend)
      }

      return data
    } catch (error) {
      console.error("Error applying design trend:", error)
      toast.error("Failed to apply design trend")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    getDesignTrend,
    applyDesignTrend,
    loading,
    trend,
  }
}

