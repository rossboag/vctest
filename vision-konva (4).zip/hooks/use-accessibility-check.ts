"use client"

import { useState } from "react"
import { toast } from "sonner"

interface AccessibilityResult {
  score: number
  issues: Array<{
    element: string
    issue: string
    severity: "low" | "medium" | "high"
    suggestion: string
  }>
  overallFeedback: string
}

interface UseAccessibilityCheckOptions {
  onSuccess?: (result: AccessibilityResult) => void
  onError?: (error: Error) => void
}

export function useAccessibilityCheck(options?: UseAccessibilityCheckOptions) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<AccessibilityResult | null>(null)

  const checkAccessibility = async (designElements: any[], projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/accessibility", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          designElements,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to check accessibility")
      }

      const data = await response.json()
      setResult(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error checking accessibility:", error)
      toast.error("Failed to check accessibility")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    checkAccessibility,
    loading,
    result,
  }
}

