"use client"

import { useState, useEffect } from "react"

type Orientation = "portrait" | "landscape"

export function useOrientation() {
  const [orientation, setOrientation] = useState<Orientation>("portrait")

  useEffect(() => {
    // Check if window is available (for SSR)
    if (typeof window === "undefined") return

    // Initial orientation check
    const checkOrientation = () => {
      if (window.matchMedia("(orientation: portrait)").matches) {
        setOrientation("portrait")
      } else {
        setOrientation("landscape")
      }
    }

    checkOrientation()

    // Listen for orientation changes
    const handleOrientationChange = () => {
      checkOrientation()
    }

    window.addEventListener("resize", handleOrientationChange)

    // Some devices support orientationchange event
    if ("onorientationchange" in window) {
      window.addEventListener("orientationchange", handleOrientationChange)
    }

    return () => {
      window.removeEventListener("resize", handleOrientationChange)
      if ("onorientationchange" in window) {
        window.removeEventListener("orientationchange", handleOrientationChange)
      }
    }
  }, [])

  return orientation
}

