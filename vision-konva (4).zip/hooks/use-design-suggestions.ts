"use client"

import { useState } from "react"
import { toast } from "sonner"

interface DesignSuggestions {
  suggestions: Array<{
    category: string
    suggestion: string
    priority: "low" | "medium" | "high"
    before?: any
    after?: any
  }>
  summary: string
}

interface UseDesignSuggestionsOptions {
  onSuccess?: (suggestions: DesignSuggestions) => void
  onError?: (error: Error) => void
}

export function useDesignSuggestions(options?: UseDesignSuggestionsOptions) {
  const [loading, setLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<DesignSuggestions | null>(null)

  const generateSuggestions = async (
    designElements: any[],
    canvasSize: { width: number; height: number },
    focusArea?: "composition" | "color" | "typography" | "accessibility" | "all",
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/suggestions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          designElements,
          canvasSize,
          focusArea,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate design suggestions")
      }

      const data = await response.json()
      setSuggestions(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating design suggestions:", error)
      toast.error("Failed to generate design suggestions")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateSuggestions,
    loading,
    suggestions,
  }
}

