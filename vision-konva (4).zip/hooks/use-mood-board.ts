"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { MoodBoard } from "@/lib/ai-style-service"

interface UseMoodBoardOptions {
  onSuccess?: (moodBoard: MoodBoard) => void
  onError?: (error: Error) => void
}

export function useMoodBoard(options?: UseMoodBoardOptions) {
  const [loading, setLoading] = useState(false)
  const [moodBoard, setMoodBoard] = useState<MoodBoard | null>(null)

  const generateMoodBoard = async (
    mood: string,
    industry?: string,
    additionalKeywords?: string[],
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/style/mood-board", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          mood,
          industry,
          additionalKeywords,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate mood board")
      }

      const data = await response.json()
      setMoodBoard(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating mood board:", error)
      toast.error("Failed to generate mood board")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateMoodBoard,
    loading,
    moodBoard,
  }
}

