"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { TypographySystem } from "@/lib/ai-design-service"

interface UseTypographySystemOptions {
  onSuccess?: (typographySystem: TypographySystem) => void
  onError?: (error: Error) => void
}

export function useTypographySystem(options?: UseTypographySystemOptions) {
  const [loading, setLoading] = useState(false)
  const [typographySystem, setTypographySystem] = useState<TypographySystem | null>(null)

  const generateTypographySystem = async (prompt: string, projectId?: string) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/typography", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate typography system")
      }

      const data = await response.json()
      setTypographySystem(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error generating typography system:", error)
      toast.error("Failed to generate typography system")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateTypographySystem,
    loading,
    typographySystem,
  }
}

