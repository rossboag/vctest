"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { BrandStyle } from "@/lib/ai-style-service"

interface UseBrandStyleOptions {
  onSuccess?: (brandStyle: BrandStyle) => void
  onError?: (error: Error) => void
}

export function useBrandStyle(options?: UseBrandStyleOptions) {
  const [loading, setLoading] = useState(false)
  const [brandStyle, setBrandStyle] = useState<BrandStyle | null>(null)

  const extractBrandStyle = async (
    elements?: any[],
    description?: string,
    imageUrls?: string[],
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/style/brand-extract", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          description,
          imageUrls,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to extract brand style")
      }

      const data = await response.json()
      setBrandStyle(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error extracting brand style:", error)
      toast.error("Failed to extract brand style")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    extractBrandStyle,
    loading,
    brandStyle,
  }
}

