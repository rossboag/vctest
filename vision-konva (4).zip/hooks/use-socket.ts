"use client"

import { useEffect, useState } from "react"
import { io, type Socket } from "socket.io-client"
import { useSession } from "next-auth/react"

let socket: Socket | null = null

export function useSocket(projectId?: string) {
  const { data: session } = useSession()
  const [isConnected, setIsConnected] = useState(false)
  const [activeUsers, setActiveUsers] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!session?.user) return

    // Initialize socket connection if not already connected
    if (!socket) {
      socket = io({
        path: "/api/socketio",
        autoConnect: true,
      })
    }

    // Set up event listeners
    function onConnect() {
      setIsConnected(true)
      setError(null)

      // Join project if projectId is provided
      if (projectId) {
        socket?.emit("join-project", projectId)
      }
    }

    function onDisconnect() {
      setIsConnected(false)
    }

    function onError(errorMessage: string) {
      setError(errorMessage)
    }

    function onActiveUsers(users: any[]) {
      setActiveUsers(users)
    }

    function onUserJoined(user: any) {
      setActiveUsers((prev) => [...prev, user])
    }

    function onUserLeft(user: any) {
      setActiveUsers((prev) => prev.filter((u) => u.userId !== user.userId))
    }

    // Register event listeners
    socket.on("connect", onConnect)
    socket.on("disconnect", onDisconnect)
    socket.on("error", onError)
    socket.on("active-users", onActiveUsers)
    socket.on("user-joined", onUserJoined)
    socket.on("user-left", onUserLeft)

    // Connect if not already connected
    if (!socket.connected) {
      socket.connect()
    } else if (projectId) {
      // If already connected and projectId is provided, join the project
      socket.emit("join-project", projectId)
    }

    // Clean up event listeners on unmount
    return () => {
      if (projectId) {
        socket?.emit("leave-project", projectId)
      }

      socket?.off("connect", onConnect)
      socket?.off("disconnect", onDisconnect)
      socket?.off("error", onError)
      socket?.off("active-users", onActiveUsers)
      socket?.off("user-joined", onUserJoined)
      socket?.off("user-left", onUserLeft)
    }
  }, [session, projectId])

  // Function to update an element
  const updateElement = (elementId: string, properties: any) => {
    if (!isConnected || !projectId) return
    socket?.emit("element-update", projectId, elementId, properties)
  }

  // Function to create an element
  const createElement = (element: any) => {
    if (!isConnected || !projectId) return
    socket?.emit("element-create", projectId, element)
  }

  // Function to delete an element
  const deleteElement = (elementId: string) => {
    if (!isConnected || !projectId) return
    socket?.emit("element-delete", projectId, elementId)
  }

  // Function to move cursor
  const moveCursor = (position: { x: number; y: number }) => {
    if (!isConnected || !projectId) return
    socket?.emit("cursor-move", projectId, position)
  }

  return {
    socket,
    isConnected,
    activeUsers,
    error,
    updateElement,
    createElement,
    deleteElement,
    moveCursor,
  }
}

