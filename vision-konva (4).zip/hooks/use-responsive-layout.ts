"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { LayoutElement, LayoutResult } from "@/lib/ai-layout-service"

interface UseResponsiveLayoutOptions {
  onSuccess?: (layout: LayoutResult) => void
  onError?: (error: Error) => void
}

export function useResponsiveLayout(options?: UseResponsiveLayoutOptions) {
  const [loading, setLoading] = useState(false)
  const [responsiveLayout, setResponsiveLayout] = useState<LayoutResult | null>(null)

  const generateResponsiveVariant = async (
    elements: LayoutElement[],
    originalSize: { width: number; height: number },
    targetSize: { width: number; height: number },
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/layout/responsive", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          elements,
          originalSize,
          targetSize,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to generate responsive layout")
      }

      const data = await response.json()
      setResponsiveLayout(data.layout)

      if (options?.onSuccess) {
        options.onSuccess(data.layout)
      }

      return data.layout
    } catch (error) {
      console.error("Error generating responsive layout:", error)
      toast.error("Failed to generate responsive layout")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    generateResponsiveVariant,
    loading,
    responsiveLayout,
  }
}

