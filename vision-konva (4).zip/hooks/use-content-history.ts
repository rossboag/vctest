"use client"

import { useState, useEffect, useCallback } from "react"
import { toast } from "sonner"

interface UseContentHistoryOptions {
  type?: string
  limit?: number
  offset?: number
  projectId?: string
  autoFetch?: boolean
}

export function useContentHistory(options: UseContentHistoryOptions = {}) {
  const [loading, setLoading] = useState(false)
  const [history, setHistory] = useState<any[]>([])
  const [totalCount, setTotalCount] = useState(0)

  const fetchHistory = useCallback(
    async (fetchOptions: UseContentHistoryOptions = {}) => {
      try {
        setLoading(true)

        const mergedOptions = { ...options, ...fetchOptions }
        const { type, limit = 10, offset = 0, projectId } = mergedOptions

        const queryParams = new URLSearchParams()
        if (type) queryParams.append("type", type)
        queryParams.append("limit", limit.toString())
        queryParams.append("offset", offset.toString())
        if (projectId) queryParams.append("projectId", projectId)

        const response = await fetch(`/api/content/history?${queryParams.toString()}`)

        if (!response.ok) {
          const error = await response.json()
          throw new Error(error.error || "Failed to fetch content history")
        }

        const data = await response.json()
        setHistory(data)

        // Get total count from header if available
        const totalCountHeader = response.headers.get("X-Total-Count")
        if (totalCountHeader) {
          setTotalCount(Number.parseInt(totalCountHeader, 10))
        }

        return data
      } catch (error) {
        console.error("Error fetching content history:", error)
        toast.error("Failed to fetch content history")
        throw error
      } finally {
        setLoading(false)
      }
    },
    [options],
  )

  useEffect(() => {
    if (options.autoFetch) {
      fetchHistory()
    }
  }, [options.autoFetch, fetchHistory])

  return {
    history,
    loading,
    totalCount,
    fetchHistory,
  }
}

