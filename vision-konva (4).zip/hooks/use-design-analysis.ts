"use client"

import { useState } from "react"
import { toast } from "sonner"
import type { DesignAnalysisResult } from "@/lib/ai-design-service"

interface UseDesignAnalysisOptions {
  onSuccess?: (analysis: DesignAnalysisResult) => void
  onError?: (error: Error) => void
}

export function useDesignAnalysis(options?: UseDesignAnalysisOptions) {
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState<DesignAnalysisResult | null>(null)

  const analyzeDesign = async (
    designElements: any[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ) => {
    try {
      setLoading(true)

      const response = await fetch("/api/design/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          designElements,
          canvasSize,
          projectId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to analyze design")
      }

      const data = await response.json()
      setAnalysis(data)

      if (options?.onSuccess) {
        options.onSuccess(data)
      }

      return data
    } catch (error) {
      console.error("Error analyzing design:", error)
      toast.error("Failed to analyze design")

      if (options?.onError && error instanceof Error) {
        options.onError(error)
      }

      throw error
    } finally {
      setLoading(false)
    }
  }

  return {
    analyzeDesign,
    loading,
    analysis,
  }
}

