import { useAIService } from "./use-ai-service"

export interface TextGenerationInput {
  prompt: string
  maxLength?: number
  temperature?: number
  style?: string
}

export interface TextGenerationOutput {
  text: string
  id: string
}

export function useAIText(options = {}) {
  return useAIService<TextGenerationInput, TextGenerationOutput>("/api/ai/text", options)
}

