import { useAIService } from "./use-ai-service"

export interface ImageGenerationInput {
  prompt: string
  width?: number
  height?: number
  style?: string
  numberOfImages?: number
}

export interface ImageGenerationOutput {
  images: string[]
  id: string
}

export function useAIImage(options = {}) {
  return useAIService<ImageGenerationInput, ImageGenerationOutput>("/api/ai/image", options)
}

