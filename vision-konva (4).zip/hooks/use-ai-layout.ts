import { useAIService } from "./use-ai-service"

export interface LayoutGenerationInput {
  prompt: string
  elements?: string[]
  width?: number
  height?: number
  style?: string
}

export interface LayoutElement {
  type: string
  x: number
  y: number
  width: number
  height: number
  properties?: Record<string, any>
}

export interface LayoutGenerationOutput {
  layout: LayoutElement[]
  id: string
}

export function useAILayout(options = {}) {
  return useAIService<LayoutGenerationInput, LayoutGenerationOutput>("/api/ai/layout", options)
}

