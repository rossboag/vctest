import http from "k6/http"
import { sleep, check } from "k6"
import { Counter, Rate, Trend } from "k6/metrics"
import { randomString } from "https://jslib.k6.io/k6-utils/1.2.0/index.js"

// Custom metrics
const errorRate = new Rate("error_rate")
const apiCalls = new Counter("api_calls")
const apiLatency = new Trend("api_latency")

// Options for the load test
export const options = {
  scenarios: {
    // Constant load test
    constant_load: {
      executor: "constant-arrival-rate",
      rate: 50, // 50 iterations per timeUnit
      timeUnit: "1m", // 1 minute
      duration: "5m", // 5 minutes
      preAllocatedVUs: 50, // Initial pool of VUs
      maxVUs: 100, // Maximum number of VUs to scale to
    },
    // Stress test
    stress_test: {
      executor: "ramping-arrival-rate",
      startRate: 10, // Starting iterations per timeUnit
      timeUnit: "1m", // 1 minute
      stages: [
        { duration: "2m", target: 50 }, // Ramp up to 50 iterations per minute over 2 minutes
        { duration: "5m", target: 50 }, // Stay at 50 iterations per minute for 5 minutes
        { duration: "2m", target: 100 }, // Ramp up to 100 iterations per minute over 2 minutes
        { duration: "5m", target: 100 }, // Stay at 100 iterations per minute for 5 minutes
        { duration: "2m", target: 0 }, // Ramp down to 0 iterations per minute over 2 minutes
      ],
      preAllocatedVUs: 20, // Initial pool of VUs
      maxVUs: 200, // Maximum number of VUs to scale to
    },
    // Spike test
    spike_test: {
      executor: "ramping-arrival-rate",
      startRate: 10, // Starting iterations per timeUnit
      timeUnit: "1m", // 1 minute
      stages: [
        { duration: "1m", target: 10 }, // Baseline
        { duration: "1m", target: 200 }, // Spike to 200 iterations per minute
        { duration: "1m", target: 10 }, // Back to baseline
      ],
      preAllocatedVUs: 20, // Initial pool of VUs
      maxVUs: 300, // Maximum number of VUs to scale to
    },
  },
  thresholds: {
    http_req_duration: ["p(95)<500"], // 95% of requests should be below 500ms
    http_req_failed: ["rate<0.01"], // Less than 1% of requests should fail
    error_rate: ["rate<0.05"], // Custom error rate should be below 5%
    "api_latency{endpoint:ai_text}": ["p(95)<2000"], // AI text endpoint should respond within 2s for 95% of requests
    "api_latency{endpoint:ai_image}": ["p(95)<5000"], // AI image endpoint should respond within 5s for 95% of requests
  },
}

// Simulated user session
export default function () {
  const baseUrl = "http://localhost:3000/api"
  const authToken = getAuthToken() // Function to get auth token

  // Common headers
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${authToken}`,
  }

  // Test AI text generation endpoint
  {
    const url = `${baseUrl}/ai/text`
    const payload = JSON.stringify({
      prompt: `Generate a creative headline for a ${randomString(5)} company`,
      maxTokens: 50,
    })

    const startTime = new Date()
    const response = apiCall(http.post, url, payload, headers)
    const endTime = new Date()

    apiLatency.add(endTime - startTime, { endpoint: "ai_text" })

    check(response, {
      "AI text status is 200": (r) => r.status === 200,
      "AI text response has content": (r) => r.json("content") !== undefined,
    }) || errorRate.add(1)
  }

  sleep(1)

  // Test AI image enhancement endpoint
  {
    const url = `${baseUrl}/content/image/enhance`
    const payload = JSON.stringify({
      imageUrl: "https://example.com/sample-image.jpg",
      enhancementType: "composition",
    })

    const startTime = new Date()
    const response = apiCall(http.post, url, payload, headers)
    const endTime = new Date()

    apiLatency.add(endTime - startTime, { endpoint: "ai_image" })

    check(response, {
      "AI image status is 200": (r) => r.status === 200,
      "AI image response has suggestions": (r) => r.json("suggestions") !== undefined,
    }) || errorRate.add(1)
  }

  sleep(1)

  // Test project creation endpoint
  {
    const url = `${baseUrl}/projects`
    const payload = JSON.stringify({
      name: `Test Project ${randomString(8)}`,
      width: 1920,
      height: 1080,
    })

    const startTime = new Date()
    const response = apiCall(http.post, url, payload, headers)
    const endTime = new Date()

    apiLatency.add(endTime - startTime, { endpoint: "create_project" })

    check(response, {
      "Create project status is 200": (r) => r.status === 200,
      "Create project response has id": (r) => r.json("id") !== undefined,
    }) || errorRate.add(1)

    if (response.status === 200) {
      const projectId = response.json("id")

      // Test adding an element to the project
      const elementUrl = `${baseUrl}/projects/${projectId}/elements`
      const elementPayload = JSON.stringify({
        type: "text",
        x: 100,
        y: 100,
        text: "Hello World",
        fontSize: 24,
      })

      const elementStartTime = new Date()
      const elementResponse = apiCall(http.post, elementUrl, elementPayload, headers)
      const elementEndTime = new Date()

      apiLatency.add(elementEndTime - elementStartTime, { endpoint: "add_element" })

      check(elementResponse, {
        "Add element status is 200": (r) => r.status === 200,
        "Add element response has id": (r) => r.json("id") !== undefined,
      }) || errorRate.add(1)
    }
  }

  sleep(1)
}

// Helper function to make API calls and track metrics
function apiCall(method, url, payload, headers) {
  apiCalls.add(1)
  const response = method(url, payload, { headers })
  if (response.status >= 400) {
    errorRate.add(1)
  }
  return response
}

// Simulated auth token retrieval
function getAuthToken() {
  // In a real test, you might want to authenticate once and reuse the token
  // For this example, we'll just return a mock token
  return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IlRlc3QgVXNlciIsImlhdCI6MTUxNjIzOTAyMn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
}

