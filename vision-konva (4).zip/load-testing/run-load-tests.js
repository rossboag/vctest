const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

// Configuration
const config = {
  outputDir: "load-test-results",
  scenarios: [
    {
      name: "constant_load",
      description: "Constant load test - 50 requests per minute for 5 minutes",
      options: "--scenario constant_load",
    },
    {
      name: "stress_test",
      description: "Stress test - Gradually increasing load up to 100 requests per minute",
      options: "--scenario stress_test",
    },
    {
      name: "spike_test",
      description: "Spike test - Sudden spike to 200 requests per minute",
      options: "--scenario spike_test",
    },
  ],
}

// Ensure output directory exists
if (!fs.existsSync(config.outputDir)) {
  fs.mkdirSync(config.outputDir, { recursive: true })
}

// Helper to run command and log output
const runCommand = (command, logFile) => {
  console.log(`Running: ${command}`)

  try {
    const output = execSync(command, { encoding: "utf8" })

    if (logFile) {
      fs.writeFileSync(path.join(config.outputDir, logFile), output)
    }

    console.log("✅ Success!")
    return { success: true, output }
  } catch (error) {
    console.error("❌ Failed!")
    console.error(error.message)

    if (logFile) {
      fs.writeFileSync(path.join(config.outputDir, logFile), `Error: ${error.message}\n\nOutput: ${error.stdout}`)
    }

    return { success: false, error }
  }
}

// Run each load test scenario
console.log("🚀 Starting load tests...")
const results = {}

for (const scenario of config.scenarios) {
  console.log(`\n📊 Running ${scenario.name}: ${scenario.description}`)
  const result = runCommand(`k6 run ${scenario.options} load-testing/k6-config.js`, `${scenario.name}-results.txt`)
  results[scenario.name] = result.success
}

// Generate test summary
const summary = {
  timestamp: new Date().toISOString(),
  results,
  allPassed: Object.values(results).every(Boolean),
}

// Write summary to file
fs.writeFileSync(path.join(config.outputDir, "load-test-summary.json"), JSON.stringify(summary, null, 2))

// Print summary
console.log("\n📊 Load Test Summary:")
console.log("--------------------------------------------------")
for (const scenario of config.scenarios) {
  console.log(`${scenario.name}: ${results[scenario.name] ? "✅ Passed" : "❌ Failed"}`)
}
console.log("--------------------------------------------------")
console.log(`Overall: ${summary.allPassed ? "✅ All tests passed!" : "❌ Some tests failed!"}`)

// Exit with appropriate code
process.exit(summary.allPassed ? 0 : 1)

