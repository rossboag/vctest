import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"
import { Redis } from "@upstash/redis"
import { Ratelimit } from "@upstash/ratelimit"
import { RateLimitError } from "./lib/errors"
import { getClientIp } from "./lib/api-utils"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

// Initialize Redis for rate limiting if environment variables are available
const redis =
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN
    ? new Redis({
        url: process.env.UPSTASH_REDIS_REST_URL,
        token: process.env.UPSTASH_REDIS_REST_TOKEN,
      })
    : null

// Create more sophisticated rate limiters
const rateLimiters = redis
  ? {
      // Regular API endpoints: 100 requests per minute
      api: new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(100, "1 m"),
        analytics: true,
        prefix: "ratelimit:api",
      }),

      // AI endpoints: 20 requests per minute for authenticated users
      ai: new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(20, "1 m"),
        analytics: true,
        prefix: "ratelimit:ai",
      }),

      // Stricter limits for unauthenticated users: 5 requests per minute
      unauthenticated: new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(5, "1 m"),
        analytics: true,
        prefix: "ratelimit:unauth",
      }),

      // Super strict limits for suspicious IPs
      suspicious: new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(3, "5 m"),
        analytics: true,
        prefix: "ratelimit:suspicious",
      }),

      // API key endpoints: 1000 requests per minute (for trusted services)
      apiKey: new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(1000, "1 m"),
        analytics: true,
        prefix: "ratelimit:apikey",
      }),

      // Admin endpoints: 500 requests per minute
      admin: new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(500, "1 m"),
        analytics: true,
        prefix: "ratelimit:admin",
      }),
    }
  : null

// Suspicious IP check
async function isSuspiciousIP(ip: string): Promise<boolean> {
  if (!redis) return false

  // Check if IP is in blocklist
  const isBlocked = await redis.get(`blocklist:ip:${ip}`)
  if (isBlocked) return true

  // Check for too many failed auth attempts
  const failedAttempts = await redis.get(`auth:fails:${ip}`)
  if (failedAttempts && Number.parseInt(failedAttempts) > 10) return true

  return false
}

// Enhanced security headers
const securityHeaders = {
  // Base security headers for all routes
  base: {
    "X-DNS-Prefetch-Control": "on",
    "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
    "X-XSS-Protection": "1; mode=block",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), interest-cohort=()",
  },

  // Additional headers for API routes
  api: {
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
    Pragma: "no-cache",
    Expires: "0",
  },

  // Headers for public pages
  public: {
    "Content-Security-Policy":
      "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self' https://api.openai.com https://api.replicate.com;",
  },
}

// Configuration
export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    "/((?!_next/static|_next/image|favicon.ico|public/).*)",
    "/api/:path*",
  ],
}

export async function middleware(request: NextRequest) {
  // Get path info for route-specific handling
  const path = request.nextUrl.pathname

  // Start with a default response
  const response = NextResponse.next()

  try {
    // Apply base security headers to all responses
    Object.entries(securityHeaders.base).forEach(([key, value]) => {
      response.headers.set(key, value)
    })

    // Add API-specific headers for API routes
    if (path.startsWith("/api/")) {
      Object.entries(securityHeaders.api).forEach(([key, value]) => {
        response.headers.set(key, value)
      })
    } else {
      // Add public page headers for non-API routes
      Object.entries(securityHeaders.public).forEach(([key, value]) => {
        response.headers.set(key, value)
      })
    }

    // Skip remaining checks for non-API routes
    if (!path.startsWith("/api/")) {
      return response
    }

    // Get client identifier
    const token = await getToken({ req: request })
    const clientIp = getClientIp(request)
    const userId = token?.sub

    // Check for API key
    const apiKey = request.headers.get("x-api-key")
    const isApiKeyRequest = apiKey && apiKey === process.env.API_SECRET_KEY

    // Determine the type of endpoint
    const isAiEndpoint = path.startsWith("/api/ai/")
    const isAdminEndpoint = path.startsWith("/api/admin/")

    // Determine which rate limiter to use
    let rateLimiterKey: string

    if (isApiKeyRequest) {
      rateLimiterKey = "apiKey"
    } else if (isAdminEndpoint) {
      rateLimiterKey = "admin"
    } else if (isAiEndpoint) {
      rateLimiterKey = userId ? "ai" : "unauthenticated"
    } else {
      rateLimiterKey = userId ? "api" : "unauthenticated"
    }

    // Check for suspicious IP
    if (clientIp && (await isSuspiciousIP(clientIp))) {
      rateLimiterKey = "suspicious"

      // Log suspicious activity
      console.warn(`Suspicious IP detected: ${clientIp} accessing ${path}`)
    }

    // Apply rate limiting if Redis is available
    if (rateLimiters && clientIp) {
      const identifier = userId || clientIp
      const rateLimiter = rateLimiters[rateLimiterKey as keyof typeof rateLimiters]

      if (rateLimiter) {
        const { success, limit, remaining, reset } = await rateLimiter.limit(`${rateLimiterKey}:${identifier}`)

        // Add rate limit headers
        response.headers.set("X-RateLimit-Limit", limit.toString())
        response.headers.set("X-RateLimit-Remaining", remaining.toString())
        response.headers.set("X-RateLimit-Reset", reset.toString())

        // Handle rate limit exceeded
        if (!success) {
          throw new RateLimitError(limit, reset, path)
        }
      }
    }

    return response
  } catch (error) {
    console.error(`Middleware error for ${path}:`, error)

    // Handle RateLimitError specifically
    if (error instanceof RateLimitError) {
      return NextResponse.json(
        {
          success: false,
          error: error.message,
          code: error.code,
          context: error.context,
        },
        {
          status: error.statusCode,
          headers: {
            ...Object.fromEntries(response.headers.entries()),
            "X-RateLimit-Limit": error.context?.limit?.toString() || "0",
            "X-RateLimit-Reset": error.context?.reset?.toString() || "0",
            "X-RateLimit-Remaining": "0",
          },
        },
      )
    }

    // For other errors, return a generic error
    return NextResponse.json(
      {
        success: false,
        error: "Internal Server Error",
        message: "An unexpected error occurred",
      },
      {
        status: 500,
        headers: {
          ...Object.fromEntries(response.headers.entries()),
        },
      },
    )
  }
}

