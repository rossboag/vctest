import { create } from "zustand"
import { produce } from "immer"
import { v4 as uuidv4 } from "uuid"
import { konvaWrapper } from "@/lib/konva-wrapper"

export type ElementType =
  | "rectangle"
  | "circle"
  | "line"
  | "triangle"
  | "hexagon"
  | "star"
  | "arrow"
  | "freehand"
  | "text"
  | "image"
  | "video"
  | "custom"
  | "ellipse"
  | "group"

export type TextWrap = "word" | "char" | "none"
export type TextAlign = "left" | "center" | "right"
export type TextOverflow = "clip" | "ellipsis"

export interface BaseElement {
  id: string
  type: ElementType
  x: number
  y: number
  width: number
  height: number
  fill: string
  opacity?: number
  blur?: number
  rotation?: number
  name?: string
  layerId: string
  startTime?: number
  endTime?: number
  locked?: boolean
}

export interface RectangleElement extends BaseElement {
  type: "rectangle"
}

export interface CircleElement extends BaseElement {
  type: "circle"
  radius: number
}

export interface LineElement extends BaseElement {
  type: "line"
  points: number[]
  stroke: string
  strokeWidth: number
}

export interface TriangleElement extends BaseElement {
  type: "triangle"
  points: number[]
}

export interface HexagonElement extends BaseElement {
  type: "hexagon"
  radius: number
}

export interface StarElement extends BaseElement {
  type: "star"
  numPoints: number
  innerRadius: number
  outerRadius: number
}

export interface ArrowElement extends BaseElement {
  type: "arrow"
  points: number[]
  stroke: string
  strokeWidth: number
}

export interface FreehandElement extends BaseElement {
  type: "freehand"
  points: number[]
  stroke: string
  strokeWidth: number
}

export interface TextElement extends BaseElement {
  type: "text"
  text: string
  fontSize: number
  fontFamily: string
  fontStyle: string
  textDecoration: string
  fill: string
  align: TextAlign
  verticalAlign: string
  lineHeight: number
  letterSpacing: number
  wrap: TextWrap
  ellipsis: boolean
  padding: number
  width: number
  height: number
}

export interface ImageElement extends BaseElement {
  type: "image"
  src: string
}

export interface VideoElement extends BaseElement {
  type: "video"
  src: string
}

export interface CustomElement extends BaseElement {
  type: "custom"
  code: string
}

export interface EllipseElement extends BaseElement {
  type: "ellipse"
  radiusX: number
  radiusY: number
}

export interface GroupElement extends BaseElement {
  type: "group"
  children: string[]
}

export type Element =
  | RectangleElement
  | CircleElement
  | LineElement
  | TriangleElement
  | HexagonElement
  | StarElement
  | ArrowElement
  | FreehandElement
  | TextElement
  | ImageElement
  | VideoElement
  | CustomElement
  | EllipseElement
  | GroupElement

interface Layer {
  id: string
  name: string
  visible: boolean
  locked: boolean
  children: string[]
}

interface EditorState {
  elements: Element[]
  layers: Layer[]
  selectedId: string | null
  selectedIds: string[]
  activeTool: string
  activeAITool:
    | "generate"
    | "enhance"
    | "analyze"
    | "assistant"
    | "chat"
    | "colorize"
    | "layout"
    | "text"
    | "image"
    | "video"
    | null
  canvasSize: { width: number; height: number }
  scale: number
  position: { x: number; y: number }
  isFitToScreen: boolean
  currentTime: number
  duration: number
  isPlaying: boolean
  gridSize: number
  snapToGrid: boolean
  history: Element[][]
  historyIndex: number
  clipboard: Element[]
  recentColors: string[]
  aiGenerationSettings: {
    type: "text" | "image" | "layout" | "animation"
    style: string
    textLength: number
    imageSize: "256x256" | "512x512" | "1024x1024"
    animationDuration: number
  }
}

const initialState: EditorState = {
  elements: [],
  layers: [{ id: "default", name: "Layer 1", visible: true, locked: false, children: [] }],
  selectedId: null,
  selectedIds: [],
  activeTool: "select",
  activeAITool: null,
  canvasSize: { width: 800, height: 600 },
  scale: 1,
  position: { x: 0, y: 0 },
  isFitToScreen: false,
  currentTime: 0,
  duration: 10,
  isPlaying: false,
  gridSize: 10,
  snapToGrid: false,
  history: [],
  historyIndex: -1,
  clipboard: [],
  recentColors: [],
  aiGenerationSettings: {
    type: "text",
    style: "",
    textLength: 100,
    imageSize: "512x512",
    animationDuration: 5,
  },
}

export const useEditorStore = create<
  EditorState & {
    addElement: (element: Omit<Element, "id">) => Element | null
    updateElement: (id: string, changes: Partial<Element>) => void
    updateElements: (ids: string[], changes: Partial<Element>) => void
    removeElement: (id: string) => void
    setSelectedId: (id: string | null) => void
    setSelectedIds: (ids: string[]) => void
    setActiveTool: (tool: string) => void
    setActiveAITool: (
      tool:
        | "generate"
        | "enhance"
        | "analyze"
        | "assistant"
        | "chat"
        | "colorize"
        | "layout"
        | "text"
        | "image"
        | "video"
        | null,
    ) => void
    setCanvasSize: (size: { width: number; height: number }) => void
    setScale: (scale: number) => void
    setPosition: (position: { x: number; y: number }) => void
    setIsFitToScreen: (isFit: boolean) => void
    setCurrentTime: (time: number) => void
    togglePlayback: () => void
    updateLayer: (id: string, changes: Partial<Layer>) => void
    reorderLayers: (sourceIndex: number, destinationIndex: number) => void
    removeLayer: (id: string) => void
    duplicateLayer: (id: string) => void
    groupLayers: (layerIds: string[]) => void
    ungroupLayer: (groupId: string) => void
    alignElements: (ids: string[], alignment: string) => void
    distributeElements: (ids: string[], distribution: string) => void
    flipElement: (id: string, direction: string) => void
    rotateElement: (id: string, angle: number) => void
    setElementOpacity: (id: string, opacity: number) => void
    lockElement: (id: string) => void
    unlockElement: (id: string) => void
    groupElements: (ids: string[]) => void
    ungroupElements: (groupId: string) => void
    resetView: () => void
    undo: () => void
    redo: () => void
    copySelectedElements: () => void
    pasteElements: () => void
    deleteSelectedElements: () => void
    selectAll: () => void
    applyEffect: (id: string, effect: { blur?: number; opacity?: number }) => void
    getShapesInRegion: (x: number, y: number, width: number, height: number) => any[]
    enableTextTransformer: (id: string) => void
    transformElement: (id: string, transformProps: any) => void
    zoomToSelection: () => void
    toggleSnapToGrid: () => void
    setGridSize: (size: number) => void
    setSnapThreshold: (threshold: number) => void
    exportProject: () => any
    importProject: (projectData: any) => void
    addRecentColor: (color: string) => void
    getRecentColors: () => string[]
    setAIGenerationType: (type: "text" | "image" | "layout" | "animation") => void
    setAIGenerationStyle: (style: string) => void
    setAITextLength: (length: number) => void
    setAIImageSize: (size: "256x256" | "512x512" | "1024x1024") => void
    setAIAnimationDuration: (duration: number) => void
  }
>((set, get) => ({
  ...initialState,

  addElement: (element) => {
    const id = uuidv4()
    const newElement = { ...element, id }
    set(
      produce((state) => {
        state.elements.push(newElement)
        state.layers.find((layer) => layer.id === element.layerId)?.children.push(id)
        state.history.push([...state.elements])
        state.historyIndex++
      }),
    )
    konvaWrapper.addElement(newElement)
    return newElement
  },

  updateElement: (id, changes) =>
    set(
      produce((state) => {
        const index = state.elements.findIndex((el) => el.id === id)
        if (index !== -1) {
          state.elements[index] = { ...state.elements[index], ...changes }
          state.history.push([...state.elements])
          state.historyIndex++
          konvaWrapper.updateElement(id, changes)
        }
      }),
    ),

  updateElements: (ids, changes) =>
    set(
      produce((state) => {
        state.elements = state.elements.map((el) => (ids.includes(el.id) ? { ...el, ...changes } : el))
        state.history.push([...state.elements])
        state.historyIndex++
        ids.forEach((id) => konvaWrapper.updateElement(id, changes))
      }),
    ),

  removeElement: (id) =>
    set(
      produce((state) => {
        state.elements = state.elements.filter((el) => el.id !== id)
        state.layers.forEach((layer) => {
          layer.children = layer.children.filter((childId) => childId !== id)
        })
        state.selectedId = null
        state.history.push([...state.elements])
        state.historyIndex++
        konvaWrapper.removeElement(id)
      }),
    ),

  setSelectedId: (id) => set({ selectedId: id }),

  setSelectedIds: (ids) => set({ selectedIds: ids }),

  setActiveTool: (tool) => set({ activeTool: tool }),

  setActiveAITool: (tool) => set({ activeAITool: tool }),

  setCanvasSize: (size) => {
    set({ canvasSize: size })
    konvaWrapper.drawCanvas(size.width, size.height)
  },

  setScale: (scale) => {
    set({ scale })
    const { canvasSize, position } = get()
    konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, position.x, position.y)
  },

  setPosition: (position) => {
    set({ position })
    const { canvasSize, scale } = get()
    konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, position.x, position.y)
  },

  setIsFitToScreen: (isFit) => set({ isFitToScreen: isFit }),

  setCurrentTime: (time) => set({ currentTime: time }),

  togglePlayback: () => set((state) => ({ isPlaying: !state.isPlaying })),

  updateLayer: (id, changes) =>
    set(
      produce((state) => {
        const layerIndex = state.layers.findIndex((layer) => layer.id === id)
        if (layerIndex !== -1) {
          state.layers[layerIndex] = { ...state.layers[layerIndex], ...changes }
        }
      }),
    ),

  reorderLayers: (sourceIndex, destinationIndex) =>
    set(
      produce((state) => {
        const [removed] = state.layers.splice(sourceIndex, 1)
        state.layers.splice(destinationIndex, 0, removed)
      }),
    ),

  removeLayer: (id) =>
    set(
      produce((state) => {
        state.layers = state.layers.filter((layer) => layer.id !== id)
        state.elements = state.elements.filter((el) => el.layerId !== id)
        state.selectedId = null
      }),
    ),

  duplicateLayer: (id) =>
    set(
      produce((state) => {
        const layerToDuplicate = state.layers.find((layer) => layer.id === id)
        if (layerToDuplicate) {
          const newLayerId = uuidv4()
          const newLayer = { ...layerToDuplicate, id: newLayerId, name: `${layerToDuplicate.name} Copy` }
          state.layers.push(newLayer)

          const elementsToClone = state.elements.filter((el) => el.layerId === id)
          const clonedElements = elementsToClone.map((el) => ({
            ...el,
            id: uuidv4(),
            layerId: newLayerId,
          }))
          state.elements.push(...clonedElements)
          newLayer.children = clonedElements.map((el) => el.id)
        }
      }),
    ),

  groupLayers: (layerIds) =>
    set(
      produce((state) => {
        const groupId = uuidv4()
        const groupName = `Group ${state.layers.length + 1}`
        const groupLayer: Layer = {
          id: groupId,
          name: groupName,
          visible: true,
          locked: false,
          children: [],
        }

        layerIds.forEach((id) => {
          const layer = state.layers.find((l) => l.id === id)
          if (layer) {
            groupLayer.children.push(...layer.children)
            state.elements.forEach((el) => {
              if (el.layerId === id) {
                el.layerId = groupId
              }
            })
          }
        })

        state.layers = state.layers.filter((layer) => !layerIds.includes(layer.id))
        state.layers.push(groupLayer)
      }),
    ),

  ungroupLayer: (groupId) =>
    set(
      produce((state) => {
        const groupLayer = state.layers.find((layer) => layer.id === groupId)
        if (groupLayer) {
          const childLayers = groupLayer.children.map((childId) => ({
            id: uuidv4(),
            name: `Layer ${state.layers.length + 1}`,
            visible: true,
            locked: false,
            children: [childId],
          }))

          state.layers = state.layers.filter((layer) => layer.id !== groupId)
          state.layers.push(...childLayers)

          state.elements.forEach((el) => {
            if (el.layerId === groupId) {
              const newLayer = childLayers.find((layer) => layer.children.includes(el.id))
              if (newLayer) {
                el.layerId = newLayer.id
              }
            }
          })
        }
      }),
    ),

  alignElements: (ids, alignment) => {
    const elements = get().elements.filter((el) => ids.includes(el.id))
    if (elements.length < 2) return

    const bbox = konvaWrapper.getBoundingBox(elements)

    elements.forEach((el) => {
      let newX = el.x
      let newY = el.y

      switch (alignment) {
        case "left":
          newX = bbox.x
          break
        case "center":
          newX = bbox.x + (bbox.width - el.width) / 2
          break
        case "right":
          newX = bbox.x + bbox.width - el.width
          break
        case "top":
          newY = bbox.y
          break
        case "middle":
          newY = bbox.y + (bbox.height - el.height) / 2
          break
        case "bottom":
          newY = bbox.y + bbox.height - el.height
          break
      }

      get().updateElement(el.id, { x: newX, y: newY })
    })
  },

  distributeElements: (ids, distribution) => {
    const elements = get().elements.filter((el) => ids.includes(el.id))
    if (elements.length < 3) return

    const sortedElements = elements.sort((a, b) => {
      return distribution === "horizontal" ? a.x - b.x : a.y - b.y
    })

    const first = sortedElements[0]
    const last = sortedElements[sortedElements.length - 1]
    const totalSpace = distribution === "horizontal" ? last.x + last.width - first.x : last.y + last.height - first.y

    const spacing = totalSpace / (elements.length - 1)

    sortedElements.forEach((el, index) => {
      if (index > 0 && index < sortedElements.length - 1) {
        const newPos =
          distribution === "horizontal" ? { x: first.x + spacing * index } : { y: first.y + spacing * index }
        get().updateElement(el.id, newPos)
      }
    })
  },

  flipElement: (id, direction) => {
    const element = get().elements.find((el) => el.id === id)
    if (element) {
      const scale = direction === "horizontal" ? { scaleX: -1 } : { scaleY: -1 }
      get().updateElement(id, scale)
    }
  },

  rotateElement: (id, angle) => {
    get().updateElement(id, { rotation: angle })
  },

  setElementOpacity: (id, opacity) => {
    get().updateElement(id, { opacity })
  },

  lockElement: (id) => {
    get().updateElement(id, { locked: true })
  },

  unlockElement: (id) => {
    get().updateElement(id, { locked: false })
  },

  groupElements: (ids) => {
    const elementsToGroup = get().elements.filter((el) => ids.includes(el.id))
    if (elementsToGroup.length < 2) return

    const groupId = uuidv4()
    const groupElement: Element = {
      id: groupId,
      type: "group",
      x: 0,
      y: 0,
      width: 0,
      height: 0,
      fill: "",
      layerId: elementsToGroup[0].layerId,
      children: ids,
    }

    set(
      produce((state) => {
        state.elements = state.elements.filter((el) => !ids.includes(el.id))
        state.elements.push(groupElement)
        state.selectedIds = [groupId]
      }),
    )

    konvaWrapper.groupElements(ids)
  },

  ungroupElements: (groupId) => {
    const groupElement = get().elements.find((el) => el.id === groupId && el.type === "group")
    if (!groupElement || !("children" in groupElement)) return

    set(
      produce((state) => {
        const childElements = state.elements.filter((el) => groupElement.children.includes(el.id))
        state.elements = state.elements.filter((el) => el.id !== groupId)
        state.elements.push(...childElements)
        state.selectedIds = childElements.map((el) => el.id)
      }),
    )

    konvaWrapper.ungroupElements(groupId)
  },

  resetView: () => {
    const { canvasSize } = get()
    const scale = Math.min(window.innerWidth / canvasSize.width, window.innerHeight / canvasSize.height)
    const x = (window.innerWidth - canvasSize.width * scale) / 2
    const y = (window.innerHeight - canvasSize.height * scale) / 2

    set({ scale, position: { x, y }, isFitToScreen: true })
    konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, x, y)
  },

  undo: () => {
    const { historyIndex, history } = get()
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1
      const newState = history[newIndex]
      set({ elements: newState, historyIndex: newIndex })
      konvaWrapper.setElements(newState)
    }
  },

  redo: () => {
    const { historyIndex, history } = get()
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1
      const newState = history[newIndex]
      set({ elements: newState, historyIndex: newIndex })
      konvaWrapper.setElements(newState)
    }
  },

  copySelectedElements: () => {
    const { selectedIds, elements } = get()
    const elementsToCopy = elements.filter((el) => selectedIds.includes(el.id))
    set({ clipboard: elementsToCopy })
  },

  pasteElements: () => {
    const { clipboard, addElement } = get()
    clipboard.forEach((el) => {
      const newElement = { ...el, id: uuidv4(), x: el.x + 10, y: el.y + 10 }
      addElement(newElement)
    })
  },

  deleteSelectedElements: () => {
    const { selectedIds } = get()
    selectedIds.forEach((id) => get().removeElement(id))
    set({ selectedIds: [] })
  },

  selectAll: () => {
    const { elements } = get()
    set({ selectedIds: elements.map((el) => el.id) })
  },

  applyEffect: (id, effect) => {
    get().updateElement(id, effect)
    konvaWrapper.applyEffect(id, effect)
  },

  getShapesInRegion: (x, y, width, height) => {
    return konvaWrapper.getShapesInRegion(x, y, width, height)
  },

  enableTextTransformer: (id) => {
    konvaWrapper.enableTextTransformer(id)
  },

  zoomToSelection: () => {
    const { selectedIds, elements, canvasSize } = get()
    if (selectedIds.length === 0) return

    const selectedElements = elements.filter((el) => selectedIds.includes(el.id))
    const bbox = konvaWrapper.getBoundingBox(selectedElements)

    const padding = 50
    const scale = Math.min(
      (canvasSize.width - padding * 2) / bbox.width,
      (canvasSize.height - padding * 2) / bbox.height,
    )

    const x = (canvasSize.width - bbox.width * scale) / 2 - bbox.x * scale
    const y = (canvasSize.height - bbox.height * scale) / 2 - bbox.y * scale

    set({ scale, position: { x, y } })
    konvaWrapper.updateStage(canvasSize.width, canvasSize.height, scale, x, y)
  },

  toggleSnapToGrid: () => set((state) => ({ snapToGrid: !state.snapToGrid })),
  setGridSize: (size) => set({ gridSize: size }),
  setSnapThreshold: (threshold) => set({ snapThreshold: threshold }),

  transformElement: (id, transformProps) => {
    const { snapToGrid, gridSize, snapThreshold } = get()
    let snappedProps = { ...transformProps }

    if (snapToGrid) {
      if ("x" in transformProps) {
        snappedProps.x = Math.round(transformProps.x / gridSize) * gridSize
      }
      if ("y" in transformProps) {
        snappedProps.y = Math.round(transformProps.y / gridSize) * gridSize
      }
      if ("width" in transformProps) {
        snappedProps.width = Math.round(transformProps.width / gridSize) * gridSize
      }
      if ("height" in transformProps) {
        snappedProps.height = Math.round(transformProps.height / gridSize) * gridSize
      }
    }

    // Snap to nearby elements
    const nearbyElements = get().elements.filter((el) => el.id !== id)
    snappedProps = snapToNearbyElements(snappedProps, nearbyElements, snapThreshold)

    get().updateElement(id, snappedProps)
    konvaWrapper.transformElement(id, snappedProps)
  },

  exportProject: () => {
    const { elements, layers, canvasSize } = get()
    return {
      version: "1.0",
      canvasSize,
      elements,
      layers,
    }
  },

  importProject: (projectData) => {
    if (projectData.version === "1.0") {
      set({
        elements: projectData.elements,
        layers: projectData.layers,
        canvasSize: projectData.canvasSize,
      })
      // Reset other state properties as needed
      set({
        selectedId: null,
        selectedIds: [],
        history: [projectData.elements],
        historyIndex: 0,
      })
      // Update the Konva stage
      konvaWrapper.clear()
      konvaWrapper.drawCanvas(projectData.canvasSize.width, projectData.canvasSize.height)
      projectData.elements.forEach((element) => konvaWrapper.addElement(element))
    } else {
      console.error("Unsupported project version")
    }
  },

  addRecentColor: (color) =>
    set((state) => {
      const updatedColors = [color, ...state.recentColors.filter((c) => c !== color)].slice(0, 10)
      return { recentColors: updatedColors }
    }),

  getRecentColors: () => get().recentColors,
  setActiveAITool: (tool) => set({ activeAITool: tool }),
  setAIGenerationType: (type: "text" | "image" | "layout" | "animation") =>
    set((state) => ({ aiGenerationSettings: { ...state.aiGenerationSettings, type } })),
  setAIGenerationStyle: (style) => set((state) => ({ aiGenerationSettings: { ...state.aiGenerationSettings, style } })),
  setAITextLength: (length) =>
    set((state) => ({ aiGenerationSettings: { ...state.aiGenerationSettings, textLength: length } })),
  setAIImageSize: (size) =>
    set((state) => ({ aiGenerationSettings: { ...state.aiGenerationSettings, imageSize: size } })),
  setAIAnimationDuration: (duration) =>
    set((state) => ({ aiGenerationSettings: { ...state.aiGenerationSettings, animationDuration: duration } })),
}))

function snapToNearbyElements(props: any, nearbyElements: Element[], threshold: number) {
  const snappedProps = { ...props }

  nearbyElements.forEach((el) => {
    if ("x" in props) {
      if (Math.abs(props.x - el.x) < threshold) snappedProps.x = el.x
      if (Math.abs(props.x + props.width - el.x) < threshold) snappedProps.x = el.x - props.width
    }
    if ("y" in props) {
      if (Math.abs(props.y - el.y) < threshold) snappedProps.y = el.y
      if (Math.abs(props.y + props.height - el.y) < threshold) snappedProps.y = el.y - props.height
    }
  })

  return snappedProps
}

