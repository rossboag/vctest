import { create } from "zustand"

interface Asset {
  id: string
  type: "image" | "video" | "font" | "audio"
  url: string
  name: string
  mimeType?: string
  size?: number
  key?: string
  userId?: string
  createdAt?: string
  updatedAt?: string
}

interface AssetStore {
  assets: Asset[]
  setAssets: (assets: Asset[]) => void
  addAsset: (asset: Asset) => void
  removeAsset: (id: string) => void
  getAssetById: (id: string) => Asset | undefined
}

export const useAssetStore = create<AssetStore>((set, get) => ({
  assets: [],
  setAssets: (assets) => set({ assets }),
  addAsset: (asset) => set((state) => ({ assets: [...state.assets, asset] })),
  removeAsset: (id) => set((state) => ({ assets: state.assets.filter((asset) => asset.id !== id) })),
  getAssetById: (id) => get().assets.find((asset) => asset.id === id),
}))

