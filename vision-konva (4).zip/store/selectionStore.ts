export const useSelectionStore = (set, get) => ({
  selectedIds: [],
  setSelectedIds: (ids: string[]) => set({ selectedIds: ids }),
  addToSelection: (id: string) => set((state) => ({ selectedIds: [...state.selectedIds, id] })),
  removeFromSelection: (id: string) =>
    set((state) => ({ selectedIds: state.selectedIds.filter((selectedId) => selectedId !== id) })),
  clearSelection: () => set({ selectedIds: [] }),
})

