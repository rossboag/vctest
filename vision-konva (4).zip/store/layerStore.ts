import type { Layer } from "../types/editor"

export const useLayerStore = (set, get) => ({
  layers: [],
  addLayer: (layer: Layer) => set((state) => ({ layers: [...state.layers, layer] })),
  removeLayer: (id: string) => set((state) => ({ layers: state.layers.filter((layer) => layer.id !== id) })),
  updateLayer: (id: string, updates: Partial<Layer>) =>
    set((state) => ({
      layers: state.layers.map((layer) => (layer.id === id ? { ...layer, ...updates } : layer)),
    })),
  reorderLayers: (sourceIndex: number, destinationIndex: number) =>
    set((state) => {
      const newLayers = Array.from(state.layers)
      const [removed] = newLayers.splice(sourceIndex, 1)
      newLayers.splice(destinationIndex, 0, removed)
      return { layers: newLayers }
    }),
})

