export const useCanvasStore = (set, get) => ({
  canvasSize: { width: 800, height: 600 },
  scale: 1,
  position: { x: 0, y: 0 },
  setCanvasSize: (size: { width: number; height: number }) => set({ canvasSize: size }),
  setScale: (scale: number) => set({ scale }),
  setPosition: (position: { x: number; y: number }) => set({ position }),
})

