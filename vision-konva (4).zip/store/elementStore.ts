import { create } from "zustand"
import { produce } from "immer"
import { v4 as uuidv4 } from "uuid"
import type { Element } from "../types/elements"
import { konvaWrapper } from "@/lib/konva-wrapper"

interface ElementState {
  elements: Element[]
  addElement: (element: Omit<Element, "id">) => Element
  updateElement: (id: string, changes: Partial<Element>) => void
  removeElement: (id: string) => void
}

export const useElementStore = create<ElementState>((set, get) => ({
  elements: [],

  addElement: (element) => {
    const newElement = { ...element, id: uuidv4() }
    set(
      produce((state) => {
        state.elements.push(newElement)
      }),
    )
    konvaWrapper.addElement(newElement)
    return newElement
  },

  updateElement: (id, changes) =>
    set(
      produce((state) => {
        const index = state.elements.findIndex((el) => el.id === id)
        if (index !== -1) {
          state.elements[index] = { ...state.elements[index], ...changes }
          konvaWrapper.updateElement(id, changes)
        }
      }),
    ),

  removeElement: (id) =>
    set(
      produce((state) => {
        state.elements = state.elements.filter((el) => el.id !== id)
        konvaWrapper.removeElement(id)
      }),
    ),
}))

