export const useHistoryStore = (set, get) => ({
  history: [],
  historyIndex: -1,
  addToHistory: (state: any) =>
    set((prevState) => ({
      history: [...prevState.history.slice(0, prevState.historyIndex + 1), state],
      historyIndex: prevState.historyIndex + 1,
    })),
  undo: () =>
    set((state) => {
      if (state.historyIndex > 0) {
        return {
          historyIndex: state.historyIndex - 1,
          // Apply the previous state here
        }
      }
      return state
    }),
  redo: () =>
    set((state) => {
      if (state.historyIndex < state.history.length - 1) {
        return {
          historyIndex: state.historyIndex + 1,
          // Apply the next state here
        }
      }
      return state
    }),
})

