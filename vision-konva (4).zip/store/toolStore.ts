export const useToolStore = (set, get) => ({
  activeTool: "select",
  setActiveTool: (tool: string) => set({ activeTool: tool }),
})

