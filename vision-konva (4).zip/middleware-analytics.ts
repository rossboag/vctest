import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { prisma } from "@/lib/db"

// Paths to exclude from analytics
const EXCLUDED_PATHS = ["/api/", "/_next/", "/favicon.ico", "/robots.txt", "/sitemap.xml"]

export async function analyticsMiddleware(req: NextRequest) {
  const path = req.nextUrl.pathname

  // Skip excluded paths
  if (EXCLUDED_PATHS.some((excludedPath) => path.startsWith(excludedPath))) {
    return NextResponse.next()
  }

  try {
    // Get today's date (without time)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Update page view count
    await prisma.pageView.upsert({
      where: {
        path_date: {
          path,
          date: today,
        },
      },
      update: {
        views: {
          increment: 1,
        },
      },
      create: {
        path,
        date: today,
        views: 1,
      },
    })
  } catch (error) {
    console.error("Error tracking page view:", error)
  }

  return NextResponse.next()
}

