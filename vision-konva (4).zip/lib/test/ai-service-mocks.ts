// Mock responses for AI services
import { jest } from "@jest/globals"

export const mockAiTextResponse = (prompt: string) => {
  // Generate deterministic response based on prompt
  const responses = {
    headline: "Create Stunning Designs with Vision Creator",
    subheadline: "The AI-powered design tool for professionals and beginners alike",
    paragraph:
      "Vision Creator combines the power of AI with intuitive design tools to help you create stunning visuals in minutes. Whether you're a professional designer or just starting out, our platform provides everything you need to bring your ideas to life.",
    cta: "Start Creating Today",
    default: "Generated text for: " + prompt,
  }

  // Find matching response or use default
  const key = Object.keys(responses).find((key) => prompt.toLowerCase().includes(key)) || "default"
  return responses[key]
}

export const mockAiImageResponse = (prompt: string) => {
  // Generate deterministic image URL based on prompt
  const baseUrl = "https://example.com/generated-images/"
  const slugifiedPrompt = prompt.toLowerCase().replace(/[^a-z0-9]+/g, "-")
  return `${baseUrl}${slugifiedPrompt}.png`
}

export const mockAiColorPaletteResponse = (prompt: string) => {
  // Generate deterministic color palette based on prompt
  const palettes = {
    vibrant: ["#FF5733", "#33FF57", "#3357FF", "#F3FF33", "#FF33F3"],
    pastel: ["#FFB6C1", "#B6FFD8", "#B6D8FF", "#FFD8B6", "#D8B6FF"],
    monochrome: ["#000000", "#333333", "#666666", "#999999", "#CCCCCC"],
    warm: ["#FF5733", "#FF8C33", "#FFBD33", "#FFE333", "#FFFF33"],
    cool: ["#33FFF5", "#33C7FF", "#338FFF", "#3357FF", "#3333FF"],
    default: ["#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF"],
  }

  // Find matching palette or use default
  const key = Object.keys(palettes).find((key) => prompt.toLowerCase().includes(key)) || "default"
  return palettes[key]
}

export const mockAiLayoutResponse = (prompt: string) => {
  // Generate deterministic layout based on prompt
  const layouts = {
    "landing page": {
      type: "landing-page",
      sections: [
        { type: "hero", height: 600 },
        { type: "features", height: 400 },
        { type: "testimonials", height: 300 },
        { type: "cta", height: 200 },
      ],
    },
    blog: {
      type: "blog",
      sections: [
        { type: "header", height: 200 },
        { type: "content", height: 800 },
        { type: "sidebar", height: 600 },
        { type: "footer", height: 100 },
      ],
    },
    portfolio: {
      type: "portfolio",
      sections: [
        { type: "header", height: 100 },
        { type: "gallery", height: 900 },
        { type: "about", height: 300 },
        { type: "contact", height: 200 },
      ],
    },
    default: {
      type: "generic",
      sections: [
        { type: "section-1", height: 300 },
        { type: "section-2", height: 300 },
        { type: "section-3", height: 300 },
      ],
    },
  }

  // Find matching layout or use default
  const key = Object.keys(layouts).find((key) => prompt.toLowerCase().includes(key)) || "default"
  return layouts[key]
}

export const mockAiAnimationResponse = (prompt: string) => {
  // Generate deterministic animation based on prompt
  const animations = {
    fade: {
      name: "Fade In",
      duration: 1000,
      easing: "easeInOut",
      keyframes: [
        { time: 0, opacity: 0 },
        { time: 1000, opacity: 1 },
      ],
    },
    slide: {
      name: "Slide In",
      duration: 1000,
      easing: "easeOut",
      keyframes: [
        { time: 0, x: -100, opacity: 0 },
        { time: 1000, x: 0, opacity: 1 },
      ],
    },
    bounce: {
      name: "Bounce",
      duration: 1000,
      easing: "easeOutBounce",
      keyframes: [
        { time: 0, y: -100, opacity: 0 },
        { time: 700, y: 10, opacity: 1 },
        { time: 800, y: -5, opacity: 1 },
        { time: 1000, y: 0, opacity: 1 },
      ],
    },
    default: {
      name: "Default Animation",
      duration: 1000,
      easing: "linear",
      keyframes: [
        { time: 0, opacity: 0, scale: 0.5 },
        { time: 1000, opacity: 1, scale: 1 },
      ],
    },
  }

  // Find matching animation or use default
  const key = Object.keys(animations).find((key) => prompt.toLowerCase().includes(key)) || "default"
  return animations[key]
}

// Mock AI service client
export const createMockAiServiceClient = () => {
  return {
    generateText: jest.fn().mockImplementation(async (prompt) => {
      return { text: mockAiTextResponse(prompt) }
    }),

    generateImage: jest.fn().mockImplementation(async (prompt) => {
      return { imageUrl: mockAiImageResponse(prompt) }
    }),

    generateColorPalette: jest.fn().mockImplementation(async (prompt) => {
      return { colors: mockAiColorPaletteResponse(prompt) }
    }),

    generateLayout: jest.fn().mockImplementation(async (prompt) => {
      return { layout: mockAiLayoutResponse(prompt) }
    }),

    generateAnimation: jest.fn().mockImplementation(async (prompt) => {
      return { animation: mockAiAnimationResponse(prompt) }
    }),

    // Add error simulation
    simulateError: jest.fn().mockImplementation(async () => {
      throw new Error("Simulated AI service error")
    }),
  }
}

