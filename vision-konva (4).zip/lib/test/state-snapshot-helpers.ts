import { useEditorStore } from "@/store/editor-store"
import { useLayerStore } from "@/store/layerStore"
import { useSelectionStore } from "@/store/selectionStore"
import { useCanvasStore } from "@/store/canvasStore"
import { useHistoryStore } from "@/store/historyStore"
import { useToolStore } from "@/store/toolStore"
import { useAssetStore } from "@/store/asset-store"
import { useElementStore } from "@/store/elementStore"

// Helper to take a snapshot of all stores
export const takeStoreSnapshot = () => {
  return {
    editor: { ...useEditorStore.getState() },
    layer: { ...useLayerStore.getState() },
    selection: { ...useSelectionStore.getState() },
    canvas: { ...useCanvasStore.getState() },
    history: { ...useHistoryStore.getState() },
    tool: { ...useToolStore.getState() },
    asset: { ...useAssetStore.getState() },
    element: { ...useElementStore.getState() },
  }
}

// Helper to restore a snapshot of all stores
export const restoreStoreSnapshot = (snapshot: any) => {
  // Reset each store
  useEditorStore.setState(snapshot.editor)
  useLayerStore.setState(snapshot.layer)
  useSelectionStore.setState(snapshot.selection)
  useCanvasStore.setState(snapshot.canvas)
  useHistoryStore.setState(snapshot.history)
  useToolStore.setState(snapshot.tool)
  useAssetStore.setState(snapshot.asset)
  useElementStore.setState(snapshot.element)
}

// Helper to compare store states
export const compareStoreStates = (stateA: any, stateB: any) => {
  const differences = {}

  // Compare each store
  Object.keys(stateA).forEach((storeName) => {
    const storeA = stateA[storeName]
    const storeB = stateB[storeName]

    // Compare store properties
    const storeDifferences = {}
    Object.keys(storeA).forEach((key) => {
      // Skip functions
      if (typeof storeA[key] === "function") return

      // Compare values
      if (JSON.stringify(storeA[key]) !== JSON.stringify(storeB[key])) {
        storeDifferences[key] = {
          before: storeA[key],
          after: storeB[key],
        }
      }
    })

    // Add store differences
    if (Object.keys(storeDifferences).length > 0) {
      differences[storeName] = storeDifferences
    }
  })

  return differences
}

// Helper to create a test store state
export const createTestStoreState = () => {
  // Create a basic test state
  return {
    editor: {
      scale: 1,
      position: { x: 0, y: 0 },
      history: [],
      currentHistoryIndex: -1,
      canUndo: false,
      canRedo: false,
    },
    layer: {
      layers: [
        {
          id: "layer1",
          name: "Layer 1",
          visible: true,
          locked: false,
          elements: ["element1", "element2"],
        },
        {
          id: "layer2",
          name: "Layer 2",
          visible: true,
          locked: false,
          elements: ["element3"],
        },
      ],
      activeLayerId: "layer1",
    },
    selection: {
      selectedIds: ["element1"],
      selectionBounds: { x: 0, y: 0, width: 100, height: 100 },
    },
    canvas: {
      width: 1920,
      height: 1080,
      backgroundColor: "#FFFFFF",
      gridVisible: true,
      snapToGrid: true,
      gridSize: 10,
    },
    history: {
      history: [
        {
          type: "element_added",
          data: { id: "element1", type: "text" },
        },
        {
          type: "element_added",
          data: { id: "element2", type: "image" },
        },
        {
          type: "element_added",
          data: { id: "element3", type: "shape" },
        },
      ],
      currentIndex: 2,
    },
    tool: {
      activeTool: "select",
      previousTool: null,
      toolOptions: {},
    },
    asset: {
      assets: [
        {
          id: "asset1",
          type: "image",
          url: "https://example.com/image1.jpg",
          name: "Image 1",
        },
        {
          id: "asset2",
          type: "image",
          url: "https://example.com/image2.jpg",
          name: "Image 2",
        },
      ],
      isLoading: false,
      error: null,
    },
    element: {
      elements: {
        element1: {
          id: "element1",
          type: "text",
          x: 100,
          y: 100,
          width: 200,
          height: 50,
          text: "Hello World",
          fontSize: 24,
          fontFamily: "Arial",
          fill: "#000000",
          align: "center",
        },
        element2: {
          id: "element2",
          type: "image",
          x: 400,
          y: 100,
          width: 300,
          height: 200,
          src: "https://example.com/image1.jpg",
        },
        element3: {
          id: "element3",
          type: "shape",
          x: 100,
          y: 300,
          width: 100,
          height: 100,
          shapeType: "circle",
          fill: "#FF0000",
          stroke: "#000000",
          strokeWidth: 2,
        },
      },
    },
  }
}

