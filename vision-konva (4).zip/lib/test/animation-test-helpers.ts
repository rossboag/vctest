import { act } from "@testing-library/react"
import * as jest from "@jest/globals"

// Helper to simulate animation frame
export const simulateAnimationFrame = () => {
  jest.spyOn(window, "requestAnimationFrame").mockImplementation((cb) => {
    cb(performance.now())
    return 0
  })
}

// Helper to simulate animation progress
export const simulateAnimationProgress = async (durationMs: number, steps = 10) => {
  const stepTime = durationMs / steps

  for (let i = 0; i < steps; i++) {
    await act(async () => {
      // Move time forward
      jest.advanceTimersByTime(stepTime)

      // Trigger animation frame
      const now = performance.now()
      const rafCallbacks = window.requestAnimationFrame["mock"].calls.map((call) => call[0])
      rafCallbacks.forEach((cb) => cb(now + i * stepTime))
    })
  }
}

// Helper to simulate Konva animation
export const simulateKonvaAnimation = async (animation: any, durationMs: number, steps = 10) => {
  const stepTime = durationMs / steps

  // Start animation
  animation.start()

  for (let i = 0; i < steps; i++) {
    await act(async () => {
      // Simulate animation frame
      animation["_onEnterFrame"]({
        time: i * stepTime,
        timeDiff: stepTime,
        frameRate: 1000 / stepTime,
      })

      // Advance timers
      jest.advanceTimersByTime(stepTime)
    })
  }

  // Stop animation
  animation.stop()
}

// Helper to simulate Konva tween
export const simulateKonvaTween = async (tween: any, durationMs: number, steps = 10) => {
  const stepTime = durationMs / steps

  // Start tween
  tween.play()

  for (let i = 0; i < steps; i++) {
    await act(async () => {
      // Calculate progress
      const progress = i / (steps - 1)

      // Apply tween
      tween["_onUpdate"](progress)

      // Advance timers
      jest.advanceTimersByTime(stepTime)
    })
  }

  // Finish tween
  tween["_onFinish"]()
}

// Helper to create a mock Konva node
export const createMockKonvaNode = (type: string, initialProps: any = {}) => {
  const props = { ...initialProps }

  return {
    nodeType: type,
    attrs: props,
    getAttr: jest.fn().mockImplementation((key) => props[key]),
    setAttr: jest.fn().mockImplementation((key, value) => {
      props[key] = value
      return props[key]
    }),
    getAbsolutePosition: jest.fn().mockReturnValue({ x: props.x || 0, y: props.y || 0 }),
    setAbsolutePosition: jest.fn(),
    width: jest.fn().mockImplementation(() => props.width || 100),
    height: jest.fn().mockImplementation(() => props.height || 100),
    rotation: jest.fn().mockImplementation(() => props.rotation || 0),
    scaleX: jest.fn().mockImplementation(() => props.scaleX || 1),
    scaleY: jest.fn().mockImplementation(() => props.scaleY || 1),
    opacity: jest.fn().mockImplementation(() => props.opacity || 1),
    visible: jest.fn().mockImplementation(() => props.visible !== false),
    cache: jest.fn(),
    draw: jest.fn(),
    getLayer: jest.fn().mockReturnValue({
      batchDraw: jest.fn(),
    }),
    getStage: jest.fn().mockReturnValue({
      container: jest.fn().mockReturnValue(document.createElement("div")),
    }),
    on: jest.fn(),
    off: jest.fn(),
    fire: jest.fn(),
    moveToTop: jest.fn(),
    moveToBottom: jest.fn(),
    destroy: jest.fn(),
  }
}

