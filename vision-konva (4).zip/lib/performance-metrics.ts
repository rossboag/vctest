import { prisma } from "@/lib/db"
import os from "os"

export async function recordPerformanceMetrics() {
  try {
    // Get CPU usage
    const cpuUsage = (os.loadavg()[0] / os.cpus().length) * 100

    // Get memory usage
    const totalMem = os.totalmem()
    const freeMem = os.freemem()
    const memoryUsage = ((totalMem - freeMem) / totalMem) * 100

    // Record metrics
    await prisma.performanceMetric.create({
      data: {
        cpuUsage,
        memoryUsage,
        // Other metrics can be added here
      },
    })
  } catch (error) {
    console.error("Failed to record performance metrics:", error)
  }
}

export function startPerformanceMonitoring(intervalMinutes = 5) {
  // Record initial metrics
  recordPerformanceMetrics()

  // Set up interval for recording metrics
  const intervalMs = intervalMinutes * 60 * 1000
  const interval = setInterval(recordPerformanceMetrics, intervalMs)

  return () => clearInterval(interval)
}

