import Konva from "konva"
import type { Element } from "@/store/editor-store"

export class KonvaTextHandler {
  addTextElement(element: Element): Konva.Text {
    return new Konva.Text({
      x: element.x,
      y: element.y,
      text: element.text,
      fontSize: element.fontSize,
      fontFamily: element.fontFamily,
      fill: element.fill,
      draggable: true,
      id: element.id,
      align: element.align,
      fontStyle: element.fontStyle,
      textDecoration: element.textDecoration,
      width: element.width,
      height: element.height,
      wrap: element.wrap,
      ellipsis: element.overflow === "ellipsis",
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }

  // Add other text-related methods here
}

