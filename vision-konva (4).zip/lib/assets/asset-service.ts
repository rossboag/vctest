import { PrismaClient, type Asset } from "@prisma/client"
import { StorageError, getStorageService } from "../storage/storage-service"
import { AppError } from "../errors"
import { z } from "zod"

const prisma = new PrismaClient()
const storageService = getStorageService()

export class AssetError extends AppError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, "ASSET_ERROR", 400, context)
  }
}

// Asset validation schemas
export const assetCreateSchema = z.object({
  name: z.string().min(1).max(255),
  type: z.enum(["image", "video", "audio", "font", "document", "other"]),
  mimeType: z.string().min(1).max(255),
  size: z.number().int().positive(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
  duration: z.number().positive().optional(),
  tags: z.array(z.string()).optional(),
  projectId: z.string().optional(),
  isPublic: z.boolean().optional(),
})

export type AssetCreateInput = z.infer<typeof assetCreateSchema>

export const assetUpdateSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  tags: z.array(z.string()).optional(),
  isPublic: z.boolean().optional(),
})

export type AssetUpdateInput = z.infer<typeof assetUpdateSchema>

export class AssetService {
  /**
   * Create a new asset
   */
  async createAsset(
    userId: string,
    file: Buffer | Blob | ReadableStream,
    fileName: string,
    contentType: string,
    metadata: AssetCreateInput,
  ): Promise<Asset> {
    try {
      // Validate input
      const validatedData = assetCreateSchema.parse(metadata)

      // Upload file to storage
      const uploadResult = await storageService.uploadFile(file, fileName, contentType, userId, {
        projectId: validatedData.projectId,
        tags: validatedData.tags,
        isPublic: validatedData.isPublic,
      })

      // Create asset record in database
      const asset = await prisma.asset.create({
        data: {
          name: validatedData.name,
          type: validatedData.type,
          url: uploadResult.url,
          thumbnailUrl: uploadResult.thumbnailUrl,
          mimeType: contentType,
          size: validatedData.size,
          width: validatedData.width,
          height: validatedData.height,
          duration: validatedData.duration,
          userId,
          projectId: validatedData.projectId,
          storageKey: uploadResult.key,
          originalName: fileName,
          isPublic: validatedData.isPublic || false,
          tags: validatedData.tags || [],
        },
      })

      return asset
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw new AssetError("Invalid asset data", { zodError: error.format() })
      }

      if (error instanceof StorageError) {
        throw new AssetError("Failed to store asset", { originalError: error.message })
      }

      console.error("Error creating asset:", error)
      throw new AssetError("Failed to create asset", { originalError: error })
    }
  }

  /**
   * Get an asset by ID
   */
  async getAsset(id: string, userId?: string): Promise<Asset> {
    const asset = await prisma.asset.findUnique({
      where: { id },
    })

    if (!asset) {
      throw new AssetError("Asset not found")
    }

    // Check if user has access to this asset
    if (userId && asset.userId !== userId && !asset.isPublic) {
      throw new AssetError("You don't have permission to access this asset")
    }

    return asset
  }

  /**
   * Update an asset
   */
  async updateAsset(id: string, userId: string, data: AssetUpdateInput): Promise<Asset> {
    try {
      // Validate input
      const validatedData = assetUpdateSchema.parse(data)

      // Check if asset exists and belongs to user
      const existingAsset = await prisma.asset.findUnique({
        where: { id },
      })

      if (!existingAsset) {
        throw new AssetError("Asset not found")
      }

      if (existingAsset.userId !== userId) {
        throw new AssetError("You don't have permission to update this asset")
      }

      // Update asset
      const updatedAsset = await prisma.asset.update({
        where: { id },
        data: validatedData,
      })

      return updatedAsset
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw new AssetError("Invalid asset data", { zodError: error.format() })
      }

      console.error("Error updating asset:", error)
      throw new AssetError("Failed to update asset", { originalError: error })
    }
  }

  /**
   * Delete an asset
   */
  async deleteAsset(id: string, userId: string): Promise<void> {
    try {
      // Check if asset exists and belongs to user
      const asset = await prisma.asset.findUnique({
        where: { id },
      })

      if (!asset) {
        throw new AssetError("Asset not found")
      }

      if (asset.userId !== userId) {
        throw new AssetError("You don't have permission to delete this asset")
      }

      // Delete from storage
      if (asset.storageKey) {
        await storageService.deleteFile(asset.storageKey)
      }

      // Delete from database
      await prisma.asset.delete({
        where: { id },
      })
    } catch (error) {
      if (error instanceof StorageError) {
        throw new AssetError("Failed to delete asset from storage", { originalError: error.message })
      }

      console.error("Error deleting asset:", error)
      throw new AssetError("Failed to delete asset", { originalError: error })
    }
  }

  /**
   * List assets for a user
   */
  async listAssets(
    userId: string,
    options: {
      type?: string
      projectId?: string
      search?: string
      page?: number
      limit?: number
      sortBy?: string
      sortOrder?: "asc" | "desc"
    } = {},
  ): Promise<{ assets: Asset[]; total: number; page: number; limit: number }> {
    const { type, projectId, search, page = 1, limit = 20, sortBy = "createdAt", sortOrder = "desc" } = options

    // Build where clause
    const where: any = { userId }

    if (type) {
      where.type = type
    }

    if (projectId) {
      where.projectId = projectId
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { originalName: { contains: search, mode: "insensitive" } },
      ]
    }

    // Get total count
    const total = await prisma.asset.count({ where })

    // Get assets
    const assets = await prisma.asset.findMany({
      where,
      orderBy: { [sortBy]: sortOrder },
      skip: (page - 1) * limit,
      take: limit,
    })

    return {
      assets,
      total,
      page,
      limit,
    }
  }

  /**
   * Get a signed URL for an asset
   */
  async getSignedUrl(id: string, userId: string, expiresIn = 3600): Promise<string> {
    // Check if asset exists and user has access
    const asset = await this.getAsset(id, userId)

    if (!asset.storageKey) {
      throw new AssetError("Asset has no storage key")
    }

    // Generate signed URL
    return await storageService.getSignedUrl(asset.storageKey, expiresIn)
  }

  /**
   * Clean up unused assets
   */
  async cleanupUnusedAssets(olderThanDays = 30): Promise<number> {
    const date = new Date()
    date.setDate(date.getDate() - olderThanDays)

    // Find unused assets
    const unusedAssets = await prisma.asset.findMany({
      where: {
        updatedAt: { lt: date },
        // Add conditions to determine if an asset is unused
        // For example, not referenced by any project
        projectId: null,
      },
    })

    // Delete each asset
    for (const asset of unusedAssets) {
      try {
        if (asset.storageKey) {
          await storageService.deleteFile(asset.storageKey)
        }

        await prisma.asset.delete({
          where: { id: asset.id },
        })
      } catch (error) {
        console.error(`Failed to delete unused asset ${asset.id}:`, error)
      }
    }

    return unusedAssets.length
  }
}

// Create a singleton instance
let assetService: AssetService | null = null

export function getAssetService(): AssetService {
  if (!assetService) {
    assetService = new AssetService()
  }

  return assetService
}

