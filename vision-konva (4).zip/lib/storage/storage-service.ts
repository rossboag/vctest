import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  ListObjectsV2Command,
} from "@aws-sdk/client-s3"
import { getSignedUrl } from "@aws-sdk/s3-request-presigner"
import { createHash } from "crypto"
import { AppError } from "../errors"
import sharp from "sharp"

export interface StorageOptions {
  provider: "s3" | "local" | "cloudinary"
  region?: string
  bucket?: string
  folder?: string
  accessKeyId?: string
  secretAccessKey?: string
  endpoint?: string
  cloudName?: string
  apiKey?: string
  apiSecret?: string
}

export interface FileMetadata {
  contentType: string
  size: number
  width?: number
  height?: number
  duration?: number
  createdAt: Date
  updatedAt: Date
  userId: string
  projectId?: string
  tags?: string[]
  originalName: string
  isPublic?: boolean
}

export interface UploadResult {
  key: string
  url: string
  thumbnailUrl?: string
  metadata: FileMetadata
}

export class StorageError extends AppError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, "STORAGE_ERROR", 500, context)
  }
}

export class StorageService {
  private provider: "s3" | "local" | "cloudinary"
  private s3Client?: S3Client
  private bucket?: string
  private folder: string
  private baseUrl?: string

  constructor(options: StorageOptions) {
    this.provider = options.provider
    this.folder = options.folder || "uploads"

    if (this.provider === "s3") {
      if (!options.region || !options.bucket || !options.accessKeyId || !options.secretAccessKey) {
        throw new StorageError("Missing required S3 configuration")
      }

      this.s3Client = new S3Client({
        region: options.region,
        credentials: {
          accessKeyId: options.accessKeyId,
          secretAccessKey: options.secretAccessKey,
        },
        endpoint: options.endpoint,
      })

      this.bucket = options.bucket
      this.baseUrl = `https://${this.bucket}.s3.${options.region}.amazonaws.com`
    } else if (this.provider === "cloudinary") {
      // Cloudinary setup would go here
      throw new StorageError("Cloudinary provider not yet implemented")
    } else if (this.provider === "local") {
      // Local file system setup would go here
      throw new StorageError("Local storage provider not yet implemented")
    }
  }

  /**
   * Generate a unique file key
   */
  private generateKey(fileName: string, userId: string): string {
    const timestamp = Date.now()
    const hash = createHash("md5").update(`${userId}-${fileName}-${timestamp}`).digest("hex").substring(0, 8)

    // Clean the filename to ensure it's URL-safe
    const cleanFileName = fileName
      .toLowerCase()
      .replace(/[^a-z0-9.]/g, "-")
      .replace(/-+/g, "-")

    return `${this.folder}/${userId}/${hash}-${cleanFileName}`
  }

  /**
   * Upload a file to storage
   */
  async uploadFile(
    file: Buffer | Blob | ReadableStream,
    fileName: string,
    contentType: string,
    userId: string,
    metadata: Partial<FileMetadata> = {},
  ): Promise<UploadResult> {
    try {
      const key = this.generateKey(fileName, userId)

      if (this.provider === "s3" && this.s3Client && this.bucket) {
        // Upload the original file
        await this.s3Client.send(
          new PutObjectCommand({
            Bucket: this.bucket,
            Key: key,
            Body: file,
            ContentType: contentType,
            Metadata: {
              userId,
              originalName: fileName,
              ...(metadata.projectId ? { projectId: metadata.projectId } : {}),
              ...(metadata.tags ? { tags: metadata.tags.join(",") } : {}),
            },
          }),
        )

        // Generate URL
        const url = `${this.baseUrl}/${key}`

        // Generate thumbnail for images
        let thumbnailUrl: string | undefined
        if (contentType.startsWith("image/") && file instanceof Buffer) {
          const thumbnailKey = `${key.replace(/\.[^/.]+$/, "")}-thumbnail.jpg`

          // Generate thumbnail
          const thumbnail = await sharp(file).resize(200, 200, { fit: "inside" }).jpeg({ quality: 80 }).toBuffer()

          // Upload thumbnail
          await this.s3Client.send(
            new PutObjectCommand({
              Bucket: this.bucket,
              Key: thumbnailKey,
              Body: thumbnail,
              ContentType: "image/jpeg",
              Metadata: {
                userId,
                originalName: fileName,
                isThumbnail: "true",
                ...(metadata.projectId ? { projectId: metadata.projectId } : {}),
              },
            }),
          )

          thumbnailUrl = `${this.baseUrl}/${thumbnailKey}`
        }

        // Extract image dimensions if it's an image
        let width: number | undefined
        let height: number | undefined

        if (contentType.startsWith("image/") && file instanceof Buffer) {
          const imageInfo = await sharp(file).metadata()
          width = imageInfo.width
          height = imageInfo.height
        }

        // Create file metadata
        const fileMetadata: FileMetadata = {
          contentType,
          size: file instanceof Buffer ? file.length : 0, // For Blob or ReadableStream, size would need to be calculated differently
          width,
          height,
          createdAt: new Date(),
          updatedAt: new Date(),
          userId,
          originalName: fileName,
          ...metadata,
        }

        return {
          key,
          url,
          thumbnailUrl,
          metadata: fileMetadata,
        }
      } else {
        throw new StorageError(`Provider ${this.provider} not configured correctly`)
      }
    } catch (error) {
      console.error("Error uploading file:", error)
      throw new StorageError("Failed to upload file", { originalError: error })
    }
  }

  /**
   * Get a signed URL for a file
   */
  async getSignedUrl(key: string, expiresIn = 3600): Promise<string> {
    try {
      if (this.provider === "s3" && this.s3Client && this.bucket) {
        const command = new GetObjectCommand({
          Bucket: this.bucket,
          Key: key,
        })

        return await getSignedUrl(this.s3Client, command, { expiresIn })
      } else {
        throw new StorageError(`Provider ${this.provider} not configured correctly`)
      }
    } catch (error) {
      console.error("Error generating signed URL:", error)
      throw new StorageError("Failed to generate signed URL", { originalError: error })
    }
  }

  /**
   * Delete a file from storage
   */
  async deleteFile(key: string): Promise<void> {
    try {
      if (this.provider === "s3" && this.s3Client && this.bucket) {
        await this.s3Client.send(
          new DeleteObjectCommand({
            Bucket: this.bucket,
            Key: key,
          }),
        )

        // Also try to delete the thumbnail if it exists
        const thumbnailKey = `${key.replace(/\.[^/.]+$/, "")}-thumbnail.jpg`
        try {
          await this.s3Client.send(
            new DeleteObjectCommand({
              Bucket: this.bucket,
              Key: thumbnailKey,
            }),
          )
        } catch (error) {
          // Ignore errors when deleting thumbnail (it might not exist)
        }
      } else {
        throw new StorageError(`Provider ${this.provider} not configured correctly`)
      }
    } catch (error) {
      console.error("Error deleting file:", error)
      throw new StorageError("Failed to delete file", { originalError: error })
    }
  }

  /**
   * List files for a user
   */
  async listFiles(userId: string, prefix?: string): Promise<{ key: string; url: string; metadata: any }[]> {
    try {
      if (this.provider === "s3" && this.s3Client && this.bucket) {
        const folderPrefix = prefix ? `${this.folder}/${userId}/${prefix}` : `${this.folder}/${userId}/`

        const response = await this.s3Client.send(
          new ListObjectsV2Command({
            Bucket: this.bucket,
            Prefix: folderPrefix,
          }),
        )

        if (!response.Contents) {
          return []
        }

        // Filter out thumbnails
        const files = response.Contents.filter((item) => !item.Key?.includes("-thumbnail."))

        return files.map((item) => ({
          key: item.Key!,
          url: `${this.baseUrl}/${item.Key}`,
          metadata: {
            size: item.Size,
            lastModified: item.LastModified,
          },
        }))
      } else {
        throw new StorageError(`Provider ${this.provider} not configured correctly`)
      }
    } catch (error) {
      console.error("Error listing files:", error)
      throw new StorageError("Failed to list files", { originalError: error })
    }
  }

  /**
   * Check if a file exists
   */
  async fileExists(key: string): Promise<boolean> {
    try {
      if (this.provider === "s3" && this.s3Client && this.bucket) {
        try {
          await this.s3Client.send(
            new GetObjectCommand({
              Bucket: this.bucket,
              Key: key,
            }),
          )
          return true
        } catch (error: any) {
          if (error.name === "NoSuchKey") {
            return false
          }
          throw error
        }
      } else {
        throw new StorageError(`Provider ${this.provider} not configured correctly`)
      }
    } catch (error) {
      console.error("Error checking if file exists:", error)
      throw new StorageError("Failed to check if file exists", { originalError: error })
    }
  }
}

// Create a singleton instance with default configuration
let storageService: StorageService | null = null

export function getStorageService(): StorageService {
  if (!storageService) {
    // Initialize with environment variables
    storageService = new StorageService({
      provider: "s3",
      region: process.env.AWS_REGION!,
      bucket: process.env.AWS_S3_BUCKET_NAME!,
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
      folder: "vision-creator",
    })
  }

  return storageService
}

