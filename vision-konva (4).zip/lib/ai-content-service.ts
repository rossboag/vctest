import { prisma } from "@/lib/db"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export interface ContentEnhancementOptions {
  tone?: "professional" | "casual" | "creative" | "formal" | "friendly" | "persuasive"
  purpose?: "marketing" | "informational" | "educational" | "entertainment" | "technical"
  targetAudience?: string
  length?: "short" | "medium" | "long" | number
  keywords?: string[]
  style?: string
  format?: "paragraph" | "bullet" | "numbered" | "headline" | "slogan" | "quote"
}

export interface ImageEnhancementOptions {
  style?: string
  enhancementType?: "quality" | "color" | "composition" | "lighting" | "detail" | "all"
  strength?: number // 0-100
}

export interface VideoSuggestionOptions {
  duration?: number
  style?: string
  purpose?: string
  targetAudience?: string
  platform?: "youtube" | "tiktok" | "instagram" | "general"
}

export interface ContentAdaptationOptions {
  platform?: "social" | "web" | "print" | "email" | "presentation"
  specificPlatform?: string // e.g., "instagram", "twitter", "facebook"
  constraints?: {
    maxLength?: number
    format?: string
    tone?: string
  }
}

export interface LocalizationOptions {
  targetLanguage: string
  targetRegion?: string
  preserveFormatting?: boolean
  adaptCulturalReferences?: boolean
}

export class AIContentService {
  /**
   * Generate or enhance text content
   */
  static async enhanceText(
    userId: string,
    content: string,
    options: ContentEnhancementOptions = {},
    projectId?: string,
  ): Promise<any> {
    try {
      const {
        tone = "professional",
        purpose = "informational",
        targetAudience = "general",
        length = "medium",
        keywords = [],
        style = "",
        format = "paragraph",
      } = options

      // Create system prompt based on options
      const systemPrompt = `You are an expert content writer specializing in ${purpose} content.
        Your task is to ${content.trim() ? "enhance" : "generate"} text with a ${tone} tone.
        The target audience is ${targetAudience}.
        ${keywords.length > 0 ? `Include these keywords: ${keywords.join(", ")}.` : ""}
        ${style ? `Write in this style: ${style}.` : ""}
        Format the content as a ${format}.
        ${
          typeof length === "number"
            ? `The content should be approximately ${length} words.`
            : `The content should be ${length} in length.`
        }
        Provide only the enhanced/generated text without additional commentary.`

      // Create user prompt
      const userPrompt = content.trim()
        ? `Enhance this content: ${content}`
        : `Generate content about: ${content || "the requested topic"}`

      // Generate enhanced text
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: userPrompt,
        system: systemPrompt,
      })

      // Save to database
      const enhancement = await prisma.contentEnhancement.create({
        data: {
          userId,
          projectId,
          originalContent: content,
          enhancedContent: text,
          options: options as any,
          type: "text",
        },
      })

      return {
        id: enhancement.id,
        originalContent: content,
        enhancedContent: text,
        options,
      }
    } catch (error) {
      console.error("Error enhancing text:", error)
      throw new Error("Failed to enhance text content")
    }
  }

  /**
   * Generate image enhancement suggestions
   */
  static async enhanceImage(
    userId: string,
    imageUrl: string,
    options: ImageEnhancementOptions = {},
    projectId?: string,
  ): Promise<any> {
    try {
      const { style = "", enhancementType = "all", strength = 50 } = options

      // Create system prompt based on options
      const systemPrompt = `You are an expert image enhancement consultant.
        Provide specific suggestions to enhance this image.
        Focus on ${enhancementType === "all" ? "all aspects" : enhancementType} of the image.
        ${style ? `The desired style is: ${style}.` : ""}
        The enhancement strength should be ${strength}% (higher means more dramatic changes).
        Provide suggestions in a structured JSON format with categories and specific actionable steps.`

      // Generate image enhancement suggestions
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Provide enhancement suggestions for this image: ${imageUrl}`,
        system: systemPrompt,
      })

      // Parse suggestions
      let suggestions
      try {
        suggestions = JSON.parse(text)
      } catch (e) {
        // If parsing fails, use the text as is
        suggestions = { general: text }
      }

      // Save to database
      const enhancement = await prisma.contentEnhancement.create({
        data: {
          userId,
          projectId,
          originalContent: imageUrl,
          enhancedContent: suggestions,
          options: options as any,
          type: "image",
        },
      })

      return {
        id: enhancement.id,
        imageUrl,
        suggestions,
        options,
      }
    } catch (error) {
      console.error("Error generating image enhancement suggestions:", error)
      throw new Error("Failed to generate image enhancement suggestions")
    }
  }

  /**
   * Generate video content suggestions
   */
  static async generateVideoSuggestions(
    userId: string,
    topic: string,
    options: VideoSuggestionOptions = {},
    projectId?: string,
  ): Promise<any> {
    try {
      const {
        duration = 60,
        style = "modern",
        purpose = "informational",
        targetAudience = "general",
        platform = "general",
      } = options

      // Create system prompt based on options
      const systemPrompt = `You are an expert video content strategist.
        Create a detailed video content plan for a ${duration}-second video.
        The video style should be ${style}.
        The purpose is ${purpose} and the target audience is ${targetAudience}.
        The video will be published on ${platform}.
        Provide a structured JSON response with:
        1. A compelling title
        2. A brief description
        3. A scene-by-scene breakdown with timing
        4. Key messages to convey
        5. Visual suggestions
        6. Audio/music suggestions
        7. Call-to-action recommendations`

      // Generate video suggestions
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Create a video content plan about: ${topic}`,
        system: systemPrompt,
      })

      // Parse suggestions
      let suggestions
      try {
        suggestions = JSON.parse(text)
      } catch (e) {
        // If parsing fails, use the text as is
        suggestions = { content: text }
      }

      // Save to database
      const enhancement = await prisma.contentEnhancement.create({
        data: {
          userId,
          projectId,
          originalContent: topic,
          enhancedContent: suggestions,
          options: options as any,
          type: "video",
        },
      })

      return {
        id: enhancement.id,
        topic,
        suggestions,
        options,
      }
    } catch (error) {
      console.error("Error generating video suggestions:", error)
      throw new Error("Failed to generate video content suggestions")
    }
  }

  /**
   * Adapt content for different platforms
   */
  static async adaptContent(
    userId: string,
    content: string,
    options: ContentAdaptationOptions = {},
    projectId?: string,
  ): Promise<any> {
    try {
      const { platform = "social", specificPlatform = "", constraints = {} } = options

      // Create system prompt based on options
      const systemPrompt = `You are an expert content adaptation specialist.
        Adapt the provided content for ${specificPlatform || platform} platform.
        ${constraints.maxLength ? `The maximum length is ${constraints.maxLength} characters.` : ""}
        ${constraints.format ? `The format should be: ${constraints.format}.` : ""}
        ${constraints.tone ? `The tone should be: ${constraints.tone}.` : ""}
        Optimize the content for the platform's specific audience and format requirements.
        Provide only the adapted content without additional commentary.`

      // Generate adapted content
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Adapt this content for ${specificPlatform || platform}: ${content}`,
        system: systemPrompt,
      })

      // Save to database
      const enhancement = await prisma.contentEnhancement.create({
        data: {
          userId,
          projectId,
          originalContent: content,
          enhancedContent: text,
          options: options as any,
          type: "adaptation",
        },
      })

      return {
        id: enhancement.id,
        originalContent: content,
        adaptedContent: text,
        platform: specificPlatform || platform,
        options,
      }
    } catch (error) {
      console.error("Error adapting content:", error)
      throw new Error("Failed to adapt content")
    }
  }

  /**
   * Localize/translate content
   */
  static async localizeContent(
    userId: string,
    content: string,
    options: LocalizationOptions,
    projectId?: string,
  ): Promise<any> {
    try {
      const { targetLanguage, targetRegion = "", preserveFormatting = true, adaptCulturalReferences = true } = options

      // Create system prompt based on options
      const systemPrompt = `You are an expert content localization specialist.
        Translate the provided content to ${targetLanguage}${targetRegion ? ` (${targetRegion})` : ""}.
        ${preserveFormatting ? "Preserve the original formatting." : ""}
        ${adaptCulturalReferences ? "Adapt cultural references to be appropriate for the target language/region." : ""}
        Provide only the localized content without additional commentary.`

      // Generate localized content
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Localize this content: ${content}`,
        system: systemPrompt,
      })

      // Save to database
      const enhancement = await prisma.contentEnhancement.create({
        data: {
          userId,
          projectId,
          originalContent: content,
          enhancedContent: text,
          options: options as any,
          type: "localization",
        },
      })

      return {
        id: enhancement.id,
        originalContent: content,
        localizedContent: text,
        targetLanguage,
        targetRegion,
        options,
      }
    } catch (error) {
      console.error("Error localizing content:", error)
      throw new Error("Failed to localize content")
    }
  }

  /**
   * Get user's content enhancement history
   */
  static async getUserEnhancements(
    userId: string,
    options?: {
      type?: string
      limit?: number
      offset?: number
      projectId?: string
    },
  ): Promise<any[]> {
    try {
      const limit = options?.limit || 10
      const offset = options?.offset || 0

      const enhancements = await prisma.contentEnhancement.findMany({
        where: {
          userId,
          ...(options?.type ? { type: options.type } : {}),
          ...(options?.projectId ? { projectId: options.projectId } : {}),
        },
        orderBy: {
          createdAt: "desc",
        },
        take: limit,
        skip: offset,
      })

      return enhancements
    } catch (error) {
      console.error("Error fetching user enhancements:", error)
      throw new Error("Failed to fetch user content enhancements")
    }
  }
}

