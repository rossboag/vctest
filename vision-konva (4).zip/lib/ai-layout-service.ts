import { prisma } from "@/lib/db"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"

export interface LayoutElement {
  id: string
  type: string // text, image, shape, container, etc.
  content?: string
  width: number
  height: number
  x?: number
  y?: number
  importance?: "high" | "medium" | "low"
  category?: string
  styles?: Record<string, any>
}

export interface GridSystem {
  columns: number
  rows?: number
  columnGap: number
  rowGap?: number
  margin: number
  padding: number
}

export interface LayoutResult {
  elements: LayoutElement[]
  gridSystem?: GridSystem
  width: number
  height: number
}

export interface LayoutSuggestion {
  id: string
  title: string
  description: string
  before: {
    elements: LayoutElement[]
  }
  after: {
    elements: LayoutElement[]
  }
  impact: "high" | "medium" | "low"
}

export interface WhitespaceAnalysis {
  score: number
  issues: Array<{
    area: string
    issue: string
    suggestion: string
  }>
  overallFeedback: string
}

export interface AlignmentAnalysis {
  score: number
  issues: Array<{
    elements: string[]
    issue: string
    suggestion: string
  }>
  overallFeedback: string
}

export class AILayoutService {
  /**
   * Generate an auto-layout based on content and constraints
   */
  static async generateLayout(
    userId: string,
    prompt: string,
    canvasSize: { width: number; height: number },
    contentElements?: {
      type: string
      content?: string
      importance?: "high" | "medium" | "low"
    }[],
    style?: string,
    projectId?: string,
  ): Promise<LayoutResult> {
    try {
      const layoutSchema = z.object({
        elements: z.array(
          z.object({
            id: z.string(),
            type: z.string(),
            content: z.string().optional(),
            width: z.number(),
            height: z.number(),
            x: z.number(),
            y: z.number(),
            importance: z.enum(["high", "medium", "low"]).optional(),
            category: z.string().optional(),
            styles: z.record(z.any()).optional(),
          }),
        ),
        gridSystem: z
          .object({
            columns: z.number(),
            rows: z.number().optional(),
            columnGap: z.number(),
            rowGap: z.number().optional(),
            margin: z.number(),
            padding: z.number(),
          })
          .optional(),
        width: z.number(),
        height: z.number(),
      })

      const systemPrompt =
        "You are an expert layout designer. " +
        "Generate a precise, well-structured layout based on the provided prompt, canvas size, and content elements. " +
        "Consider design principles, hierarchy, and balance. " +
        "Position elements with exact x/y coordinates and dimensions that fit within the canvas. " +
        `${style ? `Apply a ${style} style to the layout. ` : ""}` +
        "Return a JSON object with elements array, optional grid system, and canvas dimensions."

      const { object: layout } = await generateText({
        model: openai("gpt-4o"),
        schema: layoutSchema,
        prompt: `Generate a layout for: "${prompt}" with canvas size ${JSON.stringify(canvasSize)}${
          contentElements ? ` and content elements: ${JSON.stringify(contentElements)}` : ""
        }`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "auto_layout",
          prompt,
          result: layout,
        },
      })

      return layout
    } catch (error) {
      console.error("Error generating layout:", error)
      throw new Error("Failed to generate layout")
    }
  }

  /**
   * Optimize element positioning within a layout
   */
  static async optimizeElementPositioning(
    userId: string,
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ): Promise<LayoutElement[]> {
    try {
      const optimizedElementsSchema = z.array(
        z.object({
          id: z.string(),
          type: z.string(),
          content: z.string().optional(),
          width: z.number(),
          height: z.number(),
          x: z.number(),
          y: z.number(),
          importance: z.enum(["high", "medium", "low"]).optional(),
          category: z.string().optional(),
          styles: z.record(z.any()).optional(),
        }),
      )

      const systemPrompt =
        "You are an expert in layout optimization. " +
        "Optimize the positioning of the provided elements within the canvas to improve the overall layout. " +
        "Consider design principles like balance, proximity, alignment, and visual hierarchy. " +
        "Return an array of elements with optimized positions (x, y coordinates)."

      const { object: optimizedElements } = await generateText({
        model: openai("gpt-4o"),
        schema: optimizedElementsSchema,
        prompt: `Optimize element positioning for this layout: Elements: ${JSON.stringify(
          elements,
        )}, Canvas size: ${JSON.stringify(canvasSize)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "element_positioning",
          prompt: JSON.stringify({ elements, canvasSize }),
          result: optimizedElements,
        },
      })

      return optimizedElements
    } catch (error) {
      console.error("Error optimizing element positioning:", error)
      throw new Error("Failed to optimize element positioning")
    }
  }

  /**
   * Analyze and optimize whitespace in a layout
   */
  static async analyzeWhitespace(
    userId: string,
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ): Promise<WhitespaceAnalysis> {
    try {
      const whitespaceSchema = z.object({
        score: z.number().min(1).max(10),
        issues: z.array(
          z.object({
            area: z.string(),
            issue: z.string(),
            suggestion: z.string(),
          }),
        ),
        overallFeedback: z.string(),
      })

      const systemPrompt =
        "You are an expert in whitespace analysis. " +
        "Analyze the whitespace in the provided layout. " +
        "Consider both macro and micro whitespace, breathing room around elements, and overall balance. " +
        "Identify issues and provide specific suggestions for improvement. " +
        "Score the whitespace usage on a scale of 1-10. " +
        "Return a JSON object with the analysis results."

      const { object: whitespaceAnalysis } = await generateText({
        model: openai("gpt-4o"),
        schema: whitespaceSchema,
        prompt: `Analyze whitespace for this layout: Elements: ${JSON.stringify(
          elements,
        )}, Canvas size: ${JSON.stringify(canvasSize)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "whitespace_analysis",
          prompt: JSON.stringify({ elements, canvasSize }),
          result: whitespaceAnalysis,
        },
      })

      return whitespaceAnalysis
    } catch (error) {
      console.error("Error analyzing whitespace:", error)
      throw new Error("Failed to analyze whitespace")
    }
  }

  /**
   * Optimize whitespace in a layout
   */
  static async optimizeWhitespace(
    userId: string,
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ): Promise<LayoutElement[]> {
    try {
      const optimizedElementsSchema = z.array(
        z.object({
          id: z.string(),
          type: z.string(),
          content: z.string().optional(),
          width: z.number(),
          height: z.number(),
          x: z.number(),
          y: z.number(),
          importance: z.enum(["high", "medium", "low"]).optional(),
          category: z.string().optional(),
          styles: z.record(z.any()).optional(),
        }),
      )

      const systemPrompt =
        "You are an expert in whitespace optimization. " +
        "Optimize the whitespace in the provided layout by adjusting element positions and sizes. " +
        "Consider both macro and micro whitespace, breathing room around elements, and overall balance. " +
        "Return an array of elements with optimized positions and sizes."

      const { object: optimizedElements } = await generateText({
        model: openai("gpt-4o"),
        schema: optimizedElementsSchema,
        prompt: `Optimize whitespace for this layout: Elements: ${JSON.stringify(
          elements,
        )}, Canvas size: ${JSON.stringify(canvasSize)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "whitespace_optimization",
          prompt: JSON.stringify({ elements, canvasSize }),
          result: optimizedElements,
        },
      })

      return optimizedElements
    } catch (error) {
      console.error("Error optimizing whitespace:", error)
      throw new Error("Failed to optimize whitespace")
    }
  }

  /**
   * Generate grid system recommendations
   */
  static async generateGridSystem(
    userId: string,
    canvasSize: { width: number; height: number },
    complexity?: "simple" | "standard" | "complex",
    projectId?: string,
  ): Promise<GridSystem> {
    try {
      const gridSystemSchema = z.object({
        columns: z.number(),
        rows: z.number().optional(),
        columnGap: z.number(),
        rowGap: z.number().optional(),
        margin: z.number(),
        padding: z.number(),
      })

      complexity = complexity || "standard"

      const systemPrompt =
        "You are an expert in grid systems. " +
        "Generate a grid system appropriate for the provided canvas size. " +
        `Design a ${complexity} grid system that provides a good foundation for layout design. ` +
        "Return a JSON object with grid specifications including columns, column gap, margin, and padding. " +
        "Optionally include rows and row gap if relevant."

      const { object: gridSystem } = await generateText({
        model: openai("gpt-4o"),
        schema: gridSystemSchema,
        prompt: `Generate a ${complexity} grid system for canvas size: ${JSON.stringify(canvasSize)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "grid_system",
          prompt: JSON.stringify({ canvasSize, complexity }),
          result: gridSystem,
        },
      })

      return gridSystem
    } catch (error) {
      console.error("Error generating grid system:", error)
      throw new Error("Failed to generate grid system")
    }
  }

  /**
   * Analyze element alignment in a layout
   */
  static async analyzeAlignment(
    userId: string,
    elements: LayoutElement[],
    projectId?: string,
  ): Promise<AlignmentAnalysis> {
    try {
      const alignmentSchema = z.object({
        score: z.number().min(1).max(10),
        issues: z.array(
          z.object({
            elements: z.array(z.string()),
            issue: z.string(),
            suggestion: z.string(),
          }),
        ),
        overallFeedback: z.string(),
      })

      const systemPrompt =
        "You are an expert in design alignment. " +
        "Analyze the alignment of elements in the provided layout. " +
        "Check for horizontal and vertical alignment, consistent spacing, and alignment with a grid. " +
        "Identify alignment issues and provide specific suggestions for improvement. " +
        "Score the alignment on a scale of 1-10. " +
        "Return a JSON object with the analysis results."

      const { object: alignmentAnalysis } = await generateText({
        model: openai("gpt-4o"),
        schema: alignmentSchema,
        prompt: `Analyze alignment for these elements: ${JSON.stringify(elements)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "alignment_analysis",
          prompt: JSON.stringify(elements),
          result: alignmentAnalysis,
        },
      })

      return alignmentAnalysis
    } catch (error) {
      console.error("Error analyzing alignment:", error)
      throw new Error("Failed to analyze alignment")
    }
  }

  /**
   * Optimize element alignment in a layout
   */
  static async optimizeAlignment(
    userId: string,
    elements: LayoutElement[],
    gridSystem?: GridSystem,
    projectId?: string,
  ): Promise<LayoutElement[]> {
    try {
      const optimizedElementsSchema = z.array(
        z.object({
          id: z.string(),
          type: z.string(),
          content: z.string().optional(),
          width: z.number(),
          height: z.number(),
          x: z.number(),
          y: z.number(),
          importance: z.enum(["high", "medium", "low"]).optional(),
          category: z.string().optional(),
          styles: z.record(z.any()).optional(),
        }),
      )

      const systemPrompt =
        "You are an expert in design alignment. " +
        "Optimize the alignment of elements in the provided layout. " +
        "Ensure proper horizontal and vertical alignment, consistent spacing, and alignment with the grid (if provided). " +
        "Return an array of elements with optimized positions that maintain their essential characteristics."

      const { object: optimizedElements } = await generateText({
        model: openai("gpt-4o"),
        schema: optimizedElementsSchema,
        prompt: `Optimize alignment for these elements: ${JSON.stringify(
          elements,
        )}${gridSystem ? `, using this grid system: ${JSON.stringify(gridSystem)}` : ""}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "alignment_optimization",
          prompt: JSON.stringify({ elements, gridSystem }),
          result: optimizedElements,
        },
      })

      return optimizedElements
    } catch (error) {
      console.error("Error optimizing alignment:", error)
      throw new Error("Failed to optimize alignment")
    }
  }

  /**
   * Generate layout suggestions for improvement
   */
  static async generateLayoutSuggestions(
    userId: string,
    elements: LayoutElement[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ): Promise<LayoutSuggestion[]> {
    try {
      const layoutSuggestionsSchema = z.array(
        z.object({
          id: z.string(),
          title: z.string(),
          description: z.string(),
          before: z.object({
            elements: z.array(
              z.object({
                id: z.string(),
                type: z.string(),
                content: z.string().optional(),
                width: z.number(),
                height: z.number(),
                x: z.number(),
                y: z.number(),
              }),
            ),
          }),
          after: z.object({
            elements: z.array(
              z.object({
                id: z.string(),
                type: z.string(),
                content: z.string().optional(),
                width: z.number(),
                height: z.number(),
                x: z.number(),
                y: z.number(),
              }),
            ),
          }),
          impact: z.enum(["high", "medium", "low"]),
        }),
      )

      const systemPrompt =
        "You are an expert layout designer. " +
        "Generate suggestions to improve the provided layout. " +
        "Consider design principles, balance, alignment, hierarchy, and whitespace. " +
        "For each suggestion, provide a title, description, before and after elements, and impact level. " +
        "Ensure the suggested changes are meaningful and improve the overall design. " +
        "The 'after' elements should have optimized positions and dimensions. " +
        "Return an array of layout suggestions."

      const { object: suggestions } = await generateText({
        model: openai("gpt-4o"),
        schema: layoutSuggestionsSchema,
        prompt: `Generate layout suggestions for: Elements: ${JSON.stringify(
          elements,
        )}, Canvas size: ${JSON.stringify(canvasSize)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "layout_suggestions",
          prompt: JSON.stringify({ elements, canvasSize }),
          result: suggestions,
        },
      })

      return suggestions
    } catch (error) {
      console.error("Error generating layout suggestions:", error)
      throw new Error("Failed to generate layout suggestions")
    }
  }

  /**
   * Create a responsive layout variant
   */
  static async generateResponsiveVariant(
    userId: string,
    elements: LayoutElement[],
    originalSize: { width: number; height: number },
    targetSize: { width: number; height: number },
    projectId?: string,
  ): Promise<LayoutResult> {
    try {
      const responsiveVariantSchema = z.object({
        elements: z.array(
          z.object({
            id: z.string(),
            type: z.string(),
            content: z.string().optional(),
            width: z.number(),
            height: z.number(),
            x: z.number(),
            y: z.number(),
            importance: z.enum(["high", "medium", "low"]).optional(),
            category: z.string().optional(),
            styles: z.record(z.any()).optional(),
          }),
        ),
        gridSystem: z
          .object({
            columns: z.number(),
            rows: z.number().optional(),
            columnGap: z.number(),
            rowGap: z.number().optional(),
            margin: z.number(),
            padding: z.number(),
          })
          .optional(),
        width: z.number(),
        height: z.number(),
      })

      const systemPrompt =
        "You are an expert in responsive design. " +
        "Create a responsive variant of the provided layout for the target size. " +
        "Adjust element positions, sizes, and relationships to maintain the design's integrity at the new dimensions. " +
        "Consider how the layout should adapt (reflow, resize, reposition) for the target size. " +
        "Return a complete layout result with the adapted elements and dimensions."

      const { object: responsiveVariant } = await generateText({
        model: openai("gpt-4o"),
        schema: responsiveVariantSchema,
        prompt: `Create a responsive layout variant from original size ${JSON.stringify(
          originalSize,
        )} to target size ${JSON.stringify(targetSize)} for elements: ${JSON.stringify(elements)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "responsive_variant",
          prompt: JSON.stringify({
            elements,
            originalSize,
            targetSize,
          }),
          result: responsiveVariant,
        },
      })

      return responsiveVariant
    } catch (error) {
      console.error("Error generating responsive variant:", error)
      throw new Error("Failed to generate responsive variant")
    }
  }
}

