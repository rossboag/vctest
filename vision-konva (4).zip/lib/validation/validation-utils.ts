import { z } from "zod"
import { ValidationError } from "../errors"

/**
 * Validate data against a schema
 */
export function validateData<T>(schema: z.ZodType<T>, data: unknown): T {
  try {
    return schema.parse(data)
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new ValidationError("Validation failed", { details: error.format() })
    }
    throw error
  }
}

/**
 * Sanitize HTML content to prevent XSS
 */
export function sanitizeHtml(html: string): string {
  // Simple sanitization - remove script tags and event handlers
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .replace(/on\w+="[^"]*"/g, "")
    .replace(/on\w+='[^']*'/g, "")
}

/**
 * Validate and sanitize file name
 */
export function sanitizeFileName(fileName: string): string {
  // Remove path traversal characters and make safe for file systems
  return fileName
    .replace(/[/\\?%*:|"<>]/g, "-")
    .replace(/\.\./g, "")
    .trim()
}

/**
 * Validate file type against allowed types
 */
export function validateFileType(mimeType: string, allowedTypes: string[] = []): boolean {
  if (allowedTypes.length === 0) {
    return true
  }

  return allowedTypes.some((type) => {
    // Handle wildcards like "image/*"
    if (type.endsWith("/*")) {
      const prefix = type.split("/")[0]
      return mimeType.startsWith(`${prefix}/`)
    }
    return mimeType === type
  })
}

/**
 * Validate file size
 */
export function validateFileSize(size: number, maxSize: number): boolean {
  return size <= maxSize
}

/**
 * Common validation schemas
 */
export const validationSchemas = {
  id: z.string().min(1),

  email: z.string().email(),

  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number"),

  username: z
    .string()
    .min(3, "Username must be at least 3 characters")
    .max(30, "Username must be at most 30 characters")
    .regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, underscores, and hyphens"),

  url: z.string().url(),

  hexColor: z.string().regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, "Invalid hex color"),

  positiveNumber: z.number().positive(),

  nonNegativeNumber: z.number().min(0),

  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid date format",
  }),

  tags: z.array(z.string()),

  pagination: z.object({
    page: z.number().int().positive().default(1),
    limit: z.number().int().positive().max(100).default(20),
  }),

  search: z.object({
    query: z.string().optional(),
    filters: z.record(z.string()).optional(),
    sort: z.string().optional(),
    order: z.enum(["asc", "desc"]).optional(),
  }),
}

