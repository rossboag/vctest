import Konva from "konva"

export class KonvaEffectHandler {
  applyFilter(node: Konva.Node, filter: string, options: any) {
    switch (filter) {
      case "blur":
        node.filters([Konva.Filters.Blur])
        node.blurRadius(options.radius)
        break
      case "brighten":
        node.filters([Konva.Filters.Brighten])
        node.brightness(options.brightness)
        break
      // Add more filter cases as needed
    }
    node.cache()
  }

  // Add other effect-related methods here
}

