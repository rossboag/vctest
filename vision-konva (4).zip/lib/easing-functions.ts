export const EasingFunctions = {
  // t: current time, b: beginning value, c: change in value, d: duration
  easeInQuad: (t: number, b: number, c: number, d: number) => {
    t /= d
    return c * t * t + b
  },

  easeOutQuad: (t: number, b: number, c: number, d: number) => {
    t /= d
    return -c * t * (t - 2) + b
  },

  easeInOutQuad: (t: number, b: number, c: number, d: number) => {
    t /= d / 2
    if (t < 1) return (c / 2) * t * t + b
    t--
    return (-c / 2) * (t * (t - 2) - 1) + b
  },

  easeInCubic: (t: number, b: number, c: number, d: number) => {
    t /= d
    return c * t * t * t + b
  },

  easeOutCubic: (t: number, b: number, c: number, d: number) => {
    t /= d
    t--
    return c * (t * t * t + 1) + b
  },

  easeInOutCubic: (t: number, b: number, c: number, d: number) => {
    t /= d / 2
    if (t < 1) return (c / 2) * t * t * t + b
    t -= 2
    return (c / 2) * (t * t * t + 2) + b
  },

  // Add more easing functions as needed
}

