import Stripe from "stripe"
import { logger } from "@/lib/logger"
import { prisma } from "@/lib/prisma"

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY is not defined")
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16", // Use the latest version
})

export class StripeService {
  /**
   * Create a checkout session for subscription
   */
  static async createCheckoutSession({
    userId,
    planId,
    successUrl,
    cancelUrl,
    customerEmail,
  }: {
    userId: string
    planId: string
    successUrl: string
    cancelUrl: string
    customerEmail?: string
  }) {
    try {
      // Get the plan from the database
      const plan = await prisma.plan.findUnique({
        where: { id: planId },
      })

      if (!plan || !plan.active) {
        throw new Error("Plan not found or inactive")
      }

      // Check if user already has a subscription
      const existingSubscription = await prisma.subscription.findUnique({
        where: { userId },
      })

      // If the user has a Stripe customer ID, use it, otherwise it will be created by Stripe
      let stripeCustomerId: string | undefined

      if (existingSubscription?.stripeCustomerId) {
        stripeCustomerId = existingSubscription.stripeCustomerId
      }

      // Get the Stripe price ID associated with this plan
      const stripePriceId = await this.getStripePriceId(plan.id)

      if (!stripePriceId) {
        throw new Error("Stripe price ID not found for this plan")
      }

      // Create a checkout session
      const session = await stripe.checkout.sessions.create({
        customer: stripeCustomerId,
        customer_email: !stripeCustomerId ? customerEmail : undefined,
        payment_method_types: ["card"],
        line_items: [
          {
            price: stripePriceId,
            quantity: 1,
          },
        ],
        mode: "subscription",
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          userId,
          planId,
        },
        subscription_data: {
          metadata: {
            userId,
            planId,
          },
          trial_period_days: plan.trialDays || undefined,
        },
      })

      return session
    } catch (error) {
      logger.error("Error creating checkout session", { error })
      throw error
    }
  }

  /**
   * Create a billing portal session
   */
  static async createBillingPortalSession({
    customerId,
    returnUrl,
  }: {
    customerId: string
    returnUrl: string
  }) {
    try {
      const session = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: returnUrl,
      })

      return session
    } catch (error) {
      logger.error("Error creating billing portal session", { error })
      throw error
    }
  }

  /**
   * Handle subscription updated event
   */
  static async handleSubscriptionUpdated(subscription: Stripe.Subscription) {
    try {
      const userId = subscription.metadata.userId
      const planId = subscription.metadata.planId

      if (!userId || !planId) {
        logger.error("Missing metadata in subscription", { subscription })
        return
      }

      // Update the subscription in the database
      await prisma.subscription.upsert({
        where: { userId },
        create: {
          status: subscription.status,
          startDate: new Date(subscription.current_period_start * 1000),
          endDate: new Date(subscription.current_period_end * 1000),
          trialEndDate: subscription.trial_end ? new Date(subscription.trial_end * 1000) : null,
          cancelAtPeriodEnd: subscription.cancel_at_period_end,
          canceledAt: subscription.canceled_at ? new Date(subscription.canceled_at * 1000) : null,
          stripeCustomerId: subscription.customer as string,
          stripeSubscriptionId: subscription.id,
          userId,
          planId,
        },
        update: {
          status: subscription.status,
          startDate: new Date(subscription.current_period_start * 1000),
          endDate: new Date(subscription.current_period_end * 1000),
          trialEndDate: subscription.trial_end ? new Date(subscription.trial_end * 1000) : null,
          cancelAtPeriodEnd: subscription.cancel_at_period_end,
          canceledAt: subscription.canceled_at ? new Date(subscription.canceled_at * 1000) : null,
          stripeCustomerId: subscription.customer as string,
          stripeSubscriptionId: subscription.id,
          planId,
        },
      })

      logger.info("Subscription updated successfully", { userId, planId })
    } catch (error) {
      logger.error("Error handling subscription update", { error, subscription })
      throw error
    }
  }

  /**
   * Handle subscription deleted event
   */
  static async handleSubscriptionDeleted(subscription: Stripe.Subscription) {
    try {
      const stripeSubscriptionId = subscription.id

      const dbSubscription = await prisma.subscription.findFirst({
        where: { stripeSubscriptionId },
      })

      if (!dbSubscription) {
        logger.error("Subscription not found in database", { stripeSubscriptionId })
        return
      }

      // Update subscription to inactive status
      await prisma.subscription.update({
        where: { id: dbSubscription.id },
        data: {
          status: "canceled",
          canceledAt: new Date(),
        },
      })

      logger.info("Subscription marked as canceled", { stripeSubscriptionId })
    } catch (error) {
      logger.error("Error handling subscription deletion", { error, subscription })
      throw error
    }
  }

  /**
   * Handle invoice payment succeeded event
   */
  static async handleInvoicePaymentSucceeded(invoice: Stripe.Invoice) {
    try {
      const stripeSubscriptionId = invoice.subscription as string
      const customerId = invoice.customer as string

      if (!stripeSubscriptionId) {
        logger.error("No subscription ID in invoice", { invoice })
        return
      }

      // Find the subscription in database
      const subscription = await prisma.subscription.findFirst({
        where: { stripeSubscriptionId },
      })

      if (!subscription) {
        logger.error("Subscription not found in database", { stripeSubscriptionId })
        return
      }

      // Record the payment
      await prisma.payment.create({
        data: {
          amount: invoice.amount_paid / 100, // Convert from cents
          currency: invoice.currency.toUpperCase(),
          status: "succeeded",
          stripePaymentId: invoice.payment_intent as string,
          stripeInvoiceId: invoice.id,
          subscriptionId: subscription.id,
        },
      })

      logger.info("Payment recorded successfully", {
        stripeSubscriptionId,
        invoiceId: invoice.id,
      })
    } catch (error) {
      logger.error("Error handling invoice payment", { error, invoice })
      throw error
    }
  }

  /**
   * Handle invoice payment failed event
   */
  static async handleInvoicePaymentFailed(invoice: Stripe.Invoice) {
    try {
      const stripeSubscriptionId = invoice.subscription as string

      if (!stripeSubscriptionId) {
        logger.error("No subscription ID in invoice", { invoice })
        return
      }

      // Find the subscription in database
      const subscription = await prisma.subscription.findFirst({
        where: { stripeSubscriptionId },
      })

      if (!subscription) {
        logger.error("Subscription not found in database", { stripeSubscriptionId })
        return
      }

      // Record the failed payment
      await prisma.payment.create({
        data: {
          amount: invoice.amount_due / 100, // Convert from cents
          currency: invoice.currency.toUpperCase(),
          status: "failed",
          stripePaymentId: invoice.payment_intent as string,
          stripeInvoiceId: invoice.id,
          subscriptionId: subscription.id,
        },
      })

      // Update subscription status if needed
      if (invoice.next_payment_attempt === null) {
        await prisma.subscription.update({
          where: { id: subscription.id },
          data: { status: "past_due" },
        })
      }

      logger.info("Failed payment recorded", {
        stripeSubscriptionId,
        invoiceId: invoice.id,
      })
    } catch (error) {
      logger.error("Error handling invoice payment failure", { error, invoice })
      throw error
    }
  }

  /**
   * Helper to get Stripe price ID for a plan
   */
  private static async getStripePriceId(planId: string): Promise<string | null> {
    try {
      const planSetting = await prisma.systemSetting.findUnique({
        where: { key: `stripe_price_id_${planId}` },
      })

      return planSetting?.value || null
    } catch (error) {
      logger.error("Error getting Stripe price ID", { error, planId })
      return null
    }
  }

  /**
   * Get subscription usage limits
   */
  static async getSubscriptionLimits(userId: string) {
    try {
      const subscription = await prisma.subscription.findUnique({
        where: { userId },
        include: { plan: true },
      })

      if (!subscription || subscription.status !== "active") {
        return {
          isActive: false,
          aiGenerationsLimit: 0,
          projectsLimit: 0,
          assetsLimit: 0,
          storageLimit: 0, // in MB
        }
      }

      // Parse the features JSON to get limits
      const features = subscription.plan.features as any

      return {
        isActive: true,
        aiGenerationsLimit: features?.aiGenerationsLimit || 10,
        projectsLimit: features?.projectsLimit || 3,
        assetsLimit: features?.assetsLimit || 50,
        storageLimit: features?.storageLimit || 100, // in MB
      }
    } catch (error) {
      logger.error("Error getting subscription limits", { error, userId })
      return {
        isActive: false,
        aiGenerationsLimit: 0,
        projectsLimit: 0,
        assetsLimit: 0,
        storageLimit: 0,
      }
    }
  }

  /**
   * Check if user has reached their limits
   */
  static async checkUserLimits(userId: string, limitType: "aiGeneration" | "project" | "asset" | "storage") {
    try {
      const limits = await this.getSubscriptionLimits(userId)

      if (!limits.isActive) {
        return { allowed: false, reason: "No active subscription" }
      }

      switch (limitType) {
        case "aiGeneration": {
          const count = await prisma.aIGeneration.count({ where: { userId } })
          return {
            allowed: count < limits.aiGenerationsLimit,
            current: count,
            limit: limits.aiGenerationsLimit,
          }
        }

        case "project": {
          const count = await prisma.project.count({ where: { userId } })
          return {
            allowed: count < limits.projectsLimit,
            current: count,
            limit: limits.projectsLimit,
          }
        }

        case "asset": {
          const count = await prisma.asset.count({ where: { userId } })
          return {
            allowed: count < limits.assetsLimit,
            current: count,
            limit: limits.assetsLimit,
          }
        }

        case "storage": {
          const assets = await prisma.asset.findMany({
            where: { userId },
            select: { size: true },
          })

          const totalStorageBytes = assets.reduce((total, asset) => total + asset.size, 0)
          const totalStorageMB = totalStorageBytes / (1024 * 1024)

          return {
            allowed: totalStorageMB < limits.storageLimit,
            current: totalStorageMB,
            limit: limits.storageLimit,
          }
        }

        default:
          return { allowed: false, reason: "Unknown limit type" }
      }
    } catch (error) {
      logger.error("Error checking user limits", { error, userId, limitType })
      return { allowed: false, reason: "Error checking limits" }
    }
  }
}

