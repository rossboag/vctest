import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function getProjectWithDetails(projectId: string) {
  return await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      layers: {
        orderBy: { order: "asc" },
        include: {
          elements: {
            orderBy: { zIndex: "asc" },
          },
        },
      },
    },
  })
}

export async function duplicateProject(projectId: string, userId: string, newName?: string) {
  // Get the original project with all its data
  const originalProject = await getProjectWithDetails(projectId)

  if (!originalProject) {
    throw new Error("Project not found")
  }

  // Create a new project
  const newProject = await prisma.project.create({
    data: {
      name: newName || `${originalProject.name} (Copy)`,
      description: originalProject.description,
      canvasSize: originalProject.canvasSize,
      userId,
    },
  })

  // Duplicate layers and elements
  for (const layer of originalProject.layers) {
    const newLayer = await prisma.layer.create({
      data: {
        projectId: newProject.id,
        name: layer.name,
        visible: layer.visible,
        locked: layer.locked,
        order: layer.order,
      },
    })

    // Duplicate elements in this layer
    for (const element of layer.elements) {
      await prisma.element.create({
        data: {
          layerId: newLayer.id,
          type: element.type,
          properties: element.properties,
          zIndex: element.zIndex,
        },
      })
    }
  }

  return newProject
}

export async function reorderLayers(projectId: string, layerIds: string[]) {
  // Update the order of each layer
  const updates = layerIds.map((layerId, index) => {
    return prisma.layer.update({
      where: { id: layerId },
      data: { order: index },
    })
  })

  await prisma.$transaction(updates)
}

export async function reorderElements(layerId: string, elementIds: string[]) {
  // Update the zIndex of each element
  const updates = elementIds.map((elementId, index) => {
    return prisma.element.update({
      where: { id: elementId },
      data: { zIndex: index },
    })
  })

  await prisma.$transaction(updates)
}

