/**
 * Custom error classes for more detailed error handling
 */

// Base application error
export class AppError extends Error {
  public statusCode: number
  public code: string
  public context?: Record<string, any>
  public isOperational: boolean

  constructor(
    message: string,
    statusCode = 500,
    code = "INTERNAL_ERROR",
    context?: Record<string, any>,
    isOperational = true,
  ) {
    super(message)
    this.name = this.constructor.name
    this.statusCode = statusCode
    this.code = code
    this.context = context
    this.isOperational = isOperational // Errors we expect and can handle gracefully
    Error.captureStackTrace(this, this.constructor)
  }
}

// Validation errors
export class ValidationError extends AppError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, 400, "VALIDATION_ERROR", context, true)
  }
}

// Authentication errors
export class AuthenticationError extends AppError {
  constructor(message = "Not authenticated", context?: Record<string, any>) {
    super(message, 401, "AUTHENTICATION_ERROR", context, true)
  }
}

// Authorization errors
export class AuthorizationError extends AppError {
  constructor(message = "Not authorized", context?: Record<string, any>) {
    super(message, 403, "AUTHORIZATION_ERROR", context, true)
  }
}

// Resource not found
export class NotFoundError extends AppError {
  constructor(resource: string, id?: string) {
    const message = id ? `${resource} with ID ${id} not found` : `${resource} not found`
    super(message, 404, "NOT_FOUND", { resource, id }, true)
  }
}

// Rate limit exceeded
export class RateLimitError extends AppError {
  constructor(limit: number, reset: number, resource?: string) {
    const message = resource ? `Rate limit exceeded for ${resource}` : "Rate limit exceeded"
    super(message, 429, "RATE_LIMIT_EXCEEDED", { limit, reset, resource }, true)
  }
}

// AI specific errors
export class AIError extends AppError {
  constructor(message: string, statusCode = 500, code = "AI_ERROR", context?: Record<string, any>) {
    super(message, statusCode, code, context, true)
  }
}

// Content policy violation
export class ContentPolicyError extends AppError {
  constructor(message = "Content policy violation", context?: Record<string, any>) {
    super(message, 400, "CONTENT_POLICY_VIOLATION", context, true)
  }
}

// External service error
export class ExternalServiceError extends AppError {
  constructor(service: string, message: string, statusCode = 500, context?: Record<string, any>) {
    super(`${service} service error: ${message}`, statusCode, "EXTERNAL_SERVICE_ERROR", { ...context, service }, true)
  }
}

