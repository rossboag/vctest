// Performance metrics
const metrics = {
  renderTimes: [],
  apiCallTimes: {},
  memoryUsage: [],
  fps: [],
  interactionLatency: [],
}

// Helper to monitor performance
export const performanceMonitor = {
  // Start monitoring render time
  startRenderTimer: (componentName: string) => {
    const startTime = performance.now()

    return () => {
      const endTime = performance.now()
      const renderTime = endTime - startTime

      // Store render time
      metrics.renderTimes.push({
        component: componentName,
        time: renderTime,
        timestamp: Date.now(),
      })

      // Log if render time is too long
      if (renderTime > 16) {
        // 60fps = ~16ms per frame
        console.warn(`Slow render: ${componentName} took ${renderTime.toFixed(2)}ms`)
      }

      return renderTime
    }
  },

  // Monitor API call
  monitorApiCall: async (name: string, apiCall: () => Promise<any>) => {
    const startTime = performance.now()

    try {
      const result = await apiCall()

      const endTime = performance.now()
      const callTime = endTime - startTime

      // Store API call time
      if (!metrics.apiCallTimes[name]) {
        metrics.apiCallTimes[name] = []
      }

      metrics.apiCallTimes[name].push({
        time: callTime,
        timestamp: Date.now(),
        success: true,
      })

      return result
    } catch (error) {
      const endTime = performance.now()
      const callTime = endTime - startTime

      // Store API call time with error
      if (!metrics.apiCallTimes[name]) {
        metrics.apiCallTimes[name] = []
      }

      metrics.apiCallTimes[name].push({
        time: callTime,
        timestamp: Date.now(),
        success: false,
        error,
      })

      throw error
    }
  },

  // Monitor memory usage
  monitorMemoryUsage: () => {
    if (typeof window === "undefined" || !performance.memory) {
      return
    }

    // Store memory usage
    metrics.memoryUsage.push({
      usedJSHeapSize: performance.memory.usedJSHeapSize,
      totalJSHeapSize: performance.memory.totalJSHeapSize,
      timestamp: Date.now(),
    })
  },

  // Monitor FPS
  monitorFps: () => {
    if (typeof window === "undefined") {
      return
    }

    let frameCount = 0
    let lastTime = performance.now()

    const countFrame = () => {
      frameCount++

      const currentTime = performance.now()
      const elapsed = currentTime - lastTime

      if (elapsed >= 1000) {
        const fps = Math.round((frameCount * 1000) / elapsed)

        // Store FPS
        metrics.fps.push({
          fps,
          timestamp: Date.now(),
        })

        // Log if FPS is too low
        if (fps < 30) {
          console.warn(`Low FPS: ${fps}`)
        }

        frameCount = 0
        lastTime = currentTime
      }

      requestAnimationFrame(countFrame)
    }

    requestAnimationFrame(countFrame)
  },

  // Monitor interaction latency
  monitorInteractionLatency: () => {
    if (typeof window === "undefined") {
      return
    }

    const handleInteraction = (event) => {
      const startTime = event.timeStamp

      requestAnimationFrame(() => {
        const endTime = performance.now()
        const latency = endTime - startTime

        // Store interaction latency
        metrics.interactionLatency.push({
          type: event.type,
          latency,
          timestamp: Date.now(),
        })

        // Log if latency is too high
        if (latency > 100) {
          console.warn(`High interaction latency: ${latency.toFixed(2)}ms for ${event.type}`)
        }
      })
    }

    // Monitor various interaction events
    window.addEventListener("click", handleInteraction, { passive: true })
    window.addEventListener("touchstart", handleInteraction, { passive: true })
    window.addEventListener("keydown", handleInteraction, { passive: true })

    return () => {
      window.removeEventListener("click", handleInteraction)
      window.removeEventListener("touchstart", handleInteraction)
      window.removeEventListener("keydown", handleInteraction)
    }
  },

  // Get all metrics
  getMetrics: () => {
    return { ...metrics }
  },

  // Clear all metrics
  clearMetrics: () => {
    metrics.renderTimes = []
    metrics.apiCallTimes = {}
    metrics.memoryUsage = []
    metrics.fps = []
    metrics.interactionLatency = []
  },

  // Get performance score
  getPerformanceScore: () => {
    // Calculate average render time
    const avgRenderTime =
      metrics.renderTimes.length > 0
        ? metrics.renderTimes.reduce((sum, item) => sum + item.time, 0) / metrics.renderTimes.length
        : 0

    // Calculate average FPS
    const avgFps =
      metrics.fps.length > 0 ? metrics.fps.reduce((sum, item) => sum + item.fps, 0) / metrics.fps.length : 60

    // Calculate average interaction latency
    const avgLatency =
      metrics.interactionLatency.length > 0
        ? metrics.interactionLatency.reduce((sum, item) => sum + item.latency, 0) / metrics.interactionLatency.length
        : 0

    // Calculate performance score (0-100)
    const renderScore = Math.max(0, 100 - (avgRenderTime / 16) * 100)
    const fpsScore = (avgFps / 60) * 100
    const latencyScore = Math.max(0, 100 - (avgLatency / 100) * 100)

    const overallScore = (renderScore + fpsScore + latencyScore) / 3

    return {
      overall: Math.round(overallScore),
      render: Math.round(renderScore),
      fps: Math.round(fpsScore),
      latency: Math.round(latencyScore),
      details: {
        avgRenderTime,
        avgFps,
        avgLatency,
      },
    }
  },
}

