import Konva from "konva"

export class KonvaAnimationHandler {
  createTween(node: Konva.Node, props: any, duration: number) {
    return new Konva.Tween({
      node: node,
      duration: duration,
      ...props,
    })
  }

  // Add other animation-related methods here
}

