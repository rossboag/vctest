import { prisma } from "@/lib/db"
import type { UserIntegration, IntegrationAsset } from "@prisma/client"

// Types for integration providers
export type IntegrationProvider = "google" | "dropbox" | "onedrive"

// Types for integration tokens
export interface IntegrationTokens {
  accessToken: string
  refreshToken?: string
  expiresAt?: Date
  scope?: string
}

// Types for integration assets
export interface ExternalAsset {
  id: string
  name: string
  type: "file" | "folder"
  mimeType?: string
  size?: number
  thumbnailUrl?: string
  url?: string
  parentId?: string
  path?: string
}

export class IntegrationService {
  /**
   * Save or update integration tokens for a user
   */
  static async saveIntegration(
    userId: string,
    provider: IntegrationProvider,
    providerUserId: string,
    tokens: IntegrationTokens,
  ): Promise<UserIntegration> {
    return prisma.userIntegration.upsert({
      where: {
        userId_provider: {
          userId,
          provider,
        },
      },
      update: {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: tokens.expiresAt,
        scope: tokens.scope,
      },
      create: {
        userId,
        provider,
        providerUserId,
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: tokens.expiresAt,
        scope: tokens.scope,
      },
    })
  }

  /**
   * Get integration for a user
   */
  static async getIntegration(userId: string, provider: IntegrationProvider): Promise<UserIntegration | null> {
    return prisma.userIntegration.findUnique({
      where: {
        userId_provider: {
          userId,
          provider,
        },
      },
    })
  }

  /**
   * Get all integrations for a user
   */
  static async getUserIntegrations(userId: string): Promise<UserIntegration[]> {
    return prisma.userIntegration.findMany({
      where: {
        userId,
      },
    })
  }

  /**
   * Delete integration for a user
   */
  static async deleteIntegration(userId: string, provider: IntegrationProvider): Promise<UserIntegration> {
    return prisma.userIntegration.delete({
      where: {
        userId_provider: {
          userId,
          provider,
        },
      },
    })
  }

  /**
   * Save or update integration assets for a user
   */
  static async saveIntegrationAssets(
    userId: string,
    provider: IntegrationProvider,
    assets: ExternalAsset[],
  ): Promise<IntegrationAsset[]> {
    // Delete existing assets for this provider
    await prisma.integrationAsset.deleteMany({
      where: {
        userId,
        provider,
      },
    })

    // Create new assets
    const createdAssets = await Promise.all(
      assets.map((asset) =>
        prisma.integrationAsset.create({
          data: {
            userId,
            provider,
            externalId: asset.id,
            name: asset.name,
            type: asset.type,
            mimeType: asset.mimeType,
            size: asset.size,
            thumbnailUrl: asset.thumbnailUrl,
            url: asset.url,
            parentId: asset.parentId,
            path: asset.path,
          },
        }),
      ),
    )

    return createdAssets
  }

  /**
   * Get integration assets for a user
   */
  static async getIntegrationAssets(
    userId: string,
    provider: IntegrationProvider,
    parentId?: string,
  ): Promise<IntegrationAsset[]> {
    return prisma.integrationAsset.findMany({
      where: {
        userId,
        provider,
        parentId: parentId || null,
      },
      orderBy: [
        {
          type: "asc", // Folders first
        },
        {
          name: "asc",
        },
      ],
    })
  }

  /**
   * Get integration asset by ID
   */
  static async getIntegrationAssetById(
    userId: string,
    provider: IntegrationProvider,
    externalId: string,
  ): Promise<IntegrationAsset | null> {
    return prisma.integrationAsset.findUnique({
      where: {
        userId_provider_externalId: {
          userId,
          provider,
          externalId,
        },
      },
    })
  }
}

