import { prisma } from "@/lib/db"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"

export interface DesignAnalysisResult {
  composition: {
    score: number
    balance: number
    symmetry: number
    focusPoint: boolean
    feedback: string
  }
  colorHarmony: {
    score: number
    palette: string[]
    contrast: number
    feedback: string
  }
  typography: {
    score: number
    readability: number
    hierarchy: number
    feedback: string
  }
  accessibility: {
    score: number
    colorContrast: boolean
    textSize: boolean
    feedback: string
  }
  overallScore: number
  suggestions: string[]
}

export interface ColorPalette {
  primary: string
  secondary: string
  accent: string
  background: string
  text: string
  additional: string[]
}

export interface TypographyRecommendation {
  heading: {
    fontFamily: string
    fontSize: string
    fontWeight: string
    lineHeight: string
  }
  subheading: {
    fontFamily: string
    fontSize: string
    fontWeight: string
    lineHeight: string
  }
  body: {
    fontFamily: string
    fontSize: string
    fontWeight: string
    lineHeight: string
  }
  caption: {
    fontFamily: string
    fontSize: string
    fontWeight: string
    lineHeight: string
  }
  pairings: string[]
  feedback: string
}

export interface DesignSuggestion {
  category: string
  suggestion: string
  priority: "low" | "medium" | "high"
  before?: any
  after?: any
}

export type DesignElement = any

export class AIDesignService {
  /**
   * Analyze a design and provide feedback
   */
  static async analyzeDesign(
    userId: string,
    designElements: any[],
    canvasSize: { width: number; height: number },
    projectId?: string,
  ): Promise<DesignAnalysisResult> {
    try {
      const designSchema = z.object({
        composition: z.object({
          score: z.number().min(1).max(10),
          balance: z.number().min(1).max(10),
          symmetry: z.number().min(1).max(10),
          focusPoint: z.boolean(),
          feedback: z.string(),
        }),
        colorHarmony: z.object({
          score: z.number().min(1).max(10),
          palette: z.array(z.string()),
          contrast: z.number().min(1).max(10),
          feedback: z.string(),
        }),
        typography: z.object({
          score: z.number().min(1).max(10),
          readability: z.number().min(1).max(10),
          hierarchy: z.number().min(1).max(10),
          feedback: z.string(),
        }),
        accessibility: z.object({
          score: z.number().min(1).max(10),
          colorContrast: z.boolean(),
          textSize: z.boolean(),
          feedback: z.string(),
        }),
        overallScore: z.number().min(1).max(10),
        suggestions: z.array(z.string()),
      })

      const systemPrompt =
        "You are an expert design analyst. " +
        "Analyze the provided design elements and canvas size to evaluate the design quality. " +
        "Consider composition, color harmony, typography, and accessibility. " +
        "Provide specific, actionable feedback and suggestions for improvement."

      const { object: analysis } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Analyze this design: Canvas size: ${JSON.stringify(canvasSize)}, Elements: ${JSON.stringify(
          designElements,
        )}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "design_analysis",
          prompt: JSON.stringify({ designElements, canvasSize }),
          result: analysis,
        },
      })

      return analysis
    } catch (error) {
      console.error("Error analyzing design:", error)
      throw new Error("Failed to analyze design")
    }
  }

  /**
   * Generate color palette recommendations
   */
  static async generateColorPalette(
    userId: string,
    baseColor?: string,
    mood?: string,
    style?: string,
    projectId?: string,
  ): Promise<ColorPalette> {
    try {
      const colorPaletteSchema = z.object({
        primary: z.string(),
        secondary: z.string(),
        accent: z.string(),
        background: z.string(),
        text: z.string(),
        additional: z.array(z.string()),
      })

      const systemPrompt =
        "You are an expert color designer. " +
        "Generate a harmonious color palette based on the provided parameters. " +
        "Return hex color codes for primary, secondary, accent, background, and text colors. " +
        "Also provide additional complementary colors. " +
        "Ensure text colors have sufficient contrast with background colors for accessibility."

      let promptText = "Generate a harmonious color palette"
      if (baseColor) promptText += ` based on the color ${baseColor}`
      if (mood) promptText += ` with a ${mood} mood`
      if (style) promptText += ` in a ${style} style`

      const { object: palette } = await generateText({
        model: openai("gpt-4o"),
        schema: colorPaletteSchema,
        prompt: promptText,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "color_palette",
          prompt: JSON.stringify({ baseColor, mood, style }),
          result: palette,
        },
      })

      return palette
    } catch (error) {
      console.error("Error generating color palette:", error)
      throw new Error("Failed to generate color palette")
    }
  }

  /**
   * Generate typography recommendations
   */
  static async generateTypographyRecommendations(
    userId: string,
    style?: string,
    purpose?: string,
    projectId?: string,
  ): Promise<TypographyRecommendation> {
    try {
      const typographySchema = z.object({
        heading: z.object({
          fontFamily: z.string(),
          fontSize: z.string(),
          fontWeight: z.string(),
          lineHeight: z.string(),
        }),
        subheading: z.object({
          fontFamily: z.string(),
          fontSize: z.string(),
          fontWeight: z.string(),
          lineHeight: z.string(),
        }),
        body: z.object({
          fontFamily: z.string(),
          fontSize: z.string(),
          fontWeight: z.string(),
          lineHeight: z.string(),
        }),
        caption: z.object({
          fontFamily: z.string(),
          fontSize: z.string(),
          fontWeight: z.string(),
          lineHeight: z.string(),
        }),
        pairings: z.array(z.string()),
        feedback: z.string(),
      })

      const systemPrompt =
        "You are an expert typography designer. " +
        "Generate typography recommendations based on the provided parameters. " +
        "Include font families, sizes, weights, and line heights for headings, subheadings, body text, and captions. " +
        "Suggest font pairings and provide feedback on the typography choices. " +
        "Use common web fonts or Google Fonts that are widely available."

      let promptText = "Generate typography recommendations"
      if (style) promptText += ` in a ${style} style`
      if (purpose) promptText += ` for ${purpose}`

      const { object: typography } = await generateText({
        model: openai("gpt-4o"),
        schema: typographySchema,
        prompt: promptText,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "typography_recommendation",
          prompt: JSON.stringify({ style, purpose }),
          result: typography,
        },
      })

      return typography
    } catch (error) {
      console.error("Error generating typography recommendations:", error)
      throw new Error("Failed to generate typography recommendations")
    }
  }

  /**
   * Check accessibility of a design
   */
  static async checkAccessibility(
    userId: string,
    designElements: any[],
    projectId?: string,
  ): Promise<{
    score: number
    issues: Array<{
      element: string
      issue: string
      severity: "low" | "medium" | "high"
      suggestion: string
    }>
    overallFeedback: string
  }> {
    try {
      const accessibilitySchema = z.object({
        score: z.number().min(1).max(10),
        issues: z.array(
          z.object({
            element: z.string(),
            issue: z.string(),
            severity: z.enum(["low", "medium", "high"]),
            suggestion: z.string(),
          }),
        ),
        overallFeedback: z.string(),
      })

      const systemPrompt =
        "You are an accessibility expert. " +
        "Analyze the provided design elements for accessibility issues. " +
        "Check for color contrast, text size, element spacing, and other accessibility concerns. " +
        "Provide specific issues with severity levels and suggestions for improvement."

      const { object: accessibility } = await generateText({
        model: openai("gpt-4o"),
        schema: accessibilitySchema,
        prompt: `Check accessibility for these design elements: ${JSON.stringify(designElements)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "accessibility_check",
          prompt: JSON.stringify(designElements),
          result: accessibility,
        },
      })

      return accessibility
    } catch (error) {
      console.error("Error checking accessibility:", error)
      throw new Error("Failed to check accessibility")
    }
  }

  /**
   * Generate design improvement suggestions
   */
  static async generateDesignSuggestions(
    userId: string,
    designElements: any[],
    canvasSize: { width: number; height: number },
    focusArea?: "composition" | "color" | "typography" | "accessibility" | "all",
    projectId?: string,
  ): Promise<{
    suggestions: Array<{
      category: string
      suggestion: string
      priority: "low" | "medium" | "high"
      before?: any
      after?: any
    }>
    summary: string
  }> {
    try {
      const suggestionsSchema = z.object({
        suggestions: z.array(
          z.object({
            category: z.string(),
            suggestion: z.string(),
            priority: z.enum(["low", "medium", "high"]),
            before: z.any().optional(),
            after: z.any().optional(),
          }),
        ),
        summary: z.string(),
      })

      const systemPrompt =
        "You are an expert design consultant. " +
        "Generate specific, actionable suggestions to improve the provided design. " +
        `Focus on ${focusArea || "all aspects"} of the design. ` +
        "Provide before and after examples where possible. " +
        "Prioritize suggestions based on their impact on the overall design quality."

      const { object: suggestions } = await generateText({
        model: openai("gpt-4o"),
        schema: suggestionsSchema,
        prompt: `Generate design improvement suggestions for: Canvas size: ${JSON.stringify(
          canvasSize,
        )}, Elements: ${JSON.stringify(designElements)}`,
        system: systemPrompt,
      })

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "design_suggestions",
          prompt: JSON.stringify({ designElements, canvasSize, focusArea }),
          result: suggestions,
        },
      })

      return suggestions
    } catch (error) {
      console.error("Error generating design suggestions:", error)
      throw new Error("Failed to generate design suggestions")
    }
  }
}

