import { IntegrationService, type ExternalAsset } from "@/lib/integration-service"

export class GoogleDriveService {
  private accessToken: string
  private userId: string

  constructor(accessToken: string, userId: string) {
    this.accessToken = accessToken
    this.userId = userId
  }

  /**
   * List files and folders in Google Drive
   */
  async listFiles(folderId?: string): Promise<ExternalAsset[]> {
    try {
      const query = folderId ? `'${folderId}' in parents and trashed = false` : `'root' in parents and trashed = false`

      const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
        query,
      )}&fields=files(id,name,mimeType,size,thumbnailLink,webViewLink,parents)`

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to list files: ${response.statusText}`)
      }

      const data = await response.json()

      const assets: ExternalAsset[] = data.files.map((file: any) => ({
        id: file.id,
        name: file.name,
        type: file.mimeType === "application/vnd.google-apps.folder" ? "folder" : "file",
        mimeType: file.mimeType,
        size: file.size ? Number.parseInt(file.size) : undefined,
        thumbnailUrl: file.thumbnailLink,
        url: file.webViewLink,
        parentId: file.parents && file.parents.length > 0 ? file.parents[0] : undefined,
      }))

      // Save assets to database
      await IntegrationService.saveIntegrationAssets(this.userId, "google", assets)

      return assets
    } catch (error) {
      console.error("Error listing Google Drive files:", error)
      throw error
    }
  }

  /**
   * Get file details from Google Drive
   */
  async getFile(fileId: string): Promise<ExternalAsset> {
    try {
      const url = `https://www.googleapis.com/drive/v3/files/${fileId}?fields=id,name,mimeType,size,thumbnailLink,webViewLink,parents`

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to get file: ${response.statusText}`)
      }

      const file = await response.json()

      return {
        id: file.id,
        name: file.name,
        type: file.mimeType === "application/vnd.google-apps.folder" ? "folder" : "file",
        mimeType: file.mimeType,
        size: file.size ? Number.parseInt(file.size) : undefined,
        thumbnailUrl: file.thumbnailLink,
        url: file.webViewLink,
        parentId: file.parents && file.parents.length > 0 ? file.parents[0] : undefined,
      }
    } catch (error) {
      console.error("Error getting Google Drive file:", error)
      throw error
    }
  }

  /**
   * Download file from Google Drive
   */
  async downloadFile(fileId: string): Promise<ArrayBuffer> {
    try {
      const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to download file: ${response.statusText}`)
      }

      return await response.arrayBuffer()
    } catch (error) {
      console.error("Error downloading Google Drive file:", error)
      throw error
    }
  }

  /**
   * Upload file to Google Drive
   */
  async uploadFile(file: File, folderId?: string, filename?: string): Promise<ExternalAsset> {
    try {
      const metadata = {
        name: filename || file.name,
        mimeType: file.type,
        parents: folderId ? [folderId] : ["root"],
      }

      // Create a multipart request
      const boundary = "-------314159265358979323846"
      const delimiter = "\r\n--" + boundary + "\r\n"
      const closeDelimiter = "\r\n--" + boundary + "--"

      // Create the multipart request body
      const contentType = file.type || "application/octet-stream"

      // Convert file to array buffer
      const arrayBuffer = await file.arrayBuffer()

      // Create the multipart body
      const metadataPart = "Content-Type: application/json\r\n\r\n" + JSON.stringify(metadata)

      const filePart = "Content-Type: " + contentType + "\r\n\r\n"

      // Create the multipart body
      const multipartRequestBody = new Blob(
        [delimiter, metadataPart, delimiter, filePart, new Uint8Array(arrayBuffer), closeDelimiter],
        { type: "multipart/related; boundary=" + boundary },
      )

      const url = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": `multipart/related; boundary=${boundary}`,
        },
        body: multipartRequestBody,
      })

      if (!response.ok) {
        throw new Error(`Failed to upload file: ${response.statusText}`)
      }

      const data = await response.json()

      // Get the uploaded file details
      return await this.getFile(data.id)
    } catch (error) {
      console.error("Error uploading file to Google Drive:", error)
      throw error
    }
  }

  /**
   * Create folder in Google Drive
   */
  async createFolder(folderName: string, parentFolderId?: string): Promise<ExternalAsset> {
    try {
      const metadata = {
        name: folderName,
        mimeType: "application/vnd.google-apps.folder",
        parents: parentFolderId ? [parentFolderId] : ["root"],
      }

      const url = "https://www.googleapis.com/drive/v3/files"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(metadata),
      })

      if (!response.ok) {
        throw new Error(`Failed to create folder: ${response.statusText}`)
      }

      const data = await response.json()

      // Get the created folder details
      return await this.getFile(data.id)
    } catch (error) {
      console.error("Error creating folder in Google Drive:", error)
      throw error
    }
  }

  /**
   * Delete file or folder from Google Drive
   */
  async deleteFile(fileId: string): Promise<void> {
    try {
      const url = `https://www.googleapis.com/drive/v3/files/${fileId}`

      const response = await fetch(url, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to delete file: ${response.statusText}`)
      }
    } catch (error) {
      console.error("Error deleting Google Drive file:", error)
      throw error
    }
  }

  /**
   * Get user info from Google Drive
   */
  async getUserInfo(): Promise<{ id: string; name: string; email: string }> {
    try {
      const url = "https://www.googleapis.com/drive/v3/about?fields=user"

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to get user info: ${response.statusText}`)
      }

      const data = await response.json()

      return {
        id: data.user.permissionId,
        name: data.user.displayName,
        email: data.user.emailAddress,
      }
    } catch (error) {
      console.error("Error getting Google Drive user info:", error)
      throw error
    }
  }
}

