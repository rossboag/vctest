import { IntegrationService, type ExternalAsset } from "@/lib/integration-service"

export class OneDriveService {
  private accessToken: string
  private userId: string

  constructor(accessToken: string, userId: string) {
    this.accessToken = accessToken
    this.userId = userId
  }

  /**
   * List files and folders in OneDrive
   */
  async listFiles(folderId?: string): Promise<ExternalAsset[]> {
    try {
      const url = folderId
        ? `https://graph.microsoft.com/v1.0/me/drive/items/${folderId}/children`
        : "https://graph.microsoft.com/v1.0/me/drive/root/children"

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to list files: ${response.statusText}`)
      }

      const data = await response.json()

      const assets: ExternalAsset[] = data.value.map((item: any) => ({
        id: item.id,
        name: item.name,
        type: item.folder ? "folder" : "file",
        mimeType: item.file?.mimeType,
        size: item.size,
        thumbnailUrl: item.thumbnailUrl,
        url: item.webUrl,
        parentId: item.parentReference?.id,
        path: item.parentReference?.path ? `${item.parentReference.path}/${item.name}` : `/${item.name}`,
      }))

      // Save assets to database
      await IntegrationService.saveIntegrationAssets(this.userId, "onedrive", assets)

      return assets
    } catch (error) {
      console.error("Error listing OneDrive files:", error)
      throw error
    }
  }

  /**
   * Get file details from OneDrive
   */
  async getFile(fileId: string): Promise<ExternalAsset> {
    try {
      const url = `https://graph.microsoft.com/v1.0/me/drive/items/${fileId}`

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to get file: ${response.statusText}`)
      }

      const item = await response.json()

      return {
        id: item.id,
        name: item.name,
        type: item.folder ? "folder" : "file",
        mimeType: item.file?.mimeType,
        size: item.size,
        thumbnailUrl: item.thumbnailUrl,
        url: item.webUrl,
        parentId: item.parentReference?.id,
        path: item.parentReference?.path ? `${item.parentReference.path}/${item.name}` : `/${item.name}`,
      }
    } catch (error) {
      console.error("Error getting OneDrive file:", error)
      throw error
    }
  }

  /**
   * Download file from OneDrive
   */
  async downloadFile(fileId: string): Promise<ArrayBuffer> {
    try {
      const url = `https://graph.microsoft.com/v1.0/me/drive/items/${fileId}/content`

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to download file: ${response.statusText}`)
      }

      return await response.arrayBuffer()
    } catch (error) {
      console.error("Error downloading OneDrive file:", error)
      throw error
    }
  }

  /**
   * Upload file to OneDrive
   */
  async uploadFile(file: File, folderId?: string, filename?: string): Promise<ExternalAsset> {
    try {
      const name = filename || file.name
      const url = folderId
        ? `https://graph.microsoft.com/v1.0/me/drive/items/${folderId}:/${name}:/content`
        : `https://graph.microsoft.com/v1.0/me/drive/root:/${name}:/content`

      const arrayBuffer = await file.arrayBuffer()

      const response = await fetch(url, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": file.type,
        },
        body: new Uint8Array(arrayBuffer),
      })

      if (!response.ok) {
        throw new Error(`Failed to upload file: ${response.statusText}`)
      }

      const data = await response.json()

      // Get the uploaded file details
      return await this.getFile(data.id)
    } catch (error) {
      console.error("Error uploading file to OneDrive:", error)
      throw error
    }
  }

  /**
   * Create folder in OneDrive
   */
  async createFolder(folderName: string, parentFolderId?: string): Promise<ExternalAsset> {
    try {
      const url = parentFolderId
        ? `https://graph.microsoft.com/v1.0/me/drive/items/${parentFolderId}/children`
        : "https://graph.microsoft.com/v1.0/me/drive/root/children"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: folderName,
          folder: {},
          "@microsoft.graph.conflictBehavior": "rename",
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to create folder: ${response.statusText}`)
      }

      const data = await response.json()

      // Get the created folder details
      return await this.getFile(data.id)
    } catch (error) {
      console.error("Error creating folder in OneDrive:", error)
      throw error
    }
  }

  /**
   * Delete file or folder from OneDrive
   */
  async deleteFile(fileId: string): Promise<void> {
    try {
      const url = `https://graph.microsoft.com/v1.0/me/drive/items/${fileId}`

      const response = await fetch(url, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to delete file: ${response.statusText}`)
      }
    } catch (error) {
      console.error("Error deleting OneDrive file:", error)
      throw error
    }
  }

  /**
   * Get user info from OneDrive
   */
  async getUserInfo(): Promise<{ id: string; name: string; email: string }> {
    try {
      const url = "https://graph.microsoft.com/v1.0/me"

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to get user info: ${response.statusText}`)
      }

      const data = await response.json()

      return {
        id: data.id,
        name: data.displayName,
        email: data.userPrincipalName,
      }
    } catch (error) {
      console.error("Error getting OneDrive user info:", error)
      throw error
    }
  }
}

