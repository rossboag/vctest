import { IntegrationService, type ExternalAsset } from "@/lib/integration-service"

export class DropboxService {
  private accessToken: string
  private userId: string

  constructor(accessToken: string, userId: string) {
    this.accessToken = accessToken
    this.userId = userId
  }

  /**
   * List files and folders in Dropbox
   */
  async listFiles(path = ""): Promise<ExternalAsset[]> {
    try {
      const url = "https://api.dropboxapi.com/2/files/list_folder"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          path: path || "",
          recursive: false,
          include_media_info: true,
          include_deleted: false,
          include_has_explicit_shared_members: false,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to list files: ${response.statusText}`)
      }

      const data = await response.json()

      const assets: ExternalAsset[] = data.entries.map((entry: any) => {
        const isFolder = entry[".tag"] === "folder"
        return {
          id: entry.id,
          name: entry.name,
          type: isFolder ? "folder" : "file",
          mimeType: isFolder ? "folder" : entry.media_info?.metadata?.mime_type,
          size: entry.size,
          path: entry.path_display,
          parentId: entry.path_display ? entry.path_display.split("/").slice(0, -1).join("/") || "/" : "/",
        }
      })

      // Save assets to database
      await IntegrationService.saveIntegrationAssets(this.userId, "dropbox", assets)

      return assets
    } catch (error) {
      console.error("Error listing Dropbox files:", error)
      throw error
    }
  }

  /**
   * Get file details from Dropbox
   */
  async getFile(path: string): Promise<ExternalAsset> {
    try {
      const url = "https://api.dropboxapi.com/2/files/get_metadata"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          path,
          include_media_info: true,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to get file: ${response.statusText}`)
      }

      const entry = await response.json()
      const isFolder = entry[".tag"] === "folder"

      return {
        id: entry.id,
        name: entry.name,
        type: isFolder ? "folder" : "file",
        mimeType: isFolder ? "folder" : entry.media_info?.metadata?.mime_type,
        size: entry.size,
        path: entry.path_display,
        parentId: entry.path_display ? entry.path_display.split("/").slice(0, -1).join("/") || "/" : "/",
      }
    } catch (error) {
      console.error("Error getting Dropbox file:", error)
      throw error
    }
  }

  /**
   * Download file from Dropbox
   */
  async downloadFile(path: string): Promise<ArrayBuffer> {
    try {
      const url = "https://content.dropboxapi.com/2/files/download"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Dropbox-API-Arg": JSON.stringify({ path }),
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to download file: ${response.statusText}`)
      }

      return await response.arrayBuffer()
    } catch (error) {
      console.error("Error downloading Dropbox file:", error)
      throw error
    }
  }

  /**
   * Upload file to Dropbox
   */
  async uploadFile(file: File, path: string, filename?: string): Promise<ExternalAsset> {
    try {
      const url = "https://content.dropboxapi.com/2/files/upload"

      // Ensure path ends with the filename
      const fullPath = path.endsWith("/") ? `${path}${filename || file.name}` : `${path}/${filename || file.name}`

      const arrayBuffer = await file.arrayBuffer()

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/octet-stream",
          "Dropbox-API-Arg": JSON.stringify({
            path: fullPath,
            mode: "add",
            autorename: true,
            mute: false,
          }),
        },
        body: new Uint8Array(arrayBuffer),
      })

      if (!response.ok) {
        throw new Error(`Failed to upload file: ${response.statusText}`)
      }

      const data = await response.json()

      // Get the uploaded file details
      return await this.getFile(data.path_display)
    } catch (error) {
      console.error("Error uploading file to Dropbox:", error)
      throw error
    }
  }

  /**
   * Create folder in Dropbox
   */
  async createFolder(folderName: string, path: string): Promise<ExternalAsset> {
    try {
      const url = "https://api.dropboxapi.com/2/files/create_folder_v2"

      // Ensure path ends with the folder name
      const fullPath = path.endsWith("/") ? `${path}${folderName}` : `${path}/${folderName}`

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          path: fullPath,
          autorename: false,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to create folder: ${response.statusText}`)
      }

      const data = await response.json()

      // Get the created folder details
      return await this.getFile(data.metadata.path_display)
    } catch (error) {
      console.error("Error creating folder in Dropbox:", error)
      throw error
    }
  }

  /**
   * Delete file or folder from Dropbox
   */
  async deleteFile(path: string): Promise<void> {
    try {
      const url = "https://api.dropboxapi.com/2/files/delete_v2"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          path,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to delete file: ${response.statusText}`)
      }
    } catch (error) {
      console.error("Error deleting Dropbox file:", error)
      throw error
    }
  }

  /**
   * Get user info from Dropbox
   */
  async getUserInfo(): Promise<{ id: string; name: string; email: string }> {
    try {
      const url = "https://api.dropboxapi.com/2/users/get_current_account"

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to get user info: ${response.statusText}`)
      }

      const data = await response.json()

      return {
        id: data.account_id,
        name: data.name.display_name,
        email: data.email,
      }
    } catch (error) {
      console.error("Error getting Dropbox user info:", error)
      throw error
    }
  }
}

