import type { IntegrationProvider } from "@/lib/integration-service"
import { GoogleDriveService } from "@/lib/integrations/google-drive-service"
import { DropboxService } from "@/lib/integrations/dropbox-service"
import { OneDriveService } from "@/lib/integrations/onedrive-service"

export class IntegrationFactory {
  /**
   * Get integration service instance
   */
  static getService(provider: IntegrationProvider, accessToken: string, userId: string) {
    switch (provider) {
      case "google":
        return new GoogleDriveService(accessToken, userId)
      case "dropbox":
        return new DropboxService(accessToken, userId)
      case "onedrive":
        return new OneDriveService(accessToken, userId)
      default:
        throw new Error(`Unsupported provider: ${provider}`)
    }
  }
}

