import { prisma } from "@/lib/db"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { Redis } from "@upstash/redis"
import { Ratelimit } from "@upstash/ratelimit"

// Initialize Redis for rate limiting if environment variables are available
const redis =
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN
    ? new Redis({
        url: process.env.UPSTASH_REDIS_REST_URL,
        token: process.env.UPSTASH_REDIS_REST_TOKEN,
      })
    : null

// Create rate limiter that allows 10 requests per minute
const rateLimiter = redis
  ? new Ratelimit({
      redis,
      limiter: Ratelimit.slidingWindow(10, "1 m"),
      analytics: true,
    })
  : null

export type AIGenerationType =
  | "text_generation"
  | "image_generation"
  | "design_suggestion"
  | "animation_suggestion"
  | "color_palette"
  | "layout_suggestion"
  | "content_enhancement"
  | "style_transfer"

export interface AIGenerationResult {
  id: string
  type: AIGenerationType
  prompt: string
  result: any
  createdAt: Date
}

export class AIServiceError extends Error {
  public statusCode: number
  public context?: Record<string, any>

  constructor(message: string, statusCode = 500, context?: Record<string, any>) {
    super(message)
    this.name = "AIServiceError"
    this.statusCode = statusCode
    this.context = context
  }
}

export class AIService {
  /**
   * Check rate limiting for a user
   * Throws an error if the rate limit is exceeded
   */
  private static async checkRateLimit(userId: string, operationType: string): Promise<void> {
    if (!rateLimiter) return

    // Create a unique key for this user and operation type
    const key = `rate_limit:${operationType}:${userId}`

    const { success, limit, reset, remaining } = await rateLimiter.limit(key)

    if (!success) {
      throw new AIServiceError(`Rate limit exceeded for ${operationType}. Try again after ${reset} seconds.`, 429, {
        limit,
        reset,
        remaining,
      })
    }
  }

  /**
   * Log AI operation for analytics and monitoring
   */
  private static async logOperation(
    userId: string,
    operationType: string,
    prompt: string,
    projectId?: string,
  ): Promise<void> {
    try {
      await prisma.aIOperationLog.create({
        data: {
          userId,
          operationType,
          prompt,
          projectId,
          timestamp: new Date(),
        },
      })
    } catch (error) {
      console.error("Error logging AI operation:", error)
      // Don't throw error here to avoid disrupting the main flow
    }
  }

  /**
   * Validate that all required environment variables are set
   */
  private static validateEnvironment(requiredVars: string[]): void {
    const missingVars = requiredVars.filter((varName) => !process.env[varName])
    if (missingVars.length > 0) {
      throw new AIServiceError(`Missing required environment variables: ${missingVars.join(", ")}`, 500)
    }
  }

  /**
   * Generate text using AI
   */
  static async generateText(
    userId: string,
    prompt: string,
    projectId?: string,
    systemPrompt?: string,
    options?: {
      temperature?: number
      maxTokens?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "text_generation")

      // Input validation
      if (!prompt.trim()) {
        throw new AIServiceError("Prompt cannot be empty", 400)
      }

      const temperature = options?.temperature ?? 0.7
      const maxTokens = options?.maxTokens

      const defaultSystemPrompt =
        "You are a creative assistant for a graphic design and animation tool. " +
        "Provide helpful, creative, and concise responses. Focus on design principles, " +
        "visual aesthetics, and effective communication."

      // Generate text using AI SDK
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt,
        system: systemPrompt || defaultSystemPrompt,
        temperature,
        maxTokens,
      })

      // Log the operation for analytics
      await this.logOperation(userId, "text_generation", prompt, projectId)

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "text_generation",
          prompt,
          result: { text },
        },
      })

      return {
        id: generation.id,
        type: "text_generation" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error generating text:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to generate text", 500)
    }
  }

  /**
   * Generate image using AI
   */
  static async generateImage(
    userId: string,
    prompt: string,
    projectId?: string,
    options?: {
      size?: "1024x1024" | "1792x1024" | "1024x1792"
      style?: "natural" | "vivid"
      quality?: "standard" | "hd"
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "image_generation")

      // Input validation
      if (!prompt.trim()) {
        throw new AIServiceError("Prompt cannot be empty", 400)
      }

      const size = options?.size || "1024x1024"
      const style = options?.style || "natural"
      const quality = options?.quality || "standard"

      // Call OpenAI API directly for image generation
      const response = await fetch("https://api.openai.com/v1/images/generations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "dall-e-3",
          prompt,
          n: 1,
          size,
          style,
          quality,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new AIServiceError(error.error?.message || "Failed to generate image", response.status, {
          response: error,
        })
      }

      const data = await response.json()
      const imageUrl = data.data[0].url
      const revisedPrompt = data.data[0].revised_prompt

      // Log the operation for analytics
      await this.logOperation(userId, "image_generation", prompt, projectId)

      // Download the image and upload to storage
      // This is a placeholder - you would implement your own storage solution
      const imageResponse = await fetch(imageUrl)
      const imageBuffer = await imageResponse.arrayBuffer()

      // Upload to your storage (e.g., S3, Cloudinary, etc.)
      // const uploadedUrl = await uploadToStorage(imageBuffer);
      const uploadedUrl = imageUrl // Placeholder

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "image_generation",
          prompt,
          result: {
            url: uploadedUrl,
            revisedPrompt,
            size,
            style,
            quality,
          },
        },
      })

      return {
        id: generation.id,
        type: "image_generation" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error generating image:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to generate image", 500)
    }
  }

  /**
   * Generate color palette based on a theme or description
   */
  static async generateColorPalette(
    userId: string,
    prompt: string,
    projectId?: string,
    options?: {
      count?: number
      mode?: "analogous" | "complementary" | "triadic" | "monochromatic" | "custom"
      temperature?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "color_palette")

      // Input validation
      if (!prompt.trim()) {
        throw new AIServiceError("Prompt cannot be empty", 400)
      }

      const count = options?.count || 5
      const mode = options?.mode || "custom"
      const temperature = options?.temperature ?? 0.7

      // Validate count
      if (count < 2 || count > 10) {
        throw new AIServiceError("Color count must be between 2 and 10", 400)
      }

      const systemPrompt =
        "You are a color palette generator. " +
        "Generate a color palette based on the user's description. " +
        `Return exactly ${count} colors in a JSON array of hex codes. ` +
        `The palette should follow ${mode} color harmony principles if specified. ` +
        "Only respond with the JSON array, nothing else."

      // Generate color palette using AI SDK
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt,
        system: systemPrompt,
        temperature,
      })

      // Log the operation for analytics
      await this.logOperation(userId, "color_palette", prompt, projectId)

      // Parse the colors from the response
      let colors: string[] = []
      try {
        // Extract JSON array if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\[(.*)\]/s)
        if (jsonMatch) {
          colors = JSON.parse(`[${jsonMatch[1]}]`)
        } else {
          colors = JSON.parse(text)
        }
      } catch (e) {
        // Fallback: try to extract hex codes using regex
        const hexCodes = text.match(/#[0-9A-Fa-f]{6}/g)
        if (hexCodes) {
          colors = hexCodes.slice(0, count)
        } else {
          throw new AIServiceError("Failed to parse color palette from AI response", 500)
        }
      }

      // Validate that we got the expected number of colors
      if (colors.length === 0) {
        throw new AIServiceError("No colors returned from AI", 500)
      }

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "color_palette",
          prompt,
          result: {
            colors,
            mode,
            count,
          },
        },
      })

      return {
        id: generation.id,
        type: "color_palette" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error generating color palette:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to generate color palette", 500)
    }
  }

  /**
   * Generate layout suggestions based on content and purpose
   */
  static async generateLayoutSuggestion(
    userId: string,
    prompt: string,
    projectId?: string,
    options?: {
      width?: number
      height?: number
      elements?: Array<{
        type: string
        content?: string
        importance?: "high" | "medium" | "low"
      }>
      temperature?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "layout_suggestion")

      // Input validation
      if (!prompt.trim()) {
        throw new AIServiceError("Prompt cannot be empty", 400)
      }

      const width = options?.width || 1920
      const height = options?.height || 1080
      const elements = options?.elements || []
      const temperature = options?.temperature ?? 0.7

      // Validate dimensions
      if (width < 100 || width > 5000) {
        throw new AIServiceError("Width must be between 100 and 5000 pixels", 400)
      }
      if (height < 100 || height > 5000) {
        throw new AIServiceError("Height must be between 100 and 5000 pixels", 400)
      }

      const systemPrompt =
        "You are a layout designer for a graphic design tool. " +
        `Generate a layout for a canvas of size ${width}x${height}. ` +
        "Return a JSON object with an array of elements, each with position (x, y), " +
        "size (width, height), and type properties. " +
        "Position should be relative to the top-left corner of the canvas. " +
        "Only respond with the JSON object, nothing else."

      const enhancedPrompt = `
        Design a layout with the following requirements:
        ${prompt}
        
        Canvas size: ${width}x${height}
        
        ${
          elements.length > 0
            ? `Elements to include:
        ${elements.map((el) => `- ${el.type}${el.content ? `: "${el.content}"` : ""}${el.importance ? ` (${el.importance} importance)` : ""}`).join("\n")}`
            : ""
        }
        
        Provide a JSON layout that can be directly used in our application.
      `

      // Generate layout using AI SDK
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: enhancedPrompt,
        system: systemPrompt,
        temperature,
      })

      // Log the operation for analytics
      await this.logOperation(userId, "layout_suggestion", prompt, projectId)

      // Parse the layout from the response
      let layout: any = {}
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          layout = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          layout = JSON.parse(text)
        }
      } catch (e) {
        throw new AIServiceError("Failed to parse layout suggestion from AI response", 500)
      }

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "layout_suggestion",
          prompt,
          result: {
            layout,
            width,
            height,
          },
        },
      })

      return {
        id: generation.id,
        type: "layout_suggestion" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error generating layout suggestion:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to generate layout suggestion", 500)
    }
  }

  /**
   * Generate animation suggestions for elements
   */
  static async generateAnimationSuggestion(
    userId: string,
    prompt: string,
    projectId?: string,
    options?: {
      elementType?: string
      duration?: number
      complexity?: "simple" | "medium" | "complex"
      temperature?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "animation_suggestion")

      // Input validation
      if (!prompt.trim()) {
        throw new AIServiceError("Prompt cannot be empty", 400)
      }

      const elementType = options?.elementType || "generic"
      const duration = options?.duration || 2
      const complexity = options?.complexity || "medium"
      const temperature = options?.temperature ?? 0.7

      // Validate duration
      if (duration < 0.5 || duration > 30) {
        throw new AIServiceError("Animation duration must be between 0.5 and 30 seconds", 400)
      }

      const systemPrompt =
        "You are an animation expert for a motion graphics tool. " +
        `Generate animation keyframes for a ${elementType} element with a duration of ${duration} seconds. ` +
        `The animation should be ${complexity} in complexity. ` +
        "Return a JSON object with an array of keyframes, each with a time (in seconds), " +
        "and properties like position, scale, rotation, opacity, etc. " +
        "Only respond with the JSON object, nothing else."

      // Generate animation using AI SDK
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt,
        system: systemPrompt,
        temperature,
      })

      // Log the operation for analytics
      await this.logOperation(userId, "animation_suggestion", prompt, projectId)

      // Parse the animation from the response
      let animation: any = {}
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          animation = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          animation = JSON.parse(text)
        }
      } catch (e) {
        throw new AIServiceError("Failed to parse animation suggestion from AI response", 500)
      }

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "animation_suggestion",
          prompt,
          result: {
            animation,
            elementType,
            duration,
            complexity,
          },
        },
      })

      return {
        id: generation.id,
        type: "animation_suggestion" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error generating animation suggestion:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to generate animation suggestion", 500)
    }
  }

  /**
   * Enhance content (text, images) with AI suggestions
   */
  static async enhanceContent(
    userId: string,
    content: string,
    contentType: "text" | "image_description",
    projectId?: string,
    options?: {
      tone?: "professional" | "casual" | "creative" | "formal"
      purpose?: "marketing" | "informational" | "educational" | "entertainment"
      targetAudience?: string
      temperature?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "content_enhancement")

      // Input validation
      if (!content.trim()) {
        throw new AIServiceError("Content cannot be empty", 400)
      }

      const tone = options?.tone || "professional"
      const purpose = options?.purpose || "informational"
      const targetAudience = options?.targetAudience || "general"
      const temperature = options?.temperature ?? 0.7

      const systemPrompt =
        "You are a content enhancement expert. " +
        `Enhance the provided ${contentType} to be more engaging and effective. ` +
        `Use a ${tone} tone for ${purpose} purposes. ` +
        `The target audience is: ${targetAudience}. ` +
        "Only respond with the enhanced content, nothing else."

      // Generate enhanced content using AI SDK
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Enhance this content: ${content}`,
        system: systemPrompt,
        temperature,
      })

      // Log the operation for analytics
      await this.logOperation(userId, "content_enhancement", content.substring(0, 100), projectId)

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "content_enhancement",
          prompt: content,
          result: {
            enhancedContent: text,
            originalContent: content,
            contentType,
            tone,
            purpose,
            targetAudience,
          },
        },
      })

      return {
        id: generation.id,
        type: "content_enhancement" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error enhancing content:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to enhance content", 500)
    }
  }

  /**
   * Generate design suggestions based on project content and purpose
   */
  static async generateDesignSuggestion(
    userId: string,
    projectId: string,
    options?: {
      aspectToImprove?: "composition" | "color" | "typography" | "overall" | "branding"
      styleReference?: string
      temperature?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "design_suggestion")

      const aspectToImprove = options?.aspectToImprove || "overall"
      const styleReference = options?.styleReference || ""
      const temperature = options?.temperature ?? 0.7

      // Get project details
      const project = await prisma.project.findUnique({
        where: { id: projectId },
        include: {
          elements: true,
          layers: true,
        },
      })

      if (!project) {
        throw new AIServiceError("Project not found", 404)
      }

      // Create a description of the project for the AI
      const projectDescription = `
        Project Name: ${project.name}
        Description: ${project.description || "No description"}
        Canvas Size: ${project.width}x${project.height}
        Number of Layers: ${project.layers.length}
        Number of Elements: ${project.elements.length}
        Element Types: ${Array.from(new Set(project.elements.map((e) => e.type))).join(", ")}
      `

      const systemPrompt =
        "You are a professional graphic designer providing feedback and suggestions. " +
        `Focus on improving the ${aspectToImprove} aspect of the design. ` +
        `${styleReference ? `Reference this style: ${styleReference}` : ""} ` +
        "Provide specific, actionable suggestions that can be implemented in a design tool. " +
        "Structure your response with clear sections and bullet points."

      // Generate design suggestions using AI SDK
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Analyze this project and provide design suggestions: ${projectDescription}`,
        system: systemPrompt,
        temperature,
      })

      // Log the operation for analytics
      await this.logOperation(userId, "design_suggestion", projectDescription.substring(0, 100), projectId)

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "design_suggestion",
          prompt: projectDescription,
          result: {
            suggestions: text,
            aspectToImprove,
            styleReference: styleReference || null,
          },
        },
      })

      return {
        id: generation.id,
        type: "design_suggestion" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error generating design suggestion:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to generate design suggestion", 500)
    }
  }

  /**
   * Apply style transfer to an image
   */
  static async applyStyleTransfer(
    userId: string,
    sourceImageUrl: string,
    styleDescription: string,
    projectId?: string,
    options?: {
      intensity?: number
      temperature?: number
    },
  ): Promise<AIGenerationResult> {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits
      await this.checkRateLimit(userId, "style_transfer")

      // Input validation
      if (!sourceImageUrl) {
        throw new AIServiceError("Source image URL is required", 400)
      }
      if (!styleDescription.trim()) {
        throw new AIServiceError("Style description cannot be empty", 400)
      }

      const intensity = options?.intensity ?? 0.7
      const temperature = options?.temperature ?? 0.7

      // For now, we'll use DALL-E to generate an image in the style described
      // In a real implementation, you might use a specialized style transfer API

      const prompt = `Create an image in the following style: ${styleDescription}. 
        The image should be based on this description: A recreation of the source image with the new style applied.
        Apply the style with an intensity of ${Math.round(intensity * 100)}%.`

      // Log the operation for analytics
      await this.logOperation(userId, "style_transfer", prompt.substring(0, 100), projectId)

      // Call OpenAI API directly for image generation
      const response = await fetch("https://api.openai.com/v1/images/generations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "dall-e-3",
          prompt,
          n: 1,
          size: "1024x1024",
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new AIServiceError(error.error?.message || "Failed to apply style transfer", response.status, {
          response: error,
        })
      }

      const data = await response.json()
      const imageUrl = data.data[0].url

      // Save to database
      const generation = await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "style_transfer",
          prompt: styleDescription,
          result: {
            originalImageUrl: sourceImageUrl,
            styledImageUrl: imageUrl,
            styleDescription,
            intensity,
          },
        },
      })

      return {
        id: generation.id,
        type: "style_transfer" as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error applying style transfer:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to apply style transfer", 500)
    }
  }

  /**
   * Get user's AI generation history
   */
  static async getUserGenerations(
    userId: string,
    options?: {
      type?: AIGenerationType
      limit?: number
      offset?: number
      projectId?: string
    },
  ): Promise<AIGenerationResult[]> {
    try {
      // Input validation
      if (!userId) {
        throw new AIServiceError("User ID is required", 400)
      }

      const limit = options?.limit || 10
      const offset = options?.offset || 0

      // Validate pagination
      if (limit < 1 || limit > 100) {
        throw new AIServiceError("Limit must be between 1 and 100", 400)
      }
      if (offset < 0) {
        throw new AIServiceError("Offset must be non-negative", 400)
      }

      const generations = await prisma.aIGeneration.findMany({
        where: {
          userId,
          ...(options?.type ? { type: options.type } : {}),
          ...(options?.projectId ? { projectId: options.projectId } : {}),
        },
        orderBy: {
          createdAt: "desc",
        },
        take: limit,
        skip: offset,
      })

      return generations.map((generation) => ({
        id: generation.id,
        type: generation.type as AIGenerationType,
        prompt: generation.prompt,
        result: generation.result,
        createdAt: generation.createdAt,
      }))
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error fetching user generations:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to fetch user generations", 500)
    }
  }

  /**
   * Process batch AI generation requests
   */
  static async processBatchGeneration(
    userId: string,
    requests: Array<{
      type: AIGenerationType
      prompt: string
      options?: Record<string, any>
    }>,
    projectId?: string,
  ): Promise<
    Array<{
      type: AIGenerationType
      result?: AIGenerationResult
      error?: string
    }>
  > {
    try {
      // Validate environment
      this.validateEnvironment(["OPENAI_API_KEY"])

      // Check rate limits for batch operation
      await this.checkRateLimit(userId, "batch_generation")

      // Input validation
      if (!requests || !Array.isArray(requests) || requests.length === 0) {
        throw new AIServiceError("At least one request is required", 400)
      }

      if (requests.length > 10) {
        throw new AIServiceError("Maximum 10 requests allowed in batch mode", 400)
      }

      // Process each request
      const results = await Promise.all(
        requests.map(async ({ type, prompt, options }) => {
          try {
            switch (type) {
              case "text_generation":
                return {
                  type,
                  result: await this.generateText(userId, prompt, projectId, options?.systemPrompt, options),
                }

              case "image_generation":
                return {
                  type,
                  result: await this.generateImage(userId, prompt, projectId, options),
                }

              case "color_palette":
                return {
                  type,
                  result: await this.generateColorPalette(userId, prompt, projectId, options),
                }

              case "layout_suggestion":
                return {
                  type,
                  result: await this.generateLayoutSuggestion(userId, prompt, projectId, options),
                }

              case "animation_suggestion":
                return {
                  type,
                  result: await this.generateAnimationSuggestion(userId, prompt, projectId, options),
                }

              case "content_enhancement":
                return {
                  type,
                  result: await this.enhanceContent(userId, prompt, options?.contentType || "text", projectId, options),
                }

              case "style_transfer":
                if (!options?.sourceImageUrl) {
                  throw new AIServiceError("Source image URL is required for style transfer", 400)
                }
                return {
                  type,
                  result: await this.applyStyleTransfer(userId, options.sourceImageUrl, prompt, projectId, options),
                }

              case "design_suggestion":
                if (!projectId) {
                  throw new AIServiceError("Project ID is required for design suggestions", 400)
                }
                return {
                  type,
                  result: await this.generateDesignSuggestion(userId, projectId, options),
                }

              default:
                throw new AIServiceError(`Unsupported generation type: ${type}`, 400)
            }
          } catch (error) {
            return {
              type,
              error: error instanceof Error ? error.message : "Unknown error",
            }
          }
        }),
      )

      return results
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error
      }

      console.error("Error processing batch generation:", error)
      throw new AIServiceError(error instanceof Error ? error.message : "Failed to process batch generation", 500)
    }
  }
}

