import { prisma } from "@/lib/db"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"

export interface BrandStyle {
  colors: {
    primary: string
    secondary: string
    accent: string[]
    neutral: string[]
  }
  typography: {
    headingFont: string
    bodyFont: string
    fontPairings: string[]
  }
  imagery: {
    style: string
    filters: string[]
    composition: string
  }
  shapes: {
    primary: string
    decorative: string[]
  }
  spacing: {
    density: "compact" | "balanced" | "airy"
    rhythm: string
  }
  overall: {
    mood: string[]
    industry: string
    personality: string[]
  }
}

export interface ThemeTemplate {
  id: string
  name: string
  description: string
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    text: string
    surface: string
    error: string
    success: string
    warning: string
    info: string
  }
  typography: {
    headingFont: string
    bodyFont: string
    monoFont: string
    baseFontSize: string
    scaleRatio: number
  }
  spacing: {
    baseUnit: string
    scale: number[]
  }
  borderRadius: {
    small: string
    medium: string
    large: string
    pill: string
  }
  shadows: {
    small: string
    medium: string
    large: string
  }
  preview: string // URL to preview image
}

export interface StyleTransferResult {
  before: {
    colors: string[]
    typography: string[]
    spacing: string
    shapes: string[]
  }
  after: {
    colors: string[]
    typography: string[]
    spacing: string
    shapes: string[]
  }
  transformations: {
    type: string
    description: string
    elements: string[]
  }[]
  preview: string // URL to preview image
}

export interface MoodBoard {
  id: string
  name: string
  description: string
  colors: string[]
  typography: string[]
  imagery: string[]
  patterns: string[]
  textures: string[]
  inspirationImages: string[] // URLs
  keywords: string[]
  preview: string // URL to preview image
}

export interface DesignTrend {
  id: string
  name: string
  description: string
  year: number
  characteristics: string[]
  colors: string[]
  typography: string[]
  imagery: string
  examples: string[] // URLs
  preview: string // URL to preview image
}

export class AIStyleService {
  /**
   * Extract brand style from design elements or description
   */
  static async extractBrandStyle(
    userId: string,
    elements?: any[],
    description?: string,
    imageUrls?: string[],
    projectId?: string,
  ): Promise<BrandStyle> {
    try {
      const brandStyleSchema = z.object({
        colors: z.object({
          primary: z.string(),
          secondary: z.string(),
          accent: z.array(z.string()),
          neutral: z.array(z.string()),
        }),
        typography: z.object({
          headingFont: z.string(),
          bodyFont: z.string(),
          fontPairings: z.array(z.string()),
        }),
        imagery: z.object({
          style: z.string(),
          filters: z.array(z.string()),
          composition: z.string(),
        }),
        shapes: z.object({
          primary: z.string(),
          decorative: z.array(z.string()),
        }),
        spacing: z.object({
          density: z.enum(["compact", "balanced", "airy"]),
          rhythm: z.string(),
        }),
        overall: z.object({
          mood: z.array(z.string()),
          industry: z.string(),
          personality: z.array(z.string()),
        }),
      })

      const systemPrompt =
        "You are an expert brand designer. " +
        "Extract a comprehensive brand style from the provided design elements, description, or images. " +
        "Analyze colors, typography, imagery style, shapes, spacing, and overall mood. " +
        "Provide specific, actionable information that can be used to create a consistent brand style guide."

      let promptText = "Extract brand style from the following"
      if (elements && elements.length > 0) promptText += ` design elements: ${JSON.stringify(elements)}`
      if (description) promptText += ` description: ${description}`
      if (imageUrls && imageUrls.length > 0) promptText += ` images: ${imageUrls.join(", ")}`

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: promptText,
        system: systemPrompt,
      })

      // Parse the brand style from the response
      let brandStyle: BrandStyle
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          brandStyle = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          brandStyle = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing brand style:", e)
        throw new Error("Failed to parse brand style")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "brand_style",
          prompt: promptText,
          result: brandStyle,
        },
      })

      return brandStyle
    } catch (error) {
      console.error("Error extracting brand style:", error)
      throw new Error("Failed to extract brand style")
    }
  }

  /**
   * Generate a theme from an image
   */
  static async generateThemeFromImage(
    userId: string,
    imageUrl: string,
    themeName?: string,
    stylePreference?: string,
    projectId?: string,
  ): Promise<ThemeTemplate> {
    try {
      const themeSchema = z.object({
        id: z.string(),
        name: z.string(),
        description: z.string(),
        colors: z.object({
          primary: z.string(),
          secondary: z.string(),
          accent: z.string(),
          background: z.string(),
          text: z.string(),
          surface: z.string(),
          error: z.string(),
          success: z.string(),
          warning: z.string(),
          info: z.string(),
        }),
        typography: z.object({
          headingFont: z.string(),
          bodyFont: z.string(),
          monoFont: z.string(),
          baseFontSize: z.string(),
          scaleRatio: z.number(),
        }),
        spacing: z.object({
          baseUnit: z.string(),
          scale: z.array(z.number()),
        }),
        borderRadius: z.object({
          small: z.string(),
          medium: z.string(),
          large: z.string(),
          pill: z.string(),
        }),
        shadows: z.object({
          small: z.string(),
          medium: z.string(),
          large: z.string(),
        }),
        preview: z.string(),
      })

      const systemPrompt =
        "You are an expert design system creator. " +
        "Generate a complete theme based on the provided image URL. " +
        "Extract colors, typography, spacing, border radius, and shadows that match the image's style. " +
        "Create a cohesive design system that can be applied to a web or mobile application."

      let promptText = `Generate a theme based on this image: ${imageUrl}`
      if (themeName) promptText += ` Theme name: ${themeName}`
      if (stylePreference) promptText += ` Style preference: ${stylePreference}`

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: promptText,
        system: systemPrompt,
      })

      // Parse the theme from the response
      let theme: ThemeTemplate
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          theme = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          theme = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing theme:", e)
        throw new Error("Failed to parse theme")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "theme_from_image",
          prompt: promptText,
          result: theme,
        },
      })

      return theme
    } catch (error) {
      console.error("Error generating theme from image:", error)
      throw new Error("Failed to generate theme from image")
    }
  }

  /**
   * Transfer style between designs
   */
  static async transferStyle(
    userId: string,
    sourceElements: any[],
    targetElements: any[],
    styleAspects?: string[],
    projectId?: string,
  ): Promise<StyleTransferResult> {
    try {
      const styleTransferSchema = z.object({
        before: z.object({
          colors: z.array(z.string()),
          typography: z.array(z.string()),
          spacing: z.string(),
          shapes: z.array(z.string()),
        }),
        after: z.object({
          colors: z.array(z.string()),
          typography: z.array(z.string()),
          spacing: z.string(),
          shapes: z.array(z.string()),
        }),
        transformations: z.array(
          z.object({
            type: z.string(),
            description: z.string(),
            elements: z.array(z.string()),
          }),
        ),
        preview: z.string(),
      })

      const systemPrompt =
        "You are an expert style transfer specialist. " +
        "Transfer the style from the source design to the target design. " +
        "Consider colors, typography, spacing, and shapes. " +
        "Provide specific transformations that should be applied to the target design."

      let promptText = "Transfer style from source design to target design."
      promptText += ` Source: ${JSON.stringify(sourceElements)}`
      promptText += ` Target: ${JSON.stringify(targetElements)}`
      if (styleAspects && styleAspects.length > 0) {
        promptText += ` Focus on these style aspects: ${styleAspects.join(", ")}`
      }

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: promptText,
        system: systemPrompt,
      })

      // Parse the style transfer result from the response
      let styleTransfer: StyleTransferResult
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          styleTransfer = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          styleTransfer = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing style transfer result:", e)
        throw new Error("Failed to parse style transfer result")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "style_transfer",
          prompt: promptText,
          result: styleTransfer,
        },
      })

      return styleTransfer
    } catch (error) {
      console.error("Error transferring style:", error)
      throw new Error("Failed to transfer style")
    }
  }

  /**
   * Generate a mood-based design
   */
  static async generateMoodBoard(
    userId: string,
    mood: string,
    industry?: string,
    additionalKeywords?: string[],
    projectId?: string,
  ): Promise<MoodBoard> {
    try {
      const moodBoardSchema = z.object({
        id: z.string(),
        name: z.string(),
        description: z.string(),
        colors: z.array(z.string()),
        typography: z.array(z.string()),
        imagery: z.array(z.string()),
        patterns: z.array(z.string()),
        textures: z.array(z.string()),
        inspirationImages: z.array(z.string()),
        keywords: z.array(z.string()),
        preview: z.string(),
      })

      const systemPrompt =
        "You are an expert mood board creator. " +
        "Generate a comprehensive mood board based on the provided mood, industry, and keywords. " +
        "Include colors, typography, imagery styles, patterns, textures, and inspiration. " +
        "Create a cohesive mood board that can inspire a design project."

      let promptText = `Generate a mood board for the mood: ${mood}`
      if (industry) promptText += ` in the ${industry} industry`
      if (additionalKeywords && additionalKeywords.length > 0) {
        promptText += ` with these additional keywords: ${additionalKeywords.join(", ")}`
      }

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: promptText,
        system: systemPrompt,
      })

      // Parse the mood board from the response
      let moodBoard: MoodBoard
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          moodBoard = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          moodBoard = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing mood board:", e)
        throw new Error("Failed to parse mood board")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "mood_board",
          prompt: promptText,
          result: moodBoard,
        },
      })

      return moodBoard
    } catch (error) {
      console.error("Error generating mood board:", error)
      throw new Error("Failed to generate mood board")
    }
  }

  /**
   * Apply design trend to a design
   */
  static async applyDesignTrend(
    userId: string,
    elements: any[],
    trendName: string,
    adaptationLevel?: "subtle" | "moderate" | "full",
    projectId?: string,
  ): Promise<{
    trend: DesignTrend
    transformations: {
      elementId: string
      property: string
      before: any
      after: any
      reason: string
    }[]
    preview: string
  }> {
    try {
      const trendApplicationSchema = z.object({
        trend: z.object({
          id: z.string(),
          name: z.string(),
          description: z.string(),
          year: z.number(),
          characteristics: z.array(z.string()),
          colors: z.array(z.string()),
          typography: z.array(z.string()),
          imagery: z.string(),
          examples: z.array(z.string()),
          preview: z.string(),
        }),
        transformations: z.array(
          z.object({
            elementId: z.string(),
            property: z.string(),
            before: z.any(),
            after: z.any(),
            reason: z.string(),
          }),
        ),
        preview: z.string(),
      })

      const systemPrompt =
        "You are an expert design trend specialist. " +
        "Apply the specified design trend to the provided design elements. " +
        "Consider colors, typography, imagery, and overall style. " +
        "Provide specific transformations that should be applied to each element."

      let promptText = `Apply the ${trendName} design trend to these elements: ${JSON.stringify(elements)}`
      if (adaptationLevel) promptText += ` with a ${adaptationLevel} adaptation level`

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: promptText,
        system: systemPrompt,
      })

      // Parse the trend application result from the response
      let trendApplication: {
        trend: DesignTrend
        transformations: {
          elementId: string
          property: string
          before: any
          after: any
          reason: string
        }[]
        preview: string
      }
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          trendApplication = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          trendApplication = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing trend application result:", e)
        throw new Error("Failed to parse trend application result")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "trend_application",
          prompt: promptText,
          result: trendApplication,
        },
      })

      return trendApplication
    } catch (error) {
      console.error("Error applying design trend:", error)
      throw new Error("Failed to apply design trend")
    }
  }

  /**
   * Get design trend information
   */
  static async getDesignTrend(
    userId: string,
    trendName: string,
    year?: number,
    projectId?: string,
  ): Promise<DesignTrend> {
    try {
      const designTrendSchema = z.object({
        id: z.string(),
        name: z.string(),
        description: z.string(),
        year: z.number(),
        characteristics: z.array(z.string()),
        colors: z.array(z.string()),
        typography: z.array(z.string()),
        imagery: z.string(),
        examples: z.array(z.string()),
        preview: z.string(),
      })

      const systemPrompt =
        "You are an expert design historian. " +
        "Provide comprehensive information about the specified design trend. " +
        "Include its characteristics, typical colors, typography, imagery style, and examples. " +
        "Provide accurate and detailed information that can be used to apply this trend to designs."

      let promptText = `Provide information about the ${trendName} design trend`
      if (year) promptText += ` from ${year}`

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: promptText,
        system: systemPrompt,
      })

      // Parse the design trend from the response
      let designTrend: DesignTrend
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          designTrend = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          designTrend = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing design trend:", e)
        throw new Error("Failed to parse design trend")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "design_trend",
          prompt: promptText,
          result: designTrend,
        },
      })

      return designTrend
    } catch (error) {
      console.error("Error getting design trend:", error)
      throw new Error("Failed to get design trend")
    }
  }
}

