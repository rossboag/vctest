import { aiServiceClient } from "./ai-service-client"

export const aiHelper = {
  async generateLayoutSuggestion(elements: any[], prompt = "", creativity = 0.7) {
    return aiServiceClient.generateLayout(elements, prompt, creativity)
  },

  async enhanceDesign(elements: any[], prompt = "", creativity = 0.7) {
    return aiServiceClient.enhanceDesign(elements, prompt, creativity)
  },

  async analyzeDesign(elements: any[]) {
    return aiServiceClient.analyzeDesign(elements)
  },

  async getAssistantSuggestion(elements: any[], prompt = "") {
    return aiServiceClient.getAssistantSuggestion(elements, prompt)
  },

  async chat(prompt: string) {
    return aiServiceClient.chat(prompt)
  },

  async generateAccessibilityReport(elements: any[]) {
    return aiServiceClient.generateAccessibilityReport(elements)
  },

  async generateDesignVariations(elements: any[]) {
    return aiServiceClient.generateDesignVariations(elements)
  },
}

