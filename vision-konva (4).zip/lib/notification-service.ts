import { prisma } from "@/lib/db"
import type { Notification } from "@prisma/client"

// Types for notification creation
export interface CreateNotificationParams {
  userId: string
  senderId?: string
  type: string
  title: string
  message: string
  link?: string
  metadata?: Record<string, any>
  expiresAt?: Date
}

// Types for notification templates
export interface NotificationTemplateParams {
  [key: string]: any
}

export class NotificationService {
  /**
   * Create a new notification
   */
  static async createNotification(params: CreateNotificationParams): Promise<Notification> {
    return prisma.notification.create({
      data: {
        userId: params.userId,
        senderId: params.senderId,
        type: params.type,
        title: params.title,
        message: params.message,
        link: params.link,
        metadata: params.metadata || {},
        expiresAt: params.expiresAt,
      },
    })
  }

  /**
   * Create notifications for multiple users
   */
  static async createNotificationForUsers(
    userIds: string[],
    params: Omit<CreateNotificationParams, "userId">,
  ): Promise<Notification[]> {
    const notifications = await Promise.all(
      userIds.map((userId) =>
        this.createNotification({
          ...params,
          userId,
        }),
      ),
    )
    return notifications
  }

  /**
   * Get notifications for a user
   */
  static async getUserNotifications(
    userId: string,
    options: {
      limit?: number
      offset?: number
      includeRead?: boolean
      types?: string[]
    } = {},
  ): Promise<Notification[]> {
    const { limit = 20, offset = 0, includeRead = false, types } = options

    const where: any = {
      userId,
    }

    if (!includeRead) {
      where.isRead = false
    }

    if (types && types.length > 0) {
      where.type = {
        in: types,
      }
    }

    return prisma.notification.findMany({
      where,
      orderBy: {
        createdAt: "desc",
      },
      take: limit,
      skip: offset,
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            image: true,
          },
        },
      },
    })
  }

  /**
   * Mark a notification as read
   */
  static async markAsRead(id: string): Promise<Notification> {
    return prisma.notification.update({
      where: { id },
      data: { isRead: true },
    })
  }

  /**
   * Mark all notifications as read for a user
   */
  static async markAllAsRead(userId: string): Promise<{ count: number }> {
    const result = await prisma.notification.updateMany({
      where: {
        userId,
        isRead: false,
      },
      data: {
        isRead: true,
      },
    })

    return { count: result.count }
  }

  /**
   * Delete a notification
   */
  static async deleteNotification(id: string): Promise<Notification> {
    return prisma.notification.delete({
      where: { id },
    })
  }

  /**
   * Delete all notifications for a user
   */
  static async deleteAllNotifications(userId: string): Promise<{ count: number }> {
    const result = await prisma.notification.deleteMany({
      where: {
        userId,
      },
    })

    return { count: result.count }
  }

  /**
   * Get unread notification count for a user
   */
  static async getUnreadCount(userId: string): Promise<number> {
    return prisma.notification.count({
      where: {
        userId,
        isRead: false,
      },
    })
  }

  /**
   * Create a notification from a template
   */
  static async createFromTemplate(
    type: string,
    userId: string,
    params: NotificationTemplateParams,
    options: {
      senderId?: string
      link?: string
      metadata?: Record<string, any>
      expiresAt?: Date
    } = {},
  ): Promise<Notification | null> {
    // Get the template
    const template = await prisma.notificationTemplate.findUnique({
      where: { type },
    })

    if (!template) {
      console.error(`Notification template not found: ${type}`)
      return null
    }

    // Replace placeholders in the template
    let title = template.title
    let message = template.message

    // Replace all {{key}} with the corresponding value from params
    Object.entries(params).forEach(([key, value]) => {
      title = title.replace(new RegExp(`{{${key}}}`, "g"), String(value))
      message = message.replace(new RegExp(`{{${key}}}`, "g"), String(value))
    })

    // Create the notification
    return this.createNotification({
      userId,
      senderId: options.senderId,
      type,
      title,
      message,
      link: options.link,
      metadata: options.metadata,
      expiresAt: options.expiresAt,
    })
  }

  /**
   * Get user notification preferences
   */
  static async getUserPreferences(userId: string) {
    // Get or create user preferences
    let preferences = await prisma.notificationPreference.findUnique({
      where: { userId },
    })

    if (!preferences) {
      preferences = await prisma.notificationPreference.create({
        data: { userId },
      })
    }

    return preferences
  }

  /**
   * Update user notification preferences
   */
  static async updateUserPreferences(
    userId: string,
    data: {
      email?: boolean
      push?: boolean
      inApp?: boolean
    },
  ) {
    // Get or create user preferences
    const preferences = await this.getUserPreferences(userId)

    // Update preferences
    return prisma.notificationPreference.update({
      where: { id: preferences.id },
      data,
    })
  }
}

