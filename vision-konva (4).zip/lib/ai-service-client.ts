import OpenAI from "openai"

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export class AIServiceClient {
  // Generate layout based on elements and prompt
  async generateLayout(elements: any[], prompt: string, creativity = 0.7) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional graphic designer specializing in layout design." },
          {
            role: "user",
            content: `Generate a layout suggestion based on these elements: ${JSON.stringify(
              elements,
            )}. User prompt: ${prompt}. Creativity level: ${creativity}`,
          },
        ],
        temperature: creativity,
      })

      let result
      try {
        result = JSON.parse(response.choices[0].message.content || "[]")
      } catch (e) {
        console.error("Error parsing AI response:", e)
        result = elements || []
      }

      return result
    } catch (error) {
      console.error("Error in generateLayout:", error)
      return elements || []
    }
  }

  // Enhance design based on elements and prompt
  async enhanceDesign(elements: any[], prompt: string, creativity = 0.7) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional graphic designer specializing in design enhancement." },
          {
            role: "user",
            content: `Enhance this design based on these elements: ${JSON.stringify(
              elements,
            )}. User prompt: ${prompt}. Creativity level: ${creativity}`,
          },
        ],
        temperature: creativity,
      })

      let result
      try {
        result = JSON.parse(response.choices[0].message.content || "[]")
      } catch (e) {
        console.error("Error parsing AI response:", e)
        result = elements || []
      }

      return result
    } catch (error) {
      console.error("Error in enhanceDesign:", error)
      return elements || []
    }
  }

  // Analyze design and provide feedback
  async analyzeDesign(elements: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional graphic designer specializing in design analysis." },
          {
            role: "user",
            content: `Analyze this design and provide feedback: ${JSON.stringify(elements)}`,
          },
        ],
      })

      return response.choices[0].message.content || "Unable to analyze design at this time."
    } catch (error) {
      console.error("Error in analyzeDesign:", error)
      return "Unable to analyze design at this time."
    }
  }

  // Get assistant suggestion based on elements and prompt
  async getAssistantSuggestion(elements: any[], prompt: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional graphic design assistant." },
          {
            role: "user",
            content: `Provide design suggestions for these elements: ${JSON.stringify(
              elements,
            )}. User prompt: ${prompt}`,
          },
        ],
      })

      return response.choices[0].message.content || "Unable to provide suggestions at this time."
    } catch (error) {
      console.error("Error in getAssistantSuggestion:", error)
      return "Unable to provide suggestions at this time."
    }
  }

  // Chat with AI
  async chat(prompt: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional graphic design assistant." },
          { role: "user", content: prompt },
        ],
      })

      return response.choices[0].message.content || "I'm sorry, I couldn't process your request at this time."
    } catch (error) {
      console.error("Error in chat:", error)
      return "I'm sorry, I couldn't process your request at this time."
    }
  }

  // Generate color scheme based on elements and prompt
  async colorize(elements: any[], prompt: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional color designer." },
          {
            role: "user",
            content: `Generate a color scheme for these elements: ${JSON.stringify(
              elements,
            )}. User prompt: ${prompt}. Return a JSON object with primary, secondary, accent, background, and text colors.`,
          },
        ],
      })

      let result
      try {
        result = JSON.parse(response.choices[0].message.content || "{}")
      } catch (e) {
        console.error("Error parsing AI response:", e)
        result = {
          primary: "#3B82F6",
          secondary: "#10B981",
          accent: "#F59E0B",
          background: "#F3F4F6",
          text: "#1F2937",
        }
      }

      return result
    } catch (error) {
      console.error("Error in colorize:", error)
      return {
        primary: "#3B82F6",
        secondary: "#10B981",
        accent: "#F59E0B",
        background: "#F3F4F6",
        text: "#1F2937",
      }
    }
  }

  // Generate accessibility report
  async generateAccessibilityReport(elements: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional accessibility expert." },
          {
            role: "user",
            content: `Generate an accessibility report for these elements: ${JSON.stringify(elements)}`,
          },
        ],
      })

      return response.choices[0].message.content || "Unable to generate accessibility report at this time."
    } catch (error) {
      console.error("Error in generateAccessibilityReport:", error)
      return "Unable to generate accessibility report at this time."
    }
  }

  // Generate design variations
  async generateDesignVariations(elements: any[]) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional graphic designer specializing in design variations." },
          {
            role: "user",
            content: `Generate design variations for these elements: ${JSON.stringify(elements)}`,
          },
        ],
      })

      let result
      try {
        result = JSON.parse(response.choices[0].message.content || "[]")
      } catch (e) {
        console.error("Error parsing AI response:", e)
        result = elements || []
      }

      return result
    } catch (error) {
      console.error("Error in generateDesignVariations:", error)
      return elements || []
    }
  }

  // Generate content based on prompt and options
  async generateContent(
    prompt: string,
    options: {
      type: "text" | "image" | "video" | "layout" | "animation"
      style?: string
      length?: number
      imageSize?: "256x256" | "512x512" | "1024x1024"
      videoDuration?: number
      videoOrientation?: "landscape" | "portrait" | "square"
      animationDuration?: number
      animationType?: string
      animationDirections?: string[]
      elements?: any[]
    },
  ) {
    try {
      switch (options.type) {
        case "text":
          return this.generateText(prompt, options.length, options.style)
        case "image":
          return this.generateImage(prompt, options.imageSize, options.style)
        case "video":
          return this.generateVideo(prompt, options.videoDuration, options.style)
        case "layout":
          return this.generateLayout(options.elements || [], prompt, 0.7)
        case "animation":
          return this.generateAnimation(options.elements || [], prompt, options.animationDuration, options.style)
        default:
          return null
      }
    } catch (error) {
      console.error(`Error generating ${options.type} content:`, error)

      // Return appropriate fallback based on content type
      switch (options.type) {
        case "text":
          return "Sample text content (AI generation failed)"
        case "image":
          return "/placeholder.svg?height=512&width=512"
        case "video":
          return "/placeholder-video.mp4"
        case "layout":
        case "animation":
          return []
        default:
          return null
      }
    }
  }

  // Generate text based on prompt
  async generateText(prompt: string, length = 100, style?: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional copywriter." },
          {
            role: "user",
            content: `Generate text based on this prompt: ${prompt}. Length: approximately ${length} characters. ${
              style ? `Style: ${style}.` : ""
            }`,
          },
        ],
      })

      return response.choices[0].message.content || "Sample text content (AI generation failed)"
    } catch (error) {
      console.error("Error in generateText:", error)
      return "Sample text content (AI generation failed)"
    }
  }

  // Generate image based on prompt
  async generateImage(prompt: string, size: "256x256" | "512x512" | "1024x1024" = "512x512", style?: string) {
    try {
      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: `${prompt}${style ? ` Style: ${style}` : ""}`,
        n: 1,
        size: size,
      })

      return response.data[0].url || "/placeholder.svg?height=512&width=512"
    } catch (error) {
      console.error("Error in generateImage:", error)
      return "/placeholder.svg?height=512&width=512"
    }
  }

  // Generate animation based on elements and prompt
  async generateAnimation(elements: any[] = [], prompt: string, duration = 5, style?: string) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a professional animation designer." },
          {
            role: "user",
            content: `Generate animation keyframes for these elements: ${JSON.stringify(
              elements,
            )}. User prompt: ${prompt}. Duration: ${duration} seconds. ${style ? `Style: ${style}.` : ""}`,
          },
        ],
      })

      let result
      try {
        result = JSON.parse(response.choices[0].message.content || "[]")
      } catch (e) {
        console.error("Error parsing AI response:", e)
        result = elements || []
      }

      return result
    } catch (error) {
      console.error("Error in generateAnimation:", error)
      return elements || []
    }
  }

  // Generate video based on prompt
  async generateVideo(prompt: string, duration = 5, style?: string) {
    // This is a placeholder as OpenAI doesn't have a direct video generation API yet
    // In a real implementation, you might use a different service or a more complex workflow
    console.log(`Video generation requested: ${prompt}, duration: ${duration}, style: ${style}`)
    return "/placeholder-video.mp4"
  }
}

// Export a singleton instance
export const aiServiceClient = new AIServiceClient()

