import { prisma } from "@/lib/db"

export interface LoggedRequest {
  method: string
  path: string
  userId?: string
  userRole?: string
  statusCode: number
  responseTime: number
  ipAddress?: string
  userAgent?: string
  errorDetails?: any
  requestBody?: any
  responseBody?: any
  rateLimitKey?: string
}

export class RequestLogger {
  /**
   * Log an API request for analytics and monitoring
   */
  static async logRequest(data: LoggedRequest): Promise<void> {
    try {
      // Skip logging for certain paths (health checks, etc.)
      if (data.path.includes("/api/health") || data.path.includes("/api/ping") || data.path.includes("/_next")) {
        return
      }

      // Don't log health check status
      if (data.path === "/api/health" && data.statusCode === 200) {
        return
      }

      // Don't log sensitive fields
      const sanitizedRequestBody = data.requestBody ? this.sanitizeData(data.requestBody) : undefined
      const sanitizedResponseBody = data.responseBody ? this.sanitizeData(data.responseBody) : undefined
      const sanitizedErrorDetails = data.errorDetails ? this.sanitizeData(data.errorDetails) : undefined

      // Log to database
      await prisma.apiRequestLog.create({
        data: {
          method: data.method,
          path: data.path,
          userId: data.userId,
          userRole: data.userRole,
          statusCode: data.statusCode,
          responseTimeMs: data.responseTime,
          ipAddress: data.ipAddress,
          userAgent: data.userAgent,
          errorDetails: sanitizedErrorDetails,
          requestBody: sanitizedRequestBody,
          responseBody: sanitizedResponseBody,
          rateLimitKey: data.rateLimitKey,
          timestamp: new Date(),
        },
      })

      // Log failed requests to console for immediate visibility
      if (data.statusCode >= 400) {
        console.warn(`Failed request: ${data.method} ${data.path} [${data.statusCode}]`)

        if (data.statusCode >= 500) {
          console.error(`  Error details:`, sanitizedErrorDetails)
        }
      }

      // Log slow requests
      if (data.responseTime > 1000) {
        console.warn(`Slow request: ${data.method} ${data.path} [${data.responseTime}ms]`)
      }
    } catch (error) {
      console.error("Error logging API request:", error)
    }
  }

  /**
   * Remove sensitive data from logs
   */
  private static sanitizeData(data: any): any {
    if (!data) return data

    // Create a deep copy to avoid modifying the original
    const sanitized = structuredClone(data)

    // List of sensitive fields to redact
    const sensitiveFields = [
      "password",
      "token",
      "secret",
      "key",
      "authorization",
      "auth",
      "apiKey",
      "api_key",
      "accessToken",
      "access_token",
      "refreshToken",
      "refresh_token",
      "sessionId",
      "session_id",
      "cookie",
      "jwt",
    ]

    // Recursive function to redact sensitive fields
    const redact = (obj: any) => {
      if (typeof obj !== "object" || obj === null) return

      for (const key in obj) {
        const lowerKey = key.toLowerCase()

        // Redact sensitive field
        if (sensitiveFields.some((field) => lowerKey.includes(field))) {
          obj[key] = "[REDACTED]"
        }
        // Redact email addresses
        else if (typeof obj[key] === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(obj[key])) {
          obj[key] = "[EMAIL REDACTED]"
        }
        // Recursively process nested objects
        else if (typeof obj[key] === "object" && obj[key] !== null) {
          redact(obj[key])
        }
      }
    }

    redact(sanitized)
    return sanitized
  }

  /**
   * Log an API error for monitoring
   */
  static async logError(error: Error, request: any, response?: any): Promise<void> {
    try {
      // Sanitize data for logging
      const sanitizedRequest = this.sanitizeData(request)
      const sanitizedResponse = response ? this.sanitizeData(response) : undefined

      await prisma.errorLog.create({
        data: {
          message: error.message,
          name: error.name,
          stack: error.stack,
          requestDetails: sanitizedRequest,
          responseDetails: sanitizedResponse,
          timestamp: new Date(),
          path: request.url || request.path,
          method: request.method,
          userId: request.user?.id || request.userId,
        },
      })

      // Extract status code for severity determination
      let statusCode = 500
      if (response && typeof response.status === "number") {
        statusCode = response.status
      } else if (response && typeof response.statusCode === "number") {
        statusCode = response.statusCode
      }

      // Determine logging level based on severity
      if (statusCode >= 500) {
        console.error(`CRITICAL ERROR [${statusCode}]:`, {
          path: request.url || request.path,
          method: request.method,
          message: error.message,
          name: error.name,
        })
      } else {
        console.warn(`Error [${statusCode}]:`, {
          path: request.url || request.path,
          method: request.method,
          message: error.message,
        })
      }
    } catch (logError) {
      console.error("Error logging API error:", logError)
    }
  }

  /**
   * Track failed login attempts for rate limiting
   */
  static async trackFailedLogin(ipAddress: string, email?: string): Promise<void> {
    try {
      if (!ipAddress) return

      // Track in Redis if available
      const redis = globalThis.redis
      if (redis) {
        // Increment failed attempts count
        const ipKey = `auth:fails:${ipAddress}`
        const count = await redis.incr(ipKey)

        // Set expiration if it's a new key
        if (count === 1) {
          await redis.expire(ipKey, 60 * 60) // 1 hour expiration
        }

        // Add to blocklist if too many failures
        if (count >= 10) {
          await redis.set(`blocklist:ip:${ipAddress}`, "1", { ex: 60 * 60 * 24 }) // 24 hour block
          console.warn(`IP ${ipAddress} blocked due to too many failed login attempts`)
        }

        // Track email if provided
        if (email) {
          const emailKey = `auth:fails:email:${email}`
          const emailCount = await redis.incr(emailKey)

          if (emailCount === 1) {
            await redis.expire(emailKey, 60 * 60 * 24) // 24 hour expiration
          }
        }
      }

      // Log to database
      await prisma.securityEvent.create({
        data: {
          type: "FAILED_LOGIN",
          ipAddress,
          details: {
            email: email ? "[REDACTED_EMAIL]" : undefined,
            timestamp: new Date().toISOString(),
          },
          timestamp: new Date(),
        },
      })
    } catch (error) {
      console.error("Error tracking failed login:", error)
    }
  }

  /**
   * Track successful login for security analysis
   */
  static async trackSuccessfulLogin(userId: string, ipAddress: string): Promise<void> {
    try {
      // Log to database
      await prisma.securityEvent.create({
        data: {
          type: "SUCCESSFUL_LOGIN",
          userId,
          ipAddress,
          timestamp: new Date(),
        },
      })

      // Reset failed attempts count if using Redis
      const redis = globalThis.redis
      if (redis && ipAddress) {
        await redis.del(`auth:fails:${ipAddress}`)

        // Remove from blocklist if present
        await redis.del(`blocklist:ip:${ipAddress}`)
      }
    } catch (error) {
      console.error("Error tracking successful login:", error)
    }
  }

  /**
   * Track security relevant events
   */
  static async trackSecurityEvent(type: string, details: any, userId?: string, ipAddress?: string): Promise<void> {
    try {
      // Sanitize sensitive data
      const sanitizedDetails = this.sanitizeData(details)

      // Log to database
      await prisma.securityEvent.create({
        data: {
          type,
          userId,
          ipAddress,
          details: sanitizedDetails,
          timestamp: new Date(),
        },
      })

      // Log critical security events
      const criticalEvents = [
        "PERMISSION_ESCALATION_ATTEMPT",
        "ADMIN_ACTION",
        "API_KEY_CREATED",
        "API_KEY_REVOKED",
        "SUSPICIOUS_ACTIVITY",
        "RATE_LIMIT_EXCEEDED",
        "CONTENT_POLICY_VIOLATION",
      ]

      if (criticalEvents.includes(type)) {
        console.warn(`SECURITY EVENT [${type}]:`, {
          userId,
          ipAddress,
          details: sanitizedDetails,
        })
      }
    } catch (error) {
      console.error("Error tracking security event:", error)
    }
  }
}

