import { prisma } from "@/lib/db"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export interface AnimationPreset {
  id: string
  name: string
  description: string
  category: string
  keyframes: AnimationKeyframe[]
  duration: number
  easing: string
  tags: string[]
}

export interface AnimationKeyframe {
  time: number // Time in seconds
  properties: {
    [key: string]: any // Properties like x, y, scale, rotation, opacity, etc.
  }
}

export interface ElementAnimationConfig {
  elementId: string
  presetId?: string
  customKeyframes?: AnimationKeyframe[]
  startTime: number
  duration: number
  easing: string
  loop?: boolean
  yoyo?: boolean
  delay?: number
}

export class AIAnimationService {
  /**
   * Generate animation keyframes for an element based on a description
   */
  static async generateAnimationKeyframes(
    userId: string,
    prompt: string,
    elementType: string,
    duration = 2,
    projectId?: string,
  ): Promise<AnimationKeyframe[]> {
    try {
      const systemPrompt =
        "You are an animation expert for a motion graphics tool. " +
        `Generate animation keyframes for a ${elementType} element with a duration of ${duration} seconds. ` +
        "Return a JSON array of keyframes, each with a time (in seconds), " +
        "and properties like x, y, scaleX, scaleY, rotation, opacity, etc. " +
        "Only respond with the JSON array, nothing else. " +
        "Make sure the animation is smooth and professional. " +
        "Start with time: 0 for the initial state and end with time: " +
        duration +
        " for the final state."

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt,
        system: systemPrompt,
      })

      // Parse the keyframes from the response
      let keyframes: AnimationKeyframe[] = []
      try {
        // Extract JSON array if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\[(.*)\]/s)
        if (jsonMatch) {
          keyframes = JSON.parse(`[${jsonMatch[1]}]`)
        } else {
          keyframes = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing keyframes:", e)
        throw new Error("Failed to parse animation keyframes")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "animation_keyframes",
          prompt,
          result: {
            keyframes,
            elementType,
            duration,
          },
        },
      })

      return keyframes
    } catch (error) {
      console.error("Error generating animation keyframes:", error)
      throw new Error("Failed to generate animation keyframes")
    }
  }

  /**
   * Generate an animation preset based on a description
   */
  static async generateAnimationPreset(
    userId: string,
    name: string,
    description: string,
    category: string,
    duration = 2,
    projectId?: string,
  ): Promise<AnimationPreset> {
    try {
      const systemPrompt =
        "You are an animation expert for a motion graphics tool. " +
        `Generate an animation preset named "${name}" in the category "${category}" with a duration of ${duration} seconds. ` +
        "The animation should match this description: " +
        description +
        ". " +
        "Return a JSON object with keyframes (array), easing (string), and tags (array of strings). " +
        "Each keyframe should have time (in seconds) and properties (object with x, y, scaleX, scaleY, rotation, opacity, etc.). " +
        "Only respond with the JSON object, nothing else."

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Create an animation preset for: ${description}`,
        system: systemPrompt,
      })

      // Parse the preset from the response
      let presetData: any = {}
      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          presetData = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          presetData = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing preset:", e)
        throw new Error("Failed to parse animation preset")
      }

      // Create the preset in the database
      const preset = await prisma.animationPreset.create({
        data: {
          name,
          description,
          category,
          keyframes: presetData.keyframes || [],
          duration,
          easing: presetData.easing || "easeInOut",
          tags: presetData.tags || [],
          userId,
        },
      })

      return {
        id: preset.id,
        name: preset.name,
        description: preset.description,
        category: preset.category,
        keyframes: preset.keyframes as AnimationKeyframe[],
        duration: preset.duration,
        easing: preset.easing,
        tags: preset.tags as string[],
      }
    } catch (error) {
      console.error("Error generating animation preset:", error)
      throw new Error("Failed to generate animation preset")
    }
  }

  /**
   * Get animation presets by category
   */
  static async getPresetsByCategory(category?: string, limit = 20, offset = 0): Promise<AnimationPreset[]> {
    try {
      const presets = await prisma.animationPreset.findMany({
        where: category ? { category } : undefined,
        orderBy: { createdAt: "desc" },
        take: limit,
        skip: offset,
      })

      return presets.map((preset) => ({
        id: preset.id,
        name: preset.name,
        description: preset.description,
        category: preset.category,
        keyframes: preset.keyframes as AnimationKeyframe[],
        duration: preset.duration,
        easing: preset.easing,
        tags: preset.tags as string[],
      }))
    } catch (error) {
      console.error("Error fetching animation presets:", error)
      throw new Error("Failed to fetch animation presets")
    }
  }

  /**
   * Get animation preset by ID
   */
  static async getPresetById(id: string): Promise<AnimationPreset | null> {
    try {
      const preset = await prisma.animationPreset.findUnique({
        where: { id },
      })

      if (!preset) return null

      return {
        id: preset.id,
        name: preset.name,
        description: preset.description,
        category: preset.category,
        keyframes: preset.keyframes as AnimationKeyframe[],
        duration: preset.duration,
        easing: preset.easing,
        tags: preset.tags as string[],
      }
    } catch (error) {
      console.error("Error fetching animation preset:", error)
      throw new Error("Failed to fetch animation preset")
    }
  }

  /**
   * Search animation presets
   */
  static async searchPresets(query: string, limit = 20, offset = 0): Promise<AnimationPreset[]> {
    try {
      const presets = await prisma.animationPreset.findMany({
        where: {
          OR: [
            { name: { contains: query, mode: "insensitive" } },
            { description: { contains: query, mode: "insensitive" } },
            { category: { contains: query, mode: "insensitive" } },
            { tags: { has: query } },
          ],
        },
        orderBy: { createdAt: "desc" },
        take: limit,
        skip: offset,
      })

      return presets.map((preset) => ({
        id: preset.id,
        name: preset.name,
        description: preset.description,
        category: preset.category,
        keyframes: preset.keyframes as AnimationKeyframe[],
        duration: preset.duration,
        easing: preset.easing,
        tags: preset.tags as string[],
      }))
    } catch (error) {
      console.error("Error searching animation presets:", error)
      throw new Error("Failed to search animation presets")
    }
  }

  /**
   * Generate animation suggestions for a specific element
   */
  static async generateAnimationSuggestions(
    userId: string,
    elementType: string,
    elementContent?: string,
    projectContext?: string,
    count = 3,
  ): Promise<string[]> {
    try {
      const systemPrompt =
        "You are an animation expert for a motion graphics tool. " +
        `Generate ${count} animation suggestions for a ${elementType} element. ` +
        (elementContent ? `The element contains: "${elementContent}". ` : "") +
        (projectContext ? `The project context is: "${projectContext}". ` : "") +
        "Return a JSON array of animation descriptions, each as a string. " +
        "Make the suggestions creative, professional, and varied. " +
        "Only respond with the JSON array, nothing else."

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Suggest animations for a ${elementType} element`,
        system: systemPrompt,
      })

      // Parse the suggestions from the response
      let suggestions: string[] = []
      try {
        // Extract JSON array if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\[(.*)\]/s)
        if (jsonMatch) {
          suggestions = JSON.parse(`[${jsonMatch[1]}]`)
        } else {
          suggestions = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing suggestions:", e)
        throw new Error("Failed to parse animation suggestions")
      }

      return suggestions
    } catch (error) {
      console.error("Error generating animation suggestions:", error)
      throw new Error("Failed to generate animation suggestions")
    }
  }

  /**
   * Analyze an existing animation and provide improvements
   */
  static async analyzeAndImproveAnimation(
    userId: string,
    keyframes: AnimationKeyframe[],
    elementType: string,
    duration: number,
    projectId?: string,
  ): Promise<{
    analysis: string
    improvedKeyframes: AnimationKeyframe[]
  }> {
    try {
      const systemPrompt =
        "You are an animation expert for a motion graphics tool. " +
        "Analyze the provided animation keyframes and suggest improvements. " +
        "Return a JSON object with analysis (string) and improvedKeyframes (array). " +
        "The analysis should explain what was improved and why. " +
        "Only respond with the JSON object, nothing else."

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Analyze and improve these animation keyframes for a ${elementType} element with duration ${duration} seconds: ${JSON.stringify(keyframes)}`,
        system: systemPrompt,
      })

      // Parse the response
      let result: { analysis: string; improvedKeyframes: AnimationKeyframe[] } = {
        analysis: "",
        improvedKeyframes: [],
      }

      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          result = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          result = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing animation analysis:", e)
        throw new Error("Failed to parse animation analysis")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "animation_improvement",
          prompt: JSON.stringify(keyframes),
          result: {
            originalKeyframes: keyframes,
            improvedKeyframes: result.improvedKeyframes,
            analysis: result.analysis,
            elementType,
            duration,
          },
        },
      })

      return result
    } catch (error) {
      console.error("Error analyzing animation:", error)
      throw new Error("Failed to analyze animation")
    }
  }

  /**
   * Generate a sequence of animations for multiple elements
   */
  static async generateAnimationSequence(
    userId: string,
    elements: Array<{
      id: string
      type: string
      content?: string
    }>,
    sequenceType: "sequential" | "parallel" | "staggered" | "custom",
    duration: number,
    description: string,
    projectId?: string,
  ): Promise<{
    sequenceDescription: string
    elementAnimations: ElementAnimationConfig[]
  }> {
    try {
      const systemPrompt =
        "You are an animation expert for a motion graphics tool. " +
        `Generate a ${sequenceType} animation sequence for ${elements.length} elements over ${duration} seconds. ` +
        "The sequence should match this description: " +
        description +
        ". " +
        "Return a JSON object with sequenceDescription (string) and elementAnimations (array). " +
        "Each element animation should have elementId, startTime, duration, easing, and customKeyframes. " +
        "Only respond with the JSON object, nothing else."

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Create an animation sequence for these elements: ${JSON.stringify(elements)}`,
        system: systemPrompt,
      })

      // Parse the sequence from the response
      let sequence: {
        sequenceDescription: string
        elementAnimations: ElementAnimationConfig[]
      } = {
        sequenceDescription: "",
        elementAnimations: [],
      }

      try {
        // Extract JSON object if it's wrapped in backticks or other text
        const jsonMatch = text.match(/\{(.*)\}/s)
        if (jsonMatch) {
          sequence = JSON.parse(`{${jsonMatch[1]}}`)
        } else {
          sequence = JSON.parse(text)
        }
      } catch (e) {
        console.error("Error parsing animation sequence:", e)
        throw new Error("Failed to parse animation sequence")
      }

      // Save to database
      await prisma.aIGeneration.create({
        data: {
          userId,
          projectId,
          type: "animation_sequence",
          prompt: description,
          result: {
            elements,
            sequenceType,
            duration,
            sequence,
          },
        },
      })

      return sequence
    } catch (error) {
      console.error("Error generating animation sequence:", error)
      throw new Error("Failed to generate animation sequence")
    }
  }
}

