import { type NextRequest, NextResponse } from "next/server"
import { headers } from "next/headers"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AppError, ValidationError, AuthenticationError, AuthorizationError, ContentPolicyError } from "@/lib/errors"
import { RequestLogger } from "@/lib/request-logger"
import { z } from "zod"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export interface ApiHandlerOptions {
  requireAuth?: boolean
  allowApiKey?: boolean
  allowedRoles?: string[]
  logRequests?: boolean
  rateLimitKey?: string
  validateContentPolicy?: boolean
}

/**
 * Get the client's IP address with proper forwarding handling
 */
export function getClientIp(req: NextRequest): string {
  // Try to get from headers first (for proxied requests)
  const forwardedFor = req.headers.get("x-forwarded-for")?.split(",")[0].trim()
  if (forwardedFor) return forwardedFor

  // Fallback to request IP
  return req.ip || "unknown"
}

/**
 * Validate API key with enhanced security
 */
export function validateApiKey(req: NextRequest): boolean {
  if (!process.env.API_SECRET_KEY) return false

  const headersList = headers()
  const apiKey = headersList.get("x-api-key")

  // Enhanced validation: check for timing attacks
  if (!apiKey || apiKey.length !== process.env.API_SECRET_KEY.length) {
    return false
  }

  // Constant-time comparison to prevent timing attacks
  return timingSafeEqual(apiKey, process.env.API_SECRET_KEY)
}

/**
 * Constant time string comparison to prevent timing attacks
 */
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) {
    return false
  }

  let result = 0
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i)
  }

  return result === 0
}

/**
 * Get authenticated user with role checking
 */
export async function getAuthenticatedUser(
  req: NextRequest,
  allowedRoles?: string[],
): Promise<{ id: string; role: string } | null> {
  const session = await getServerSession(authOptions)
  const hasValidApiKey = validateApiKey(req)

  if (session?.user) {
    // Get user with role from database for role checking
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, role: true },
    })

    // Check role if specified
    if (allowedRoles && allowedRoles.length > 0) {
      if (!user || !allowedRoles.includes(user.role)) {
        return null
      }
    }

    return user
  } else if (hasValidApiKey) {
    return { id: "api-client", role: "API" }
  }

  return null
}

/**
 * Check if content violates content policy
 */
export function checkContentPolicy(content: string, safetyLevel: "low" | "medium" | "high" = "medium"): boolean {
  // List of prohibited content patterns based on safety level
  const prohibitedPatterns: Record<string, RegExp[]> = {
    high: [
      /\b(nude|naked|porn|sex|explicit|nsfw)\b/i,
      /\b(weapon|gun|kill|violent|terrorism)\b/i,
      /\b(racist|nazi|offensive|slur)\b/i,
      /\b(hack|steal|illegal|fraud)\b/i,
    ],
    medium: [/\b(porn|sex|explicit|nsfw)\b/i, /\b(kill|terrorism)\b/i, /\b(racist|nazi|slur)\b/i, /\b(hack|fraud)\b/i],
    low: [/\b(porn|explicit|nsfw)\b/i, /\b(terrorism)\b/i, /\b(nazi|slur)\b/i],
  }

  const patterns = prohibitedPatterns[safetyLevel] || []

  // Check if content contains any prohibited patterns
  return !patterns.some((pattern) => pattern.test(content))
}

/**
 * Validate request body against schema
 */
export function validateRequest<T>(schema: z.ZodType<T>, data: unknown): T {
  try {
    return schema.parse(data)
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new ValidationError("Validation failed", { details: error.format() })
    }
    throw error
  }
}

/**
 * Enhanced API handler with better error handling and security
 */
export function withApiHandler<T>(
  handler: (req: NextRequest, user: { id: string; role: string }) => Promise<T>,
  options: ApiHandlerOptions = {
    requireAuth: true,
    allowApiKey: true,
    logRequests: true,
    validateContentPolicy: false,
  },
) {
  return async (req: NextRequest) => {
    const requestStartTime = Date.now()
    let requestBody: any
    let user: { id: string; role: string } | null = null
    let statusCode = 200
    let responseBody: any
    let errorDetails: any

    try {
      // Parse request body
      try {
        if (["POST", "PUT", "PATCH"].includes(req.method || "")) {
          const clonedReq = req.clone()
          requestBody = await clonedReq.json()
        }
      } catch (e) {
        requestBody = {}
      }

      // Check content policy if enabled
      if (options.validateContentPolicy && requestBody) {
        // Check each string field in the request body
        const contentToCheck = JSON.stringify(requestBody)
        const safetyLevel = (requestBody.safetyLevel || "medium") as "low" | "medium" | "high"

        if (!checkContentPolicy(contentToCheck, safetyLevel)) {
          throw new ContentPolicyError("Content policy violation", {
            safetyLevel,
          })
        }
      }

      // Check authentication if required
      if (options.requireAuth) {
        user = await getAuthenticatedUser(req, options.allowedRoles)

        if (!user) {
          if (options.allowedRoles && options.allowedRoles.length > 0) {
            throw new AuthorizationError(`Access restricted. Required roles: ${options.allowedRoles.join(", ")}`)
          } else {
            throw new AuthenticationError()
          }
        }
      } else {
        // For non-auth-required endpoints, still try to get user if available
        user = await getAuthenticatedUser(req)
      }

      // Execute the handler
      const result = await handler(req, user || { id: "anonymous", role: "PUBLIC" })

      // Set response body
      responseBody = { success: true, data: result }

      // Return successful response
      return NextResponse.json(responseBody)
    } catch (error) {
      console.error(`Error in API route ${req.nextUrl.pathname}:`, error)

      // Handle custom application errors
      if (error instanceof AppError) {
        statusCode = error.statusCode
        errorDetails = {
          message: error.message,
          code: error.code,
          context: error.context,
        }

        responseBody = {
          success: false,
          error: error.message,
          code: error.code,
          ...(error.context ? { context: error.context } : {}),
        }
      } else {
        // Handle unknown errors
        statusCode = 500
        errorDetails = {
          message: error instanceof Error ? error.message : "Unknown error",
          stack: error instanceof Error ? error.stack : undefined,
        }

        responseBody = {
          success: false,
          error: "Internal Server Error",
          message: "An unexpected error occurred",
        }

        // Log unexpected errors
        if (error instanceof Error) {
          await RequestLogger.logError(
            error,
            {
              method: req.method,
              url: req.url,
              headers: Object.fromEntries(req.headers.entries()),
              body: requestBody,
              user: user?.id,
            },
            responseBody,
          )
        }
      }

      return NextResponse.json(responseBody, { status: statusCode })
    } finally {
      // Log the request
      if (options.logRequests) {
        const responseTime = Date.now() - requestStartTime

        try {
          await RequestLogger.logRequest({
            method: req.method || "UNKNOWN",
            path: req.nextUrl.pathname,
            userId: user?.id,
            userRole: user?.role,
            statusCode,
            responseTime,
            ipAddress: getClientIp(req),
            userAgent: req.headers.get("user-agent") || undefined,
            errorDetails,
            requestBody,
            responseBody,
            rateLimitKey: options.rateLimitKey,
          })
        } catch (logError) {
          console.error("Error logging request:", logError)
        }
      }
    }
  }
}

