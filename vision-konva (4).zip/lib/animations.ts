import { Easings } from "konva/lib/Tween"

export const animationPresets = {
  fadeIn: (node) => ({
    opacity: 1,
    duration: 1,
    easing: Easings.EaseInOut,
  }),
  fadeOut: (node) => ({
    opacity: 0,
    duration: 1,
    easing: Easings.EaseInOut,
  }),
  slideIn: (node) => ({
    x: node.x() + 100,
    duration: 0.5,
    easing: Easings.EaseOut,
  }),
  slideOut: (node) => ({
    x: node.x() - 100,
    duration: 0.5,
    easing: Easings.EaseIn,
  }),
  bounce: (node) => ({
    y: node.y() - 20,
    duration: 0.4,
    easing: Easings.EaseInOut,
    yoyo: true,
    repeat: 3,
  }),
  pulse: (node) => ({
    scaleX: 1.1,
    scaleY: 1.1,
    duration: 0.3,
    easing: Easings.EaseInOut,
    yoyo: true,
    repeat: 2,
  }),
}

export const easingFunctions = Object.keys(Easings).map((key) => ({
  name: key,
  function: Easings[key],
}))

