import Konva from "konva"

export const AnimationPresets = {
  fadeIn: (node: Konva.Node, duration = 1) => {
    node.opacity(0)
    return new Konva.Tween({
      node: node,
      duration: duration,
      opacity: 1,
    })
  },

  fadeOut: (node: Konva.Node, duration = 1) => {
    return new Konva.Tween({
      node: node,
      duration: duration,
      opacity: 0,
    })
  },

  slideIn: (node: Konva.Node, direction: "left" | "right" | "top" | "bottom", duration = 1) => {
    const stage = node.getStage()
    if (!stage) return

    const { x, y } = node.position()
    let startX = x,
      startY = y

    switch (direction) {
      case "left":
        startX = -node.width()
        break
      case "right":
        startX = stage.width()
        break
      case "top":
        startY = -node.height()
        break
      case "bottom":
        startY = stage.height()
        break
    }

    node.position({ x: startX, y: startY })
    return new Konva.Tween({
      node: node,
      duration: duration,
      x: x,
      y: y,
    })
  },

  rotate: (node: Konva.Node, angle: number, duration = 1) => {
    return new Konva.Tween({
      node: node,
      duration: duration,
      rotation: angle,
    })
  },

  scale: (node: Konva.Node, scale: number, duration = 1) => {
    return new Konva.Tween({
      node: node,
      duration: duration,
      scaleX: scale,
      scaleY: scale,
    })
  },

  bounce: (node: Konva.Node, height = 50, duration = 1) => {
    const originalY = node.y()
    return new Konva.Animation((frame) => {
      if (!frame) return
      const time = frame.time / 1000
      const y = originalY - Math.abs(Math.sin(time * Math.PI * 2)) * height
      node.y(y)
    }, node.getLayer())
  },
}

