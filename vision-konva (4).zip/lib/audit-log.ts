import { prisma } from "@/lib/db"

export type AuditAction =
  | "CREATE"
  | "UPDATE"
  | "DELETE"
  | "LOGIN"
  | "LOGOUT"
  | "IMPERSONATE"
  | "EXPORT"
  | "IMPORT"
  | "SHARE"
  | "PAYMENT"
  | "SUBSCRIPTION"
  | "SETTINGS"

export type AuditEntity = "USER" | "PROJECT" | "ASSET" | "SUBSCRIPTION" | "PAYMENT" | "SYSTEM"

export async function createAuditLog(
  action: AuditAction,
  entity: AuditEntity,
  entityId?: string,
  userId?: string,
  metadata?: Record<string, any>,
) {
  try {
    await prisma.auditLog.create({
      data: {
        action,
        entity,
        entityId,
        userId,
        metadata,
      },
    })
  } catch (error) {
    console.error("Failed to create audit log:", error)
  }
}

