import Konva from "konva"

// Configure Konva for better performance
export const optimizeKonvaPerformance = () => {
  // Disable perfect drawing
  Konva.perfectDrawEnabled = false

  // Set hit graph optimization
  Konva.hitOnDragEnabled = false

  // Optimize for mobile
  if (typeof window !== "undefined" && window.innerWidth < 768) {
    // Reduce shadow blur for better performance on mobile
    Konva.shadowOffsetX = 1
    Konva.shadowOffsetY = 1
    Konva.shadowBlur = 2

    // Reduce default stroke width
    Konva.strokeWidth = 1
  }

  return {
    // Helper to optimize layer for performance
    optimizeLayer: (layer: Konva.Layer) => {
      // Disable listening for better performance when not needed
      layer.listening(false)

      // Enable layer caching for static content
      layer.cache()

      return {
        // Enable listening when needed (e.g., for interaction)
        enableListening: () => {
          layer.listening(true)
          layer.clearCache()
        },

        // Disable listening when not needed
        disableListening: () => {
          layer.listening(false)
          layer.cache()
        },

        // Update cache
        updateCache: () => {
          layer.clearCache()
          layer.cache()
        },
      }
    },

    // Helper to optimize shape for performance
    optimizeShape: (shape: Konva.Shape) => {
      // Disable shadow for better performance
      shape.shadowEnabled(false)

      // Disable stroke for better performance
      if (shape.strokeWidth() <= 0) {
        shape.strokeEnabled(false)
      }

      // Cache shape for better performance
      shape.cache()

      return {
        // Enable shadow when needed
        enableShadow: () => {
          shape.shadowEnabled(true)
          shape.clearCache()
          shape.cache()
        },

        // Disable shadow when not needed
        disableShadow: () => {
          shape.shadowEnabled(false)
          shape.clearCache()
          shape.cache()
        },

        // Update cache
        updateCache: () => {
          shape.clearCache()
          shape.cache()
        },
      }
    },

    // Helper to optimize stage for performance
    optimizeStage: (stage: Konva.Stage) => {
      // Disable hit graph when not needed
      stage.hitGraphEnabled(false)

      return {
        // Enable hit graph when needed (e.g., for selection)
        enableHitGraph: () => {
          stage.hitGraphEnabled(true)
        },

        // Disable hit graph when not needed
        disableHitGraph: () => {
          stage.hitGraphEnabled(false)
        },

        // Optimize for animation
        optimizeForAnimation: () => {
          // Disable hit graph during animation
          stage.hitGraphEnabled(false)

          // Disable listening on all layers
          stage.getLayers().forEach((layer) => {
            layer.listening(false)
          })
        },

        // Restore after animation
        restoreAfterAnimation: () => {
          // Re-enable hit graph
          stage.hitGraphEnabled(true)

          // Re-enable listening on all layers
          stage.getLayers().forEach((layer) => {
            layer.listening(true)
          })
        },
      }
    },
  }
}

// Helper to optimize image loading
export const optimizeImageLoading = () => {
  return {
    // Preload images
    preloadImages: (urls: string[]) => {
      return Promise.all(
        urls.map((url) => {
          return new Promise((resolve, reject) => {
            const img = new Image()
            img.crossOrigin = "anonymous"
            img.onload = () => resolve(img)
            img.onerror = reject
            img.src = url
          })
        }),
      )
    },

    // Create optimized image
    createOptimizedImage: (url: string, maxWidth = 1024, maxHeight = 1024) => {
      return new Promise((resolve, reject) => {
        const img = new Image()
        img.crossOrigin = "anonymous"

        img.onload = () => {
          // Check if resizing is needed
          if (img.width <= maxWidth && img.height <= maxHeight) {
            resolve(img)
            return
          }

          // Calculate new dimensions
          let width = img.width
          let height = img.height

          if (width > maxWidth) {
            height = (height * maxWidth) / width
            width = maxWidth
          }

          if (height > maxHeight) {
            width = (width * maxHeight) / height
            height = maxHeight
          }

          // Create canvas for resizing
          const canvas = document.createElement("canvas")
          canvas.width = width
          canvas.height = height

          // Draw resized image
          const ctx = canvas.getContext("2d")
          ctx.drawImage(img, 0, 0, width, height)

          // Create new image from canvas
          const resizedImg = new Image()
          resizedImg.crossOrigin = "anonymous"
          resizedImg.onload = () => resolve(resizedImg)
          resizedImg.onerror = reject
          resizedImg.src = canvas.toDataURL("image/jpeg", 0.9)
        }

        img.onerror = reject
        img.src = url
      })
    },
  }
}

// Helper to optimize animations
export const optimizeAnimations = () => {
  return {
    // Create optimized tween
    createOptimizedTween: (node: Konva.Node, props: any, duration: number, easing: string) => {
      // Store original properties
      const originalProps = {}
      Object.keys(props).forEach((key) => {
        originalProps[key] = node[key]()
      })

      // Create tween
      const tween = new Konva.Tween({
        node,
        duration,
        easing,
        ...props,
      })

      // Optimize before animation
      const stage = node.getStage()
      if (stage) {
        stage.hitGraphEnabled(false)
      }

      // Start tween
      tween.play()

      // Restore after animation
      tween.onFinish = () => {
        if (stage) {
          stage.hitGraphEnabled(true)
        }

        // Call original onFinish if provided
        if (props.onFinish) {
          props.onFinish()
        }
      }

      return {
        tween,
        reset: () => {
          tween.pause()
          Object.keys(originalProps).forEach((key) => {
            node[key](originalProps[key])
          })
          node.getLayer()?.batchDraw()
        },
      }
    },

    // Create optimized animation
    createOptimizedAnimation: (func: (frame: Konva.Frame) => void) => {
      // Create animation
      const animation = new Konva.Animation(func)

      // Store original function
      const originalFunc = func

      // Wrap function with optimization
      animation.func = (frame: Konva.Frame) => {
        // Call original function
        originalFunc(frame)

        // Limit frame rate on mobile
        if (typeof window !== "undefined" && window.innerWidth < 768) {
          if (frame.frameRate > 30) {
            animation.stop()
            setTimeout(() => animation.start(), 1000 / 30)
          }
        }
      }

      return animation
    },
  }
}

