import {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminSetUserPasswordCommand,
  AdminInitiateAuthCommand,
  AdminRespondToAuthChallengeCommand,
} from "@aws-sdk/client-cognito-identity-provider"

const cognitoClient = new CognitoIdentityProviderClient({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
  },
})

const userPoolId = process.env.COGNITO_USER_POOL_ID || ""
const clientId = process.env.COGNITO_CLIENT_ID || ""

export async function createCognitoUser(email: string, password: string, name: string) {
  try {
    // Create the user
    const createUserCommand = new AdminCreateUserCommand({
      UserPoolId: userPoolId,
      Username: email,
      TemporaryPassword: password,
      UserAttributes: [
        {
          Name: "email",
          Value: email,
        },
        {
          Name: "email_verified",
          Value: "true",
        },
        {
          Name: "name",
          Value: name,
        },
      ],
      MessageAction: "SUPPRESS", // Don't send welcome email
    })

    await cognitoClient.send(createUserCommand)

    // Set permanent password
    const setPasswordCommand = new AdminSetUserPasswordCommand({
      UserPoolId: userPoolId,
      Username: email,
      Password: password,
      Permanent: true,
    })

    await cognitoClient.send(setPasswordCommand)

    return { success: true }
  } catch (error) {
    console.error("Error creating Cognito user:", error)
    return { success: false, error }
  }
}

export async function authenticateCognitoUser(email: string, password: string) {
  try {
    const authCommand = new AdminInitiateAuthCommand({
      UserPoolId: userPoolId,
      ClientId: clientId,
      AuthFlow: "ADMIN_NO_SRP_AUTH",
      AuthParameters: {
        USERNAME: email,
        PASSWORD: password,
      },
    })

    const authResponse = await cognitoClient.send(authCommand)

    // Handle new password required challenge
    if (authResponse.ChallengeName === "NEW_PASSWORD_REQUIRED") {
      const challengeResponse = new AdminRespondToAuthChallengeCommand({
        UserPoolId: userPoolId,
        ClientId: clientId,
        ChallengeName: "NEW_PASSWORD_REQUIRED",
        ChallengeResponses: {
          USERNAME: email,
          NEW_PASSWORD: password,
        },
        Session: authResponse.Session,
      })

      const finalResponse = await cognitoClient.send(challengeResponse)
      return {
        success: true,
        tokens: finalResponse.AuthenticationResult,
      }
    }

    return {
      success: true,
      tokens: authResponse.AuthenticationResult,
    }
  } catch (error) {
    console.error("Error authenticating Cognito user:", error)
    return { success: false, error }
  }
}

