import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3"
import { getSignedUrl } from "@aws-sdk/s3-request-presigner"
import crypto from "crypto"

// Initialize S3 client
const s3Client = new S3Client({
  region: process.env.AWS_REGION!,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
})

const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME!

// Generate a unique filename to prevent collisions
export function generateUniqueFileName(originalName: string): string {
  const timestamp = Date.now()
  const randomString = crypto.randomBytes(16).toString("hex")
  const extension = originalName.split(".").pop()
  return `${timestamp}-${randomString}.${extension}`
}

// Upload a file to S3
export async function uploadFileToS3(
  file: Buffer,
  fileName: string,
  contentType: string,
): Promise<{ url: string; key: string }> {
  const key = `assets/${fileName}`

  const params = {
    Bucket: BUCKET_NAME,
    Key: key,
    Body: file,
    ContentType: contentType,
  }

  await s3Client.send(new PutObjectCommand(params))

  // Return the URL and key
  return {
    url: `https://${BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`,
    key,
  }
}

// Delete a file from S3
export async function deleteFileFromS3(key: string): Promise<void> {
  const params = {
    Bucket: BUCKET_NAME,
    Key: key,
  }

  await s3Client.send(new DeleteObjectCommand(params))
}

// Generate a presigned URL for temporary access
export async function generatePresignedUrl(key: string, expiresIn = 3600): Promise<string> {
  const command = new GetObjectCommand({
    Bucket: BUCKET_NAME,
    Key: key,
  })

  return getSignedUrl(s3Client, command, { expiresIn })
}

