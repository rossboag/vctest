import { prisma } from "@/lib/db"

export async function trackError(error: Error, metadata: Record<string, any> = {}) {
  try {
    await prisma.errorLog.create({
      data: {
        type: error.name,
        message: error.message,
        stack: error.stack,
        path: metadata.path,
        userId: metadata.userId,
        metadata: metadata,
      },
    })
  } catch (err) {
    console.error("Failed to track error:", err)
  }
}

export function createErrorHandler(userId?: string) {
  return async (error: Error, path?: string) => {
    await trackError(error, { userId, path })
  }
}

