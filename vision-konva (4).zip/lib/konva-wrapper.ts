import Konva from "konva"
import { v4 as uuidv4 } from "uuid"
import type { Element } from "@/store/editor-store"
import { aiHelper } from "./ai-helper"
import { Potrace } from "potrace"
import { KonvaTextHandler } from "./konva-text"
import { KonvaShapeHandler } from "./konva-shapes"
import { KonvaEffectHandler } from "./konva-effects"
import { KonvaAnimationHandler } from "./konva-animation"

class KonvaWrapper {
  private stage: Konva.Stage | null = null
  private layer: Konva.Layer | null = null
  private elements: Map<string, Konva.Shape> = new Map()
  private textDoubleClickHandlers: ((id: string) => void)[] = []
  private textHandler: KonvaTextHandler
  private shapeHandler: KonvaShapeHandler
  private effectHandler: KonvaEffectHandler
  private animationHandler: KonvaAnimationHandler

  private cachedLayers: Map<string, Konva.Layer> = new Map()
  private dirtyLayers: Set<string> = new Set()

  constructor() {
    this.textHandler = new KonvaTextHandler()
    this.shapeHandler = new KonvaShapeHandler()
    this.effectHandler = new KonvaEffectHandler()
    this.animationHandler = new KonvaAnimationHandler()
  }

  initStage(containerId: string, width: number, height: number) {
    this.stage = new Konva.Stage({
      container: containerId,
      width: width,
      height: height,
    })

    this.layer = new Konva.Layer()
    this.stage.add(this.layer)
    this.layer.batchDraw()

    this.stage.on("dblclick", (e) => {
      if (e.target instanceof Konva.Text) {
        const id = e.target.id()
        this.textDoubleClickHandlers.forEach((handler) => handler(id))
      }
    })
  }

  getStage() {
    return this.stage
  }

  getLayer() {
    return this.layer
  }

  setBackground(color: string) {
    if (!this.stage) return

    this.stage.container().style.backgroundColor = color
  }

  drawCanvas(width: number, height: number) {
    if (!this.stage) return

    this.stage.width(width)
    this.stage.height(height)
    this.layer?.batchDraw()
  }

  updateStage(width: number, height: number, scale: number, x: number, y: number) {
    if (!this.stage) return

    this.stage.width(width)
    this.stage.height(height)
    this.stage.scale({ x: scale, y: scale })
    this.stage.position({ x: x, y: y })
    this.layer?.batchDraw()
  }

  clear() {
    this.layer?.destroyChildren()
    this.elements.clear()
  }

  addElement(element: Element) {
    switch (element.type) {
      case "rectangle":
        this.addRectangle(element)
        break
      case "circle":
        this.addCircle(element)
        break
      case "line":
        this.addLine(element)
        break
      case "triangle":
        this.addTriangle(element)
        break
      case "hexagon":
        this.addHexagon(element)
        break
      case "star":
        this.addStar(element)
        break
      case "arrow":
        this.addArrow(element)
        break
      case "freehand":
        this.addFreehandLine(element)
        break
      case "text":
        this.addTextElement(element)
        break
      case "image":
        this.addImage(element)
        break
      case "video":
        this.addVideo(element)
        break
      case "custom":
        this.addCustomShape(element.pathData, element)
        break
      case "ellipse":
        this.addEllipse(element)
        break
      default:
        console.warn("Unknown element type:", element.type)
    }
    this.markLayerAsDirty(element.layerId)
  }

  updateElement(id: string, changes: Partial<Element>) {
    const element = this.elements.get(id)
    if (element) {
      Object.assign(element, changes)
      this.markLayerAsDirty(element.layerId)
    }
  }

  addRectangle(element: Element) {
    const rect = this.shapeHandler.addRectangle(element)
    this.elements.set(element.id, rect)
    this.layer?.add(rect)
    this.layer?.batchDraw()
  }

  addCircle(element: Element) {
    const circle = this.shapeHandler.addCircle(element)
    this.elements.set(element.id, circle)
    this.layer?.add(circle)
    this.layer?.batchDraw()
  }

  addLine(element: Element) {
    const line = new Konva.Line({
      points: element.points,
      stroke: element.fill,
      strokeWidth: 5,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })

    this.elements.set(element.id, line)
    this.layer?.add(line)
    this.layer?.batchDraw()
  }

  addTriangle(element: Element) {
    const triangle = new Konva.RegularPolygon({
      x: element.x,
      y: element.y,
      sides: 3,
      radius: element.width / 2,
      fill: element.fill,
      stroke: element.stroke,
      strokeWidth: element.strokeWidth,
      opacity: element.opacity,
      draggable: true,
      id: element.id,
    })

    this.elements.set(element.id, triangle)
    this.layer?.add(triangle)
    this.layer?.batchDraw()
  }

  addHexagon(element: Element) {
    const hexagon = new Konva.RegularPolygon({
      x: element.x,
      y: element.y,
      sides: 6,
      radius: element.width / 2,
      fill: element.fill,
      stroke: element.stroke,
      strokeWidth: element.strokeWidth,
      opacity: element.opacity,
      draggable: true,
      id: element.id,
    })

    this.elements.set(element.id, hexagon)
    this.layer?.add(hexagon)
    this.layer?.batchDraw()
  }

  addStar(element: Element) {
    const star = new Konva.Star({
      x: element.x,
      y: element.y,
      numPoints: element.numPoints,
      innerRadius: element.innerRadius,
      outerRadius: element.outerRadius,
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })

    this.elements.set(element.id, star)
    this.layer?.add(star)
    this.layer?.batchDraw()
  }

  addArrow(element: Element) {
    const arrow = new Konva.Arrow({
      x: element.x,
      y: element.y,
      points: element.points,
      pointerLength: 20,
      pointerWidth: 20,
      fill: element.fill,
      stroke: element.fill,
      strokeWidth: 4,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })

    this.elements.set(element.id, arrow)
    this.layer?.add(arrow)
    this.layer?.batchDraw()
  }

  addFreehandLine(element: Element) {
    const line = new Konva.Line({
      points: element.points || [],
      stroke: element.stroke,
      strokeWidth: element.strokeWidth,
      opacity: element.opacity,
      tension: 0.5,
      lineCap: "round",
      lineJoin: "round",
      draggable: true,
      id: element.id,
    })

    this.elements.set(element.id, line)
    this.layer?.add(line)
    this.layer?.batchDraw()
  }

  addTextElement(element: Element) {
    const text = this.textHandler.addTextElement(element)
    this.elements.set(element.id, text)
    this.layer?.add(text)
    this.layer?.batchDraw()
  }

  updateTextElement(id: string, changes: Partial<Element>) {
    const text = this.elements.get(id) as Konva.Text
    if (!text) return

    Object.keys(changes).forEach((key) => {
      switch (key) {
        case "text":
        case "fontSize":
        case "fontFamily":
        case "fill":
        case "align":
        case "fontStyle":
        case "textDecoration":
        case "width":
        case "wrap":
        case "letterSpacing":
        case "lineHeight":
        case "padding":
        case "stroke":
        case "strokeWidth":
        case "shadowColor":
        case "shadowBlur":
        case "shadowOffsetX":
        case "shadowOffsetY":
          text[key](changes[key])
          break
        case "opacity":
          text.opacity(changes[key] as number)
          break
        case "blurRadius":
          text.blurRadius(changes[key] as number)
          break
        default:
          console.warn(`Unknown text property: ${key}`)
      }
    })

    this.layer?.batchDraw()
  }

  addImage(element: Element) {
    const imageObj = new window.Image()
    imageObj.onload = () => {
      const image = new Konva.Image({
        x: element.x,
        y: element.y,
        image: imageObj,
        width: element.width,
        height: element.height,
        draggable: true,
        id: element.id,
        opacity: element.opacity,
        blurRadius: element.blur,
      })

      this.elements.set(element.id, image)
      this.layer?.add(image)
      this.layer?.batchDraw()
    }
    imageObj.src = element.imageUrl || ""
  }

  addVideo(element: Element) {
    const video = document.createElement("video")
    video.src = element.videoUrl || ""
    video.muted = true
    video.loop = true
    video.autoplay = true

    video.addEventListener("loadeddata", () => {
      const videoNode = new Konva.Image({
        x: element.x,
        y: element.y,
        image: video,
        width: element.width,
        height: element.height,
        draggable: true,
        id: element.id,
        opacity: element.opacity,
        blurRadius: element.blur,
      })

      this.elements.set(element.id, videoNode)
      this.layer?.add(videoNode)

      const animate = new Konva.Animation(() => {
        videoNode.image(video)
      }, this.layer)

      animate.start()
      this.layer?.batchDraw()
    })
  }

  addCustomShape(pathData: string, element: any) {
    const customShape = new Konva.Path({
      x: element.x,
      y: element.y,
      data: pathData,
      fill: element.fill,
      stroke: element.stroke,
      strokeWidth: element.strokeWidth,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })

    this.elements.set(element.id, customShape)
    this.layer?.add(customShape)
    this.layer?.batchDraw()
  }

  updateCustomShape(id: string, pathData: string, style: any) {
    const shape = this.elements.get(id) as Konva.Path
    if (shape) {
      shape.data(pathData)
      shape.fill(style.fill)
      shape.stroke(style.stroke)
      shape.strokeWidth(style.strokeWidth)
      this.layer?.batchDraw()
    }
  }

  getElement(id: string) {
    return this.elements.get(id)
  }

  removeElement(id: string) {
    const element = this.elements.get(id)
    if (element) {
      element.destroy()
      this.elements.delete(id)
      this.markLayerAsDirty(element.layerId)
    }
  }

  enableCaching(id: string) {
    const element = this.elements.get(id)
    if (element) {
      element.cache()
      this.layer?.batchDraw()
    }
  }

  disableCaching(id: string) {
    const element = this.elements.get(id)
    if (element) {
      element.clearCache()
      this.layer?.batchDraw()
    }
  }

  applyTextOnPath(id: string, pathData: string) {
    const textNode = this.elements.get(id) as Konva.Text
    if (!textNode) return

    const textPath = new Konva.TextPath({
      text: textNode.text(),
      fontSize: textNode.fontSize(),
      fontFamily: textNode.fontFamily(),
      fill: textNode.fill(),
      data: pathData,
    })

    this.elements.set(id, textPath)
    textNode.destroy()
    this.layer?.add(textPath)
    this.layer?.batchDraw()
  }

  removeTextFromPath(id: string) {
    const textPath = this.elements.get(id) as Konva.TextPath
    if (!textPath) return

    const text = new Konva.Text({
      text: textPath.text(),
      fontSize: textPath.fontSize(),
      fontFamily: textPath.fontFamily(),
      fill: textPath.fill(),
      x: textPath.x(),
      y: textPath.y(),
    })

    this.elements.set(id, text)
    textPath.destroy()
    this.layer?.add(text)
    this.layer?.batchDraw()
  }

  applyTextGradient(id: string, gradientType: "linear" | "radial", colorStops: Array<[number, string]>) {
    const textNode = this.elements.get(id) as Konva.Text
    if (textNode) {
      const context = this.layer?.getContext()
      if (context) {
        let gradient
        if (gradientType === "linear") {
          gradient = context.createLinearGradient(0, 0, textNode.width(), textNode.height())
        } else {
          const radius = Math.max(textNode.width(), textNode.height()) / 2
          gradient = context.createRadialGradient(
            textNode.width() / 2,
            textNode.height() / 2,
            0,
            textNode.width() / 2,
            textNode.height() / 2,
            radius,
          )
        }
        colorStops.forEach(([offset, color]) => gradient.addColorStop(offset, color))
        textNode.fillPriority("pattern")
        textNode.fillPatternImage(gradient as any)
      }
      this.layer?.batchDraw()
    }
  }

  removeTextGradient(id: string) {
    const textNode = this.elements.get(id) as Konva.Text
    if (!textNode) return

    textNode.fillLinearGradientStartPoint(null)
    textNode.fillLinearGradientEndPoint(null)
    textNode.fillLinearGradientColorStops(null)

    this.layer?.batchDraw()
  }

  applyTextAnimation(id: string, animationType: "typewriter" | "fadeIn" | "bounce", options: any) {
    const textNode = this.elements.get(id) as Konva.Text
    if (textNode) {
      const originalText = textNode.text()
      switch (animationType) {
        case "typewriter":
          textNode.text("")
          const duration = options.duration || 1000
          const interval = duration / originalText.length
          let charIndex = 0
          const typewriterInterval = setInterval(() => {
            if (charIndex < originalText.length) {
              textNode.text(originalText.slice(0, charIndex + 1))
              this.layer?.batchDraw()
              charIndex++
            } else {
              clearInterval(typewriterInterval)
            }
          }, interval)
          break
        case "fadeIn":
          textNode.opacity(0)
          new Konva.Tween({
            node: textNode,
            opacity: 1,
            duration: options.duration || 1,
            easing: Konva.Easings.EaseInOut,
          }).play()
          break
        case "bounce":
          const amplitude = options.amplitude || 20
          const period = options.period || 1000
          const anim = new Konva.Animation((frame) => {
            if (frame) {
              textNode.y(textNode.getAttr("originalY") + amplitude * Math.sin((frame.time * 2 * Math.PI) / period))
            }
          }, this.layer)
          textNode.setAttr("originalY", textNode.y())
          anim.start()
          break
      }
    }
  }

  applyRichTextStyles(id: string, styles: Array<{ text: string; attrs: Konva.TextConfig }>) {
    const textNode = this.elements.get(id) as Konva.Text
    if (!textNode) return

    textNode.text("")
    textNode.setAttr("partialText", "")

    styles.forEach((style, i) => {
      textNode.setAttr("partialText", textNode.getAttr("partialText") + style.text)
      textNode.textArr.forEach((charObj: any) => {
        if (charObj.text.length + textNode.getAttr("partialText").length <= style.text.length) {
          Object.assign(charObj, style.attrs)
        }
      })
    })

    this.layer?.batchDraw()
  }

  applyTextFilter(id: string, filterType: string, filterValue: number) {
    // Implement logic to apply text filter
  }

  removeTextFilter(id: string) {
    // Implement logic to remove text filter
  }

  applyTextMask(id: string, maskType: "image" | "video", source: string) {
    const textNode = this.elements.get(id) as Konva.Text
    if (textNode) {
      if (maskType === "image") {
        const imageObj = new Image()
        imageObj.onload = () => {
          textNode.fillPriority("pattern")
          textNode.fillPatternImage(imageObj)
          textNode.fillPatternRepeat("no-repeat")
          textNode.fillPatternScale({
            x: textNode.width() / imageObj.width,
            y: textNode.height() / imageObj.height,
          })
          this.layer?.batchDraw()
        }
        imageObj.src = source
      } else if (maskType === "video") {
        const videoElement = document.createElement("video")
        videoElement.src = source
        videoElement.loop = true
        videoElement.muted = true
        videoElement.play()
        textNode.fillPriority("pattern")
        textNode.fillPatternImage(videoElement)
        textNode.fillPatternRepeat("no-repeat")
        const anim = new Konva.Animation(() => {}, this.layer)
        anim.start()
      }
    }
  }

  removeTextMask(id: string) {
    const textNode = this.elements.get(id) as Konva.Text
    if (!textNode) return

    textNode.fillPatternImage(null)
    textNode.clipFunc(null)
    this.layer?.batchDraw()
  }

  applyTextEffect(id: string, effect: "outline" | "shadow" | "glow", options: any) {
    const textNode = this.elements.get(id) as Konva.Text
    if (textNode) {
      switch (effect) {
        case "outline":
          textNode.stroke(options.color)
          textNode.strokeWidth(options.width)
          break
        case "shadow":
          textNode.shadowColor(options.color)
          textNode.shadowBlur(options.blur)
          textNode.shadowOffset({ x: options.offsetX, y: options.offsetY })
          textNode.shadowOpacity(options.opacity)
          break
        case "glow":
          textNode.shadowColor(options.color)
          textNode.shadowBlur(options.blur)
          textNode.shadowOpacity(1)
          textNode.shadowOffset({ x: 0, y: 0 })
          break
      }
      this.layer?.batchDraw()
    }
  }

  removeTextEffect(id: string, effectType: string) {
    // Implement logic to remove text effect
  }

  applyTextTransformation(id: string, transformationType: "circular" | "wavy", options: any) {
    const textNode = this.elements.get(id) as Konva.Text
    if (!textNode) return

    const originalText = textNode.text()
    const chars = originalText.split("")

    textNode.text("")

    switch (transformationType) {
      case "circular":
        const radius = options.radius || Math.min(textNode.width(), textNode.height()) / 2
        const startAngle = options.startAngle || 0
        chars.forEach((char, i) => {
          const angle = startAngle + (i / chars.length) * Math.PI * 2
          const charNode = new Konva.Text({
            text: char,
            fontSize: textNode.fontSize(),
            fontFamily: textNode.fontFamily(),
            fill: textNode.fill(),
            x: textNode.x() + radius + Math.cos(angle) * radius,
            y: textNode.y() + radius + Math.sin(angle) * radius,
            rotation: (angle * 180) / Math.PI + 90,
          })
          this.layer?.add(charNode)
        })
        break
      case "wavy":
        const amplitude = options.amplitude || 20
        const frequency = options.frequency || 0.1
        chars.forEach((char, i) => {
          const charNode = new Konva.Text({
            text: char,
            fontSize: textNode.fontSize(),
            fontFamily: textNode.fontFamily(),
            fill: textNode.fill(),
            x: textNode.x() + i * (textNode.width() / chars.length),
            y: textNode.y() + Math.sin(i * frequency) * amplitude,
          })
          this.layer?.add(charNode)
        })
        break
    }

    textNode.destroy()
    this.elements.delete(id)
    this.layer?.batchDraw()
  }

  removeTextTransformation(id: string) {
    // Implement logic to revert text to its original state
    // This might involve recreating the original text node and removing the transformed characters
  }

  onTextDoubleClick(handler: (id: string) => void) {
    this.textDoubleClickHandlers.push(handler)
  }

  offTextDoubleClick(handler: (id: string) => void) {
    this.textDoubleClickHandlers = this.textDoubleClickHandlers.filter((h) => h !== handler)
  }

  createEmptyTextElement(x: number, y: number): string {
    const id = uuidv4()
    const newElement = {
      type: "text",
      x: x,
      y: y,
      text: "New Text",
      fontSize: 24,
      fontFamily: "Arial",
      fill: "#000000",
      width: 200,
      height: 50,
      id: id,
      align: "left",
      fontStyle: "normal",
      textDecoration: "",
      wrap: "word",
      overflow: "clip",
      layerId: "default",
    }

    this.addTextElement(newElement)
    return id
  }

  enterTextEditMode(id: string, textNode: Konva.Text) {
    // Implementation will be added by the user
  }

  exitTextEditMode(id: string, textarea: HTMLTextAreaElement) {
    // Implementation will be added by the user
  }

  setTextWrap(id: string, wrap: string) {
    // Implementation will be added by the user
  }

  setTextOverflow(id: string, overflow: string) {
    // Implementation will be added by the user
  }

  setTextWidth(id: string, width: number) {
    // Implementation will be added by the user
  }

  calculateTextMetrics(text: string, fontSize: number, fontFamily: string): { width: number; height: number } {
    const tempText = new Konva.Text({
      text: text,
      fontSize: fontSize,
      fontFamily: fontFamily,
    })
    return { width: tempText.width(), height: tempText.height() }
  }

  autoSizeText(id: string, maxWidth: number, maxHeight: number) {
    const textNode = this.elements.get(id) as Konva.Text
    if (!textNode) return

    textNode.width(maxWidth)
    textNode.height(maxHeight)
    this.layer?.batchDraw()
  }

  createBezierCurve(points: number[]) {
    const id = uuidv4()
    const line = new Konva.Line({
      points: points,
      stroke: "black",
      strokeWidth: 2,
      lineCap: "round",
      lineJoin: "round",
      tension: 0.5,
      draggable: true,
      id: id,
    })
    this.elements.set(id, line)
    this.layer?.add(line)
    this.layer?.batchDraw()
    return id
  }

  addControlPoint(curveId: string, x: number, y: number) {
    const curve = this.elements.get(curveId) as Konva.Line
    if (curve) {
      const points = curve.points()
      points.push(x, y)
      curve.points(points)
      this.layer?.batchDraw()
    }
  }

  removeControlPoint(curveId: string, index: number) {
    const curve = this.elements.get(curveId) as Konva.Line
    if (curve) {
      const points = curve.points()
      points.splice(index * 2, 2)
      curve.points(points)
      this.layer?.batchDraw()
    }
  }

  updateControlPoint(curveId: string, index: number, x: number, y: number) {
    const curve = this.elements.get(curveId) as Konva.Line
    if (curve) {
      const points = curve.points()
      points[index * 2] = x
      points[index * 2 + 1] = y
      curve.points(points)
      this.layer?.batchDraw()
    }
  }

  createCustomShape(points: number[]) {
    const id = uuidv4()
    const shape = new Konva.Line({
      points: points,
      fill: "#00D2FF",
      stroke: "black",
      strokeWidth: 2,
      closed: true,
      draggable: true,
      id: id,
    })
    this.elements.set(id, shape)
    this.layer?.add(shape)
    this.layer?.batchDraw()
    return id
  }

  morphShape(fromShapeId: string, toShapeId: string, duration: number) {
    const fromShape = this.elements.get(fromShapeId) as Konva.Line
    const toShape = this.elements.get(toShapeId) as Konva.Line

    if (fromShape && toShape) {
      const fromPoints = fromShape.points()
      const toPoints = toShape.points()

      const tween = new Konva.Tween({
        node: fromShape,
        duration: duration,
        points: toPoints,
        easing: Konva.Easings.EaseInOut,
      })

      tween.play()
    }
  }

  applyPathEffect(id: string, effect: "zigzag" | "wave" | "roughen", intensity: number) {
    const shape = this.elements.get(id) as Konva.Line | Konva.Path
    if (shape) {
      const originalPoints = shape instanceof Konva.Line ? shape.points() : this.pathToPoints(shape.data())
      let newPoints: number[] = []

      switch (effect) {
        case "zigzag":
          newPoints = this.applyZigzagEffect(originalPoints, intensity)
          break
        case "wave":
          newPoints = this.applyWaveEffect(originalPoints, intensity)
          break
        case "roughen":
          newPoints = this.applyRoughenEffect(originalPoints, intensity)
          break
      }

      if (shape instanceof Konva.Line) {
        shape.points(newPoints)
      } else {
        shape.data(this.pointsToPath(newPoints))
      }
      this.layer?.batchDraw()
    }
  }

  private applyZigzagEffect(points: number[], intensity: number): number[] {
    const newPoints: number[] = []
    for (let i = 0; i < points.length - 2; i += 2) {
      const x1 = points[i]
      const y1 = points[i + 1]
      const x2 = points[i + 2]
      const y2 = points[i + 3]
      newPoints.push(x1, y1)
      const midX = (x1 + x2) / 2
      const midY = (y1 + y2) / 2
      const angle = Math.atan2(y2 - y1, x2 - x1) + Math.PI / 2
      const zigzagX = midX + Math.cos(angle) * intensity
      const zigzagY = midY + Math.sin(angle) * intensity
      newPoints.push(zigzagX, zigzagY)
    }
    newPoints.push(points[points.length - 2], points[points.length - 1])
    return newPoints
  }

  private applyWaveEffect(points: number[], intensity: number): number[] {
    const newPoints: number[] = []
    for (let i = 0; i < points.length - 2; i += 2) {
      const x1 = points[i]
      const y1 = points[i + 1]
      const x2 = points[i + 2]
      const y2 = points[i + 3]
      const distance = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2))
      const steps = Math.ceil(distance / 10)
      for (let j = 0; j < steps; j++) {
        const t = j / steps
        const x = x1 + (x2 - x1) * t
        const y = y1 + (y2 - y1) * t + Math.sin(t * Math.PI * 2) * intensity
        newPoints.push(x, y)
      }
    }
    newPoints.push(points[points.length - 2], points[points.length - 1])
    return newPoints
  }

  private applyRoughenEffect(points: number[], intensity: number): number[] {
    const newPoints: number[] = []
    for (let i = 0; i < points.length; i += 2) {
      const x = points[i] + (Math.random() - 0.5) * intensity * 2
      const y = points[i + 1] + (Math.random() - 0.5) * intensity * 2
      newPoints.push(x, y)
    }
    return newPoints
  }

  private pathToPoints(pathData: string): number[] {
    // Implement conversion from SVG path data to points
    // This is a simplified version and may need to be expanded for complex paths
    const numbers = pathData.match(/-?[\d.]+/g)
    return numbers ? numbers.map(Number) : []
  }

  private pointsToPath(points: number[]): string {
    // Implement conversion from points to SVG path data
    // This is a simplified version and may need to be expanded for complex paths
    let pathData = `M${points[0]},${points[1]}`
    for (let i = 2; i < points.length; i += 2) {
      pathData += ` L${points[i]},${points[i + 1]}`
    }
    return pathData
  }

  applyImageFilter(
    id: string,
    filter: "blur" | "brighten" | "contrast" | "emboss" | "enhance" | "grayscale" | "noise" | "pixelate",
    options: any,
  ) {
    const imageNode = this.elements.get(id) as Konva.Image
    if (imageNode) {
      switch (filter) {
        case "blur":
          imageNode.filters([Konva.Filters.Blur])
          imageNode.blurRadius(options.radius)
          break
        case "brighten":
          imageNode.filters([Konva.Filters.Brighten])
          imageNode.brightness(options.brightness)
          break
        case "contrast":
          imageNode.filters([Konva.Filters.Contrast])
          imageNode.contrast(options.contrast)
          break
        case "emboss":
          imageNode.filters([Konva.Filters.Emboss])
          imageNode.embossStrength(options.strength)
          imageNode.embossWhiteLevel(options.whiteLevel)
          imageNode.embossDirection(options.direction)
          imageNode.embossBlend(options.blend)
          break
        case "enhance":
          imageNode.filters([Konva.Filters.Enhance])
          imageNode.enhance(options.enhance)
          break
        case "grayscale":
          imageNode.filters([Konva.Filters.Grayscale])
          break
        case "noise":
          imageNode.filters([Konva.Filters.Noise])
          imageNode.noise(options.noise)
          break
        case "pixelate":
          imageNode.filters([Konva.Filters.Pixelate])
          imageNode.pixelSize(options.pixelSize)
          break
      }
      imageNode.cache()
      this.layer?.batchDraw()
    }
  }

  applyImageMask(id: string, maskType: "alpha" | "luminance", maskImage: string) {
    const imageNode = this.elements.get(id) as Konva.Image
    if (imageNode) {
      const mask = new Image()
      mask.onload = () => {
        imageNode.filters([Konva.Filters.Mask])
        imageNode.threshold(100)
        imageNode.mask(mask)
        if (maskType === "luminance") {
          imageNode.invertMask(true)
        }
        imageNode.cache()
        this.layer?.batchDraw()
      }
      mask.src = maskImage
    }
  }

  applyImageCrop(id: string, x: number, y: number, width: number, height: number) {
    const imageNode = this.elements.get(id) as Konva.Image
    if (imageNode) {
      imageNode.crop({
        x: x,
        y: y,
        width: width,
        height: height,
      })
      imageNode.width(width)
      imageNode.height(height)
      this.layer?.batchDraw()
    }
  }

  applyImageBlendMode(id: string, blendMode: string) {
    const imageNode = this.elements.get(id) as Konva.Image
    if (imageNode) {
      imageNode.globalCompositeOperation(blendMode)
      this.layer?.batchDraw()
    }
  }

  createImageCollage(imageIds: string[], layout: "grid" | "masonry", options: any) {
    const collageGroup = new Konva.Group()
    const images = imageIds.map((id) => this.elements.get(id) as Konva.Image).filter(Boolean)

    if (layout === "grid") {
      const { rows, cols } = options
      const cellWidth = options.width / cols
      const cellHeight = options.height / rows

      images.forEach((image, index) => {
        const row = Math.floor(index / cols)
        const col = index % cols
        image.width(cellWidth)
        image.height(cellHeight)
        image.x(col * cellWidth)
        image.y(row * cellHeight)
        collageGroup.add(image)
      })
    } else if (layout === "masonry") {
      const { columnWidth, gutter } = options
      const columnHeights = new Array(options.columns).fill(0)

      images.forEach((image) => {
        const shortestColumnIndex = columnHeights.indexOf(Math.min(...columnHeights))
        const aspectRatio = image.height() / image.width()
        const newWidth = columnWidth
        const newHeight = newWidth * aspectRatio

        image.width(newWidth)
        image.height(newHeight)
        image.x(shortestColumnIndex * (columnWidth + gutter))
        image.y(columnHeights[shortestColumnIndex])

        columnHeights[shortestColumnIndex] += newHeight + gutter
        collageGroup.add(image)
      })
    }

    const collageId = uuidv4()
    this.elements.set(collageId, collageGroup)
    this.layer?.add(collageGroup)
    this.layer?.batchDraw()
    return collageId
  }

  createKeyframe(elementId: string, time: number, properties: any) {
    const element = this.elements.get(elementId)
    if (element) {
      if (!element.attrs.keyframes) {
        element.attrs.keyframes = []
      }
      element.attrs.keyframes.push({ time, properties })
      element.attrs.keyframes.sort((a, b) => a.time - b.time)
    }
  }

  removeKeyframe(elementId: string, time: number) {
    const element = this.elements.get(elementId)
    if (element && element.attrs.keyframes) {
      element.attrs.keyframes = element.attrs.keyframes.filter((kf) => kf.time !== time)
    }
  }

  updateKeyframe(elementId: string, time: number, properties: any) {
    const element = this.elements.get(elementId)
    if (element && element.attrs.keyframes) {
      const keyframe = element.attrs.keyframes.find((kf) => kf.time === time)
      if (keyframe) {
        Object.assign(keyframe.properties, properties)
      }
    }
  }

  playAnimation(elementId: string, startTime: number, endTime: number, onFinish?: () => void) {
    const element = this.elements.get(elementId)
    if (element && element.attrs.keyframes) {
      const relevantKeyframes = element.attrs.keyframes.filter((kf) => kf.time >= startTime && kf.time <= endTime)
      if (relevantKeyframes.length < 2) return

      const duration = endTime - startTime
      const anim = new Konva.Animation((frame) => {
        if (frame) {
          const elapsedTime = (frame.time % duration) / 1000
          const currentTime = startTime + elapsedTime

          const prevKeyframe = relevantKeyframes.reduce((prev, curr) =>
            curr.time <= currentTime && curr.time > prev.time ? curr : prev,
          )
          const nextKeyframe =
            relevantKeyframes.find((kf) => kf.time > currentTime) || relevantKeyframes[relevantKeyframes.length - 1]

          const t = (currentTime - prevKeyframe.time) / (nextKeyframe.time - prevKeyframe.time)

          Object.keys(nextKeyframe.properties).forEach((key) => {
            const prevValue = prevKeyframe.properties[key]
            const nextValue = nextKeyframe.properties[key]
            const interpolatedValue = this.interpolateValue(prevValue, nextValue, t)
            element[key](interpolatedValue)
          })

          if (elapsedTime >= duration) {
            anim.stop()
            if (onFinish) onFinish()
          }
        }
      }, this.layer)

      anim.start()
    }
  }

  private interpolateValue(start: any, end: any, t: number): any {
    if (typeof start === "number" && typeof end === "number") {
      return start + (end - start) * t
    } else if (Array.isArray(start) && Array.isArray(end) && start.length === end.length) {
      return start.map((s, i) => this.interpolateValue(s, end[i], t))
    } else if (typeof start === "object" && typeof end === "object") {
      const result = {}
      Object.keys(start).forEach((key) => {
        result[key] = this.interpolateValue(start[key], end[key], t)
      })
      return result
    }
    return t < 0.5 ? start : end
  }

  applyEasing(elementId: string, easingFunction: string) {
    const element = this.elements.get(elementId)
    if (element) {
      element.attrs.easing = Konva.Easings[easingFunction]
    }
  }

  createMotionPath(elementId: string, path: string, duration: number, autoRotate = false) {
    const element = this.elements.get(elementId)
    if (element) {
      const pathNode = new Konva.Path({
        data: path,
        stroke: "transparent",
      })

      const anim = new Konva.Animation((frame) => {
        if (frame) {
          const t = (frame.time % duration) / duration
          const pos = pathNode.getPointAtLength(t * pathNode.getLength())
          element.position(pos)

          if (autoRotate) {
            const tangent = pathNode.getTangentAtLength(t * pathNode.getLength())
            element.rotation((Math.atan2(tangent.y, tangent.x) * 180) / Math.PI)
          }
        }
      }, this.layer)

      anim.start()
    }
  }

  async analyzeImage(id: string) {
    const imageNode = this.elements.get(id) as Konva.Image
    if (imageNode) {
      const imageUrl = imageNode.getAttr("src")
      const description = await aiHelper.generateImageDescription(imageUrl)
      return description
    }
    return null
  }

  async improveDesign() {
    const canvasDescription = this.describeCanvas()
    const suggestions = await aiHelper.suggestDesignImprovements(canvasDescription)
    return suggestions
  }

  async generateColorPalette(theme: string, numberOfColors: number) {
    const palette = await aiHelper.generateColorPalette(theme, numberOfColors)
    return palette
  }

  async generateText(prompt: string, length: "short" | "medium" | "long") {
    const text = await aiHelper.generateTextContent(prompt, length)
    return text
  }

  async improveLayout() {
    const elements = Array.from(this.elements.values()).map((el) => ({
      type: el.getClassName(),
      x: el.x(),
      y: el.y(),
      width: el.width(),
      height: el.height(),
    }))
    const suggestions = await aiHelper.suggestLayoutImprovements(elements)
    return suggestions
  }

  private describeCanvas(): string {
    const description = Array.from(this.elements.values())
      .map((el) => {
        const type = el.getClassName()
        const attrs = el.getAttrs()
        return `${type}: ${JSON.stringify(attrs)}`
      })
      .join("\n")
    return `Canvas size: ${this.stage?.width()}x${this.stage?.height()}\nElements:\n${description}`
  }

  createPolygon(points: number[]): string {
    const id = uuidv4()
    const polygon = new Konva.Line({
      points: points,
      fill: "#00D2FF",
      stroke: "black",
      strokeWidth: 2,
      closed: true,
      draggable: true,
      id: id,
    })
    this.elements.set(id, polygon)
    this.layer?.add(polygon)
    this.layer?.batchDraw()
    return id
  }

  createStar(x: number, y: number, numPoints: number, innerRadius: number, outerRadius: number): string {
    const id = uuidv4()
    const star = new Konva.Star({
      x: x,
      y: y,
      numPoints: numPoints,
      innerRadius: innerRadius,
      outerRadius: outerRadius,
      fill: "#89b717",
      stroke: "black",
      strokeWidth: 2,
      draggable: true,
      id: id,
    })
    this.elements.set(id, star)
    this.layer?.add(star)
    this.layer?.batchDraw()
    return id
  }

  createArrow(points: number[]): string {
    const id = uuidv4()
    const arrow = new Konva.Arrow({
      points: points,
      pointerLength: 10,
      pointerWidth: 10,
      fill: "black",
      stroke: "black",
      strokeWidth: 4,
      draggable: true,
      id: id,
    })
    this.elements.set(id, arrow)
    this.layer?.add(arrow)
    this.layer?.batchDraw()
    return id
  }

  combineShapes(shapeIds: string[], operation: "union" | "intersection" | "difference" | "xor"): string {
    const shapes = shapeIds.map((id) => this.elements.get(id)).filter(Boolean) as Konva.Shape[]
    if (shapes.length < 2) return ""

    const path = new Konva.Path({
      data: "",
      fill: shapes[0].fill(),
      stroke: shapes[0].stroke(),
      strokeWidth: shapes[0].strokeWidth(),
      draggable: true,
    })

    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")!

    shapes.forEach((shape, index) => {
      const dataUrl = shape.toDataURL()
      const img = new Image()
      img.onload = () => {
        if (index === 0) {
          ctx.drawImage(img, 0, 0)
        } else {
          ctx.globalCompositeOperation = operation as GlobalCompositeOperation
          ctx.drawImage(img, 0, 0)
        }
        if (index === shapes.length - 1) {
          const dataUrl = canvas.toDataURL()
          const newImg = new Image()
          newImg.onload = () => {
            path.data(this.imageToSVGPath(newImg))
            this.layer?.batchDraw()
          }
          newImg.src = dataUrl
        }
      }
      img.src = dataUrl
    })

    const id = uuidv4()
    this.elements.set(id, path)
    this.layer?.add(path)
    shapeIds.forEach((id) => this.removeElement(id))
    return id
  }

  private imageToSVGPath(img: HTMLImageElement): string {
    const canvas = document.createElement("canvas")
    canvas.width = img.width
    canvas.height = img.height
    const ctx = canvas.getContext("2d")!
    ctx.drawImage(img, 0, 0)
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
    const potrace = new Potrace()
    potrace.setParameters({
      turdSize: 2,
      turnPolicy: Potrace.TURNPOLICY_MINORITY,
      alphaMax: 1,
      optCurve: true,
      optTolerance: 0.2,
      threshold: 128,
      blackOnWhite: true,
      background: Potrace.COLOR_TRANSPARENT,
    })
    potrace.loadImageFromCanvas(canvas)
    return potrace.getSVG(1)
  }

  convertToPath(shape: Konva.Shape) {
    const path = new Konva.Path({
      data: shape.toDataURL(),
      fill: shape.fill(),
      stroke: shape.stroke(),
      strokeWidth: shape.strokeWidth(),
    })
    shape.destroy()
    return path
  }

  editPath(path: Konva.Path) {
    const points = path.dataArray.map((cmd) => ({ x: cmd.points[0], y: cmd.points[1] }))
    const anchors = points.map(
      (point) =>
        new Konva.Circle({
          x: point.x,
          y: point.y,
          radius: 4,
          fill: "white",
          stroke: "black",
          strokeWidth: 1,
          draggable: true,
        }),
    )

    anchors.forEach((anchor, i) => {
      anchor.on("dragmove", () => {
        path.dataArray[i].points = [anchor.x(), anchor.y()]
        path.data(path.dataArray.map((cmd) => `${cmd.command}${cmd.points.join(",")}`).join(" "))
      })
    })

    return anchors
  }

  smoothPath(path: Konva.Path, tension = 0.5) {
    const points = path.dataArray.flatMap((cmd) => cmd.points)
    const smoothedPoints = Konva.Util.getControlPoints(points, tension)
    const newData = `M${points[0]},${points[1]} Q${smoothedPoints.join(" ")}`
    path.data(newData)
  }

  addEllipse(element: Element) {
    const ellipse = new Konva.Ellipse({
      x: element.x,
      y: element.y,
      radiusX: element.radiusX,
      radiusY: element.radiusY,
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })

    this.elements.set(element.id, ellipse)
    this.layer?.add(ellipse)
    this.layer?.batchDraw()
  }

  enableTextTransformer(id: string) {
    const textNode = this.elements.get(id) as Konva.Text
    if (textNode && textNode instanceof Konva.Text) {
      this.stage?.find("Transformer").destroy()
      const tr = new Konva.Transformer({
        node: textNode,
        enabledAnchors: ["middle-left", "middle-right"],
        boundBoxFunc: (oldBox, newBox) => {
          newBox.width = Math.max(30, newBox.width)
          return newBox
        },
      })
      this.layer?.add(tr)
      this.layer?.batchDraw()
    }
  }

  enableTransformer(ids: string[]) {
    const shapes = ids.map((id) => this.elements.get(id)).filter(Boolean)
    if (shapes.length > 0) {
      this.stage?.find("Transformer").destroy()
      const tr = new Konva.Transformer({
        nodes: shapes,
        rotateAnchorOffset: 30,
        enabledAnchors: ["top-left", "top-right", "bottom-left", "bottom-right"],
        boundBoxFunc: (oldBox, newBox) => {
          // Limit resize
          if (newBox.width < 5 || newBox.height < 5) {
            return oldBox
          }
          return newBox
        },
      })
      this.layer?.add(tr)
      this.layer?.batchDraw()
    }
  }

  disableTransformer() {
    this.stage?.find("Transformer").destroy()
    this.layer?.batchDraw()
  }

  alignElements(ids: string[], alignment: "left" | "center" | "right" | "top" | "middle" | "bottom") {
    const elements = ids.map((id) => this.elements.get(id)).filter(Boolean)
    if (elements.length < 2) return

    const bbox = this.getBoundingBox(elements)

    elements.forEach((el) => {
      switch (alignment) {
        case "left":
          el.x(bbox.x)
          break
        case "center":
          el.x(bbox.x + (bbox.width - el.width()) / 2)
          break
        case "right":
          el.x(bbox.x + bbox.width - el.width())
          break
        case "top":
          el.y(bbox.y)
          break
        case "middle":
          el.y(bbox.y + (bbox.height - el.height()) / 2)
          break
        case "bottom":
          el.y(bbox.y + bbox.height - el.height())
          break
      }
    })

    this.layer?.batchDraw()
  }

  distributeElements(ids: string[], distribution: "horizontal" | "vertical") {
    const elements = ids.map((id) => this.elements.get(id)).filter(Boolean)
    if (elements.length < 3) return

    const sortedElements = elements.sort((a, b) => {
      return distribution === "horizontal" ? a.x() - b.x() : a.y() - b.y()
    })

    const first = sortedElements[0]
    const last = sortedElements[sortedElements.length - 1]
    const totalSpace =
      distribution === "horizontal" ? last.x() + last.width() - first.x() : last.y() + last.height() - first.y()

    const spacing = totalSpace / (elements.length - 1)

    sortedElements.forEach((el, index) => {
      if (index > 0 && index < sortedElements.length - 1) {
        if (distribution === "horizontal") {
          el.x(first.x() + spacing * index)
        } else {
          el.y(first.y() + spacing * index)
        }
      }
    })

    this.layer?.batchDraw()
  }

  private getBoundingBox(elements: Konva.Node[]): { x: number; y: number; width: number; height: number } {
    let minX = Number.POSITIVE_INFINITY,
      minY = Number.POSITIVE_INFINITY,
      maxX = Number.NEGATIVE_INFINITY,
      maxY = Number.NEGATIVE_INFINITY

    elements.forEach((el) => {
      const box = el.getClientRect()
      minX = Math.min(minX, box.x)
      minY = Math.min(minY, box.y)
      maxX = Math.max(maxX, box.x + box.width)
      maxY = Math.max(maxY, box.y + box.height)
    })

    return {
      x: minX,
      y: minY,
      width: maxX - minX,
      height: maxY - minY,
    }
  }

  flipElement(id: string, direction: "horizontal" | "vertical") {
    const element = this.elements.get(id)
    if (element) {
      if (direction === "horizontal") {
        element.scaleX(element.scaleX() * -1)
      } else {
        element.scaleY(element.scaleY() * -1)
      }
      this.layer?.batchDraw()
    }
  }

  rotateElement(id: string, angle: number) {
    const element = this.elements.get(id)
    if (element) {
      element.rotation(angle)
      this.layer?.batchDraw()
    }
  }

  setElementOpacity(id: string, opacity: number) {
    const element = this.elements.get(id)
    if (element) {
      element.opacity(opacity)
      this.layer?.batchDraw()
    }
  }

  lockElement(id: string) {
    const element = this.elements.get(id)
    if (element) {
      element.draggable(false)
      element.setAttr("locked", true)
    }
  }

  unlockElement(id: string) {
    const element = this.elements.get(id)
    if (element) {
      element.draggable(true)
      element.setAttr("locked", false)
    }
  }

  groupElements(ids: string[]) {
    const elements = ids.map((id) => this.elements.get(id)).filter(Boolean)
    if (elements.length < 2) return

    const group = new Konva.Group()
    elements.forEach((el) => {
      el.moveTo(group)
      this.elements.delete(el.id())
    })

    const groupId = uuidv4()
    group.id(groupId)
    this.elements.set(groupId, group)
    this.layer?.add(group)
    this.layer?.batchDraw()

    return groupId
  }

  ungroupElements(groupId: string) {
    const group = this.elements.get(groupId) as Konva.Group
    if (group && group instanceof Konva.Group) {
      const childIds: string[] = []
      group.getChildren().each((child) => {
        child.moveTo(this.layer!)
        const childId = child.id() || uuidv4()
        child.id(childId)
        this.elements.set(childId, child)
        childIds.push(childId)
      })
      group.destroy()
      this.elements.delete(groupId)
      this.layer?.batchDraw()
      return childIds
    }
    return null
  }

  transformElement(
    id: string,
    transformProps: {
      x?: number
      y?: number
      width?: number
      height?: number
      rotation?: number
      scaleX?: number
      scaleY?: number
    },
  ) {
    const element = this.elements.get(id)
    if (element) {
      element.setAttrs(transformProps)
      this.layer?.batchDraw()
    }
  }

  snapToGrid(value: number, gridSize = 10): number {
    return Math.round(value / gridSize) * gridSize
  }

  enableTransformer(
    ids: string[],
    options: {
      keepRatio?: boolean
      enabledAnchors?: string[]
      boundBoxFunc?: (oldBox: Konva.Box, newBox: Konva.Box) => Konva.Box
    } = {},
  ) {
    const shapes = ids.map((id) => this.elements.get(id)).filter(Boolean)
    if (shapes.length > 0) {
      this.stage?.find("Transformer").destroy()
      const tr = new Konva.Transformer({
        nodes: shapes,
        rotateAnchorOffset: 30,
        enabledAnchors: options.enabledAnchors || ["top-left", "top-right", "bottom-left", "bottom-right"],
        keepRatio: options.keepRatio || false,
        boundBoxFunc:
          options.boundBoxFunc ||
          ((oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox
            }
            return newBox
          }),
      })
      this.layer?.add(tr)
      this.layer?.batchDraw()
    }
  }

  addEllipse(element: Element) {
    const ellipse = new Konva.Ellipse({
      x: element.x,
      y: element.y,
      radiusX: element.radiusX,
      radiusY: element.radiusY,
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })

    this.elements.set(element.id, ellipse)
    this.layer?.add(ellipse)
    this.layer?.batchDraw()
  }

  interpolateKeyframes(element: Konva.Node, keyframes: any[], currentTime: number) {
    if (keyframes.length < 2) return

    const [prevKeyframe, nextKeyframe] = this.findSurroundingKeyframes(keyframes, currentTime)

    const timeDiff = nextKeyframe.time - prevKeyframe.time
    const progress = (currentTime - prevKeyframe.time) / timeDiff

    const interpolatedProps = {}
    for (const prop in prevKeyframe.props) {
      if (prop in nextKeyframe.props) {
        interpolatedProps[prop] = this.interpolateValue(prevKeyframe.props[prop], nextKeyframe.props[prop], progress)
      }
    }

    element.setAttrs(interpolatedProps)
  }

  private findSurroundingKeyframes(keyframes: any[], currentTime: number) {
    let prevKeyframe = keyframes[0]
    let nextKeyframe = keyframes[keyframes.length - 1]

    for (let i = 0; i < keyframes.length - 1; i++) {
      if (keyframes[i].time <= currentTime && keyframes[i + 1].time > currentTime) {
        prevKeyframe = keyframes[i]
        nextKeyframe = keyframes[i + 1]
        break
      }
    }

    return [prevKeyframe, nextKeyframe]
  }

  private interpolateValue(start: any, end: any, progress: number) {
    if (typeof start === "number" && typeof end === "number") {
      return start + (end - start) * progress
    }
    if (Array.isArray(start) && Array.isArray(end) && start.length === end.length) {
      return start.map((s, i) => this.interpolateValue(s, end[i], progress))
    }
    // Add more cases for other types as needed
    return progress < 0.5 ? start : end
  }

  private markLayerAsDirty(layerId: string) {
    this.dirtyLayers.add(layerId)
  }

  private getCachedLayer(layerId: string): Konva.Layer {
    if (!this.cachedLayers.has(layerId)) {
      const layer = new Konva.Layer()
      this.cachedLayers.set(layerId, layer)
      this.stage?.add(layer)
    }
    return this.cachedLayers.get(layerId)!
  }

  render() {
    this.dirtyLayers.forEach((layerId) => {
      const layer = this.getCachedLayer(layerId)
      layer.clear()
      this.elements.forEach((element: any) => {
        if (element.layerId === layerId) {
          layer.add(element)
        }
      })
      layer.batchDraw()
    })
    this.dirtyLayers.clear()
  }
}

export const konvaWrapper = new KonvaWrapper()

