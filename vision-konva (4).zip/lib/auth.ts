import type { NextAuthOptions } from "next-auth"
import { PrismaAdapter } from "@next-auth/prisma-adapter"
import { prisma } from "@/lib/db"
import GoogleProvider from "next-auth/providers/google"
import DropboxProvider from "next-auth/providers/dropbox"
import AzureADProvider from "next-auth/providers/azure-ad"
import { IntegrationService } from "@/lib/integration-service"

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          scope: "openid email profile https://www.googleapis.com/auth/drive",
          prompt: "consent",
          access_type: "offline",
        },
      },
    }),
    DropboxProvider({
      clientId: process.env.DROPBOX_CLIENT_ID!,
      clientSecret: process.env.DROPBOX_CLIENT_SECRET!,
      authorization: {
        params: {
          scope: "files.content.read files.content.write files.metadata.read files.metadata.write",
        },
      },
    }),
    AzureADProvider({
      clientId: process.env.AZURE_AD_CLIENT_ID!,
      clientSecret: process.env.AZURE_AD_CLIENT_SECRET!,
      tenantId: process.env.AZURE_AD_TENANT_ID,
      authorization: {
        params: {
          scope: "openid email profile offline_access Files.ReadWrite.All",
        },
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      // Initial sign in
      if (account && user) {
        // Save the integration if it's a supported provider
        if (account.provider === "google" || account.provider === "dropbox" || account.provider === "azure-ad") {
          const provider = account.provider === "azure-ad" ? "onedrive" : account.provider

          await IntegrationService.saveIntegration(user.id, provider as any, account.providerAccountId, {
            accessToken: account.access_token!,
            refreshToken: account.refresh_token,
            expiresAt: account.expires_at ? new Date(account.expires_at * 1000) : undefined,
            scope: account.scope,
          })
        }

        return {
          ...token,
          id: user.id,
          role: (user as any).role || "user",
        }
      }

      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
        session.user.role = token.role as string
      }
      return session
    },
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
  session: {
    strategy: "jwt",
  },
}

