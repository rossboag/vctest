import { act } from "@testing-library/react"
import jest from "jest-mock"

// Mock window.matchMedia for tests
export function mockMatchMedia() {
  Object.defineProperty(window, "matchMedia", {
    writable: true,
    value: jest.fn().mockImplementation((query) => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(), // Deprecated
      removeListener: jest.fn(), // Deprecated
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    })),
  })
}

// Mock ResizeObserver for tests
export function mockResizeObserver() {
  global.ResizeObserver = class ResizeObserver {
    observe = jest.fn()
    unobserve = jest.fn()
    disconnect = jest.fn()
  }
}

// Mock Intersection Observer for tests
export function mockIntersectionObserver() {
  global.IntersectionObserver = class IntersectionObserver {
    constructor(callback) {
      this.callback = callback
    }
    observe = jest.fn()
    unobserve = jest.fn()
    disconnect = jest.fn()
    trigger = (entries) => this.callback(entries, this)
  }
}

// Helper to simulate window resize
export function resizeWindow(width, height) {
  Object.defineProperty(window, "innerWidth", { writable: true, configurable: true, value: width })
  Object.defineProperty(window, "innerHeight", { writable: true, configurable: true, value: height })
  window.dispatchEvent(new Event("resize"))
}

// Helper to simulate orientation change
export function changeOrientation(isPortrait) {
  const mediaQueryList = {
    matches: isPortrait,
    media: "(orientation: portrait)",
    onchange: null,
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
  }

  jest.spyOn(window, "matchMedia").mockImplementation((query) => {
    if (query === "(orientation: portrait)") {
      return mediaQueryList
    }
    return {
      matches: false,
      media: query,
      onchange: null,
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
    }
  })

  window.dispatchEvent(new Event("orientationchange"))
}

// Helper to simulate touch events
export function createTouchEvent(type, touches = []) {
  const event = new Event(type, { bubbles: true })
  Object.defineProperty(event, "touches", {
    value: touches.map((touch, index) => ({
      identifier: index,
      clientX: touch.x,
      clientY: touch.y,
      target: document.body,
    })),
  })
  return event
}

// Helper to simulate pinch gesture
export async function simulatePinchGesture(element, startDistance, endDistance) {
  const startTouches = [
    { x: 100, y: 100 },
    { x: 100 + startDistance, y: 100 },
  ]

  const endTouches = [
    { x: 100, y: 100 },
    { x: 100 + endDistance, y: 100 },
  ]

  const touchStartEvent = createTouchEvent("touchstart", startTouches)
  const touchMoveEvent = createTouchEvent("touchmove", endTouches)
  const touchEndEvent = createTouchEvent("touchend", [])

  await act(async () => {
    element.dispatchEvent(touchStartEvent)
    element.dispatchEvent(touchMoveEvent)
    element.dispatchEvent(touchEndEvent)
  })
}

