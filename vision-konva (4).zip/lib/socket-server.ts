import type { Server as NetServer } from "http"
import { Server as SocketIOServer } from "socket.io"
import type { NextApiRequest } from "next"
import { getToken } from "next-auth/jwt"
import { prisma } from "./db"

export type SocketUser = {
  id: string
  name: string
  email: string
  role: string
}

export type SocketClient = {
  userId: string
  socketId: string
  projectId: string
  lastActivity: Date
  cursor?: { x: number; y: number }
}

// Store active clients
const clients: Record<string, SocketClient[]> = {}

// Initialize Socket.IO server
export function initSocketServer(server: NetServer) {
  const io = new SocketIOServer(server, {
    path: "/api/socketio",
    cors: {
      origin: process.env.NEXTAUTH_URL || "http://localhost:3000",
      methods: ["GET", "POST"],
      credentials: true,
    },
  })

  // Middleware to authenticate socket connections
  io.use(async (socket, next) => {
    try {
      const req = socket.request as NextApiRequest
      const token = await getToken({ req })

      if (!token) {
        return next(new Error("Authentication error"))
      }

      // Attach user to socket
      socket.data.user = {
        id: token.sub as string,
        name: token.name as string,
        email: token.email as string,
        role: token.role as string,
      }

      next()
    } catch (error) {
      next(new Error("Authentication error"))
    }
  })

  io.on("connection", (socket) => {
    const user = socket.data.user as SocketUser

    console.log(`User connected: ${user.name} (${user.id})`)

    // Handle joining a project
    socket.on("join-project", async (projectId: string) => {
      try {
        // Check if user has access to this project
        const project = await prisma.project.findUnique({
          where: {
            id: projectId,
          },
        })

        if (!project || (project.userId !== user.id && user.role !== "admin")) {
          socket.emit("error", "You don't have access to this project")
          return
        }

        // Join the project room
        socket.join(`project:${projectId}`)

        // Add client to clients list
        const client: SocketClient = {
          userId: user.id,
          socketId: socket.id,
          projectId,
          lastActivity: new Date(),
        }

        if (!clients[projectId]) {
          clients[projectId] = []
        }

        clients[projectId].push(client)

        // Notify other users in the project
        socket.to(`project:${projectId}`).emit("user-joined", {
          userId: user.id,
          name: user.name,
        })

        // Send list of active users to the new user
        const activeUsers = clients[projectId].map((client) => ({
          userId: client.userId,
          name: client.userId === user.id ? `${user.name} (You)` : user.name,
          cursor: client.cursor,
        }))

        socket.emit("active-users", activeUsers)

        console.log(`User ${user.name} joined project ${projectId}`)
      } catch (error) {
        console.error("Error joining project:", error)
        socket.emit("error", "Failed to join project")
      }
    })

    // Handle leaving a project
    socket.on("leave-project", (projectId: string) => {
      socket.leave(`project:${projectId}`)

      // Remove client from clients list
      if (clients[projectId]) {
        clients[projectId] = clients[projectId].filter((client) => client.socketId !== socket.id)

        if (clients[projectId].length === 0) {
          delete clients[projectId]
        }
      }

      // Notify other users in the project
      socket.to(`project:${projectId}`).emit("user-left", {
        userId: user.id,
        name: user.name,
      })

      console.log(`User ${user.name} left project ${projectId}`)
    })

    // Handle element changes
    socket.on("element-update", (projectId: string, elementId: string, properties: any) => {
      // Update last activity
      const clientIndex = clients[projectId]?.findIndex((client) => client.socketId === socket.id)

      if (clientIndex !== undefined && clientIndex >= 0) {
        clients[projectId][clientIndex].lastActivity = new Date()
      }

      // Broadcast to other users in the project
      socket.to(`project:${projectId}`).emit("element-updated", {
        userId: user.id,
        elementId,
        properties,
      })
    })

    // Handle element creation
    socket.on("element-create", (projectId: string, element: any) => {
      // Update last activity
      const clientIndex = clients[projectId]?.findIndex((client) => client.socketId === socket.id)

      if (clientIndex !== undefined && clientIndex >= 0) {
        clients[projectId][clientIndex].lastActivity = new Date()
      }

      // Broadcast to other users in the project
      socket.to(`project:${projectId}`).emit("element-created", {
        userId: user.id,
        element,
      })
    })

    // Handle element deletion
    socket.on("element-delete", (projectId: string, elementId: string) => {
      // Update last activity
      const clientIndex = clients[projectId]?.findIndex((client) => client.socketId === socket.id)

      if (clientIndex !== undefined && clientIndex >= 0) {
        clients[projectId][clientIndex].lastActivity = new Date()
      }

      // Broadcast to other users in the project
      socket.to(`project:${projectId}`).emit("element-deleted", {
        userId: user.id,
        elementId,
      })
    })

    // Handle cursor movement
    socket.on("cursor-move", (projectId: string, position: { x: number; y: number }) => {
      // Update cursor position
      const clientIndex = clients[projectId]?.findIndex((client) => client.socketId === socket.id)

      if (clientIndex !== undefined && clientIndex >= 0) {
        clients[projectId][clientIndex].cursor = position
      }

      // Broadcast to other users in the project
      socket.to(`project:${projectId}`).emit("cursor-moved", {
        userId: user.id,
        name: user.name,
        position,
      })
    })

    // Handle disconnection
    socket.on("disconnect", () => {
      console.log(`User disconnected: ${user.name} (${user.id})`)

      // Remove client from all projects
      Object.keys(clients).forEach((projectId) => {
        const clientIndex = clients[projectId].findIndex((client) => client.socketId === socket.id)

        if (clientIndex >= 0) {
          // Notify other users in the project
          socket.to(`project:${projectId}`).emit("user-left", {
            userId: user.id,
            name: user.name,
          })

          // Remove client
          clients[projectId].splice(clientIndex, 1)

          if (clients[projectId].length === 0) {
            delete clients[projectId]
          }
        }
      })
    })
  })

  return io
}

// Get active users in a project
export function getActiveUsers(projectId: string) {
  return clients[projectId] || []
}

// Check if a user is active in a project
export function isUserActive(projectId: string, userId: string) {
  return clients[projectId]?.some((client) => client.userId === userId) || false
}

