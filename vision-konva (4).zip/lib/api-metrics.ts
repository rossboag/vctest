import { prisma } from "@/lib/db"
import { type NextRequest, NextResponse } from "next/server"

export async function trackApiMetric(req: NextRequest, res: NextResponse, startTime: number, userId?: string) {
  const endTime = performance.now()
  const responseTime = endTime - startTime

  try {
    await prisma.apiMetric.create({
      data: {
        endpoint: req.nextUrl.pathname,
        method: req.method,
        statusCode: res.status,
        responseTime,
        userId,
      },
    })
  } catch (error) {
    console.error("Failed to track API metric:", error)
  }
}

export function withApiMetrics(handler: (req: NextRequest) => Promise<NextResponse>) {
  return async (req: NextRequest) => {
    const startTime = performance.now()

    try {
      const res = await handler(req)
      await trackApiMetric(req, res, startTime)
      return res
    } catch (error) {
      const errorResponse = NextResponse.json({ error: "Internal Server Error" }, { status: 500 })
      await trackApiMetric(req, errorResponse, startTime)
      throw error
    }
  }
}

