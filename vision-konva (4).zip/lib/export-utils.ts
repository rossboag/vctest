import { createCanvas, loadImage } from "canvas"
import sharp from "sharp"
import fs from "fs"
import path from "path"
import { v4 as uuidv4 } from "uuid"
import { exec } from "child_process"
import util from "util"
import os from "os"

const execPromise = util.promisify(exec)

// Temporary directory for file operations
const TEMP_DIR = path.join(os.tmpdir(), "vision-creator-exports")

// Ensure temp directory exists
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true })
}

export interface ExportOptions {
  width: number
  height: number
  format: "png" | "jpeg" | "svg" | "mp4" | "gif"
  quality?: number
  fps?: number
  duration?: number
  elements: any[]
  background?: string
}

export interface ExportResult {
  url: string
  filename: string
  mimeType: string
}

export const exportUtils = {
  /**
   * Export a static image (PNG, JPEG, SVG)
   */
  async exportImage(options: ExportOptions): Promise<ExportResult> {
    const { width, height, format, quality = 90, elements, background = "#ffffff" } = options

    // Create a canvas with the specified dimensions
    const canvas = createCanvas(width, height)
    const ctx = canvas.getContext("2d")

    // Fill background
    ctx.fillStyle = background
    ctx.fillRect(0, 0, width, height)

    // Render elements to canvas
    await this.renderElementsToCanvas(ctx, elements)

    // Generate a unique filename
    const filename = `export-${uuidv4()}.${format}`
    const filepath = path.join(TEMP_DIR, filename)

    // Export based on format
    let buffer: Buffer
    let mimeType: string

    if (format === "svg") {
      // For SVG, generate an SVG string
      const svgString = this.generateSVG(width, height, elements, background)
      fs.writeFileSync(filepath, svgString)
      buffer = Buffer.from(svgString)
      mimeType = "image/svg+xml"
    } else {
      // For PNG and JPEG, use the canvas
      buffer =
        format === "png" ? canvas.toBuffer("image/png") : canvas.toBuffer("image/jpeg", { quality: quality / 100 })
      fs.writeFileSync(filepath, buffer)
      mimeType = format === "png" ? "image/png" : "image/jpeg"
    }

    // In a real implementation, you would upload this file to S3 or similar
    // For now, we'll just return a local file path
    return {
      url: `/api/exports/${filename}`,
      filename,
      mimeType,
    }
  },

  /**
   * Export an animation (GIF)
   */
  async exportGIF(options: ExportOptions): Promise<ExportResult> {
    const { width, height, fps = 30, duration = 5, elements, background = "#ffffff" } = options

    // Calculate total frames
    const totalFrames = fps * duration

    // Create a temporary directory for frames
    const framesDir = path.join(TEMP_DIR, `frames-${uuidv4()}`)
    fs.mkdirSync(framesDir, { recursive: true })

    // Generate frames
    for (let i = 0; i < totalFrames; i++) {
      const progress = i / totalFrames
      const canvas = createCanvas(width, height)
      const ctx = canvas.getContext("2d")

      // Fill background
      ctx.fillStyle = background
      ctx.fillRect(0, 0, width, height)

      // Render elements at this point in time
      await this.renderElementsToCanvas(ctx, elements, progress)

      // Save frame
      const frameFilepath = path.join(framesDir, `frame-${i.toString().padStart(6, "0")}.png`)
      fs.writeFileSync(frameFilepath, canvas.toBuffer("image/png"))
    }

    // Generate a unique filename for the output
    const filename = `export-${uuidv4()}.gif`
    const filepath = path.join(TEMP_DIR, filename)

    // Use sharp to create a GIF from the frames
    const frameFiles = fs
      .readdirSync(framesDir)
      .filter((file) => file.startsWith("frame-"))
      .sort()
      .map((file) => path.join(framesDir, file))

    // Create GIF using sharp
    const firstFrame = await sharp(frameFiles[0]).toBuffer()
    const otherFrames = frameFiles.slice(1).map((file) => ({ input: file, delay: Math.round(1000 / fps) }))

    await sharp(firstFrame, { animated: true })
      .gif({
        delay: Math.round(1000 / fps),
        loop: 0, // 0 means loop forever
      })
      .toFile(filepath)

    // Clean up frame directory
    for (const file of frameFiles) {
      fs.unlinkSync(file)
    }
    fs.rmdirSync(framesDir)

    // In a real implementation, you would upload this file to S3 or similar
    // For now, we'll just return a local file path
    return {
      url: `/api/exports/${filename}`,
      filename,
      mimeType: "image/gif",
    }
  },

  /**
   * Export a video (MP4)
   */
  async exportVideo(options: ExportOptions): Promise<ExportResult> {
    const { width, height, fps = 30, duration = 5, elements, background = "#ffffff" } = options

    // Calculate total frames
    const totalFrames = fps * duration

    // Create a temporary directory for frames
    const framesDir = path.join(TEMP_DIR, `frames-${uuidv4()}`)
    fs.mkdirSync(framesDir, { recursive: true })

    // Generate frames
    for (let i = 0; i < totalFrames; i++) {
      const progress = i / totalFrames
      const canvas = createCanvas(width, height)
      const ctx = canvas.getContext("2d")

      // Fill background
      ctx.fillStyle = background
      ctx.fillRect(0, 0, width, height)

      // Render elements at this point in time
      await this.renderElementsToCanvas(ctx, elements, progress)

      // Save frame
      const frameFilepath = path.join(framesDir, `frame-${i.toString().padStart(6, "0")}.png`)
      fs.writeFileSync(frameFilepath, canvas.toBuffer("image/png"))
    }

    // Generate a unique filename for the output
    const filename = `export-${uuidv4()}.mp4`
    const filepath = path.join(TEMP_DIR, filename)

    // Use ffmpeg to create a video from the frames
    // Note: This requires ffmpeg to be installed on the server
    try {
      await execPromise(
        `ffmpeg -framerate ${fps} -i ${path.join(
          framesDir,
          "frame-%06d.png",
        )} -c:v libx264 -pix_fmt yuv420p -crf 23 ${filepath}`,
      )
    } catch (error) {
      console.error("Error creating video:", error)
      throw new Error("Failed to create video")
    }

    // Clean up frame directory
    const frameFiles = fs.readdirSync(framesDir)
    for (const file of frameFiles) {
      fs.unlinkSync(path.join(framesDir, file))
    }
    fs.rmdirSync(framesDir)

    // In a real implementation, you would upload this file to S3 or similar
    // For now, we'll just return a local file path
    return {
      url: `/api/exports/${filename}`,
      filename,
      mimeType: "video/mp4",
    }
  },

  /**
   * Render elements to a canvas context
   */
  async renderElementsToCanvas(ctx: CanvasRenderingContext2D, elements: any[], progress = 0): Promise<void> {
    // Sort elements by z-index
    const sortedElements = [...elements].sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0))

    // Render each element
    for (const element of sortedElements) {
      await this.renderElement(ctx, element, progress)
    }
  },

  /**
   * Render a single element to a canvas context
   */
  async renderElement(ctx: CanvasRenderingContext2D, element: any, progress = 0): Promise<void> {
    // Save the current context state
    ctx.save()

    // Apply transformations
    const { x = 0, y = 0, width = 100, height = 100, rotation = 0, opacity = 1, scaleX = 1, scaleY = 1 } = element

    // Apply animations if present
    const animatedProps = this.getAnimatedProperties(element, progress)
    const animX = animatedProps.x !== undefined ? animatedProps.x : x
    const animY = animatedProps.y !== undefined ? animatedProps.y : y
    const animWidth = animatedProps.width !== undefined ? animatedProps.width : width
    const animHeight = animatedProps.height !== undefined ? animatedProps.height : height
    const animRotation = animatedProps.rotation !== undefined ? animatedProps.rotation : rotation
    const animOpacity = animatedProps.opacity !== undefined ? animatedProps.opacity : opacity
    const animScaleX = animatedProps.scaleX !== undefined ? animatedProps.scaleX : scaleX
    const animScaleY = animatedProps.scaleY !== undefined ? animatedProps.scaleY : scaleY

    // Set global alpha for opacity
    ctx.globalAlpha = animOpacity

    // Apply transformations
    ctx.translate(animX + animWidth / 2, animY + animHeight / 2)
    ctx.rotate((animRotation * Math.PI) / 180)
    ctx.scale(animScaleX, animScaleY)
    ctx.translate(-animWidth / 2, -animHeight / 2)

    // Render based on element type
    switch (element.type) {
      case "rect":
        this.renderRect(ctx, element, animWidth, animHeight)
        break
      case "circle":
        this.renderCircle(ctx, element, animWidth, animHeight)
        break
      case "text":
        this.renderText(ctx, element, animWidth, animHeight)
        break
      case "image":
        await this.renderImage(ctx, element, animWidth, animHeight)
        break
      case "path":
        this.renderPath(ctx, element)
        break
      default:
        console.warn(`Unknown element type: ${element.type}`)
    }

    // Restore the context state
    ctx.restore()
  },

  /**
   * Render a rectangle
   */
  renderRect(ctx: CanvasRenderingContext2D, element: any, width: number, height: number): void {
    const { fill, stroke, strokeWidth = 0, cornerRadius = 0 } = element

    // Set fill and stroke styles
    if (fill) {
      ctx.fillStyle = fill
    }
    if (stroke) {
      ctx.strokeStyle = stroke
      ctx.lineWidth = strokeWidth
    }

    // Draw rectangle with corner radius
    if (cornerRadius > 0) {
      this.roundRect(ctx, 0, 0, width, height, cornerRadius)
    } else {
      ctx.beginPath()
      ctx.rect(0, 0, width, height)
      ctx.closePath()
    }

    // Fill and stroke
    if (fill) {
      ctx.fill()
    }
    if (stroke) {
      ctx.stroke()
    }
  },

  /**
   * Render a circle
   */
  renderCircle(ctx: CanvasRenderingContext2D, element: any, width: number, height: number): void {
    const { fill, stroke, strokeWidth = 0 } = element
    const radius = Math.min(width, height) / 2

    // Set fill and stroke styles
    if (fill) {
      ctx.fillStyle = fill
    }
    if (stroke) {
      ctx.strokeStyle = stroke
      ctx.lineWidth = strokeWidth
    }

    // Draw circle
    ctx.beginPath()
    ctx.arc(width / 2, height / 2, radius, 0, Math.PI * 2)
    ctx.closePath()

    // Fill and stroke
    if (fill) {
      ctx.fill()
    }
    if (stroke) {
      ctx.stroke()
    }
  },

  /**
   * Render text
   */
  renderText(ctx: CanvasRenderingContext2D, element: any, width: number, height: number): void {
    const {
      text = "",
      fill = "#000000",
      fontFamily = "Arial",
      fontSize = 16,
      fontStyle = "normal",
      fontWeight = "normal",
      textAlign = "left",
      verticalAlign = "top",
      lineHeight = 1.2,
    } = element

    // Set text styles
    ctx.fillStyle = fill
    ctx.font = `${fontStyle} ${fontWeight} ${fontSize}px ${fontFamily}`
    ctx.textAlign = textAlign as CanvasTextAlign
    ctx.textBaseline = this.mapVerticalAlign(verticalAlign)

    // Split text into lines
    const lines = text.split("\n")
    const lineHeightPx = fontSize * lineHeight

    // Calculate vertical position based on alignment
    let y = 0
    if (verticalAlign === "middle") {
      y = height / 2 - (lines.length * lineHeightPx) / 2 + fontSize / 2
    } else if (verticalAlign === "bottom") {
      y = height - lines.length * lineHeightPx + fontSize
    } else {
      y = fontSize // top alignment
    }

    // Calculate horizontal position based on alignment
    let x = 0
    if (textAlign === "center") {
      x = width / 2
    } else if (textAlign === "right") {
      x = width
    }

    // Render each line
    for (let i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], x, y + i * lineHeightPx)
    }
  },

  /**
   * Render an image
   */
  async renderImage(ctx: CanvasRenderingContext2D, element: any, width: number, height: number): Promise<void> {
    const { src } = element

    if (!src) {
      console.warn("Image element missing src")
      return
    }

    try {
      // Load the image
      const image = await loadImage(src)

      // Draw the image
      ctx.drawImage(image, 0, 0, width, height)
    } catch (error) {
      console.error("Error loading image:", error)
    }
  },

  /**
   * Render a path
   */
  renderPath(ctx: CanvasRenderingContext2D, element: any): void {
    const { data, fill, stroke, strokeWidth = 0 } = element

    if (!data) {
      console.warn("Path element missing data")
      return
    }

    // Set fill and stroke styles
    if (fill) {
      ctx.fillStyle = fill
    }
    if (stroke) {
      ctx.strokeStyle = stroke
      ctx.lineWidth = strokeWidth
    }

    // Parse and draw the path
    try {
      const path = new Path2D(data)
      if (fill) {
        ctx.fill(path)
      }
      if (stroke) {
        ctx.stroke(path)
      }
    } catch (error) {
      console.error("Error rendering path:", error)
    }
  },

  /**
   * Draw a rounded rectangle
   */
  roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number): void {
    ctx.beginPath()
    ctx.moveTo(x + radius, y)
    ctx.lineTo(x + width - radius, y)
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius)
    ctx.lineTo(x + width, y + height - radius)
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
    ctx.lineTo(x + radius, y + height)
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius)
    ctx.lineTo(x, y + radius)
    ctx.quadraticCurveTo(x, y, x + radius, y)
    ctx.closePath()
  },

  /**
   * Map vertical align values to canvas textBaseline values
   */
  mapVerticalAlign(verticalAlign: string): CanvasTextBaseline {
    switch (verticalAlign) {
      case "top":
        return "top"
      case "middle":
        return "middle"
      case "bottom":
        return "bottom"
      default:
        return "top"
    }
  },

  /**
   * Generate SVG from elements
   */
  generateSVG(width: number, height: number, elements: any[], background: string): string {
    // Start SVG
    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">\n`

    // Add background
    svg += `  <rect width="${width}" height="${height}" fill="${background}" />\n`

    // Sort elements by z-index
    const sortedElements = [...elements].sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0))

    // Add elements
    for (const element of sortedElements) {
      svg += this.elementToSVG(element)
    }

    // Close SVG
    svg += "</svg>"

    return svg
  },

  /**
   * Convert an element to SVG
   */
  elementToSVG(element: any): string {
    const { type, x = 0, y = 0, width = 100, height = 100, rotation = 0, opacity = 1, scaleX = 1, scaleY = 1 } = element

    // Calculate transform
    let transform = ""
    if (rotation !== 0 || scaleX !== 1 || scaleY !== 1) {
      const centerX = x + width / 2
      const centerY = y + height / 2
      transform = `transform="translate(${centerX} ${centerY}) rotate(${rotation}) scale(${scaleX} ${scaleY}) translate(${-width / 2} ${-height / 2})"`
    }

    // Add opacity
    const opacityAttr = opacity !== 1 ? `opacity="${opacity}"` : ""

    // Generate SVG based on element type
    switch (type) {
      case "rect":
        return this.rectToSVG(element, transform, opacityAttr)
      case "circle":
        return this.circleToSVG(element, transform, opacityAttr)
      case "text":
        return this.textToSVG(element, transform, opacityAttr)
      case "image":
        return this.imageToSVG(element, transform, opacityAttr)
      case "path":
        return this.pathToSVG(element, transform, opacityAttr)
      default:
        console.warn(`Unknown element type for SVG: ${type}`)
        return ""
    }
  },

  /**
   * Convert a rectangle to SVG
   */
  rectToSVG(element: any, transform: string, opacityAttr: string): string {
    const { x = 0, y = 0, width = 100, height = 100, fill, stroke, strokeWidth = 0, cornerRadius = 0 } = element

    const fillAttr = fill ? `fill="${fill}"` : 'fill="none"'
    const strokeAttr = stroke ? `stroke="${stroke}"` : ""
    const strokeWidthAttr = stroke ? `stroke-width="${strokeWidth}"` : ""
    const rxAttr = cornerRadius > 0 ? `rx="${cornerRadius}" ry="${cornerRadius}"` : ""

    return `  <rect x="${x}" y="${y}" width="${width}" height="${height}" ${rxAttr} ${fillAttr} ${strokeAttr} ${strokeWidthAttr} ${transform} ${opacityAttr} />\n`
  },

  /**
   * Convert a circle to SVG
   */
  circleToSVG(element: any, transform: string, opacityAttr: string): string {
    const { x = 0, y = 0, width = 100, height = 100, fill, stroke, strokeWidth = 0 } = element
    const radius = Math.min(width, height) / 2
    const cx = x + width / 2
    const cy = y + height / 2

    const fillAttr = fill ? `fill="${fill}"` : 'fill="none"'
    const strokeAttr = stroke ? `stroke="${stroke}"` : ""
    const strokeWidthAttr = stroke ? `stroke-width="${strokeWidth}"` : ""

    return `  <circle cx="${cx}" cy="${cy}" r="${radius}" ${fillAttr} ${strokeAttr} ${strokeWidthAttr} ${transform} ${opacityAttr} />\n`
  },

  /**
   * Convert text to SVG
   */
  textToSVG(element: any, transform: string, opacityAttr: string): string {
    const {
      x = 0,
      y = 0,
      width = 100,
      height = 100,
      text = "",
      fill = "#000000",
      fontFamily = "Arial",
      fontSize = 16,
      fontStyle = "normal",
      fontWeight = "normal",
      textAlign = "left",
      verticalAlign = "top",
      lineHeight = 1.2,
    } = element

    // Calculate text position based on alignment
    let textX = x
    if (textAlign === "center") {
      textX = x + width / 2
    } else if (textAlign === "right") {
      textX = x + width
    }

    // Calculate vertical position based on alignment
    const lines = text.split("\n")
    const lineHeightPx = fontSize * lineHeight
    let textY = y + fontSize // Default for top alignment

    if (verticalAlign === "middle") {
      textY = y + height / 2 - (lines.length * lineHeightPx) / 2 + fontSize
    } else if (verticalAlign === "bottom") {
      textY = y + height - (lines.length - 1) * lineHeightPx
    }

    // Set text attributes
    const fillAttr = `fill="${fill}"`
    const fontAttr = `font-family="${fontFamily}" font-size="${fontSize}" font-style="${fontStyle}" font-weight="${fontWeight}"`
    const textAnchor = textAlign === "left" ? "start" : textAlign === "center" ? "middle" : "end"
    const textAnchorAttr = `text-anchor="${textAnchor}"`

    // Generate SVG for each line
    let textSVG = ""
    for (let i = 0; i < lines.length; i++) {
      textSVG += `  <text x="${textX}" y="${textY + i * lineHeightPx}" ${fillAttr} ${fontAttr} ${textAnchorAttr} ${transform} ${opacityAttr}>${this.escapeXML(
        lines[i],
      )}</text>\n`
    }

    return textSVG
  },

  /**
   * Convert an image to SVG
   */
  imageToSVG(element: any, transform: string, opacityAttr: string): string {
    const { x = 0, y = 0, width = 100, height = 100, src } = element

    if (!src) {
      return ""
    }

    return `  <image x="${x}" y="${y}" width="${width}" height="${height}" href="${src}" ${transform} ${opacityAttr} />\n`
  },

  /**
   * Convert a path to SVG
   */
  pathToSVG(element: any, transform: string, opacityAttr: string): string {
    const { data, fill, stroke, strokeWidth = 0 } = element

    if (!data) {
      return ""
    }

    const fillAttr = fill ? `fill="${fill}"` : 'fill="none"'
    const strokeAttr = stroke ? `stroke="${stroke}"` : ""
    const strokeWidthAttr = stroke ? `stroke-width="${strokeWidth}"` : ""

    return `  <path d="${data}" ${fillAttr} ${strokeAttr} ${strokeWidthAttr} ${transform} ${opacityAttr} />\n`
  },

  /**
   * Escape XML special characters
   */
  escapeXML(text: string): string {
    return text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;")
  },

  /**
   * Get animated properties based on progress
   */
  getAnimatedProperties(element: any, progress: number): any {
    if (!element.animations || !Array.isArray(element.animations) || element.animations.length === 0) {
      return {}
    }

    const result: any = {}

    // Find animations that apply at the current progress
    for (const animation of element.animations) {
      const { property, keyframes } = animation
      if (!property || !keyframes || !Array.isArray(keyframes) || keyframes.length < 2) {
        continue
      }

      // Sort keyframes by time
      const sortedKeyframes = [...keyframes].sort((a, b) => a.time - b.time)

      // Find the keyframes that bracket the current progress
      let startFrame = sortedKeyframes[0]
      let endFrame = sortedKeyframes[sortedKeyframes.length - 1]

      for (let i = 0; i < sortedKeyframes.length - 1; i++) {
        if (progress >= sortedKeyframes[i].time && progress <= sortedKeyframes[i + 1].time) {
          startFrame = sortedKeyframes[i]
          endFrame = sortedKeyframes[i + 1]
          break
        }
      }

      // Calculate the interpolation factor
      const timeRange = endFrame.time - startFrame.time
      const interpolationFactor = timeRange === 0 ? 0 : (progress - startFrame.time) / timeRange

      // Interpolate the value
      result[property] = this.interpolateValue(startFrame.value, endFrame.value, interpolationFactor, animation.easing)
    }

    return result
  },

  /**
   * Interpolate between two values
   */
  interpolateValue(start: any, end: any, factor: number, easing = "linear"): any {
    // Apply easing function
    const easedFactor = this.applyEasing(factor, easing)

    // Handle different value types
    if (typeof start === "number" && typeof end === "number") {
      return start + (end - start) * easedFactor
    } else if (typeof start === "string" && typeof end === "string") {
      // Check if it's a color
      if (start.startsWith("#") && end.startsWith("#")) {
        return this.interpolateColor(start, end, easedFactor)
      }
    }

    // Default to returning the end value if we can't interpolate
    return factor < 0.5 ? start : end
  },

  /**
   * Apply easing function
   */
  applyEasing(factor: number, easing: string): number {
    switch (easing) {
      case "linear":
        return factor
      case "easeInQuad":
        return factor * factor
      case "easeOutQuad":
        return factor * (2 - factor)
      case "easeInOutQuad":
        return factor < 0.5 ? 2 * factor * factor : -1 + (4 - 2 * factor) * factor
      case "easeInCubic":
        return factor * factor * factor
      case "easeOutCubic":
        return --factor * factor * factor + 1
      case "easeInOutCubic":
        return factor < 0.5 ? 4 * factor * factor * factor : (factor - 1) * (2 * factor - 2) * (2 * factor - 2) + 1
      case "easeInQuart":
        return factor * factor * factor * factor
      case "easeOutQuart":
        return 1 - --factor * factor * factor * factor
      case "easeInOutQuart":
        return factor < 0.5 ? 8 * factor * factor * factor * factor : 1 - 8 * --factor * factor * factor * factor
      case "easeInQuint":
        return factor * factor * factor * factor * factor
      case "easeOutQuint":
        return 1 + --factor * factor * factor * factor * factor
      case "easeInOutQuint":
        return factor < 0.5
          ? 16 * factor * factor * factor * factor * factor
          : 1 + 16 * --factor * factor * factor * factor * factor
      default:
        return factor
    }
  },

  /**
   * Interpolate between two colors
   */
  interpolateColor(startColor: string, endColor: string, factor: number): string {
    // Convert hex to RGB
    const startRGB = this.hexToRgb(startColor)
    const endRGB = this.hexToRgb(endColor)

    if (!startRGB || !endRGB) {
      return factor < 0.5 ? startColor : endColor
    }

    // Interpolate each component
    const r = Math.round(startRGB.r + (endRGB.r - startRGB.r) * factor)
    const g = Math.round(startRGB.g + (endRGB.g - startRGB.g) * factor)
    const b = Math.round(startRGB.b + (endRGB.b - startRGB.b) * factor)

    // Convert back to hex
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`
  },

  /**
   * Convert hex color to RGB
   */
  hexToRgb(hex: string): { r: number; g: number; b: number } | null {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
    return result
      ? {
          r: Number.parseInt(result[1], 16),
          g: Number.parseInt(result[2], 16),
          b: Number.parseInt(result[3], 16),
        }
      : null
  },
}

