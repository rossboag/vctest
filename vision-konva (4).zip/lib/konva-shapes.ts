import Konva from "konva"
import type { Element } from "@/store/editor-store"

export class KonvaShapeHandler {
  addRectangle(element: Element): Konva.Rect {
    return new Konva.Rect({
      x: element.x,
      y: element.y,
      width: element.width,
      height: element.height,
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }

  addCircle(element: Element): Konva.Circle {
    return new Konva.Circle({
      x: element.x,
      y: element.y,
      radius: element.width / 2, // Assuming width is diameter
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }

  addLine(element: Element): Konva.Line {
    return new Konva.Line({
      points: element.points,
      stroke: element.fill,
      strokeWidth: 5,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }

  addTriangle(element: Element): Konva.RegularPolygon {
    return new Konva.RegularPolygon({
      x: element.x,
      y: element.y,
      sides: 3,
      radius: element.width / 2,
      fill: element.fill,
      stroke: element.stroke,
      strokeWidth: element.strokeWidth,
      opacity: element.opacity,
      draggable: true,
      id: element.id,
    })
  }

  addHexagon(element: Element): Konva.RegularPolygon {
    return new Konva.RegularPolygon({
      x: element.x,
      y: element.y,
      sides: 6,
      radius: element.width / 2,
      fill: element.fill,
      stroke: element.stroke,
      strokeWidth: element.strokeWidth,
      opacity: element.opacity,
      draggable: true,
      id: element.id,
    })
  }

  addStar(element: Element): Konva.Star {
    return new Konva.Star({
      x: element.x,
      y: element.y,
      numPoints: element.numPoints,
      innerRadius: element.innerRadius,
      outerRadius: element.outerRadius,
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }

  addArrow(element: Element): Konva.Arrow {
    return new Konva.Arrow({
      x: element.x,
      y: element.y,
      points: element.points,
      pointerLength: 20,
      pointerWidth: 20,
      fill: element.fill,
      stroke: element.fill,
      strokeWidth: 4,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }

  addEllipse(element: Element): Konva.Ellipse {
    return new Konva.Ellipse({
      x: element.x,
      y: element.y,
      radiusX: element.radiusX,
      radiusY: element.radiusY,
      fill: element.fill,
      draggable: true,
      id: element.id,
      opacity: element.opacity,
      blurRadius: element.blur,
    })
  }
}

