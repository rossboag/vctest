describe("Mobile Responsiveness", () => {
  context("Desktop", () => {
    beforeEach(() => {
      cy.viewport(Cypress.env("desktop").viewportWidth, Cypress.env("desktop").viewportHeight)
      cy.visit("/editor")
    })

    it("displays desktop layout", () => {
      // Should show all toolbars
      cy.get('[data-testid="top-toolbar"]').should("be.visible")
      cy.get('[data-testid="editor-toolbar"]').should("be.visible")
      cy.get('[data-testid="right-toolbar"]').should("be.visible")

      // Should show timeline panel
      cy.get('[data-testid="timeline-panel"]').should("be.visible")

      // Should not show mobile UI
      cy.get('[data-testid="mobile-ui-adaptations"]').should("not.exist")
    })

    it("allows canvas interactions", () => {
      // Test zoom
      cy.get('[data-testid="zoom-in-button"]').click()
      cy.get('[data-testid="zoom-level"]').should("contain", "110%")

      // Test pan
      cy.get('[data-testid="editor-canvas"]')
        .trigger("mousedown", { button: 1 })
        .trigger("mousemove", { clientX: 100, clientY: 100 })
        .trigger("mouseup")
    })
  })

  context("Tablet", () => {
    beforeEach(() => {
      cy.viewport(Cypress.env("tablet").viewportWidth, Cypress.env("tablet").viewportHeight)
      cy.visit("/editor")
    })

    it("displays tablet layout", () => {
      // Should show all toolbars
      cy.get('[data-testid="top-toolbar"]').should("be.visible")
      cy.get('[data-testid="editor-toolbar"]').should("be.visible")
      cy.get('[data-testid="right-toolbar"]').should("be.visible")

      // Should show timeline panel with reduced height
      cy.get('[data-testid="timeline-panel"]').should("be.visible").should("have.css", "height", "128px") // 32px = 2rem

      // Should not show mobile UI
      cy.get('[data-testid="mobile-ui-adaptations"]').should("not.exist")
    })
  })

  context("Mobile", () => {
    beforeEach(() => {
      cy.viewport(Cypress.env("mobile").viewportWidth, Cypress.env("mobile").viewportHeight)
      cy.visit("/editor")
    })

    it("displays mobile layout", () => {
      // Should show main toolbars
      cy.get('[data-testid="top-toolbar"]').should("be.visible")

      // Should show mobile UI
      cy.get('[data-testid="mobile-ui-adaptations"]').should("be.visible")

      // Should not show timeline panel
      cy.get('[data-testid="timeline-panel"]').should("not.be.visible")
    })

    it("shows orientation warning in portrait mode", () => {
      // Should show orientation warning
      cy.get('[data-testid="orientation-warning"]').should("be.visible")

      // Dismiss warning
      cy.get('[data-testid="continue-button"]').click()
      cy.get('[data-testid="orientation-warning"]').should("not.exist")
    })

    it("allows touch interactions", () => {
      // Dismiss orientation warning if present
      cy.get('[data-testid="continue-button"]').click({ force: true })

      // Test mobile zoom buttons
      cy.get('[data-testid="mobile-zoom-in"]').click()
      cy.get('[data-testid="mobile-zoom-level"]').should("contain", "110%")

      // Test mobile undo/redo
      cy.get('[data-testid="mobile-undo"]').click()
      cy.get('[data-testid="mobile-redo"]').click()

      // Test mobile layers panel
      cy.get('[data-testid="mobile-layers-button"]').click()
      cy.get('[data-testid="mobile-layers-panel"]').should("be.visible")
      cy.get("body").click({ force: true }) // Close panel

      // Test mobile timeline panel
      cy.get('[data-testid="mobile-timeline-button"]').click()
      cy.get('[data-testid="mobile-timeline-panel"]').should("be.visible")
    })
  })
})

