"use client"

import { useState } from "react"
import { TextEnhancementTool } from "@/components/ai/text-enhancement-tool"
import { ImageEnhancementTool } from "@/components/ai/image-enhancement-tool"
import { VideoSuggestionTool } from "@/components/ai/video-suggestion-tool"
import { ContentAdaptationTool } from "@/components/ai/content-adaptation-tool"
import { ContentLocalizationTool } from "@/components/ai/content-localization-tool"
import { ContentHistory } from "@/components/ai/content-history"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Image, Video, Globe, Share2, History } from "lucide-react"

export default function ContentStudioPage() {
  const [activeTab, setActiveTab] = useState("text")
  const [enhancedText, setEnhancedText] = useState("")
  const [imageSuggestions, setImageSuggestions] = useState<any>(null)
  const [videoSuggestions, setVideoSuggestions] = useState<any>(null)
  const [adaptedContent, setAdaptedContent] = useState("")
  const [localizedContent, setLocalizedContent] = useState("")

  return (
    <div className="container mx-auto py-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Content Studio</h1>
        <p className="text-muted-foreground mt-2">Enhance, adapt, and localize your content with AI assistance</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>AI Content Enhancement Tools</CardTitle>
              <CardDescription>Select a tool to enhance your content</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-6">
                  <TabsTrigger value="text" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    <span className="hidden sm:inline">Text</span>
                  </TabsTrigger>
                  <TabsTrigger value="image" className="flex items-center gap-2">
                    <Image className="h-4 w-4" />
                    <span className="hidden sm:inline">Image</span>
                  </TabsTrigger>
                  <TabsTrigger value="video" className="flex items-center gap-2">
                    <Video className="h-4 w-4" />
                    <span className="hidden sm:inline">Video</span>
                  </TabsTrigger>
                  <TabsTrigger value="adapt" className="flex items-center gap-2">
                    <Share2 className="h-4 w-4" />
                    <span className="hidden sm:inline">Adapt</span>
                  </TabsTrigger>
                  <TabsTrigger value="localize" className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    <span className="hidden sm:inline">Localize</span>
                  </TabsTrigger>
                  <TabsTrigger value="history" className="flex items-center gap-2">
                    <History className="h-4 w-4" />
                    <span className="hidden sm:inline">History</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="text" className="mt-6">
                  <TextEnhancementTool onEnhanced={setEnhancedText} />
                </TabsContent>

                <TabsContent value="image" className="mt-6">
                  <ImageEnhancementTool onEnhanced={setImageSuggestions} />
                </TabsContent>

                <TabsContent value="video" className="mt-6">
                  <VideoSuggestionTool onGenerated={setVideoSuggestions} />
                </TabsContent>

                <TabsContent value="adapt" className="mt-6">
                  <ContentAdaptationTool onAdapted={setAdaptedContent} initialContent={enhancedText} />
                </TabsContent>

                <TabsContent value="localize" className="mt-6">
                  <ContentLocalizationTool
                    onLocalized={setLocalizedContent}
                    initialContent={enhancedText || adaptedContent}
                  />
                </TabsContent>

                <TabsContent value="history" className="mt-6">
                  <ContentHistory
                    onSelect={(item) => {
                      if (item.type === "text") {
                        setEnhancedText(item.enhancedContent)
                        setActiveTab("text")
                      } else if (item.type === "image") {
                        setImageSuggestions(item.enhancedContent)
                        setActiveTab("image")
                      } else if (item.type === "video") {
                        setVideoSuggestions(item.enhancedContent)
                        setActiveTab("video")
                      } else if (item.type === "adaptation") {
                        setAdaptedContent(item.enhancedContent)
                        setActiveTab("adapt")
                      } else if (item.type === "localization") {
                        setLocalizedContent(item.enhancedContent)
                        setActiveTab("localize")
                      }
                    }}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Content Workflow</CardTitle>
              <CardDescription>Create, enhance, adapt, and localize your content</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <h3 className="font-medium">1. Create or Enhance Text</h3>
                  <p className="text-sm text-muted-foreground">
                    Use the Text Enhancement tool to create new content or improve existing text.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">2. Enhance Images</h3>
                  <p className="text-sm text-muted-foreground">Get AI-powered suggestions to improve your images.</p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">3. Plan Video Content</h3>
                  <p className="text-sm text-muted-foreground">
                    Generate detailed video content plans with scene breakdowns.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">4. Adapt for Different Platforms</h3>
                  <p className="text-sm text-muted-foreground">
                    Optimize your content for specific platforms and formats.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">5. Localize for Global Audiences</h3>
                  <p className="text-sm text-muted-foreground">
                    Translate and adapt your content for different languages and regions.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

