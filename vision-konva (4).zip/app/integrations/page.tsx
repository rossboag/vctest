"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ConnectIntegration } from "@/components/integrations/connect-integration"
import { FileBrowser } from "@/components/integrations/file-browser"
import { FileUploader } from "@/components/integrations/file-uploader"
import { toast } from "sonner"
import { DashboardHomeLink } from "@/components/dashboard-home-link"

export default function IntegrationsPage() {
  const [integrations, setIntegrations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("google")
  const [currentFolder, setCurrentFolder] = useState<string | undefined>(undefined)
  const [currentPath, setCurrentPath] = useState<string | undefined>(undefined)
  const [refreshKey, setRefreshKey] = useState(0)

  // Fetch integrations
  const fetchIntegrations = useCallback(async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/integrations")
      const data = await response.json()

      if (response.ok) {
        setIntegrations(data)
      }
    } catch (error) {
      console.error("Error fetching integrations:", error)
      toast.error("Failed to fetch integrations")
    } finally {
      setLoading(false)
    }
  }, [])

  // Disconnect integration
  const disconnectIntegration = async (provider: string) => {
    try {
      const response = await fetch(`/api/integrations/${provider}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast.success(`Disconnected from ${provider}`)
        fetchIntegrations()
      } else {
        throw new Error(`Failed to disconnect from ${provider}`)
      }
    } catch (error) {
      console.error(`Error disconnecting from ${provider}:`, error)
      toast.error(`Failed to disconnect from ${provider}`)
    }
  }

  // Check if integration is connected
  const isConnected = (provider: string) => {
    return integrations.some((integration) => integration.provider === provider)
  }

  // Handle folder change
  const handleFolderChange = (folderId?: string, path?: string) => {
    setCurrentFolder(folderId)
    setCurrentPath(path)
  }

  // Handle upload complete
  const handleUploadComplete = () => {
    setRefreshKey((prev) => prev + 1)
  }

  // Initial fetch
  useEffect(() => {
    fetchIntegrations()
  }, [fetchIntegrations])

  return (
    <div className="relative">
      <DashboardHomeLink />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">Integrations</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <ConnectIntegration
            provider="google"
            title="Google Drive"
            description="Connect to Google Drive to import and export files"
            connected={isConnected("google")}
            onDisconnect={() => disconnectIntegration("google")}
          />
          <ConnectIntegration
            provider="dropbox"
            title="Dropbox"
            description="Connect to Dropbox to import and export files"
            connected={isConnected("dropbox")}
            onDisconnect={() => disconnectIntegration("dropbox")}
          />
          <ConnectIntegration
            provider="azure-ad"
            title="OneDrive"
            description="Connect to OneDrive to import and export files"
            connected={isConnected("onedrive")}
            onDisconnect={() => disconnectIntegration("onedrive")}
          />
        </div>

        <Tabs defaultValue="google" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="google">Google Drive</TabsTrigger>
            <TabsTrigger value="dropbox">Dropbox</TabsTrigger>
            <TabsTrigger value="onedrive">OneDrive</TabsTrigger>
          </TabsList>

          <TabsContent value="google">
            {isConnected("google") ? (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <FileBrowser
                    key={`google-${refreshKey}`}
                    provider="google"
                    onFileSelect={(file) => console.log("Selected file:", file)}
                  />
                </div>
                <div>
                  <FileUploader provider="google" folderId={currentFolder} onUploadComplete={handleUploadComplete} />
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">Connect to Google Drive to browse and upload files</p>
                <Button onClick={() => document.getElementById("google-connect-button")?.click()}>
                  Connect to Google Drive
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="dropbox">
            {isConnected("dropbox") ? (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <FileBrowser
                    key={`dropbox-${refreshKey}`}
                    provider="dropbox"
                    onFileSelect={(file) => console.log("Selected file:", file)}
                  />
                </div>
                <div>
                  <FileUploader provider="dropbox" path={currentPath} onUploadComplete={handleUploadComplete} />
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">Connect to Dropbox to browse and upload files</p>
                <Button onClick={() => document.getElementById("dropbox-connect-button")?.click()}>
                  Connect to Dropbox
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="onedrive">
            {isConnected("onedrive") ? (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <FileBrowser
                    key={`onedrive-${refreshKey}`}
                    provider="onedrive"
                    onFileSelect={(file) => console.log("Selected file:", file)}
                  />
                </div>
                <div>
                  <FileUploader provider="onedrive" folderId={currentFolder} onUploadComplete={handleUploadComplete} />
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">Connect to OneDrive to browse and upload files</p>
                <Button onClick={() => document.getElementById("azure-ad-connect-button")?.click()}>
                  Connect to OneDrive
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

