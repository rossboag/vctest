"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AIAnimationKeyframesGenerator } from "@/components/ai/ai-animation-keyframes-generator"
import { AIAnimationPresetCreator } from "@/components/ai/ai-animation-preset-creator"
import { AnimationPresetBrowser } from "@/components/ai/animation-preset-browser"
import { AIAnimationSuggestions } from "@/components/ai/ai-animation-suggestions"
import { AIAnimationSequenceGenerator } from "@/components/ai/ai-animation-sequence-generator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHomeLink } from "@/components/dashboard-home-link"
import { Play, Sparkles, Wand2 } from "lucide-react"
import { toast } from "sonner"
import type { AnimationPreset } from "@/lib/ai-animation-service"

export default function AnimationStudioPage() {
  const [activeTab, setActiveTab] = useState("keyframes")
  const [selectedPreset, setSelectedPreset] = useState<AnimationPreset | null>(null)

  const handlePresetSelect = (preset: AnimationPreset) => {
    setSelectedPreset(preset)
    toast.success(`Selected preset: ${preset.name}`)
  }

  const handleSuggestionSelect = (suggestion: string) => {
    toast.success(`Selected suggestion: ${suggestion}`)
    // Here you would typically use this suggestion to generate keyframes
  }

  return (
    <div className="relative">
      <DashboardHomeLink />
      <div className="container mx-auto p-6">
        <div className="flex items-center mb-6">
          <Play className="h-6 w-6 mr-2" />
          <h1 className="text-3xl font-bold">Animation Studio</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Create Animations with AI</CardTitle>
                <CardDescription>Use AI to generate animations for your projects</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid grid-cols-4 mb-4">
                    <TabsTrigger value="keyframes">Keyframes</TabsTrigger>
                    <TabsTrigger value="presets">Presets</TabsTrigger>
                    <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                    <TabsTrigger value="sequence">Sequence</TabsTrigger>
                  </TabsList>

                  <TabsContent value="keyframes">
                    <AIAnimationKeyframesGenerator
                      title="Generate Animation Keyframes"
                      onGenerated={(keyframes) => {
                        toast.success("Animation keyframes generated!")
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="presets">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <AIAnimationPresetCreator
                        title="Create Animation Preset"
                        onCreated={(preset) => {
                          toast.success(`Preset "${preset.name}" created!`)
                        }}
                      />
                      <Card>
                        <CardHeader>
                          <CardTitle>Browse Presets</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <AnimationPresetBrowser onSelectPreset={handlePresetSelect} />
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="suggestions">
                    <AIAnimationSuggestions onSelectSuggestion={handleSuggestionSelect} />
                  </TabsContent>

                  <TabsContent value="sequence">
                    <AIAnimationSequenceGenerator
                      title="Generate Animation Sequence"
                      onGenerated={(result) => {
                        toast.success("Animation sequence generated!")
                      }}
                      initialElements={[
                        { id: "element1", type: "text", content: "Heading" },
                        { id: "element2", type: "image" },
                        { id: "element3", type: "button", content: "Click Me" },
                      ]}
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Wand2 className="h-5 w-5 mr-2" />
                  <CardTitle>Animation Preview</CardTitle>
                </div>
                <CardDescription>Preview and test your animations</CardDescription>
              </CardHeader>
              <CardContent>
                {selectedPreset ? (
                  <div className="space-y-4">
                    <h3 className="font-medium">{selectedPreset.name}</h3>
                    <p className="text-sm text-muted-foreground">{selectedPreset.description}</p>
                    <div className="p-4 border rounded-md">
                      <div className="aspect-video bg-muted rounded-md flex items-center justify-center">
                        <div className="text-center">
                          <p className="text-muted-foreground">Animation Preview</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            (Preview functionality would be implemented here)
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      <p>Duration: {selectedPreset.duration}s</p>
                      <p>Easing: {selectedPreset.easing}</p>
                      <p>Category: {selectedPreset.category}</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedPreset.tags.map((tag, index) => (
                          <span key={index} className="bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>Select a preset or generate an animation to preview</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

