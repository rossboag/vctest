"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AITextGenerator } from "@/components/ai/ai-text-generator"
import { AIImageGenerator } from "@/components/ai/ai-image-generator"
import { AILayoutGenerator } from "@/components/ai/ai-layout-generator"
import { AIAnimationGenerator } from "@/components/ai/ai-animation-generator"
import { AIColorsGenerator } from "@/components/ai/ai-colors-generator"
import { AIBatchGenerator } from "@/components/ai/ai-batch-generator"
import type { LayoutElement } from "@/hooks/use-ai-layout"
import type { KeyframeData } from "@/hooks/use-ai-animation"

export default function AIDemo() {
  const [generatedText, setGeneratedText] = useState<string | null>(null)
  const [generatedImages, setGeneratedImages] = useState<string[] | null>(null)
  const [generatedLayout, setGeneratedLayout] = useState<LayoutElement[] | null>(null)
  const [generatedKeyframes, setGeneratedKeyframes] = useState<KeyframeData[] | null>(null)
  const [generatedColors, setGeneratedColors] = useState<string[] | null>(null)

  const batchOperations = [
    {
      type: "text" as const,
      params: {
        prompt: "Write a short tagline for a design software",
        maxLength: 50,
        temperature: 0.7,
      },
      label: "Generate Tagline Text",
    },
    {
      type: "colors" as const,
      params: {
        prompt: "Modern design app color scheme",
        numberOfColors: 5,
      },
      label: "Generate Color Palette",
    },
  ]

  return (
    <div className="container mx-auto py-8">
      <h1 className="mb-8 text-center text-3xl font-bold">AI Generation Demo</h1>

      <Tabs defaultValue="text" className="mx-auto max-w-3xl">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="text">Text</TabsTrigger>
          <TabsTrigger value="image">Image</TabsTrigger>
          <TabsTrigger value="layout">Layout</TabsTrigger>
          <TabsTrigger value="animation">Animation</TabsTrigger>
          <TabsTrigger value="colors">Colors</TabsTrigger>
          <TabsTrigger value="batch">Batch</TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="mt-6">
          <AITextGenerator
            onGenerated={(text) => setGeneratedText(text)}
            defaultPrompt="Write a creative description for a design tool"
          />
        </TabsContent>

        <TabsContent value="image" className="mt-6">
          <AIImageGenerator
            onGenerated={(images) => setGeneratedImages(images)}
            defaultPrompt="A modern design workspace with creative tools"
          />
        </TabsContent>

        <TabsContent value="layout" className="mt-6">
          <AILayoutGenerator
            onGenerated={(layout) => setGeneratedLayout(layout)}
            defaultPrompt="Create a landing page layout for a design tool"
          />
        </TabsContent>

        <TabsContent value="animation" className="mt-6">
          <AIAnimationGenerator
            elementId="demo-element"
            elementType="header"
            onGenerated={(keyframes, duration) => {
              setGeneratedKeyframes(keyframes)
              console.log("Animation duration:", duration)
            }}
          />
        </TabsContent>

        <TabsContent value="colors" className="mt-6">
          <AIColorsGenerator
            onGenerated={(colors) => setGeneratedColors(colors)}
            defaultPrompt="Creative and vibrant color palette"
          />
        </TabsContent>

        <TabsContent value="batch" className="mt-6">
          <AIBatchGenerator
            operations={batchOperations}
            onCompleted={(results) => {
              console.log("Batch results:", results)
            }}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

