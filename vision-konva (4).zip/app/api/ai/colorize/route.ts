import { NextResponse } from "next/server"
import { aiServiceClient } from "@/lib/ai-service-client"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { elements, prompt } = await request.json()

    // Call the AI service client
    const result = await aiServiceClient.colorize(elements, prompt)

    return NextResponse.json({
      result,
    })
  } catch (error) {
    console.error("Error in colorize API:", error)
    return NextResponse.json({ error: "Failed to colorize design" }, { status: 500 })
  }
}

