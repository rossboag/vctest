import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService } from "@/lib/ai-service"
import { z } from "zod"

// Define validation schema
const animationGenerationSchema = z.object({
  prompt: z.string().min(1, "Prompt is required"),
  projectId: z.string().optional(),
  elementType: z.string().optional().default("generic"),
  duration: z.number().min(0.5).max(30).optional().default(2),
  complexity: z.enum(["simple", "medium", "complex"]).optional().default("medium"),
  easing: z.string().optional(),
  targetElements: z.array(z.string()).optional(),
})

export async function POST(req: NextRequest) {
  try {
    // Authenticate user
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse and validate request body
    const body = await req.json()
    const validationResult = animationGenerationSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json({ error: "Invalid request", details: validationResult.error.format() }, { status: 400 })
    }

    const { prompt, projectId, elementType, duration, complexity } = validationResult.data

    // Generate animation using AI service
    const result = await AIService.generateAnimationSuggestion(session.user.id, prompt, projectId, {
      elementType,
      duration,
      complexity,
    })

    // Return successful response
    return NextResponse.json({
      success: true,
      data: result,
    })
  } catch (error) {
    console.error("Error generating animation:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to generate animation",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

