import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService, AIServiceError } from "@/lib/ai-service"
import { z } from "zod"
import { headers } from "next/headers"

// Define schemas for different generation types
const textRequestSchema = z.object({
  type: z.literal("text_generation"),
  prompt: z.string().min(1, "Prompt is required"),
  options: z
    .object({
      systemPrompt: z.string().optional(),
      temperature: z.number().min(0).max(1).optional(),
      maxTokens: z.number().optional(),
    })
    .optional(),
})

const imageRequestSchema = z.object({
  type: z.literal("image_generation"),
  prompt: z.string().min(1, "Prompt is required"),
  options: z
    .object({
      size: z.enum(["1024x1024", "1792x1024", "1024x1792"]).optional(),
      style: z.enum(["natural", "vivid"]).optional(),
      quality: z.enum(["standard", "hd"]).optional(),
    })
    .optional(),
})

const colorPaletteRequestSchema = z.object({
  type: z.literal("color_palette"),
  prompt: z.string().min(1, "Prompt is required"),
  options: z
    .object({
      count: z.number().min(2).max(10).optional(),
      mode: z.enum(["analogous", "complementary", "triadic", "monochromatic", "custom"]).optional(),
      temperature: z.number().min(0).max(1).optional(),
    })
    .optional(),
})

const layoutRequestSchema = z.object({
  type: z.literal("layout_suggestion"),
  prompt: z.string().min(1, "Prompt is required"),
  options: z
    .object({
      width: z.number().optional(),
      height: z.number().optional(),
      elements: z.array(z.any()).optional(),
      temperature: z.number().min(0).max(1).optional(),
    })
    .optional(),
})

const animationRequestSchema = z.object({
  type: z.literal("animation_suggestion"),
  prompt: z.string().min(1, "Prompt is required"),
  options: z
    .object({
      elementType: z.string().optional(),
      duration: z.number().optional(),
      complexity: z.enum(["simple", "medium", "complex"]).optional(),
      temperature: z.number().min(0).max(1).optional(),
    })
    .optional(),
})

const contentEnhancementRequestSchema = z.object({
  type: z.literal("content_enhancement"),
  prompt: z.string().min(1, "Content is required"),
  options: z
    .object({
      contentType: z.enum(["text", "image_description"]).optional(),
      tone: z.enum(["professional", "casual", "creative", "formal"]).optional(),
      purpose: z.enum(["marketing", "informational", "educational", "entertainment"]).optional(),
      targetAudience: z.string().optional(),
      temperature: z.number().min(0).max(1).optional(),
    })
    .optional(),
})

const styleTransferRequestSchema = z.object({
  type: z.literal("style_transfer"),
  prompt: z.string().min(1, "Style description is required"),
  options: z
    .object({
      sourceImageUrl: z.string().url("Valid source image URL is required"),
      intensity: z.number().min(0).max(1).optional(),
      temperature: z.number().min(0).max(1).optional(),
    })
    .required(),
})

const designSuggestionRequestSchema = z.object({
  type: z.literal("design_suggestion"),
  prompt: z.string().optional(),
  options: z
    .object({
      aspectToImprove: z.enum(["composition", "color", "typography", "overall", "branding"]).optional(),
      styleReference: z.string().optional(),
      temperature: z.number().min(0).max(1).optional(),
    })
    .optional(),
})

// Combined schema for any generation request
const generationRequestSchema = z.discriminatedUnion("type", [
  textRequestSchema,
  imageRequestSchema,
  colorPaletteRequestSchema,
  layoutRequestSchema,
  animationRequestSchema,
  contentEnhancementRequestSchema,
  styleTransferRequestSchema,
  designSuggestionRequestSchema,
])

// Schema for the batch request
const batchGenerationSchema = z.object({
  projectId: z.string().optional(),
  requests: z.array(generationRequestSchema).min(1).max(10),
})

// Middleware to check API key for 3rd party applications
function validateApiKey(req: NextRequest): boolean {
  if (!process.env.API_SECRET_KEY) return false

  const headersList = headers()
  const apiKey = headersList.get("x-api-key")

  return apiKey === process.env.API_SECRET_KEY
}

export async function POST(req: NextRequest) {
  try {
    // Check for API key or authenticated session
    const session = await getServerSession(authOptions)
    const hasValidApiKey = validateApiKey(req)

    if (!session?.user && !hasValidApiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "Unauthorized",
        },
        { status: 401 },
      )
    }

    const userId = session?.user?.id || "api-client"

    // Parse and validate request body
    const body = await req.json()
    const validationResult = batchGenerationSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid request",
          details: validationResult.error.format(),
        },
        { status: 400 },
      )
    }

    const { projectId, requests } = validationResult.data

    // Process batch generation
    const results = await AIService.processBatchGeneration(userId, requests, projectId)

    // Return successful response
    return NextResponse.json({
      success: true,
      data: results,
    })
  } catch (error) {
    console.error("Error processing batch generation:", error)

    if (error instanceof AIServiceError) {
      return NextResponse.json(
        {
          success: false,
          error: error.message,
          statusCode: error.statusCode,
          context: error.context,
        },
        { status: error.statusCode },
      )
    }

    return NextResponse.json(
      {
        success: false,
        error: "Failed to process batch generation",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

