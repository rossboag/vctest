import { NextResponse } from "next/server"
import { aiServiceClient } from "@/lib/ai-service-client"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { elements, prompt, creativity } = await request.json()

    // Call the AI service client
    const result = await aiServiceClient.generateLayout(elements, prompt, creativity)

    return NextResponse.json({
      result,
    })
  } catch (error) {
    console.error("Error in generate-layout API:", error)
    return NextResponse.json({ error: "Failed to generate layout" }, { status: 500 })
  }
}

