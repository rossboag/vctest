import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService } from "@/lib/ai-service"
import { z } from "zod"

// Define validation schema
const designFeedbackSchema = z.object({
  projectId: z.string().min(1, "Project ID is required"),
  aspectToImprove: z.enum(["composition", "color", "typography", "overall", "branding"]).optional().default("overall"),
  styleReference: z.string().optional(),
  detailLevel: z.enum(["brief", "detailed", "comprehensive"]).optional().default("detailed"),
})

export async function POST(req: NextRequest) {
  try {
    // Authenticate user
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse and validate request body
    const body = await req.json()
    const validationResult = designFeedbackSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json({ error: "Invalid request", details: validationResult.error.format() }, { status: 400 })
    }

    const { projectId, aspectToImprove, styleReference } = validationResult.data

    // Generate design suggestions using AI service
    const result = await AIService.generateDesignSuggestion(session.user.id, projectId, {
      aspectToImprove,
      styleReference,
    })

    // Return successful response
    return NextResponse.json({
      success: true,
      data: result,
    })
  } catch (error) {
    console.error("Error generating design feedback:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to generate design feedback",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

