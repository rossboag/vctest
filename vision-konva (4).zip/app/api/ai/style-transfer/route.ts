import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService } from "@/lib/ai-service"
import { z } from "zod"

// Define validation schema
const styleTransferSchema = z.object({
  sourceImageUrl: z.string().url("Valid source image URL is required"),
  styleDescription: z.string().min(1, "Style description is required"),
  projectId: z.string().optional(),
  intensity: z.number().min(0).max(1).optional().default(0.7),
})

export async function POST(req: NextRequest) {
  try {
    // Authenticate user
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse and validate request body
    const body = await req.json()
    const validationResult = styleTransferSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json({ error: "Invalid request", details: validationResult.error.format() }, { status: 400 })
    }

    const { sourceImageUrl, styleDescription, projectId } = validationResult.data

    // Apply style transfer using AI service
    const result = await AIService.applyStyleTransfer(session.user.id, sourceImageUrl, styleDescription, projectId)

    // Return successful response
    return NextResponse.json({
      success: true,
      data: result,
    })
  } catch (error) {
    console.error("Error applying style transfer:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to apply style transfer",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

