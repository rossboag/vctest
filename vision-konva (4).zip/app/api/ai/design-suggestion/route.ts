import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService } from "@/lib/ai-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { projectId, aspectToImprove, styleReference } = body

    if (!projectId) {
      return NextResponse.json({ error: "Project ID is required" }, { status: 400 })
    }

    const result = await AIService.generateDesignSuggestion(session.user.id, projectId, {
      aspectToImprove,
      styleReference,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error generating design suggestion:", error)
    return NextResponse.json({ error: "Failed to generate design suggestion" }, { status: 500 })
  }
}

