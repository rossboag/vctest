import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService, AIServiceError } from "@/lib/ai-service"
import { z } from "zod"
import { headers } from "next/headers"
import { RequestLogger } from "@/lib/request-logger"

// Define validation schema
const colorPaletteSchema = z.object({
  prompt: z.string().min(1, "Prompt is required"),
  projectId: z.string().optional(),
  count: z.number().min(2).max(10).optional().default(5),
  mode: z.enum(["analogous", "complementary", "triadic", "monochromatic", "custom"]).optional().default("custom"),
  temperature: z.number().min(0).max(1).optional().default(0.7),
})

// Middleware to check API key for 3rd party applications
function validateApiKey(req: NextRequest): boolean {
  if (!process.env.API_SECRET_KEY) return false

  const headersList = headers()
  const apiKey = headersList.get("x-api-key")

  return apiKey === process.env.API_SECRET_KEY
}

export async function POST(req: NextRequest) {
  const requestStartTime = Date.now()
  let requestBody
  let userId: string | undefined
  let statusCode = 200
  let responseBody: any
  let errorMessage: string | undefined

  try {
    // Parse request body for logging
    try {
      requestBody = await req.json()
      // Clone the request with the parsed body for further processing
      req = new NextRequest(req.url, {
        headers: req.headers,
        method: req.method,
        body: JSON.stringify(requestBody),
        cache: req.cache,
        credentials: req.credentials,
        integrity: req.integrity,
        keepalive: req.keepalive,
        mode: req.mode,
        redirect: req.redirect,
        referrer: req.referrer,
        referrerPolicy: req.referrerPolicy,
      })
    } catch (e) {
      requestBody = {}
    }

    // Check for API key or authenticated session
    const session = await getServerSession(authOptions)
    const hasValidApiKey = validateApiKey(req)

    if (!session?.user && !hasValidApiKey) {
      statusCode = 401
      responseBody = { success: false, error: "Unauthorized" }
      return NextResponse.json(responseBody, { status: statusCode })
    }

    userId = session?.user?.id || "api-client"

    // Parse and validate request body
    const validationResult = colorPaletteSchema.safeParse(requestBody)

    if (!validationResult.success) {
      statusCode = 400
      responseBody = {
        success: false,
        error: "Invalid request",
        details: validationResult.error.format(),
      }
      return NextResponse.json(responseBody, { status: statusCode })
    }

    const { prompt, projectId, count, mode, temperature } = validationResult.data

    // Generate color palette using AI service
    const result = await AIService.generateColorPalette(userId, prompt, projectId, { count, mode, temperature })

    // Set response body for logging
    responseBody = { success: true, data: result }

    // Return successful response
    return NextResponse.json(responseBody)
  } catch (error) {
    console.error("Error generating color palette:", error)

    if (error instanceof AIServiceError) {
      statusCode = error.statusCode
      errorMessage = error.message
      responseBody = {
        success: false,
        error: error.message,
        statusCode: error.statusCode,
        context: error.context,
      }
      return NextResponse.json(responseBody, { status: statusCode })
    }

    statusCode = 500
    errorMessage = error instanceof Error ? error.message : "Unknown error"
    responseBody = {
      success: false,
      error: "Failed to generate color palette",
      details: errorMessage,
    }

    // Log the error
    if (error instanceof Error) {
      await RequestLogger.logError(
        error,
        {
          method: req.method,
          url: req.url,
          headers: Object.fromEntries(req.headers.entries()),
          body: requestBody,
        },
        responseBody,
      )
    }

    return NextResponse.json(responseBody, { status: statusCode })
  } finally {
    // Log the request
    const responseTime = Date.now() - requestStartTime
    await RequestLogger.logRequest({
      method: req.method || "UNKNOWN",
      path: req.nextUrl.pathname,
      userId,
      statusCode,
      responseTime,
      ipAddress: req.ip || req.headers.get("x-forwarded-for") || undefined,
      userAgent: req.headers.get("user-agent") || undefined,
      errorMessage,
      requestBody,
      responseBody,
    })
  }
}

