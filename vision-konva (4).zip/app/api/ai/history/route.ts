import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService } from "@/lib/ai-service"

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const type = searchParams.get("type") as any
    const limit = searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : undefined
    const offset = searchParams.get("offset") ? Number.parseInt(searchParams.get("offset")!) : undefined
    const projectId = searchParams.get("projectId") || undefined

    const generations = await AIService.getUserGenerations(session.user.id, { type, limit, offset, projectId })

    return NextResponse.json(generations)
  } catch (error) {
    console.error("Error fetching AI generation history:", error)
    return NextResponse.json({ error: "Failed to fetch AI generation history" }, { status: 500 })
  }
}

