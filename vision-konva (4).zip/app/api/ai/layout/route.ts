import type { NextRequest } from "next/server"
import { AIService } from "@/lib/ai-service"
import { z } from "zod"
import { withApiHandler } from "@/lib/api-utils"

// Define element schema
const elementSchema = z.object({
  type: z.string(),
  content: z.string().optional(),
  importance: z.enum(["high", "medium", "low"]).optional(),
})

// Define validation schema
const layoutGenerationSchema = z.object({
  prompt: z.string().min(1, "Prompt is required"),
  projectId: z.string().optional(),
  width: z.number().min(100).max(4000).optional().default(1920),
  height: z.number().min(100).max(4000).optional().default(1080),
  elements: z.array(elementSchema).optional().default([]),
  style: z.string().optional(),
  purpose: z.enum(["marketing", "presentation", "social-media", "print", "web", "other"]).optional().default("web"),
  temperature: z.number().min(0).max(1).optional().default(0.7),
})

async function handler(req: NextRequest, userId: string) {
  // Parse and validate request body
  const body = await req.json()
  const validationResult = layoutGenerationSchema.safeParse(body)

  if (!validationResult.success) {
    throw new Error(`Invalid request: ${JSON.stringify(validationResult.error.format())}`)
  }

  const { prompt, projectId, width, height, elements, temperature } = validationResult.data

  // Generate layout using AI service
  return await AIService.generateLayoutSuggestion(userId, prompt, projectId, { width, height, elements, temperature })
}

export const POST = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: true,
  logRequests: true,
})

