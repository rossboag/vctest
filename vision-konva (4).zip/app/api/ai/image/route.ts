import type { NextRequest } from "next/server"
import { z } from "zod"
import { withApiHandler, validateRequest, checkContentPolicy } from "@/lib/api-utils"
import { AIService } from "@/lib/ai-service"
import { ContentPolicyError } from "@/lib/errors"
import { RequestLogger } from "@/lib/request-logger"

// Define validation schema with stricter validation
const imageGenerationSchema = z.object({
  prompt: z
    .string()
    .min(3, "Prompt must be at least 3 characters")
    .max(1000, "Prompt cannot exceed 1000 characters")
    .refine((val) => !val.includes("http"), {
      message: "Prompt cannot contain URLs",
    }),
  projectId: z.string().uuid("Invalid project ID format").optional(),
  size: z.enum(["1024x1024", "1792x1024", "1024x1792"]).optional().default("1024x1024"),
  style: z.enum(["natural", "vivid"]).optional().default("natural"),
  quality: z.enum(["standard", "hd"]).optional().default("standard"),
  safetyLevel: z.enum(["low", "medium", "high"]).optional().default("medium"),
  returnFormat: z.enum(["url", "base64", "json"]).optional().default("url"),
  numberOfGenerations: z
    .number()
    .int("Number of generations must be an integer")
    .min(1, "At least 1 generation required")
    .max(4, "Maximum 4 generations allowed")
    .optional()
    .default(1),
})

// Type inference from the schema
type ImageGenerationRequest = z.infer<typeof imageGenerationSchema>

async function handler(req: NextRequest, user: { id: string; role: string }) {
  // Parse and validate request
  const body = await req.json()
  const data = validateRequest<ImageGenerationRequest>(imageGenerationSchema, body)

  // Enhanced content policy check with additional rules for AI image generation
  if (!checkContentPolicy(data.prompt, data.safetyLevel)) {
    // Log content policy violation
    await RequestLogger.trackSecurityEvent(
      "CONTENT_POLICY_VIOLATION",
      {
        endpoint: "image-generation",
        promptLength: data.prompt.length,
        safetyLevel: data.safetyLevel,
      },
      user.id,
      req.ip,
    )

    throw new ContentPolicyError("Content policy violation: Prompt contains prohibited content", {
      safetyLevel: data.safetyLevel,
    })
  }

  // Apply rate limiting based on user role and model
  const rateLimit = {
    ADMIN: 100,
    PREMIUM: 50,
    USER: 20,
    PUBLIC: 5,
    API: 200,
  }

  const userRateLimit = rateLimit[user.role as keyof typeof rateLimit] || 5

  // Check if user has enough remaining generations
  // This would typically be implemented with Redis or a database check

  // Generate image(s)
  const results = []

  for (let i = 0; i < data.numberOfGenerations; i++) {
    const result = await AIService.generateImage(user.id, data.prompt, data.projectId, {
      size: data.size,
      style: data.style,
      quality: data.quality,
      returnFormat: data.returnFormat,
    })

    results.push(result)
  }

  // Return single result or array based on numberOfGenerations
  return data.numberOfGenerations === 1 ? results[0] : results
}

// Enhanced API handler with detailed options
export const POST = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: true,
  logRequests: true,
  validateContentPolicy: true,
  rateLimitKey: "ai:image",
  allowedRoles: ["ADMIN", "PREMIUM", "USER", "API"], // Restrict to these roles
})

