import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIService } from "@/lib/ai-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { content, contentType, projectId, tone, purpose, targetAudience } = body

    if (!content || !contentType) {
      return NextResponse.json({ error: "Content and contentType are required" }, { status: 400 })
    }

    const result = await AIService.enhanceContent(session.user.id, content, contentType, projectId, {
      tone,
      purpose,
      targetAudience,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error enhancing content:", error)
    return NextResponse.json({ error: "Failed to enhance content" }, { status: 500 })
  }
}

