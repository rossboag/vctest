import type { NextRequest } from "next/server"
import { withApiHandler } from "@/lib/api-utils"
import { AIBulkOperations } from "@/lib/ai-bulk-operations"

async function handler(req: NextRequest, userId: string) {
  const jobId = req.nextUrl.pathname.split("/").pop()

  if (!jobId) {
    throw new Error("Job ID is required")
  }

  // Get job status
  return await AIBulkOperations.getBulkJobStatus(jobId, userId)
}

export const GET = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: true,
  logRequests: true,
})

