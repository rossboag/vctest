import type { NextRequest } from "next/server"
import { z } from "zod"
import { withApiHandler } from "@/lib/api-utils"
import { AIBulkOperations } from "@/lib/ai-bulk-operations"

// Define bulk generation request schema
const bulkRequestSchema = z.object({
  projectId: z.string().optional(),
  requests: z
    .array(
      z.object({
        type: z.enum([
          "text_generation",
          "image_generation",
          "color_palette",
          "layout_suggestion",
          "animation_suggestion",
          "content_enhancement",
          "style_transfer",
          "design_suggestion",
        ]),
        prompt: z.string().min(1, "Prompt is required"),
        options: z.record(z.any()).optional(),
      }),
    )
    .min(1)
    .max(50),
})

async function handler(req: NextRequest, userId: string) {
  // Parse and validate request body
  const body = await req.json()
  const validationResult = bulkRequestSchema.safeParse(body)

  if (!validationResult.success) {
    throw new Error(`Invalid request: ${JSON.stringify(validationResult.error.format())}`)
  }

  const { projectId, requests } = validationResult.data

  // Start bulk generation job
  const jobId = await AIBulkOperations.startBulkGeneration(userId, requests, projectId)

  return {
    jobId,
    message: "Bulk generation job started",
  }
}

export const POST = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: true,
  logRequests: true,
})

