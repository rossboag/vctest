import { NextResponse } from "next/server"
import { aiServiceClient } from "@/lib/ai-service-client"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { prompt, options } = await request.json()

    // Call the AI service client
    const result = await aiServiceClient.generateContent(prompt, options)

    return NextResponse.json({
      result,
    })
  } catch (error) {
    console.error("Error in generate-content API:", error)
    return NextResponse.json(
      { error: `Failed to generate ${request.body?.options?.type || "content"}` },
      { status: 500 },
    )
  }
}

