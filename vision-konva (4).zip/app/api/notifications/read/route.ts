import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { NotificationService } from "@/lib/notification-service"

// POST /api/notifications/read - Mark notifications as read
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { id, all } = body

    if (all) {
      // Mark all notifications as read
      const result = await NotificationService.markAllAsRead(session.user.id)
      return NextResponse.json(result)
    } else if (id) {
      // Mark a specific notification as read
      const notification = await NotificationService.markAsRead(id)
      return NextResponse.json(notification)
    } else {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }
  } catch (error) {
    console.error("Error marking notifications as read:", error)
    return NextResponse.json({ error: "Failed to mark notifications as read" }, { status: 500 })
  }
}

