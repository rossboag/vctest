import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { NotificationService } from "@/lib/notification-service"

// POST /api/notifications/delete - Delete notifications
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { id, all } = body

    if (all) {
      // Delete all notifications
      const result = await NotificationService.deleteAllNotifications(session.user.id)
      return NextResponse.json(result)
    } else if (id) {
      // Delete a specific notification
      const notification = await NotificationService.deleteNotification(id)
      return NextResponse.json(notification)
    } else {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }
  } catch (error) {
    console.error("Error deleting notifications:", error)
    return NextResponse.json({ error: "Failed to delete notifications" }, { status: 500 })
  }
}

