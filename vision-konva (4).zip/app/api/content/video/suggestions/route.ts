import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIContentService, type VideoSuggestionOptions } from "@/lib/ai-content-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { topic, options, projectId } = body

    if (!topic) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    const result = await AIContentService.generateVideoSuggestions(
      session.user.id,
      topic,
      options as VideoSuggestionOptions,
      projectId,
    )

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error generating video suggestions:", error)
    return NextResponse.json({ error: "Failed to generate video suggestions" }, { status: 500 })
  }
}

