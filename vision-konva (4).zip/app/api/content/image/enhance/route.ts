import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIContentService, type ImageEnhancementOptions } from "@/lib/ai-content-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { imageUrl, options, projectId } = body

    if (!imageUrl) {
      return NextResponse.json({ error: "Image URL is required" }, { status: 400 })
    }

    const result = await AIContentService.enhanceImage(
      session.user.id,
      imageUrl,
      options as ImageEnhancementOptions,
      projectId,
    )

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error enhancing image:", error)
    return NextResponse.json({ error: "Failed to enhance image" }, { status: 500 })
  }
}

