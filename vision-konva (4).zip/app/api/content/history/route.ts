import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIContentService } from "@/lib/ai-content-service"

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = req.nextUrl.searchParams
    const type = searchParams.get("type") || undefined
    const limit = Number.parseInt(searchParams.get("limit") || "10", 10)
    const offset = Number.parseInt(searchParams.get("offset") || "0", 10)
    const projectId = searchParams.get("projectId") || undefined

    const result = await AIContentService.getUserEnhancements(session.user.id, {
      type,
      limit,
      offset,
      projectId,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error fetching content enhancement history:", error)
    return NextResponse.json({ error: "Failed to fetch content enhancement history" }, { status: 500 })
  }
}

