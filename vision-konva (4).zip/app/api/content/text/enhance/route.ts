import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIContentService, type ContentEnhancementOptions } from "@/lib/ai-content-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { content, options, projectId } = body

    if (content === undefined) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    const result = await AIContentService.enhanceText(
      session.user.id,
      content,
      options as ContentEnhancementOptions,
      projectId,
    )

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error enhancing text:", error)
    return NextResponse.json({ error: "Failed to enhance text content" }, { status: 500 })
  }
}

