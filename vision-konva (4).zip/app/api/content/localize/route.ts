import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIContentService, type LocalizationOptions } from "@/lib/ai-content-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { content, options, projectId } = body

    if (!content) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    if (!options?.targetLanguage) {
      return NextResponse.json({ error: "Target language is required" }, { status: 400 })
    }

    const result = await AIContentService.localizeContent(
      session.user.id,
      content,
      options as LocalizationOptions,
      projectId,
    )

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error localizing content:", error)
    return NextResponse.json({ error: "Failed to localize content" }, { status: 500 })
  }
}

