import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIContentService, type ContentAdaptationOptions } from "@/lib/ai-content-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { content, options, projectId } = body

    if (!content) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    const result = await AIContentService.adaptContent(
      session.user.id,
      content,
      options as ContentAdaptationOptions,
      projectId,
    )

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error adapting content:", error)
    return NextResponse.json({ error: "Failed to adapt content" }, { status: 500 })
  }
}

