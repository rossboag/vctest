import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIDesignService, type DesignAnalysisResult, type DesignElement } from "@/lib/ai-design-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { analysisResult, elements, canvasWidth, canvasHeight, projectId } = body

    if (!analysisResult || !elements || !canvasWidth || !canvasHeight) {
      return NextResponse.json(
        { error: "Analysis result, elements, canvas width, and canvas height are required" },
        { status: 400 },
      )
    }

    const actions = await AIDesignService.generateImprovementActions(
      session.user.id,
      analysisResult as DesignAnalysisResult,
      elements as DesignElement[],
      canvasWidth,
      canvasHeight,
      projectId,
    )

    return NextResponse.json(actions)
  } catch (error) {
    console.error("Error generating improvement actions:", error)
    return NextResponse.json({ error: "Failed to generate improvement actions" }, { status: 500 })
  }
}

