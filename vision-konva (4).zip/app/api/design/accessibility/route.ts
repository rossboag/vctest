import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIDesignService } from "@/lib/ai-design-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { designElements, projectId } = body

    if (!designElements) {
      return NextResponse.json({ error: "Design elements are required" }, { status: 400 })
    }

    const accessibility = await AIDesignService.checkAccessibility(session.user.id, designElements, projectId)

    return NextResponse.json(accessibility)
  } catch (error) {
    console.error("Error checking accessibility:", error)
    return NextResponse.json({ error: "Failed to check accessibility" }, { status: 500 })
  }
}

