import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIDesignService } from "@/lib/ai-design-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { designElements, canvasSize, projectId } = body

    if (!designElements || !canvasSize) {
      return NextResponse.json({ error: "Design elements and canvas size are required" }, { status: 400 })
    }

    const analysis = await AIDesignService.analyzeDesign(session.user.id, designElements, canvasSize, projectId)

    return NextResponse.json(analysis)
  } catch (error) {
    console.error("Error analyzing design:", error)
    return NextResponse.json({ error: "Failed to analyze design" }, { status: 500 })
  }
}

