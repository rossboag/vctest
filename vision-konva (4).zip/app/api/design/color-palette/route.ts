import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIDesignService } from "@/lib/ai-design-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { baseColor, mood, style, projectId } = body

    const palette = await AIDesignService.generateColorPalette(session.user.id, baseColor, mood, style, projectId)

    return NextResponse.json(palette)
  } catch (error) {
    console.error("Error generating color palette:", error)
    return NextResponse.json({ error: "Failed to generate color palette" }, { status: 500 })
  }
}

