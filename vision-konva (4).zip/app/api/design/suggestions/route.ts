import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIDesignService } from "@/lib/ai-design-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { designElements, canvasSize, focusArea, projectId } = body

    if (!designElements || !canvasSize) {
      return NextResponse.json({ error: "Design elements and canvas size are required" }, { status: 400 })
    }

    const suggestions = await AIDesignService.generateDesignSuggestions(
      session.user.id,
      designElements,
      canvasSize,
      focusArea,
      projectId,
    )

    return NextResponse.json(suggestions)
  } catch (error) {
    console.error("Error generating design suggestions:", error)
    return NextResponse.json({ error: "Failed to generate design suggestions" }, { status: 500 })
  }
}

