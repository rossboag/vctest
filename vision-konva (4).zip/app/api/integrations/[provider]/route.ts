import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { IntegrationService, type IntegrationProvider } from "@/lib/integration-service"

// DELETE /api/integrations/[provider] - Delete integration
export async function DELETE(req: NextRequest, { params }: { params: { provider: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const provider = params.provider as IntegrationProvider

    await IntegrationService.deleteIntegration(session.user.id, provider)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting integration:", error)
    return NextResponse.json({ error: "Failed to delete integration" }, { status: 500 })
  }
}

