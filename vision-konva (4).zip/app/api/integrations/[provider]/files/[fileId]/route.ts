import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { IntegrationService, type IntegrationProvider } from "@/lib/integration-service"
import { IntegrationFactory } from "@/lib/integrations/integration-factory"

// GET /api/integrations/[provider]/files/[fileId] - Get file
export async function GET(req: NextRequest, { params }: { params: { provider: string; fileId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const provider = params.provider as IntegrationProvider
    const fileId = params.fileId
    const { searchParams } = new URL(req.url)
    const download = searchParams.get("download") === "true"

    // Get integration
    const integration = await IntegrationService.getIntegration(session.user.id, provider)

    if (!integration) {
      return NextResponse.json({ error: "Integration not found" }, { status: 404 })
    }

    // Get service
    const service = IntegrationFactory.getService(provider, integration.accessToken, session.user.id)

    if (download) {
      // Download file
      const fileData = await (service as any).downloadFile(fileId)

      // Get file metadata
      const fileInfo = await (service as any).getFile(fileId)

      // Return file data
      return new NextResponse(fileData, {
        headers: {
          "Content-Type": fileInfo.mimeType || "application/octet-stream",
          "Content-Disposition": `attachment; filename="${fileInfo.name}"`,
        },
      })
    } else {
      // Get file metadata
      const file = await (service as any).getFile(fileId)
      return NextResponse.json(file)
    }
  } catch (error) {
    console.error("Error getting file:", error)
    return NextResponse.json({ error: "Failed to get file" }, { status: 500 })
  }
}

// DELETE /api/integrations/[provider]/files/[fileId] - Delete file
export async function DELETE(req: NextRequest, { params }: { params: { provider: string; fileId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const provider = params.provider as IntegrationProvider
    const fileId = params.fileId

    // Get integration
    const integration = await IntegrationService.getIntegration(session.user.id, provider)

    if (!integration) {
      return NextResponse.json({ error: "Integration not found" }, { status: 404 })
    }

    // Get service
    const service = IntegrationFactory.getService(provider, integration.accessToken, session.user.id)

    // Delete file
    await (service as any).deleteFile(fileId)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting file:", error)
    return NextResponse.json({ error: "Failed to delete file" }, { status: 500 })
  }
}

