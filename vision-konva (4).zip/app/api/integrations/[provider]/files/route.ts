import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { IntegrationService, type IntegrationProvider } from "@/lib/integration-service"
import { IntegrationFactory } from "@/lib/integrations/integration-factory"

// GET /api/integrations/[provider]/files - List files
export async function GET(req: NextRequest, { params }: { params: { provider: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const provider = params.provider as IntegrationProvider
    const { searchParams } = new URL(req.url)
    const folderId = searchParams.get("folderId") || undefined
    const path = searchParams.get("path") || undefined

    // Get integration
    const integration = await IntegrationService.getIntegration(session.user.id, provider)

    if (!integration) {
      return NextResponse.json({ error: "Integration not found" }, { status: 404 })
    }

    // Get service
    const service = IntegrationFactory.getService(provider, integration.accessToken, session.user.id)

    // List files
    let files
    if (provider === "dropbox") {
      files = await (service as any).listFiles(path)
    } else {
      files = await (service as any).listFiles(folderId)
    }

    return NextResponse.json(files)
  } catch (error) {
    console.error("Error listing files:", error)
    return NextResponse.json({ error: "Failed to list files" }, { status: 500 })
  }
}

// POST /api/integrations/[provider]/files - Upload file
export async function POST(req: NextRequest, { params }: { params: { provider: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const provider = params.provider as IntegrationProvider

    // Get integration
    const integration = await IntegrationService.getIntegration(session.user.id, provider)

    if (!integration) {
      return NextResponse.json({ error: "Integration not found" }, { status: 404 })
    }

    // Get service
    const service = IntegrationFactory.getService(provider, integration.accessToken, session.user.id)

    // Parse form data
    const formData = await req.formData()
    const file = formData.get("file") as File
    const folderId = formData.get("folderId") as string
    const path = formData.get("path") as string
    const filename = formData.get("filename") as string

    if (!file) {
      return NextResponse.json({ error: "File is required" }, { status: 400 })
    }

    // Upload file
    let result
    if (provider === "dropbox") {
      result = await (service as any).uploadFile(file, path, filename)
    } else {
      result = await (service as any).uploadFile(file, folderId, filename)
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error uploading file:", error)
    return NextResponse.json({ error: "Failed to upload file" }, { status: 500 })
  }
}

