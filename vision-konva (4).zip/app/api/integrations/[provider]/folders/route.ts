import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { IntegrationService, type IntegrationProvider } from "@/lib/integration-service"
import { IntegrationFactory } from "@/lib/integrations/integration-factory"

// POST /api/integrations/[provider]/folders - Create folder
export async function POST(req: NextRequest, { params }: { params: { provider: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const provider = params.provider as IntegrationProvider
    const body = await req.json()
    const { name, parentId, path } = body

    if (!name) {
      return NextResponse.json({ error: "Folder name is required" }, { status: 400 })
    }

    // Get integration
    const integration = await IntegrationService.getIntegration(session.user.id, provider)

    if (!integration) {
      return NextResponse.json({ error: "Integration not found" }, { status: 404 })
    }

    // Get service
    const service = IntegrationFactory.getService(provider, integration.accessToken, session.user.id)

    // Create folder
    let folder
    if (provider === "dropbox") {
      folder = await (service as any).createFolder(name, path || "")
    } else {
      folder = await (service as any).createFolder(name, parentId)
    }

    return NextResponse.json(folder)
  } catch (error) {
    console.error("Error creating folder:", error)
    return NextResponse.json({ error: "Failed to create folder" }, { status: 500 })
  }
}

