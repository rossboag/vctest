import type { NextRequest } from "next/server"
import { getAssetService } from "@/lib/assets/asset-service"
import { withApiHandler } from "@/lib/api-utils"

const assetService = getAssetService()

interface RouteParams {
  params: {
    id: string
  }
}

/**
 * Get asset by ID
 */
export const GET = withApiHandler(
  async (req: NextRequest, user, { params }: RouteParams) => {
    const { id } = params
    return await assetService.getAsset(id, user.id)
  },
  {
    requireAuth: true,
    logRequests: true,
  },
)

/**
 * Update asset
 */
export const PATCH = withApiHandler(
  async (req: NextRequest, user, { params }: RouteParams) => {
    const { id } = params
    const data = await req.json()

    return await assetService.updateAsset(id, user.id, data)
  },
  {
    requireAuth: true,
    logRequests: true,
  },
)

/**
 * Delete asset
 */
export const DELETE = withApiHandler(
  async (req: NextRequest, user, { params }: RouteParams) => {
    const { id } = params

    await assetService.deleteAsset(id, user.id)

    return { success: true }
  },
  {
    requireAuth: true,
    logRequests: true,
  },
)

