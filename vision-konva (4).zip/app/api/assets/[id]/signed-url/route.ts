import type { NextRequest } from "next/server"
import { getAssetService } from "@/lib/assets/asset-service"
import { withApiHandler } from "@/lib/api-utils"

const assetService = getAssetService()

interface RouteParams {
  params: {
    id: string
  }
}

/**
 * Get a signed URL for an asset
 */
export const GET = withApiHandler(
  async (req: NextRequest, user, { params }: RouteParams) => {
    const { id } = params
    const { searchParams } = new URL(req.url)

    const expiresIn = Number.parseInt(searchParams.get("expiresIn") || "3600")

    const signedUrl = await assetService.getSignedUrl(id, user.id, expiresIn)

    return { signedUrl }
  },
  {
    requireAuth: true,
    logRequests: true,
  },
)

