import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { generateUniqueFileName, uploadFileToS3 } from "@/lib/s3-client"
import { prisma } from "@/lib/db"

// Maximum file size (10MB)
const MAX_FILE_SIZE = 10 * 1024 * 1024

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if the request is multipart/form-data
    const contentType = req.headers.get("content-type") || ""
    if (!contentType.includes("multipart/form-data")) {
      return NextResponse.json({ error: "Invalid content type" }, { status: 400 })
    }

    const formData = await req.formData()
    const file = formData.get("file") as File | null
    const assetType = formData.get("type") as string | null
    const assetName = formData.get("name") as string | null

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    if (!assetType || !["image", "video", "font", "audio"].includes(assetType)) {
      return NextResponse.json({ error: "Invalid asset type" }, { status: 400 })
    }

    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: "File size exceeds the limit (10MB)" }, { status: 400 })
    }

    // Generate a unique filename
    const fileName = generateUniqueFileName(file.name)

    // Convert File to Buffer
    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Upload to S3
    const { url, key } = await uploadFileToS3(buffer, fileName, file.type)

    // Create asset record in the database
    const asset = await prisma.asset.create({
      data: {
        name: assetName || file.name,
        type: assetType,
        mimeType: file.type,
        size: file.size,
        url,
        key,
        userId: session.user.id,
      },
    })

    return NextResponse.json(asset)
  } catch (error) {
    console.error("Error uploading file:", error)
    return NextResponse.json({ error: "Failed to upload file" }, { status: 500 })
  }
}

