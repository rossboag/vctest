import type { NextRequest } from "next/server"
import { getAssetService } from "@/lib/assets/asset-service"
import { withApiHandler } from "@/lib/api-utils"
import { ValidationError } from "@/lib/errors"

const assetService = getAssetService()

/**
 * List assets
 */
export const GET = withApiHandler(
  async (req: NextRequest, user) => {
    const { searchParams } = new URL(req.url)

    const type = searchParams.get("type") || undefined
    const projectId = searchParams.get("projectId") || undefined
    const search = searchParams.get("search") || undefined
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const sortBy = searchParams.get("sortBy") || "createdAt"
    const sortOrder = (searchParams.get("sortOrder") || "desc") as "asc" | "desc"

    const result = await assetService.listAssets(user.id, {
      type,
      projectId,
      search,
      page,
      limit,
      sortBy,
      sortOrder,
    })

    return result
  },
  {
    requireAuth: true,
    logRequests: true,
  },
)

/**
 * Upload a new asset
 */
export const POST = withApiHandler(
  async (req: NextRequest, user) => {
    const formData = await req.formData()

    // Get file from form data
    const file = formData.get("file")
    if (!file || !(file instanceof File)) {
      throw new ValidationError("No file provided")
    }

    // Get and validate metadata
    const name = formData.get("name") as string
    const type = formData.get("type") as string
    const projectId = formData.get("projectId") as string | undefined
    const isPublic = formData.get("isPublic") === "true"
    const tagsString = formData.get("tags") as string | undefined
    const tags = tagsString ? JSON.parse(tagsString) : undefined

    // Read file as buffer
    const buffer = Buffer.from(await file.arrayBuffer())

    // Create asset
    const asset = await assetService.createAsset(user.id, buffer, file.name, file.type, {
      name: name || file.name,
      type: type || "other",
      mimeType: file.type,
      size: file.size,
      projectId,
      isPublic,
      tags,
    })

    return asset
  },
  {
    requireAuth: true,
    logRequests: true,
  },
)

