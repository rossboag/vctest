import { type NextRequest, NextResponse } from "next/server"
import { StripeService, stripe } from "@/lib/stripe/stripe-service"
import { logger } from "@/lib/logger"

export async function POST(req: NextRequest) {
  try {
    // Get the signature header
    const signature = req.headers.get("stripe-signature")

    if (!signature) {
      return NextResponse.json({ error: "Stripe signature not found" }, { status: 400 })
    }

    // Get the webhook secret
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET

    if (!webhookSecret) {
      logger.error("STRIPE_WEBHOOK_SECRET is not defined")
      return NextResponse.json({ error: "Webhook secret not configured" }, { status: 500 })
    }

    // Get the raw body
    const body = await req.text()

    // Verify the event
    let event
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err: any) {
      logger.error(`Webhook signature verification failed: ${err.message}`)
      return NextResponse.json({ error: `Webhook signature verification failed: ${err.message}` }, { status: 400 })
    }

    // Handle the event
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as any

        // If it's a subscription checkout, the subscription will be created
        // and we'll handle it in the subscription events
        logger.info("Checkout completed", { sessionId: session.id })
        break
      }

      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as any
        await StripeService.handleSubscriptionUpdated(subscription)
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as any
        await StripeService.handleSubscriptionDeleted(subscription)
        break
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as any
        await StripeService.handleInvoicePaymentSucceeded(invoice)
        break
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as any
        await StripeService.handleInvoicePaymentFailed(invoice)
        break
      }

      default: {
        logger.info(`Unhandled event type: ${event.type}`)
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    logger.error("Error in Stripe webhook handler", { error })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export const config = {
  api: {
    bodyParser: false, // Don't parse the body, we need the raw body for signature verification
  },
}

