import { type NextRequest, NextResponse } from "next/server"

// This route is just a placeholder for the Socket.IO server
// The actual Socket.IO server is initialized in server.js
export async function GET(req: NextRequest) {
  return NextResponse.json({ message: "Socket.IO server is running" }, { status: 200 })
}

