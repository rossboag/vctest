import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { exportUtils, type ExportOptions } from "@/lib/export-utils"
import { prisma } from "@/lib/db"
import { z } from "zod"

// Export request schema
const exportRequestSchema = z.object({
  projectId: z.string().optional(),
  elements: z.array(z.any()).optional(),
  width: z.number().min(1).max(10000).default(1920),
  height: z.number().min(1).max(10000).default(1080),
  format: z.enum(["png", "jpeg", "svg", "mp4", "gif"]).default("png"),
  quality: z.number().min(1).max(100).default(90),
  fps: z.number().min(1).max(60).default(30),
  duration: z.number().min(1).max(60).default(5),
  background: z.string().default("#ffffff"),
})

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse request body
    const body = await request.json()
    const validationResult = exportRequestSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json({ error: "Invalid request", details: validationResult.error }, { status: 400 })
    }

    const { projectId, elements, width, height, format, quality, fps, duration, background } = validationResult.data

    // Get elements from project if projectId is provided and elements are not
    let elementsToExport = elements
    if (projectId && !elements) {
      const project = await prisma.project.findUnique({
        where: { id: projectId },
        include: {
          elements: true,
        },
      })

      if (!project) {
        return NextResponse.json({ error: "Project not found" }, { status: 404 })
      }

      // Check if user has access to this project
      if (project.userId !== session.user.id && session.user.role !== "admin") {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
      }

      elementsToExport = project.elements
    }

    if (!elementsToExport || elementsToExport.length === 0) {
      return NextResponse.json({ error: "No elements to export" }, { status: 400 })
    }

    // Create export options
    const exportOptions: ExportOptions = {
      width,
      height,
      format,
      quality,
      fps,
      duration,
      elements: elementsToExport,
      background,
    }

    // Export based on format
    let result
    if (format === "gif") {
      result = await exportUtils.exportGIF(exportOptions)
    } else if (format === "mp4") {
      result = await exportUtils.exportVideo(exportOptions)
    } else {
      result = await exportUtils.exportImage(exportOptions)
    }

    // Save export record in database
    const exportRecord = await prisma.export.create({
      data: {
        userId: session.user.id,
        projectId: projectId || null,
        format,
        width,
        height,
        url: result.url,
        filename: result.filename,
        mimeType: result.mimeType,
      },
    })

    return NextResponse.json({
      id: exportRecord.id,
      url: result.url,
      filename: result.filename,
      mimeType: result.mimeType,
    })
  } catch (error) {
    console.error("Error in export API:", error)
    return NextResponse.json({ error: "Failed to export" }, { status: 500 })
  }
}

