import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import fs from "fs"
import path from "path"
import os from "os"

// Temporary directory for file operations
const TEMP_DIR = path.join(os.tmpdir(), "vision-creator-exports")

export async function GET(request: Request, { params }: { params: { filename: string } }) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { filename } = params

    // Validate filename to prevent directory traversal
    if (!filename || filename.includes("..") || filename.includes("/") || filename.includes("\\")) {
      return NextResponse.json({ error: "Invalid filename" }, { status: 400 })
    }

    const filepath = path.join(TEMP_DIR, filename)

    // Check if file exists
    if (!fs.existsSync(filepath)) {
      return NextResponse.json({ error: "File not found" }, { status: 404 })
    }

    // Read file
    const file = fs.readFileSync(filepath)

    // Determine content type
    let contentType = "application/octet-stream"
    if (filename.endsWith(".png")) {
      contentType = "image/png"
    } else if (filename.endsWith(".jpg") || filename.endsWith(".jpeg")) {
      contentType = "image/jpeg"
    } else if (filename.endsWith(".svg")) {
      contentType = "image/svg+xml"
    } else if (filename.endsWith(".mp4")) {
      contentType = "video/mp4"
    } else if (filename.endsWith(".gif")) {
      contentType = "image/gif"
    }

    // Return file
    return new NextResponse(file, {
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    })
  } catch (error) {
    console.error("Error in export file API:", error)
    return NextResponse.json({ error: "Failed to get export file" }, { status: 500 })
  }
}

