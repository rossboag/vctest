import type { NextRequest } from "next/server"
import { withApiHandler } from "@/lib/api-utils"
import { AuthorizationError } from "@/lib/errors"

async function handler(req: NextRequest, user: { id: string; role: string }) {
  // Only allow admins and developers
  if (!["ADMIN", "DEVELOPER"].includes(user.role)) {
    throw new AuthorizationError("Admin or developer access required")
  }

  // Get Redis instance
  const redis = globalThis.redis
  if (!redis) {
    return {
      status: "unavailable",
      message: "Redis is not configured",
    }
  }

  // Get user ID to check
  const url = new URL(req.url)
  const targetUserId = url.searchParams.get("userId") || user.id

  // Get all rate limiters status
  const limiters = ["api", "ai", "unauthenticated", "suspicious", "apiKey", "admin"]
  const results: Record<string, any> = {}

  for (const limiter of limiters) {
    const key = `ratelimit:${limiter}:${targetUserId}`
    try {
      const value = await redis.get(key)
      if (value) {
        // Parse the rate limit data
        results[limiter] = JSON.parse(value)
      } else {
        results[limiter] = { status: "no data" }
      }
    } catch (error) {
      console.error(`Error fetching rate limit for ${limiter}:`, error)
      results[limiter] = { status: "error", message: error instanceof Error ? error.message : "Unknown error" }
    }
  }

  // Check if user is on blocklist
  const isBlocked = await redis.get(`blocklist:ip:${req.ip}`)

  return {
    userId: targetUserId,
    ipAddress: req.ip,
    isBlocked: !!isBlocked,
    rateLimits: results,
    timestamp: new Date().toISOString(),
  }
}

export const GET = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: false,
  logRequests: true,
  allowedRoles: ["ADMIN", "DEVELOPER"],
})

