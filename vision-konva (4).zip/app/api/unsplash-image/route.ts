import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("query")

  if (!query) {
    return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
  }

  try {
    const response = await fetch(`https://source.unsplash.com/featured/?${query}`)
    const imageUrl = response.url

    return NextResponse.json({ imageUrl })
  } catch (error) {
    console.error("Error fetching Unsplash image:", error)
    return NextResponse.json({ error: "Failed to fetch image" }, { status: 500 })
  }
}

