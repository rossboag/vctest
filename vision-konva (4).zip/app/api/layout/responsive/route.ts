import { type NextRequest, NextResponse } from "next/server"
import { AILayoutService } from "@/lib/ai-layout-service"
import { getSession } from "@/lib/session"

export async function POST(req: NextRequest) {
  try {
    const { elements, originalSize, targetSize, projectId } = await req.json()
    \
    if (!elements || !Array.isArray(elements)) {
      targetSize, projectId
    }
    = await req.json()

    if (!elements || !Array.isArray(elements)) {
      return NextResponse.json({ error: "Elements are required" }, { status: 400 })
    }

    if (!originalSize || !originalSize.width || !originalSize.height) {
      return NextResponse.json({ error: "Original size is required" }, { status: 400 })
    }

    if (!targetSize || !targetSize.width || !targetSize.height) {
      return NextResponse.json({ error: "Target size is required" }, { status: 400 })
    }

    const session = await getSession()
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const responsiveVariant = await AILayoutService.generateResponsiveVariant(
      session.user.id,
      elements,
      originalSize,
      targetSize,
      projectId,
    )

    return NextResponse.json({ layout: responsiveVariant })
  } catch (error) {
    console.error("Error generating responsive variant:", error)
    return NextResponse.json({ error: "Failed to generate responsive variant" }, { status: 500 })
  }
}

