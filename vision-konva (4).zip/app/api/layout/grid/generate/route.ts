import { type NextRequest, NextResponse } from "next/server"
import { AILayoutService } from "@/lib/ai-layout-service"
import { getSession } from "@/lib/session"

export async function POST(req: NextRequest) {
  try {
    const { canvasSize, complexity, projectId } = await req.json()

    if (!canvasSize || !canvasSize.width || !canvasSize.height) {
      return NextResponse.json({ error: "Canvas size is required" }, { status: 400 })
    }

    const session = await getSession()
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const gridSystem = await AILayoutService.generateGridSystem(session.user.id, canvasSize, complexity, projectId)

    return NextResponse.json({ gridSystem })
  } catch (error) {
    console.error("Error generating grid system:", error)
    return NextResponse.json({ error: "Failed to generate grid system" }, { status: 500 })
  }
}

