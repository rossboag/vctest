import { type NextRequest, NextResponse } from "next/server"
import { AILayoutService } from "@/lib/ai-layout-service"
import { getSession } from "@/lib/session"

export async function POST(req: NextRequest) {
  try {
    const { prompt, canvasSize, contentElements, style, projectId } = await req.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    if (!canvasSize || !canvasSize.width || !canvasSize.height) {
      return NextResponse.json({ error: "Canvas size is required" }, { status: 400 })
    }

    const session = await getSession()
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const layout = await AILayoutService.generateLayout(
      session.user.id,
      prompt,
      canvasSize,
      contentElements,
      style,
      projectId,
    )

    return NextResponse.json({ layout })
  } catch (error) {
    console.error("Error generating layout:", error)
    return NextResponse.json({ error: "Failed to generate layout" }, { status: 500 })
  }
}

