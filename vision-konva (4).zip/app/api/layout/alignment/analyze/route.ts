import { type NextRequest, NextResponse } from "next/server"
import { AILayoutService } from "@/lib/ai-layout-service"
import { getSession } from "@/lib/session"

export async function POST(req: NextRequest) {
  try {
    const { elements, projectId } = await req.json()

    if (!elements || !Array.isArray(elements)) {
      return NextResponse.json({ error: "Elements are required" }, { status: 400 })
    }

    const session = await getSession()
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const analysis = await AILayoutService.analyzeAlignment(session.user.id, elements, projectId)

    return NextResponse.json({ analysis })
  } catch (error) {
    console.error("Error analyzing alignment:", error)
    return NextResponse.json({ error: "Failed to analyze alignment" }, { status: 500 })
  }
}

