import { type NextRequest, NextResponse } from "next/server"
import { AILayoutService } from "@/lib/ai-layout-service"
import { getSession } from "@/lib/session"

export async function POST(req: NextRequest) {
  try {
    const { elements, gridSystem, projectId } = await req.json()

    if (!elements || !Array.isArray(elements)) {
      return NextResponse.json({ error: "Elements are required" }, { status: 400 })
    }

    const session = await getSession()
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const optimizedElements = await AILayoutService.optimizeAlignment(session.user.id, elements, gridSystem, projectId)

    return NextResponse.json({ elements: optimizedElements })
  } catch (error) {
    console.error("Error optimizing alignment:", error)
    return NextResponse.json({ error: "Failed to optimize alignment" }, { status: 500 })
  }
}

