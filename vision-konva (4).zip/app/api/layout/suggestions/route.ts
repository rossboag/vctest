import { type NextRequest, NextResponse } from "next/server"
import { AILayoutService } from "@/lib/ai-layout-service"
import { getSession } from "@/lib/session"

export async function POST(req: NextRequest) {
  try {
    const { elements, canvasSize, projectId } = await req.json()

    if (!elements || !Array.isArray(elements)) {
      return NextResponse.json({ error: "Elements are required" }, { status: 400 })
    }

    if (!canvasSize || !canvasSize.width || !canvasSize.height) {
      return NextResponse.json({ error: "Canvas size is required" }, { status: 400 })
    }

    const session = await getSession()
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const suggestions = await AILayoutService.generateLayoutSuggestions(
      session.user.id,
      elements,
      canvasSize,
      projectId,
    )

    return NextResponse.json({ suggestions })
  } catch (error) {
    console.error("Error generating layout suggestions:", error)
    return NextResponse.json({ error: "Failed to generate layout suggestions" }, { status: 500 })
  }
}

