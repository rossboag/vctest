import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { z } from "zod"

// Schema for template update
const templateUpdateSchema = z.object({
  type: z.string().min(1).optional(),
  title: z.string().min(1).optional(),
  message: z.string().min(1).optional(),
})

// GET /api/admin/notification-templates/[id] - Get a specific notification template
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const template = await prisma.notificationTemplate.findUnique({
      where: {
        id: params.id,
      },
    })

    if (!template) {
      return NextResponse.json({ error: "Notification template not found" }, { status: 404 })
    }

    return NextResponse.json(template)
  } catch (error) {
    console.error("Error fetching notification template:", error)
    return NextResponse.json({ error: "Failed to fetch notification template" }, { status: 500 })
  }
}

// PATCH /api/admin/notification-templates/[id] - Update a notification template
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const validatedData = templateUpdateSchema.parse(body)

    // Check if the template exists
    const existingTemplate = await prisma.notificationTemplate.findUnique({
      where: {
        id: params.id,
      },
    })

    if (!existingTemplate) {
      return NextResponse.json({ error: "Notification template not found" }, { status: 404 })
    }

    // If type is being updated, check if it conflicts with another template
    if (validatedData.type && validatedData.type !== existingTemplate.type) {
      const conflictingTemplate = await prisma.notificationTemplate.findUnique({
        where: {
          type: validatedData.type,
        },
      })

      if (conflictingTemplate && conflictingTemplate.id !== params.id) {
        return NextResponse.json({ error: "A template with this type already exists" }, { status: 400 })
      }
    }

    const updatedTemplate = await prisma.notificationTemplate.update({
      where: {
        id: params.id,
      },
      data: validatedData,
    })

    return NextResponse.json(updatedTemplate)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    console.error("Error updating notification template:", error)
    return NextResponse.json({ error: "Failed to update notification template" }, { status: 500 })
  }
}

// DELETE /api/admin/notification-templates/[id] - Delete a notification template
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if the template exists
    const existingTemplate = await prisma.notificationTemplate.findUnique({
      where: {
        id: params.id,
      },
    })

    if (!existingTemplate) {
      return NextResponse.json({ error: "Notification template not found" }, { status: 404 })
    }

    await prisma.notificationTemplate.delete({
      where: {
        id: params.id,
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting notification template:", error)
    return NextResponse.json({ error: "Failed to delete notification template" }, { status: 500 })
  }
}

