import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { z } from "zod"

// Schema for template creation/update
const templateSchema = z.object({
  type: z.string().min(1),
  title: z.string().min(1),
  message: z.string().min(1),
})

// GET /api/admin/notification-templates - Get all notification templates
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const templates = await prisma.notificationTemplate.findMany({
      orderBy: {
        createdAt: "desc",
      },
    })

    return NextResponse.json(templates)
  } catch (error) {
    console.error("Error fetching notification templates:", error)
    return NextResponse.json({ error: "Failed to fetch notification templates" }, { status: 500 })
  }
}

// POST /api/admin/notification-templates - Create a new notification template
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const validatedData = templateSchema.parse(body)

    // Check if a template with this type already exists
    const existingTemplate = await prisma.notificationTemplate.findUnique({
      where: {
        type: validatedData.type,
      },
    })

    if (existingTemplate) {
      return NextResponse.json({ error: "A template with this type already exists" }, { status: 400 })
    }

    const template = await prisma.notificationTemplate.create({
      data: validatedData,
    })

    return NextResponse.json(template)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    console.error("Error creating notification template:", error)
    return NextResponse.json({ error: "Failed to create notification template" }, { status: 500 })
  }
}

