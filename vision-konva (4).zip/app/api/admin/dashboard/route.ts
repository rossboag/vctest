import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    // Check if user is authenticated and is an admin
    const session = await getServerSession(authOptions)
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get user count
    const userCount = await prisma.user.count()

    // Get active users (users who have logged in within the last 24 hours)
    const oneDayAgo = new Date()
    oneDayAgo.setDate(oneDayAgo.getDate() - 1)

    const activeUsers = await prisma.user.count({
      where: {
        lastLoginAt: {
          gte: oneDayAgo,
        },
      },
    })

    // Calculate storage used (in GB)
    const assets = await prisma.asset.findMany({
      select: {
        size: true,
      },
    })

    const totalBytes = assets.reduce((total, asset) => total + (asset.size || 0), 0)
    const storageUsed = Math.round((totalBytes / (1024 * 1024 * 1024)) * 100) / 100 // Convert bytes to GB with 2 decimal places

    // Return dashboard stats
    return NextResponse.json({
      stats: {
        userCount,
        activeUsers,
        storageUsed,
      },
    })
  } catch (error) {
    console.error("Error fetching dashboard stats:", error)
    return NextResponse.json({ error: "Failed to fetch dashboard stats" }, { status: 500 })
  }
}

