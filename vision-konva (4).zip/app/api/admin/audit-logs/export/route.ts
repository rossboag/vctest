import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { createAuditLog } from "@/lib/audit-log"

export async function GET(req: NextRequest) {
  try {
    // Check if user is authenticated and is an admin
    const session = await getServerSession(authOptions)
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get query parameters
    const { searchParams } = new URL(req.url)
    const search = searchParams.get("search") || ""
    const action = searchParams.get("action") || ""
    const entity = searchParams.get("entity") || ""

    // Build where clause
    const where: any = {}

    if (search) {
      where.OR = [
        { entityId: { contains: search, mode: "insensitive" } },
        { userId: { contains: search, mode: "insensitive" } },
      ]
    }

    if (action) {
      where.action = action
    }

    if (entity) {
      where.entity = entity
    }

    // Get all audit logs matching the criteria
    const logs = await prisma.auditLog.findMany({
      where,
      orderBy: {
        createdAt: "desc",
      },
    })

    // Convert logs to CSV
    const headers = ["ID", "Timestamp", "Action", "Entity", "Entity ID", "User ID", "Metadata"]
    const rows = logs.map((log) => [
      log.id,
      new Date(log.createdAt).toISOString(),
      log.action,
      log.entity,
      log.entityId || "",
      log.userId || "",
      JSON.stringify(log.metadata || {}),
    ])

    const csv = [
      headers.join(","),
      ...rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")),
    ].join("\n")

    // Log the export action
    await createAuditLog("EXPORT", "SYSTEM", undefined, session.user.id, {
      type: "audit_logs",
      filters: { search, action, entity },
    })

    // Return CSV file
    return new NextResponse(csv, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": `attachment; filename="audit-logs-${new Date().toISOString().split("T")[0]}.csv"`,
      },
    })
  } catch (error) {
    console.error("Error exporting audit logs:", error)
    return NextResponse.json({ error: "Failed to export audit logs" }, { status: 500 })
  }
}

