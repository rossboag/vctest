import { type NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/db"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

// Schema for system settings
const systemSettingsSchema = z.object({
  siteName: z.string().min(1).max(100).optional(),
  siteDescription: z.string().max(500).optional(),
  maxUploadSize: z.number().min(1).max(1000).optional(),
  maxProjectSize: z.number().min(1).max(10000).optional(),
  defaultLanguage: z.string().min(2).max(10).optional(),
  userRegistration: z.boolean().optional(),
  requireEmailVerification: z.boolean().optional(),
  allowSocialLogin: z.boolean().optional(),
  maintenanceMode: z.boolean().optional(),
  analyticsEnabled: z.boolean().optional(),
  defaultTheme: z.enum(["light", "dark", "system"]).optional(),
  maxProjectsPerUser: z.number().min(1).max(1000).optional(),
  maxCollaboratorsPerProject: z.number().min(1).max(100).optional(),
  autoSaveInterval: z.number().min(1).max(60).optional(),
  allowPublicProjects: z.boolean().optional(),
  customCssEnabled: z.boolean().optional(),
  customJsEnabled: z.boolean().optional(),
  customCss: z.string().max(10000).optional(),
  customJs: z.string().max(10000).optional(),
  footerText: z.string().max(500).optional(),
  apiRateLimit: z.number().min(10).max(10000).optional(),
})

export async function GET(req: NextRequest) {
  try {
    // Check if user is authenticated and is an admin
    const session = await getServerSession(authOptions)
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get all settings
    const settings = await prisma.systemSetting.findMany()

    // Convert to key-value object
    const settingsObject = settings.reduce(
      (acc, setting) => {
        acc[setting.key] = setting.value
        return acc
      },
      {} as Record<string, any>,
    )

    return NextResponse.json({ settings: settingsObject })
  } catch (error) {
    console.error("Error fetching settings:", error)
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 })
  }
}

export async function PUT(req: NextRequest) {
  try {
    // Check if user is authenticated and is an admin
    const session = await getServerSession(authOptions)
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Parse and validate request body
    const body = await req.json()
    const validatedData = systemSettingsSchema.parse(body)

    // Update settings
    const updatedSettings = []
    for (const [key, value] of Object.entries(validatedData)) {
      const setting = await prisma.systemSetting.upsert({
        where: { key },
        update: { value: JSON.stringify(value) },
        create: { key, value: JSON.stringify(value) },
      })
      updatedSettings.push(setting)
    }

    return NextResponse.json({ settings: updatedSettings })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    console.error("Error updating settings:", error)
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
  }
}

