import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    // Check if user is authenticated and is an admin
    const session = await getServerSession(authOptions)
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get query parameters
    const { searchParams } = new URL(req.url)
    const period = searchParams.get("period") || "7d" // Default to 7 days

    // Calculate date range based on period
    const endDate = new Date()
    const startDate = new Date()

    switch (period) {
      case "24h":
        startDate.setHours(startDate.getHours() - 24)
        break
      case "7d":
        startDate.setDate(startDate.getDate() - 7)
        break
      case "30d":
        startDate.setDate(startDate.getDate() - 30)
        break
      case "90d":
        startDate.setDate(startDate.getDate() - 90)
        break
      default:
        startDate.setDate(startDate.getDate() - 7)
    }

    // Get page views by date
    const pageViews = await prisma.pageView.groupBy({
      by: ["date"],
      _sum: {
        views: true,
      },
      where: {
        date: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        date: "asc",
      },
    })

    // Get page views by path
    const pathViews = await prisma.pageView.groupBy({
      by: ["path"],
      _sum: {
        views: true,
      },
      where: {
        date: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        _sum: {
          views: "desc",
        },
      },
      take: 10,
    })

    // Get user registrations by date
    const userRegistrations = await prisma.user.groupBy({
      by: ["createdAt"],
      _count: {
        id: true,
      },
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        createdAt: "asc",
      },
    })

    // Get project creations by date
    const projectCreations = await prisma.project.groupBy({
      by: ["createdAt"],
      _count: {
        id: true,
      },
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        createdAt: "asc",
      },
    })

    // Get error counts by type
    const errors = await prisma.errorLog.groupBy({
      by: ["type"],
      _count: {
        id: true,
      },
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        _count: {
          id: "desc",
        },
      },
      take: 10,
    })

    // Return analytics data
    return NextResponse.json({
      pageViews: pageViews.map((item) => ({
        date: item.date,
        views: item._sum.views || 0,
      })),
      pathViews: pathViews.map((item) => ({
        path: item.path,
        views: item._sum.views || 0,
      })),
      userRegistrations: userRegistrations.map((item) => ({
        date: item.createdAt,
        count: item._count.id,
      })),
      projectCreations: projectCreations.map((item) => ({
        date: item.createdAt,
        count: item._count.id,
      })),
      errors: errors.map((item) => ({
        type: item.type,
        count: item._count.id,
      })),
    })
  } catch (error) {
    console.error("Error fetching analytics data:", error)
    return NextResponse.json({ error: "Failed to fetch analytics data" }, { status: 500 })
  }
}

