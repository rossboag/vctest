import type { NextRequest } from "next/server"
import { z } from "zod"
import { withApiHandler, validateRequest } from "@/lib/api-utils"
import { prisma } from "@/lib/db"
import { AuthorizationError } from "@/lib/errors"

// Schema for querying security events
const securityQuerySchema = z.object({
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  type: z.string().optional(),
  userId: z.string().optional(),
  ipAddress: z.string().optional(),
  limit: z.number().min(1).max(100).optional().default(50),
  page: z.number().min(1).optional().default(1),
})

async function handler(req: NextRequest, user: { id: string; role: string }) {
  // Only allow admin access
  if (user.role !== "ADMIN") {
    throw new AuthorizationError("Admin access required")
  }

  // Parse URL search params
  const url = new URL(req.url)
  const searchParams = Object.fromEntries(url.searchParams.entries())

  // Convert numeric params
  if (searchParams.limit) searchParams.limit = Number.parseInt(searchParams.limit)
  if (searchParams.page) searchParams.page = Number.parseInt(searchParams.page)

  // Validate params
  const params = validateRequest(securityQuerySchema, searchParams)

  // Build filter criteria
  const where: any = {}

  if (params.type) where.type = params.type
  if (params.userId) where.userId = params.userId
  if (params.ipAddress) where.ipAddress = params.ipAddress

  if (params.startDate || params.endDate) {
    where.timestamp = {}

    if (params.startDate) {
      where.timestamp.gte = new Date(params.startDate)
    }

    if (params.endDate) {
      where.timestamp.lte = new Date(params.endDate)
    }
  }

  // Query security events
  const [totalCount, securityEvents] = await Promise.all([
    // Count total matching records
    prisma.securityEvent.count({ where }),

    // Get paginated results
    prisma.securityEvent.findMany({
      where,
      orderBy: { timestamp: "desc" },
      take: params.limit,
      skip: (params.page - 1) * params.limit,
    }),
  ])

  // Get summary statistics
  const eventTypes = await prisma.securityEvent.groupBy({
    by: ["type"],
    _count: true,
    where: { timestamp: where.timestamp },
  })

  const suspiciousIps = await prisma.securityEvent.groupBy({
    by: ["ipAddress"],
    _count: true,
    orderBy: { _count: { ipAddress: "desc" } },
    where: { timestamp: where.timestamp },
    having: { ipAddress: { _count: { gt: 10 } } },
    take: 10,
  })

  const recentFailedLogins = await prisma.securityEvent.findMany({
    where: {
      type: "FAILED_LOGIN",
      timestamp: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }, // Last 24h
    },
    orderBy: { timestamp: "desc" },
    take: 10,
  })

  return {
    events: securityEvents,
    pagination: {
      total: totalCount,
      page: params.page,
      limit: params.limit,
      totalPages: Math.ceil(totalCount / params.limit),
    },
    summary: {
      eventTypes,
      suspiciousIps,
      recentFailedLogins,
    },
  }
}

export const GET = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: false,
  logRequests: true,
  rateLimitKey: "admin:security",
  allowedRoles: ["ADMIN"],
})

