import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import os from "os"
import { prisma } from "@/lib/db"

export async function GET(req: NextRequest) {
  try {
    // Check if user is authenticated and is an admin
    const session = await getServerSession(authOptions)
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get query parameters
    const { searchParams } = new URL(req.url)
    const period = searchParams.get("period") || "1h" // Default to 1 hour

    // Calculate date range based on period
    const endDate = new Date()
    const startDate = new Date()

    switch (period) {
      case "1h":
        startDate.setHours(startDate.getHours() - 1)
        break
      case "6h":
        startDate.setHours(startDate.getHours() - 6)
        break
      case "24h":
        startDate.setHours(startDate.getHours() - 24)
        break
      case "7d":
        startDate.setDate(startDate.getDate() - 7)
        break
      default:
        startDate.setHours(startDate.getHours() - 1)
    }

    // Get performance metrics from database
    const metrics = await prisma.performanceMetric.findMany({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        timestamp: "asc",
      },
    })

    // Get current system metrics
    const currentMetrics = {
      cpuUsage: process.cpuUsage(),
      memoryUsage: process.memoryUsage(),
      systemMemory: {
        total: os.totalmem(),
        free: os.freemem(),
      },
      uptime: process.uptime(),
      loadAverage: os.loadavg(),
    }

    // Get API response times
    const apiResponseTimes = await prisma.apiMetric.groupBy({
      by: ["endpoint"],
      _avg: {
        responseTime: true,
      },
      _max: {
        responseTime: true,
      },
      _min: {
        responseTime: true,
      },
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
      },
      orderBy: {
        _avg: {
          responseTime: "desc",
        },
      },
      take: 10,
    })

    // Return performance data
    return NextResponse.json({
      historicalMetrics: metrics,
      currentMetrics,
      apiResponseTimes: apiResponseTimes.map((item) => ({
        endpoint: item.endpoint,
        avgResponseTime: item._avg.responseTime || 0,
        maxResponseTime: item._max.responseTime || 0,
        minResponseTime: item._min.responseTime || 0,
      })),
    })
  } catch (error) {
    console.error("Error fetching performance metrics:", error)
    return NextResponse.json({ error: "Failed to fetch performance metrics" }, { status: 500 })
  }
}

