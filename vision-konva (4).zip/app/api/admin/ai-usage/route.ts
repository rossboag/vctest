import type { NextRequest } from "next/server"
import { withApiHandler } from "@/lib/api-utils"
import { prisma } from "@/lib/db"

async function handler(req: NextRequest, userId: string) {
  // Only allow admin users
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { role: true },
  })

  if (!user || user.role !== "ADMIN") {
    throw new Error("Unauthorized")
  }

  // Get query parameters
  const { searchParams } = new URL(req.url)
  const startDate = searchParams.get("startDate")
    ? new Date(searchParams.get("startDate")!)
    : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Default to last 30 days

  const endDate = searchParams.get("endDate") ? new Date(searchParams.get("endDate")!) : new Date()

  // Get AI usage statistics
  const totalGenerations = await prisma.aIGeneration.count({
    where: {
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
    },
  })

  const generationsByType = await prisma.aIGeneration.groupBy({
    by: ["type"],
    _count: true,
    where: {
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
    },
  })

  const topUsers = await prisma.aIGeneration.groupBy({
    by: ["userId"],
    _count: true,
    orderBy: {
      _count: {
        userId: "desc",
      },
    },
    take: 10,
    where: {
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
    },
  })

  // Get user details for top users
  const userDetails = await Promise.all(
    topUsers.map(async (item) => {
      const user = await prisma.user.findUnique({
        where: { id: item.userId },
        select: { name: true, email: true },
      })
      return {
        userId: item.userId,
        count: item._count,
        name: user?.name || "Unknown",
        email: user?.email || "Unknown",
      }
    }),
  )

  // Get daily usage
  const dailyUsage = await prisma.$queryRaw`
    SELECT 
      DATE(createdAt) as date, 
      COUNT(*) as count 
    FROM 
      AIGeneration 
    WHERE 
      createdAt >= ${startDate} AND createdAt <= ${endDate}
    GROUP BY 
      DATE(createdAt)
    ORDER BY 
      date
  `

  return {
    totalGenerations,
    generationsByType,
    topUsers: userDetails,
    dailyUsage,
    timeRange: {
      startDate,
      endDate,
    },
  }
}

export const GET = withApiHandler(handler, {
  requireAuth: true,
  allowApiKey: false,
  logRequests: true,
})

