import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { NotificationService } from "@/lib/notification-service"
import { prisma } from "@/lib/db"

// POST /api/admin/notifications/broadcast - Send a notification to all users
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { type, title, message, link, metadata } = body

    if (!type || !title || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Get all users
    const users = await prisma.user.findMany({
      select: {
        id: true,
      },
    })

    // Send notification to all users
    const notifications = await NotificationService.createNotificationForUsers(
      users.map((user) => user.id),
      {
        senderId: session.user.id,
        type,
        title,
        message,
        link,
        metadata,
      },
    )

    return NextResponse.json({
      success: true,
      count: notifications.length,
    })
  } catch (error) {
    console.error("Error broadcasting notification:", error)
    return NextResponse.json({ error: "Failed to broadcast notification" }, { status: 500 })
  }
}

