import type { NextRequest } from "next/server"
import { getAssetService } from "@/lib/assets/asset-service"
import { withApiHandler } from "@/lib/api-utils"

const assetService = getAssetService()

/**
 * Clean up unused assets
 */
export const POST = withApiHandler(
  async (req: NextRequest, user) => {
    const { days } = await req.json()

    const olderThanDays = Number.parseInt(days || "30")

    const count = await assetService.cleanupUnusedAssets(olderThanDays)

    return {
      success: true,
      message: `Cleaned up ${count} unused assets older than ${olderThanDays} days`,
      count,
    }
  },
  {
    requireAuth: true,
    allowedRoles: ["admin"],
    logRequests: true,
  },
)

