import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIAnimationService } from "@/lib/ai-animation-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { elementType, elementContent, projectContext, count } = body

    if (!elementType) {
      return NextResponse.json({ error: "Element type is required" }, { status: 400 })
    }

    const suggestions = await AIAnimationService.generateAnimationSuggestions(
      session.user.id,
      elementType,
      elementContent,
      projectContext,
      count,
    )

    return NextResponse.json({ suggestions })
  } catch (error) {
    console.error("Error generating animation suggestions:", error)
    return NextResponse.json({ error: "Failed to generate animation suggestions" }, { status: 500 })
  }
}

