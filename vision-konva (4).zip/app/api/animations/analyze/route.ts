import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIAnimationService } from "@/lib/ai-animation-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { keyframes, elementType, duration, projectId } = body

    if (!keyframes || !elementType || !duration) {
      return NextResponse.json({ error: "Keyframes, element type, and duration are required" }, { status: 400 })
    }

    const result = await AIAnimationService.analyzeAndImproveAnimation(
      session.user.id,
      keyframes,
      elementType,
      duration,
      projectId,
    )

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error analyzing animation:", error)
    return NextResponse.json({ error: "Failed to analyze animation" }, { status: 500 })
  }
}

