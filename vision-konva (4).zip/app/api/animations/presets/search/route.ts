import { type NextRequest, NextResponse } from "next/server"
import { AIAnimationService } from "@/lib/ai-animation-service"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const query = searchParams.get("q")
    const limit = searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : undefined
    const offset = searchParams.get("offset") ? Number.parseInt(searchParams.get("offset")!) : undefined

    if (!query) {
      return NextResponse.json({ error: "Search query is required" }, { status: 400 })
    }

    const presets = await AIAnimationService.searchPresets(query, limit, offset)

    return NextResponse.json(presets)
  } catch (error) {
    console.error("Error searching animation presets:", error)
    return NextResponse.json({ error: "Failed to search animation presets" }, { status: 500 })
  }
}

