import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIAnimationService } from "@/lib/ai-animation-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { name, description, category, duration, projectId } = body

    if (!name || !description || !category) {
      return NextResponse.json({ error: "Name, description, and category are required" }, { status: 400 })
    }

    const preset = await AIAnimationService.generateAnimationPreset(
      session.user.id,
      name,
      description,
      category,
      duration,
      projectId,
    )

    return NextResponse.json(preset)
  } catch (error) {
    console.error("Error generating animation preset:", error)
    return NextResponse.json({ error: "Failed to generate animation preset" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get("category") || undefined
    const limit = searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : undefined
    const offset = searchParams.get("offset") ? Number.parseInt(searchParams.get("offset")!) : undefined

    const presets = await AIAnimationService.getPresetsByCategory(category, limit, offset)

    return NextResponse.json(presets)
  } catch (error) {
    console.error("Error fetching animation presets:", error)
    return NextResponse.json({ error: "Failed to fetch animation presets" }, { status: 500 })
  }
}

