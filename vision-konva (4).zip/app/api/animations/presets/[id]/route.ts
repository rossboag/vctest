import { type NextRequest, NextResponse } from "next/server"
import { AIAnimationService } from "@/lib/ai-animation-service"

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    const preset = await AIAnimationService.getPresetById(id)

    if (!preset) {
      return NextResponse.json({ error: "Animation preset not found" }, { status: 404 })
    }

    return NextResponse.json(preset)
  } catch (error) {
    console.error("Error fetching animation preset:", error)
    return NextResponse.json({ error: "Failed to fetch animation preset" }, { status: 500 })
  }
}

