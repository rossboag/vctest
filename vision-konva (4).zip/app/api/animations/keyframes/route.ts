import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIAnimationService } from "@/lib/ai-animation-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { prompt, elementType, duration, projectId } = body

    if (!prompt || !elementType) {
      return NextResponse.json({ error: "Prompt and element type are required" }, { status: 400 })
    }

    const keyframes = await AIAnimationService.generateAnimationKeyframes(
      session.user.id,
      prompt,
      elementType,
      duration,
      projectId,
    )

    return NextResponse.json({ keyframes })
  } catch (error) {
    console.error("Error generating animation keyframes:", error)
    return NextResponse.json({ error: "Failed to generate animation keyframes" }, { status: 500 })
  }
}

