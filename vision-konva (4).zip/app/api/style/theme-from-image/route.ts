import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIStyleService } from "@/lib/ai-style-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { imageUrl, themeName, stylePreference, projectId } = body

    if (!imageUrl) {
      return NextResponse.json({ error: "Image URL is required" }, { status: 400 })
    }

    const theme = await AIStyleService.generateThemeFromImage(
      session.user.id,
      imageUrl,
      themeName,
      stylePreference,
      projectId,
    )

    return NextResponse.json(theme)
  } catch (error) {
    console.error("Error generating theme from image:", error)
    return NextResponse.json({ error: "Failed to generate theme from image" }, { status: 500 })
  }
}

