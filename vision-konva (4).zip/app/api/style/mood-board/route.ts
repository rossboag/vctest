import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIStyleService } from "@/lib/ai-style-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { mood, industry, additionalKeywords, projectId } = body

    if (!mood) {
      return NextResponse.json({ error: "Mood is required" }, { status: 400 })
    }

    const moodBoard = await AIStyleService.generateMoodBoard(
      session.user.id,
      mood,
      industry,
      additionalKeywords,
      projectId,
    )

    return NextResponse.json(moodBoard)
  } catch (error) {
    console.error("Error generating mood board:", error)
    return NextResponse.json({ error: "Failed to generate mood board" }, { status: 500 })
  }
}

