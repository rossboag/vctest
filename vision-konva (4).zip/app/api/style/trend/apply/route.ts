import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIStyleService } from "@/lib/ai-style-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { elements, trendName, adaptationLevel, projectId } = body

    if (!elements || !trendName) {
      return NextResponse.json({ error: "Elements and trend name are required" }, { status: 400 })
    }

    const trendApplication = await AIStyleService.applyDesignTrend(
      session.user.id,
      elements,
      trendName,
      adaptationLevel,
      projectId,
    )

    return NextResponse.json(trendApplication)
  } catch (error) {
    console.error("Error applying design trend:", error)
    return NextResponse.json({ error: "Failed to apply design trend" }, { status: 500 })
  }
}

