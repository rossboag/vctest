import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIStyleService } from "@/lib/ai-style-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { trendName, year, projectId } = body

    if (!trendName) {
      return NextResponse.json({ error: "Trend name is required" }, { status: 400 })
    }

    const designTrend = await AIStyleService.getDesignTrend(session.user.id, trendName, year, projectId)

    return NextResponse.json(designTrend)
  } catch (error) {
    console.error("Error getting design trend:", error)
    return NextResponse.json({ error: "Failed to get design trend" }, { status: 500 })
  }
}

