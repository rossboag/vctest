import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIStyleService } from "@/lib/ai-style-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { sourceElements, targetElements, styleAspects, projectId } = body

    if (!sourceElements || !targetElements) {
      return NextResponse.json({ error: "Source and target elements are required" }, { status: 400 })
    }

    const styleTransfer = await AIStyleService.transferStyle(
      session.user.id,
      sourceElements,
      targetElements,
      styleAspects,
      projectId,
    )

    return NextResponse.json(styleTransfer)
  } catch (error) {
    console.error("Error transferring style:", error)
    return NextResponse.json({ error: "Failed to transfer style" }, { status: 500 })
  }
}

