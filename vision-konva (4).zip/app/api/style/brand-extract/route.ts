import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { AIStyleService } from "@/lib/ai-style-service"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { elements, description, imageUrls, projectId } = body

    if (!elements && !description && (!imageUrls || imageUrls.length === 0)) {
      return NextResponse.json(
        { error: "At least one of elements, description, or imageUrls is required" },
        { status: 400 },
      )
    }

    const brandStyle = await AIStyleService.extractBrandStyle(
      session.user.id,
      elements,
      description,
      imageUrls,
      projectId,
    )

    return NextResponse.json(brandStyle)
  } catch (error) {
    console.error("Error extracting brand style:", error)
    return NextResponse.json({ error: "Failed to extract brand style" }, { status: 500 })
  }
}

