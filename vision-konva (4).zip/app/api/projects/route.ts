import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getCurrentUser } from "@/lib/session"
import { z } from "zod"

const prisma = new PrismaClient()

// Validation schema for creating/updating projects
const projectSchema = z.object({
  name: z.string().min(1, "Project name is required"),
  description: z.string().optional(),
  canvasSize: z.object({
    width: z.number().min(1),
    height: z.number().min(1),
  }),
})

// GET - Retrieve all projects for the current user
export async function GET() {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const projects = await prisma.project.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: "desc" },
    })

    return NextResponse.json(projects)
  } catch (error) {
    console.error("Error fetching projects:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}

// POST - Create a new project
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()

    // Validate input
    const validation = projectSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json({ error: "Invalid input", details: validation.error.format() }, { status: 400 })
    }

    const { name, description, canvasSize } = validation.data

    // Create project
    const project = await prisma.project.create({
      data: {
        name,
        description: description || "",
        canvasSize,
        userId: user.id,
      },
    })

    // Create default layer
    await prisma.layer.create({
      data: {
        name: "Background",
        projectId: project.id,
        visible: true,
        locked: false,
        order: 0,
      },
    })

    return NextResponse.json(project, { status: 201 })
  } catch (error) {
    console.error("Error creating project:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}

