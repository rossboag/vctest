import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getCurrentUser } from "@/lib/session"
import { z } from "zod"

const prisma = new PrismaClient()

// Validation schema for updating layers
const layerUpdateSchema = z.object({
  name: z.string().min(1, "Layer name is required").optional(),
  visible: z.boolean().optional(),
  locked: z.boolean().optional(),
  order: z.number().int().optional(),
})

// GET - Retrieve a specific layer
export async function GET(request: Request, { params }: { params: { id: string; layerId: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: projectId, layerId } = params

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get the layer
    const layer = await prisma.layer.findUnique({
      where: { id: layerId },
      include: {
        elements: {
          orderBy: { zIndex: "asc" },
        },
      },
    })

    if (!layer) {
      return NextResponse.json({ error: "Layer not found" }, { status: 404 })
    }

    // Check if layer belongs to the project
    if (layer.projectId !== projectId) {
      return NextResponse.json({ error: "Layer not found in project" }, { status: 404 })
    }

    return NextResponse.json(layer)
  } catch (error) {
    console.error("Error fetching layer:", error)
    return NextResponse.json({ error: "Failed to fetch layer" }, { status: 500 })
  }
}

// PUT - Update a layer
export async function PUT(request: Request, { params }: { params: { id: string; layerId: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: projectId, layerId } = params
    const body = await request.json()

    // Validate input
    const validation = layerUpdateSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json({ error: "Invalid input", details: validation.error.format() }, { status: 400 })
    }

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Check if layer exists and belongs to the project
    const layer = await prisma.layer.findUnique({
      where: { id: layerId },
    })

    if (!layer) {
      return NextResponse.json({ error: "Layer not found" }, { status: 404 })
    }

    if (layer.projectId !== projectId) {
      return NextResponse.json({ error: "Layer not found in project" }, { status: 404 })
    }

    // Update layer
    const updatedLayer = await prisma.layer.update({
      where: { id: layerId },
      data: validation.data,
    })

    return NextResponse.json(updatedLayer)
  } catch (error) {
    console.error("Error updating layer:", error)
    return NextResponse.json({ error: "Failed to update layer" }, { status: 500 })
  }
}

// DELETE - Delete a layer
export async function DELETE(request: Request, { params }: { params: { id: string; layerId: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: projectId, layerId } = params

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Check if layer exists and belongs to the project
    const layer = await prisma.layer.findUnique({
      where: { id: layerId },
    })

    if (!layer) {
      return NextResponse.json({ error: "Layer not found" }, { status: 404 })
    }

    if (layer.projectId !== projectId) {
      return NextResponse.json({ error: "Layer not found in project" }, { status: 404 })
    }

    // Check if it's the last layer
    const layerCount = await prisma.layer.count({
      where: { projectId },
    })

    if (layerCount <= 1) {
      return NextResponse.json({ error: "Cannot delete the last layer" }, { status: 400 })
    }

    // Delete layer (cascade will delete elements)
    await prisma.layer.delete({
      where: { id: layerId },
    })

    return NextResponse.json({ message: "Layer deleted successfully" })
  } catch (error) {
    console.error("Error deleting layer:", error)
    return NextResponse.json({ error: "Failed to delete layer" }, { status: 500 })
  }
}

