import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getCurrentUser } from "@/lib/session"
import { z } from "zod"

const prisma = new PrismaClient()

// Validation schema for layers
const layerSchema = z.object({
  name: z.string().min(1, "Layer name is required"),
  visible: z.boolean().default(true),
  locked: z.boolean().default(false),
  order: z.number().int().optional(),
})

// GET - Retrieve all layers for a project
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const projectId = params.id

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get all layers for the project
    const layers = await prisma.layer.findMany({
      where: { projectId },
      orderBy: { order: "asc" },
      include: {
        _count: {
          select: { elements: true },
        },
      },
    })

    return NextResponse.json(layers)
  } catch (error) {
    console.error("Error fetching layers:", error)
    return NextResponse.json({ error: "Failed to fetch layers" }, { status: 500 })
  }
}

// POST - Create a new layer
export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const projectId = params.id
    const body = await request.json()

    // Validate input
    const validation = layerSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json({ error: "Invalid input", details: validation.error.format() }, { status: 400 })
    }

    const { name, visible, locked, order } = validation.data

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get highest order if not provided
    let layerOrder = order
    if (layerOrder === undefined) {
      const highestLayer = await prisma.layer.findFirst({
        where: { projectId },
        orderBy: { order: "desc" },
      })

      layerOrder = highestLayer ? highestLayer.order + 1 : 0
    }

    // Create layer
    const layer = await prisma.layer.create({
      data: {
        projectId,
        name,
        visible,
        locked,
        order: layerOrder,
      },
    })

    return NextResponse.json(layer, { status: 201 })
  } catch (error) {
    console.error("Error creating layer:", error)
    return NextResponse.json({ error: "Failed to create layer" }, { status: 500 })
  }
}

