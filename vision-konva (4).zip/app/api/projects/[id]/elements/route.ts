import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getCurrentUser } from "@/lib/session"
import { z } from "zod"

const prisma = new PrismaClient()

// Validation schema for elements
const elementSchema = z.object({
  layerId: z.string().uuid(),
  type: z.string(),
  properties: z.record(z.any()),
  zIndex: z.number().int().optional(),
})

// GET - Retrieve all elements for a project
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const projectId = params.id

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get all elements for the project
    const elements = await prisma.element.findMany({
      where: {
        layer: {
          projectId,
        },
      },
      orderBy: { zIndex: "asc" },
      include: {
        layer: true,
      },
    })

    return NextResponse.json(elements)
  } catch (error) {
    console.error("Error fetching elements:", error)
    return NextResponse.json({ error: "Failed to fetch elements" }, { status: 500 })
  }
}

// POST - Create a new element
export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const projectId = params.id
    const body = await request.json()

    // Validate input
    const validation = elementSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json({ error: "Invalid input", details: validation.error.format() }, { status: 400 })
    }

    const { layerId, type, properties, zIndex } = validation.data

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Check if layer exists and belongs to the project
    const layer = await prisma.layer.findUnique({
      where: { id: layerId },
    })

    if (!layer || layer.projectId !== projectId) {
      return NextResponse.json({ error: "Invalid layer" }, { status: 400 })
    }

    // Get highest zIndex if not provided
    let elementZIndex = zIndex
    if (elementZIndex === undefined) {
      const highestElement = await prisma.element.findFirst({
        where: {
          layer: {
            projectId,
          },
        },
        orderBy: { zIndex: "desc" },
      })

      elementZIndex = highestElement ? highestElement.zIndex + 1 : 0
    }

    // Create element
    const element = await prisma.element.create({
      data: {
        layerId,
        type,
        properties,
        zIndex: elementZIndex,
      },
    })

    return NextResponse.json(element, { status: 201 })
  } catch (error) {
    console.error("Error creating element:", error)
    return NextResponse.json({ error: "Failed to create element" }, { status: 500 })
  }
}

