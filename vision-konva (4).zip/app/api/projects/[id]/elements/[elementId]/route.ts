import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getCurrentUser } from "@/lib/session"
import { z } from "zod"

const prisma = new PrismaClient()

// Validation schema for updating elements
const elementUpdateSchema = z.object({
  layerId: z.string().uuid().optional(),
  type: z.string().optional(),
  properties: z.record(z.any()).optional(),
  zIndex: z.number().int().optional(),
})

// GET - Retrieve a specific element
export async function GET(request: Request, { params }: { params: { id: string; elementId: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: projectId, elementId } = params

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get the element
    const element = await prisma.element.findUnique({
      where: { id: elementId },
      include: {
        layer: true,
      },
    })

    if (!element) {
      return NextResponse.json({ error: "Element not found" }, { status: 404 })
    }

    // Check if element belongs to the project
    if (element.layer.projectId !== projectId) {
      return NextResponse.json({ error: "Element not found in project" }, { status: 404 })
    }

    return NextResponse.json(element)
  } catch (error) {
    console.error("Error fetching element:", error)
    return NextResponse.json({ error: "Failed to fetch element" }, { status: 500 })
  }
}

// PUT - Update an element
export async function PUT(request: Request, { params }: { params: { id: string; elementId: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: projectId, elementId } = params
    const body = await request.json()

    // Validate input
    const validation = elementUpdateSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json({ error: "Invalid input", details: validation.error.format() }, { status: 400 })
    }

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Check if element exists and belongs to the project
    const element = await prisma.element.findUnique({
      where: { id: elementId },
      include: {
        layer: true,
      },
    })

    if (!element) {
      return NextResponse.json({ error: "Element not found" }, { status: 404 })
    }

    if (element.layer.projectId !== projectId) {
      return NextResponse.json({ error: "Element not found in project" }, { status: 404 })
    }

    // If layerId is provided, check if it's valid
    if (validation.data.layerId) {
      const layer = await prisma.layer.findUnique({
        where: { id: validation.data.layerId },
      })

      if (!layer || layer.projectId !== projectId) {
        return NextResponse.json({ error: "Invalid layer" }, { status: 400 })
      }
    }

    // Update element
    const updatedElement = await prisma.element.update({
      where: { id: elementId },
      data: validation.data,
    })

    return NextResponse.json(updatedElement)
  } catch (error) {
    console.error("Error updating element:", error)
    return NextResponse.json({ error: "Failed to update element" }, { status: 500 })
  }
}

// DELETE - Delete an element
export async function DELETE(request: Request, { params }: { params: { id: string; elementId: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id: projectId, elementId } = params

    // Check if project exists and user owns it
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Check if element exists and belongs to the project
    const element = await prisma.element.findUnique({
      where: { id: elementId },
      include: {
        layer: true,
      },
    })

    if (!element) {
      return NextResponse.json({ error: "Element not found" }, { status: 404 })
    }

    if (element.layer.projectId !== projectId) {
      return NextResponse.json({ error: "Element not found in project" }, { status: 404 })
    }

    // Delete element
    await prisma.element.delete({
      where: { id: elementId },
    })

    return NextResponse.json({ message: "Element deleted successfully" })
  } catch (error) {
    console.error("Error deleting element:", error)
    return NextResponse.json({ error: "Failed to delete element" }, { status: 500 })
  }
}

