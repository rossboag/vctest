import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getCurrentUser } from "@/lib/session"
import { duplicateProject } from "@/lib/project-utils"
import { z } from "zod"

const prisma = new PrismaClient()

// Validation schema for duplicating projects
const duplicateSchema = z.object({
  name: z.string().optional(),
})

// POST - Duplicate a project
export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const projectId = params.id
    const body = await request.json()

    // Validate input
    const validation = duplicateSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json({ error: "Invalid input", details: validation.error.format() }, { status: 400 })
    }

    // Check if project exists and user has access
    const project = await prisma.project.findUnique({
      where: { id: projectId },
    })

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.userId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Duplicate the project
    const newProject = await duplicateProject(projectId, user.id, validation.data.name)

    return NextResponse.json(newProject, { status: 201 })
  } catch (error) {
    console.error("Error duplicating project:", error)
    return NextResponse.json({ error: "Failed to duplicate project" }, { status: 500 })
  }
}

