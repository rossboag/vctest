import { ResponsiveEditor } from "@/components/responsive-editor"
import { OrientationHandler } from "@/components/orientation-handler"

export default function EditorPage() {
  return (
    <>
      <OrientationHandler />
      <ResponsiveEditor />
    </>
  )
}

