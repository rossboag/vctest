import { AssetGallery } from "@/components/assets/asset-gallery"

export default function AssetsPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Asset Management</h1>
      <AssetGallery showUploader={true} />
    </div>
  )
}

