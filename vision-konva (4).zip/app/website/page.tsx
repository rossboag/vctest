"use client"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { WebsiteNavigation } from "@/components/website/navigation"
import { WebsiteFooter } from "@/components/website/footer"

export default function WebsitePage() {
  const features = [
    {
      title: "AI-Powered Design",
      description: "Generate layouts, enhance images, and get creative suggestions with our AI tools",
      image:
        "https://images.unsplash.com/photo-1633412802994-5c058f151b66?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Advanced Animation",
      description: "Create stunning animations with our intuitive timeline and keyframe editor",
      image:
        "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1474&q=80",
    },
    {
      title: "Rich Text Editing",
      description: "Powerful text tools with support for custom fonts and advanced styling",
      image:
        "https://images.unsplash.com/photo-1632389758962-f8d2ab16c961?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80",
    },
    {
      title: "Layer Management",
      description: "Organize your designs with an intuitive layer system and grouping options",
      image:
        "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Export Options",
      description: "Export your designs in multiple formats, including PNG, SVG, and JSON",
      image:
        "https://images.unsplash.com/photo-1633409361618-c73427e4e206?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1480&q=80",
    },
    {
      title: "Collaboration Tools",
      description: "Work together with your team using real-time collaboration features",
      image:
        "https://images.unsplash.com/photo-1600267185393-e158a98703de?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <WebsiteNavigation />

      {/* Hero Section */}
      <section
        className="relative py-40 px-4 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80')`,
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="container mx-auto max-w-6xl relative z-10 text-center text-white">
          <h1 className="text-5xl font-bold tracking-tight mb-6">Create stunning designs with VISION CREATOR</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Combine the power of professional design tools with AI-enhanced capabilities. Design, animate, and
            collaborate all in one platform.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/editor">
              <Button size="lg" className="rounded-full px-8">
                Try it free
              </Button>
            </Link>
            <Link href="/website/features">
              <Button variant="outline" size="lg" className="rounded-full px-8">
                See features
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Powerful Features</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to create professional designs and animations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-card p-6 rounded-lg border">
                <Image
                  src={feature.image || "/placeholder.svg"}
                  alt={feature.title}
                  width={300}
                  height={200}
                  className="rounded-lg mb-4 object-cover w-full h-48"
                />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/website/features">
              <Button variant="outline" size="lg">
                Explore all features
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing Section Preview */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Flexible Pricing Options</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From free trials to team plans, choose the option that works best for you
            </p>
          </div>

          <div className="flex justify-center">
            <Link href="/website/pricing">
              <Button size="lg">View pricing plans</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Hear from designers and creators who use VISION CREATOR
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                quote:
                  "VISION CREATOR has revolutionized my workflow. The AI features and intuitive interface save me hours of work every day.",
                author: "Sarah Johnson",
                role: "Graphic Designer",
              },
              {
                quote:
                  "The animation capabilities in VISION CREATOR are unparalleled. It's become an essential tool for my motion design projects.",
                author: "Michael Chen",
                role: "Motion Designer",
              },
            ].map((testimonial, index) => (
              <div key={index} className="bg-card p-8 rounded-lg border">
                <p className="text-lg mb-4 italic">"{testimonial.quote}"</p>
                <p className="font-semibold">{testimonial.author}</p>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="container mx-auto max-w-6xl text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8 text-primary-foreground/80">
            Join thousands of designers and creators using VISION CREATOR
          </p>
          <Link href="/editor">
            <Button size="lg" variant="secondary" className="rounded-full px-8">
              Try it free
            </Button>
          </Link>
        </div>
      </section>

      <WebsiteFooter />
    </div>
  )
}

