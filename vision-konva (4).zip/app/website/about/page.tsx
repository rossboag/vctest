"use client"
import { WebsiteNavigation } from "@/components/website/navigation"
import { WebsiteFooter } from "@/components/website/footer"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Alex Johnson",
      role: "Founder & CEO",
      bio: "Alex has over 15 years of experience in design software and AI. Previously led product at Adobe.",
      image: "/placeholder.svg?height=300&width=300",
    },
    {
      name: "Sarah Chen",
      role: "CTO",
      bio: "Sarah is an AI expert with a PhD from MIT. She leads our engineering team and AI research.",
      image: "/placeholder.svg?height=300&width=300",
    },
    {
      name: "Michael Rodriguez",
      role: "Head of Design",
      bio: "Michael is an award-winning designer who previously worked at Figma and Canva.",
      image: "/placeholder.svg?height=300&width=300",
    },
    {
      name: "Priya Patel",
      role: "VP of Product",
      bio: "Priya has shipped products used by millions of designers worldwide.",
      image: "/placeholder.svg?height=300&width=300",
    },
  ]

  const values = [
    {
      title: "Innovation",
      description: "We're constantly pushing the boundaries of what's possible in design and animation.",
    },
    {
      title: "Accessibility",
      description: "We believe powerful design tools should be accessible to everyone, regardless of technical skill.",
    },
    {
      title: "Quality",
      description: "We're committed to building high-quality software that professionals can rely on.",
    },
    {
      title: "Community",
      description: "We value our community of users and actively incorporate their feedback.",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <WebsiteNavigation />

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-primary/5">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold tracking-tight mb-6">Our Mission</h1>
              <p className="text-xl text-muted-foreground mb-8">
                We're on a mission to democratize design and animation, making professional-quality tools accessible to
                everyone through the power of AI.
              </p>
            </div>
            <div className="bg-muted rounded-xl aspect-video flex items-center justify-center p-8">
              <div className="text-center">
                <p className="text-lg font-medium">Company Video</p>
                <p className="text-sm text-muted-foreground">Our story and vision</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="bg-muted rounded-xl aspect-square flex items-center justify-center p-8">
              <div className="text-center">
                <p className="text-lg font-medium">Company Timeline</p>
                <p className="text-sm text-muted-foreground">Our journey from idea to today</p>
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-lg">
                <p>
                  VISION CREATOR was founded in 2021 by a team of designers, engineers, and AI researchers who were
                  frustrated with the limitations of existing design tools.
                </p>
                <p>
                  We saw a gap in the market: professional animation tools were too complex for most users, while simple
                  design tools lacked the power needed for sophisticated projects.
                </p>
                <p>
                  Our solution was to combine the power of professional animation software with the simplicity of modern
                  design tools, all enhanced by AI to make complex tasks simple.
                </p>
                <p>
                  Today, VISION CREATOR is used by thousands of designers, marketers, and creators around the world to
                  bring their ideas to life.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold mb-12 text-center">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-background p-6 rounded-lg border">
                <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold mb-12 text-center">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <img
                  src={member.image || "/placeholder.svg"}
                  alt={member.name}
                  className="w-48 h-48 rounded-full object-cover mb-4"
                />
                <h3 className="text-xl font-semibold">{member.name}</h3>
                <p className="text-primary mb-2">{member.role}</p>
                <p className="text-muted-foreground">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="container mx-auto max-w-6xl text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Team</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8 text-primary-foreground/80">
            We're always looking for talented individuals to join our mission
          </p>
          <Link href="/website/careers">
            <Button size="lg" variant="secondary" className="rounded-full px-8">
              View Open Positions
            </Button>
          </Link>
        </div>
      </section>

      <WebsiteFooter />
    </div>
  )
}

