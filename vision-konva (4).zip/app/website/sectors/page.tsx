import { WebsiteNavigation } from "@/components/website/navigation"
import { WebsiteFooter } from "@/components/website/footer"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

const sectors = [
  {
    name: "Digital Signage",
    description: "Dynamic displays for information and advertising",
    image: "https://images.unsplash.com/photo-1618556450994-a6a128ef0d9d?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Hospitality",
    description: "Engaging content for hotels, resorts, and restaurants",
    image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Fast Food",
    description: "Eye-catching menu boards and promotional displays",
    image: "https://images.unsplash.com/photo-1542282088-fe8426682b8f?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Healthcare",
    description: "Informative displays for hospitals and clinics",
    image: "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Retail",
    description: "Interactive product showcases and promotions",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Education",
    description: "Engaging content for schools and universities",
    image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Corporate",
    description: "Internal communications and meeting room displays",
    image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Transportation",
    description: "Real-time information for airports and stations",
    image: "https://images.unsplash.com/photo-1517400508447-f8dd518b86db?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Entertainment",
    description: "Immersive experiences for theaters and venues",
    image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Sports",
    description: "Dynamic scoreboards and fan engagement",
    image: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Banking",
    description: "Informative displays for financial institutions",
    image: "https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Automotive",
    description: "Showroom displays and interactive catalogs",
    image: "https://images.unsplash.com/photo-1489824904134-891ab64532f1?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Real Estate",
    description: "Property showcases and virtual tours",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Fitness",
    description: "Motivational displays for gyms and health clubs",
    image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Museums",
    description: "Interactive exhibits and informational displays",
    image: "https://images.unsplash.com/photo-1553701879-4aa576804f65?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Government",
    description: "Public information and wayfinding systems",
    image: "https://images.unsplash.com/photo-1523292562811-8fa7962a78c8?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Events",
    description: "Dynamic signage for conferences and trade shows",
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Outdoor Advertising",
    description: "Eye-catching billboards and street furniture",
    image: "https://images.unsplash.com/photo-1617913517081-9bccf2f7f9cf?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Smart Cities",
    description: "Urban information systems and kiosks",
    image: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=800&auto=format&fit=crop&q=60",
  },
  {
    name: "Social Media",
    description: "Engaging content for various social platforms",
    image: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800&auto=format&fit=crop&q=60",
  },
]

export default function SectorsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <WebsiteNavigation />
      <main className="flex-grow">
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl font-bold text-center mb-8">Sectors We Serve</h1>
            <p className="text-xl text-center text-muted-foreground mb-12">
              VISION CREATOR empowers businesses across various industries with dynamic digital content solutions.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sectors.map((sector, index) => (
                <div key={index} className="bg-card rounded-lg shadow-md overflow-hidden">
                  <div className="relative h-48">
                    <Image src={sector.image || "/placeholder.svg"} alt={sector.name} fill className="object-cover" />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{sector.name}</h3>
                    <p className="text-muted-foreground mb-4">{sector.description}</p>
                    <Link href="/editor">
                      <Button variant="outline" size="sm">
                        Try for {sector.name}
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <WebsiteFooter />
    </div>
  )
}

