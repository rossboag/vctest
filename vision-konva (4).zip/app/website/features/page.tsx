"use client"
import { WebsiteNavigation } from "@/components/website/navigation"
import { WebsiteFooter } from "@/components/website/footer"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check, Monitor, Smartphone, Palette, Zap, Users, Lock, Globe } from "lucide-react"

export default function FeaturesPage() {
  const featureSections = [
    {
      title: "Digital Signage Optimization",
      description: "Create eye-catching content for any display",
      icon: Monitor,
      image:
        "https://images.unsplash.com/photo-1616763355603-9755a640a287?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      features: [
        "Multi-screen layout design for video walls",
        "Dynamic content scheduling and playlists",
        "Real-time data integration for live updates",
        "Template library for quick content creation",
        "Resolution-adaptive designs for various screen sizes",
        "Interactive touchscreen content creation",
      ],
    },
    {
      title: "Design Tools",
      description: "Professional design tools that are easy to use",
      icon: Palette,
      image:
        "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      features: [
        "Intuitive drag-and-drop canvas interface",
        "Powerful text editing with custom font support",
        "Shape tools with customizable properties",
        "Image manipulation with filters and effects",
        "Video embedding and editing capabilities",
        "Advanced layer management for complex designs",
        "Gradient and fill tools with various options",
      ],
    },
    {
      title: "Animation Capabilities",
      description: "Create stunning animations with professional tools",
      icon: Zap,
      image:
        "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1474&q=80",
      features: [
        "Timeline-based animation editor for precise control",
        "Keyframe animation for all object properties",
        "Motion presets for quick, professional animations",
        "Text animation effects and transitions",
        "Export animations in multiple formats (MP4, GIF, WebM)",
        "Real-time animation preview and playback",
        "Path-based animations for complex motion",
      ],
    },
    {
      title: "AI-Powered Features",
      description: "Let AI enhance your design process",
      icon: Smartphone,
      image:
        "https://images.unsplash.com/photo-1633412802994-5c058f151b66?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      features: [
        "AI-generated layout suggestions for various industries",
        "Smart color palette recommendations based on brand guidelines",
        "Automated image enhancement and background removal",
        "Intelligent object arrangement and alignment",
        "AI-powered text suggestions and translations",
        "Automated animation presets based on content type",
        "Voice-to-text for easy captioning and subtitles",
      ],
    },
    {
      title: "Collaboration Tools",
      description: "Work together seamlessly with your team",
      icon: Users,
      image:
        "https://images.unsplash.com/photo-1600267185393-e158a98703de?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      features: [
        "Real-time collaborative editing for multiple users",
        "Project management features with task assignments",
        "Version history and rollback capabilities",
        "Team permissions and role management",
        "Shared asset libraries for consistent branding",
        "Comment and annotation tools for feedback",
        "Integration with popular project management tools",
      ],
    },
    {
      title: "Security and Compliance",
      description: "Keep your content and data safe",
      icon: Lock,
      image:
        "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      features: [
        "End-to-end encryption for all projects and assets",
        "Role-based access control for team members",
        "GDPR and CCPA compliant data handling",
        "Regular security audits and penetration testing",
        "Two-factor authentication (2FA) support",
        "Secure content delivery network (CDN) integration",
        "Detailed activity logs and audit trails",
      ],
    },
    {
      title: "Multi-Platform Support",
      description: "Design once, publish everywhere",
      icon: Globe,
      image:
        "https://images.unsplash.com/photo-1633409361618-c73427e4e206?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1480&q=80",
      features: [
        "Responsive designs for web, mobile, and digital signage",
        "Social media platform-specific templates and sizes",
        "Automatic content adaptation for different aspect ratios",
        "Cross-platform preview and testing tools",
        "Integration with popular CMS and DAM systems",
        "Export options for print and digital formats",
        "API for custom integrations and workflows",
      ],
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <WebsiteNavigation />

      {/* Hero Section */}
      <section
        className="relative bg-cover bg-center py-32 px-4"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80')`,
        }}
      >
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="relative z-10 container mx-auto max-w-6xl text-center">
          <h1 className="text-5xl font-bold tracking-tight mb-6 text-white">
            Powerful Features for Creative Professionals
          </h1>
          <p className="text-xl text-white/80 mb-8 max-w-3xl mx-auto">
            Discover all the tools and capabilities that make VISION CREATOR the ultimate platform for design and
            animation.
          </p>
        </div>
      </section>

      {/* Feature Sections */}
      {featureSections.map((section, index) => (
        <section key={index} className={`py-20 px-4 ${index % 2 === 1 ? "bg-muted/50" : ""}`}>
          <div className="container mx-auto max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className={index % 2 === 1 ? "md:order-2" : ""}>
                <div className="flex items-center gap-4 mb-6">
                  <section.icon className="h-10 w-10 text-primary" />
                  <h2 className="text-3xl font-bold">{section.title}</h2>
                </div>
                <p className="text-xl text-muted-foreground mb-8">{section.description}</p>
                <ul className="space-y-3">
                  {section.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className={index % 2 === 1 ? "md:order-1" : ""}>
                <Image
                  src={section.image || "/placeholder.svg"}
                  alt={section.title}
                  width={600}
                  height={400}
                  className="rounded-xl shadow-lg object-cover"
                />
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="container mx-auto max-w-6xl text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to revolutionize your digital signage?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8 text-primary-foreground/80">
            Start creating stunning, dynamic content for your displays today
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/editor">
              <Button size="lg" variant="secondary" className="rounded-full px-8">
                Try it free
              </Button>
            </Link>
            <Link href="/website/pricing">
              <Button
                size="lg"
                variant="outline"
                className="rounded-full px-8 bg-transparent text-primary-foreground border-primary-foreground/20 hover:bg-primary-foreground/10"
              >
                View pricing
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <WebsiteFooter />
    </div>
  )
}

