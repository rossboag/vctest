import { Button } from "@/components/ui/button"
import { WebsiteNavigation } from "@/components/website/navigation"
import { WebsiteFooter } from "@/components/website/footer"
import Image from "next/image"
import {
  ArrowRight,
  Menu,
  ShoppingBag,
  Clock,
  FileSlidersIcon as Slideshow,
  Video,
  Calendar,
  ImageIcon,
  Instagram,
  LogInIcon as Logo,
  Snowflake,
  PhoneCall,
  Palette,
  Music,
  Type,
  Zap,
  Award,
  Tv,
  Layers,
  PenTool,
} from "lucide-react"

export default function ApplicationsPage() {
  const applications = [
    {
      title: "Dynamic Menu Designs",
      icon: Menu,
      description: "Create visually appealing and easily updatable menu designs for restaurants and cafes.",
      image:
        "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Engaging Product Promotions",
      icon: ShoppingBag,
      description: "Design eye-catching promotional materials to showcase products and special offers.",
      image:
        "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Interactive Slideshows",
      icon: Slideshow,
      description:
        "Craft captivating slideshows combining images, videos, and animations for presentations or displays.",
      image:
        "https://images.unsplash.com/photo-1558403194-611308249627?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Informative Displays",
      icon: Tv,
      description:
        "Design clear and concise information displays for events, public spaces, or corporate communications.",
      image:
        "https://images.unsplash.com/photo-1610465299996-30f240ac2b1c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Social Media Advertisements",
      icon: Instagram,
      description: "Create scroll-stopping social media ads optimized for various platforms.",
      image:
        "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1474&q=80",
    },
    {
      title: "Logo Animations",
      icon: Logo,
      description: "Bring logos to life with smooth, professional animations for brand intros or transitions.",
      image:
        "https://images.unsplash.com/photo-1636622433525-127afdf3662d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1632&q=80",
    },
    {
      title: "Animated Opening Times",
      icon: Clock,
      description: "Design visually appealing and dynamic displays of business hours or event schedules.",
      image:
        "https://images.unsplash.com/photo-1506485338023-6ce5f36692df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Seasonal Greetings",
      icon: Snowflake,
      description: "Craft festive and engaging seasonal messages and promotional materials.",
      image:
        "https://images.unsplash.com/photo-1512389142860-9c449e58a543?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1469&q=80",
    },
    {
      title: "Interactive Contact Information",
      icon: PhoneCall,
      description: "Create visually appealing and easily accessible contact information displays.",
      image:
        "https://images.unsplash.com/photo-1423666639041-f56000c27a9a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1474&q=80",
    },
    {
      title: "Brand Style Guides",
      icon: Palette,
      description: "Design comprehensive, interactive brand style guides for consistent visual communication.",
      image:
        "https://images.unsplash.com/photo-1485841890310-6a055c88698a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Video Content Creation",
      icon: Video,
      description: "Edit and enhance video content for marketing, social media, or informational purposes.",
      image:
        "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Event Calendars",
      icon: Calendar,
      description: "Design dynamic, visually appealing event calendars that are easy to update and share.",
      image:
        "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1468&q=80",
    },
    {
      title: "Photo Galleries",
      icon: ImageIcon,
      description: "Create stunning photo galleries and portfolios to showcase work or products.",
      image:
        "https://images.unsplash.com/photo-1482245294234-b3f2f8d5f1a4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Music Visualizations",
      icon: Music,
      description: "Design captivating visual accompaniments for music or audio content.",
      image:
        "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Typographic Animations",
      icon: Type,
      description: "Bring text to life with kinetic typography for impactful messaging.",
      image:
        "https://images.unsplash.com/photo-1632722754679-0d51c7eaef8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Animated Infographics",
      icon: Zap,
      description: "Transform complex information into engaging, animated infographics.",
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Award Ceremonies Content",
      icon: Award,
      description: "Design elegant graphics and animations for virtual or in-person award ceremonies.",
      image:
        "https://images.unsplash.com/photo-1531545514256-b1400bc00f31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80",
    },
    {
      title: "Brand Storytelling Narratives",
      icon: Video,
      description: "Craft compelling visual narratives to tell your brand's story across various mediums.",
      image:
        "https://images.unsplash.com/photo-1516321497487-e288fb19713f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Interactive Data Visualizations",
      icon: Layers,
      description: "Create dynamic, interactive charts and graphs to present data in an engaging way.",
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      title: "Custom Illustration Animations",
      icon: PenTool,
      description: "Bring illustrations to life with custom animations for unique, eye-catching content.",
      image:
        "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <WebsiteNavigation />
      <main className="flex-grow">
        <section className="py-12 md:py-24 lg:py-32 bg-background">
          <div className="container px-4 md:px-6">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-8">
              Creative Applications of VISION CREATOR
            </h1>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400 text-center mb-12">
              Unleash your creativity with VISION CREATOR. From dynamic menu designs to custom illustration animations,
              our tool empowers you to create engaging visual content for any medium or platform.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {applications.map((app, index) => (
                <div key={index} className="flex flex-col items-center text-center p-4 border rounded-lg shadow-sm">
                  <Image
                    src={app.image || "/placeholder.svg"}
                    alt={app.title}
                    width={300}
                    height={200}
                    className="rounded-lg mb-4 object-cover w-full h-48"
                  />
                  <app.icon className="w-12 h-12 mb-4 text-primary" />
                  <h3 className="text-lg font-semibold mb-2">{app.title}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{app.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        <section className="py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ready to Bring Your Ideas to Life?</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Start creating stunning visual content with VISION CREATOR today. Our intuitive tools and AI-powered
                  features make it easy to design professional-looking content for any application or platform.
                </p>
              </div>
              <div className="space-x-4">
                <Button>
                  Start Creating <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline">Explore Templates</Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <WebsiteFooter />
    </div>
  )
}

