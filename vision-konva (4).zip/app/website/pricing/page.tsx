"use client"

import { WebsiteNavigation } from "@/components/website/navigation"
import { WebsiteFooter } from "@/components/website/footer"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check, HelpCircle } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function PricingPage() {
  const plans = [
    {
      id: 1,
      name: "Free Plan (7-Day Trial)",
      price: 0,
      period: "7-day trial",
      features: [
        "Full access to AI builder and editor",
        "Limited to 5 exports total during the trial",
        "Limited AI suggestions for layout and color",
        "No access to system templates or saved projects",
        "Community support only",
        "Trial expires after 7 days",
      ],
      badge: "Trial",
      cta: "Start Free Trial",
    },
    {
      id: 2,
      name: "Starter Plan",
      price: 39,
      period: "per month",
      features: [
        "Full access to AI builder and editor",
        "Limited to 5 exports per month",
        "No AI-powered content creation",
        "No access to system templates or template library",
        "Community support only",
        "Single user license",
      ],
      badge: "Starter",
      cta: "Choose Starter",
    },
    {
      id: 3,
      name: "Pro Plan",
      price: 79,
      period: "per month",
      features: [
        "Full access to editor, AI builder, and basic AI-powered features",
        "Limited to 25 exports per month",
        "AI-generated layout suggestions",
        "AI-powered font & color recommendations",
        "No AI image or animation generation",
        "Access to the full system template library",
        "Standard support (email response within 48 hours)",
        "Single user license",
      ],
      badge: "Pro",
      cta: "Choose Pro",
      popular: true,
    },
    {
      id: 4,
      name: "Teams Plan",
      price: 159,
      period: "per month",
      features: [
        "Full access to editor, AI builder, and expanded AI-powered features",
        "Limited to 100 exports per month",
        "AI layout and font recommendations",
        "AI text suggestions (no AI image generation)",
        "AI animation presets",
        "Access to all templates + team-shared template library",
        "Priority email support (24-hour response time)",
        "Up to 5 users",
      ],
      badge: "Teams",
      cta: "Choose Teams",
    },
  ]

  const faqs = [
    {
      question: "What's included in the 7-day free trial?",
      answer:
        "The free trial gives you full access to the AI builder and editor, with a limit of 5 total exports. You'll have limited AI suggestions for layout and color, but no access to system templates or saved projects. Community support is available during the trial period.",
    },
    {
      question: "Can I upgrade or downgrade my plan?",
      answer:
        "Yes, you can upgrade or downgrade your plan at any time. If you upgrade, you'll immediately get access to the new features and your billing will be adjusted accordingly. If you downgrade, the changes will take effect at the start of your next billing cycle.",
    },
    {
      question: "What happens if I exceed my monthly export limit?",
      answer:
        "If you reach your monthly export limit, you won't be able to export any more projects until the next billing cycle begins. You can still work on and save projects within the editor. If you frequently hit your limit, consider upgrading to a higher tier plan.",
    },
    {
      question: "Do you offer refunds?",
      answer:
        "We offer a 14-day money-back guarantee for all paid plans. If you're not satisfied with our service, you can request a full refund within 14 days of your initial purchase or upgrade.",
    },
    {
      question: "Can I use VISION CREATOR for commercial projects?",
      answer:
        "Yes, all our plans allow you to use VISION CREATOR for commercial projects. The license you purchase (single user or team) determines how many people can use the account for creating these projects.",
    },
    {
      question: "Do you offer custom enterprise solutions?",
      answer:
        "Yes, we offer custom enterprise solutions for larger teams or organizations with specific needs. Please contact our sales team for more information on custom pricing, features, and support options.",
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <WebsiteNavigation />

      {/* Hero Section */}
      <section
        className="relative bg-cover bg-center py-32"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1626908013351-800ddd734b8a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')",
        }}
      >
        <div className="absolute inset-0 bg-black opacity-60"></div>
        <div className="relative z-10 container mx-auto max-w-6xl text-center text-white">
          <h1 className="text-5xl font-bold tracking-tight mb-6">Choose the Perfect Plan for Your Creative Journey</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            From free trials to advanced team collaborations, we have a plan to suit every creator's needs.
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {plans.map((plan, index) => (
              <Card key={index} className={`flex flex-col ${plan.popular ? "border-primary shadow-lg relative" : ""}`}>
                {plan.popular && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <div className="flex items-end gap-1 mt-2">
                    <span className="text-4xl font-bold">£{plan.price}</span>
                    <span className="text-muted-foreground mb-1">{plan.period}</span>
                  </div>
                  <CardDescription className="mt-2">
                    <span className="inline-block bg-secondary text-secondary-foreground px-2 py-1 rounded-full text-xs font-medium">
                      {plan.badge}
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <ul className="space-y-2">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button
                    className={`w-full ${plan.popular ? "" : "variant-outline"}`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    {plan.cta}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enterprise Section */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Enterprise Solutions</h2>
              <p className="text-xl text-muted-foreground mb-6">
                Need a custom solution for your organization? We offer enterprise plans with additional features and
                support.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Customizable user limits and permissions</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Advanced AI features and custom model training</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Dedicated account manager and priority support</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Custom onboarding and training programs</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Enhanced security features and compliance support</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>API access for seamless integrations</span>
                </li>
              </ul>
              <Button size="lg">Contact Enterprise Sales</Button>
            </div>
            <div className="bg-background rounded-xl p-8 border">
              <h3 className="text-xl font-semibold mb-4">Request a Demo</h3>
              <p className="text-muted-foreground mb-6">
                See how VISION CREATOR can transform your organization's design workflow.
              </p>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">First Name</label>
                    <input type="text" className="w-full p-2 rounded-md border" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Last Name</label>
                    <input type="text" className="w-full p-2 rounded-md border" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <input type="email" className="w-full p-2 rounded-md border" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Company</label>
                  <input type="text" className="w-full p-2 rounded-md border" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Message</label>
                  <textarea className="w-full p-2 rounded-md border" rows={3}></textarea>
                </div>
                <Button className="w-full">Request Demo</Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="border rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2 flex items-center">
                  <HelpCircle className="h-5 w-5 text-primary mr-2" />
                  {faq.question}
                </h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="container mx-auto max-w-6xl text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to unleash your creativity?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8 text-primary-foreground/80">
            Start your 7-day free trial today and experience the power of AI-enhanced design.
          </p>
          <Link href="/editor">
            <Button size="lg" variant="secondary" className="rounded-full px-8">
              Start Free Trial
            </Button>
          </Link>
        </div>
      </section>

      <WebsiteFooter />
    </div>
  )
}

