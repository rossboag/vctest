"use client"

import { useState } from "react"
import { PageHeader } from "@/components/page-header"
import { AutoLayoutGenerator } from "@/components/ai/auto-layout-generator"
import { GridSystemGenerator } from "@/components/ai/grid-system-generator"
import { WhitespaceAnalyzer } from "@/components/ai/whitespace-analyzer"
import { AlignmentAnalyzer } from "@/components/ai/alignment-analyzer"
import { ResponsiveLayoutGenerator } from "@/components/ai/responsive-layout-generator"
import type { LayoutResult, GridSystem, LayoutElement } from "@/lib/ai-layout-service"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Download, Copy, Share2 } from "lucide-react"

export default function LayoutStudioPage() {
  const [activeTab, setActiveTab] = useState("auto-layout")
  const [layout, setLayout] = useState<LayoutResult | null>(null)
  const [gridSystem, setGridSystem] = useState<GridSystem | null>(null)

  // Mock elements for demonstration purposes
  const [elements, setElements] = useState<LayoutElement[]>([
    {
      id: "header",
      type: "container",
      width: 1200,
      height: 80,
      x: 0,
      y: 0,
    },
    {
      id: "logo",
      type: "image",
      width: 150,
      height: 50,
      x: 30,
      y: 15,
    },
    {
      id: "navigation",
      type: "container",
      width: 500,
      height: 50,
      x: 650,
      y: 15,
    },
    {
      id: "hero",
      type: "container",
      width: 1200,
      height: 500,
      x: 0,
      y: 100,
    },
    {
      id: "hero-text",
      type: "text",
      content: "Welcome to our platform",
      width: 600,
      height: 200,
      x: 100,
      y: 250,
    },
    {
      id: "hero-image",
      type: "image",
      width: 400,
      height: 300,
      x: 750,
      y: 200,
    },
  ])

  const handleLayoutGenerated = (newLayout: LayoutResult) => {
    setLayout(newLayout)
    setElements(newLayout.elements)
    toast.success("Layout generated successfully!")
  }

  const handleGridGenerated = (grid: GridSystem) => {
    setGridSystem(grid)
    toast.success("Grid system generated successfully!")
  }

  const handleElementsOptimized = (optimizedElements: LayoutElement[]) => {
    setElements(optimizedElements)
    toast.success("Elements optimized successfully!")
  }

  const exportLayout = () => {
    if (!layout && !elements.length) {
      toast.error("No layout to export")
      return
    }

    const exportData = {
      elements: elements,
      gridSystem: gridSystem,
      width: layout?.width || 1200,
      height: layout?.height || 800,
      timestamp: new Date().toISOString(),
    }

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `layout-${new Date().getTime()}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("Layout exported successfully!")
  }

  const copyToClipboard = () => {
    if (!layout && !elements.length) {
      toast.error("No layout to copy")
      return
    }

    const exportData = {
      elements: elements,
      gridSystem: gridSystem,
      width: layout?.width || 1200,
      height: layout?.height || 800,
    }

    navigator.clipboard.writeText(JSON.stringify(exportData, null, 2))
    toast.success("Layout copied to clipboard!")
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <PageHeader title="Layout Studio" description="Generate, analyze, and optimize layouts with AI assistance" />

      <div className="flex gap-4">
        <Button variant="outline" onClick={exportLayout}>
          <Download className="h-4 w-4 mr-2" />
          Export Layout
        </Button>
        <Button variant="outline" onClick={copyToClipboard}>
          <Copy className="h-4 w-4 mr-2" />
          Copy JSON
        </Button>
        <Button variant="outline">
          <Share2 className="h-4 w-4 mr-2" />
          Share Layout
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full">
              <TabsTrigger value="auto-layout" className="flex-1">
                Auto Layout
              </TabsTrigger>
              <TabsTrigger value="grid" className="flex-1">
                Grid
              </TabsTrigger>
              <TabsTrigger value="optimize" className="flex-1">
                Optimize
              </TabsTrigger>
            </TabsList>

            <TabsContent value="auto-layout" className="mt-4">
              <AutoLayoutGenerator initialWidth={1200} initialHeight={800} onLayoutGenerated={handleLayoutGenerated} />
            </TabsContent>

            <TabsContent value="grid" className="mt-4">
              <GridSystemGenerator
                canvasSize={{ width: layout?.width || 1200, height: layout?.height || 800 }}
                onGridGenerated={handleGridGenerated}
              />
            </TabsContent>

            <TabsContent value="optimize" className="mt-4 space-y-6">
              <WhitespaceAnalyzer
                canvasSize={{ width: layout?.width || 1200, height: layout?.height || 800 }}
                elements={elements}
                onElementsOptimized={handleElementsOptimized}
              />

              <AlignmentAnalyzer
                elements={elements}
                gridSystem={gridSystem}
                onElementsOptimized={handleElementsOptimized}
              />

              <ResponsiveLayoutGenerator
                elements={elements}
                originalSize={{ width: layout?.width || 1200, height: layout?.height || 800 }}
                onLayoutGenerated={handleLayoutGenerated}
              />
            </TabsContent>
          </Tabs>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardContent className="p-6">
              <div
                className="bg-muted rounded-lg relative overflow-hidden"
                style={{
                  height: "600px",
                  width: "100%",
                }}
              >
                {/* Layout Preview */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {elements.length > 0 ? (
                    <div
                      className="relative"
                      style={{
                        width: layout?.width || 1200,
                        height: layout?.height || 800,
                        transform: "scale(0.5)",
                        transformOrigin: "center",
                        border: "1px solid #e5e7eb",
                      }}
                    >
                      {/* Render Grid if available */}
                      {gridSystem && (
                        <div className="absolute inset-0 pointer-events-none">
                          <div
                            className="w-full h-full grid"
                            style={{
                              gridTemplateColumns: `repeat(${gridSystem.columns}, 1fr)`,
                              gridGap: `${gridSystem.columnGap}px`,
                              padding: `${gridSystem.margin}px`,
                            }}
                          >
                            {Array.from({ length: gridSystem.columns }).map((_, i) => (
                              <div key={i} className="h-full bg-blue-100/20 border-r border-blue-200/20"></div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Render elements */}
                      {elements.map((element) => (
                        <div
                          key={element.id}
                          className="absolute bg-white border rounded-md flex items-center justify-center"
                          style={{
                            width: `${element.width}px`,
                            height: `${element.height}px`,
                            left: `${element.x}px`,
                            top: `${element.y}px`,
                            backgroundColor: element.type === "image" ? "#f3f4f6" : "#ffffff",
                            border: "1px solid #e5e7eb",
                          }}
                        >
                          <span className="text-xs text-gray-500">
                            {element.type}
                            {element.content ? `: ${element.content}` : ""}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-gray-400">Generate a layout to see the preview</div>
                  )}
                </div>
              </div>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-2">Layout Data:</h3>
                <div className="h-[200px] overflow-auto p-4 bg-muted rounded-md">
                  <pre className="text-xs">
                    {JSON.stringify(
                      { elements, gridSystem, width: layout?.width || 1200, height: layout?.height || 800 },
                      null,
                      2,
                    )}
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

