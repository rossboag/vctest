"use client"

import { useState } from "react"
import { StylePanel } from "@/components/editor/style-panel"
import { Card, CardContent } from "@/components/ui/card"
import { toast } from "sonner"
import type { BrandStyle, ThemeTemplate, MoodBoard } from "@/lib/ai-style-service"

export default function StyleStudioPage() {
  const [elements, setElements] = useState<any[]>([])
  const [projectId, setProjectId] = useState<string>("demo-project")

  const handleApplyBrandStyle = (brandStyle: BrandStyle) => {
    toast.success("Brand style applied successfully!")
    // In a real implementation, this would update the design with the brand style
  }

  const handleApplyTheme = (theme: ThemeTemplate) => {
    toast.success("Theme applied successfully!")
    // In a real implementation, this would update the design with the theme
  }

  const handleApplyStyleTransfer = (result: any) => {
    toast.success("Style transfer applied successfully!")
    // In a real implementation, this would update the design with the style transfer
  }

  const handleApplyMoodBoard = (moodBoard: MoodBoard) => {
    toast.success("Mood board applied successfully!")
    // In a real implementation, this would update the design with the mood board
  }

  const handleApplyDesignTrend = (result: any) => {
    toast.success("Design trend applied successfully!")
    // In a real implementation, this would update the design with the design trend
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Style Studio</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-6">
              <StylePanel
                projectId={projectId}
                elements={elements}
                onApplyBrandStyle={handleApplyBrandStyle}
                onApplyTheme={handleApplyTheme}
                onApplyStyleTransfer={handleApplyStyleTransfer}
                onApplyMoodBoard={handleApplyMoodBoard}
                onApplyDesignTrend={handleApplyDesignTrend}
              />
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-semibold">Style Preview</h2>
              <p className="text-muted-foreground">
                Apply styles from the Style Studio to see a preview of your design with the new style applied.
              </p>
              <div className="aspect-video bg-muted rounded-md flex items-center justify-center">
                <p className="text-muted-foreground">Style preview will appear here</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

