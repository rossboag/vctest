"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AITextGenerator } from "@/components/ai/ai-text-generator"
import { AIImageGenerator } from "@/components/ai/ai-image-generator"
import { AIColorPaletteGenerator } from "@/components/ai/ai-color-palette-generator"
import { AILayoutGenerator } from "@/components/ai/ai-layout-generator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHomeLink } from "@/components/dashboard-home-link"
import { History, Sparkles } from "lucide-react"
import { toast } from "sonner"

export default function AIStudioPage() {
  const [activeTab, setActiveTab] = useState("text")
  const [history, setHistory] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  // Fetch AI generation history
  useEffect(() => {
    const fetchHistory = async () => {
      try {
        setLoading(true)
        const response = await fetch("/api/ai/history?limit=10")
        if (response.ok) {
          const data = await response.json()
          setHistory(data)
        }
      } catch (error) {
        console.error("Error fetching AI history:", error)
        toast.error("Failed to fetch AI history")
      } finally {
        setLoading(false)
      }
    }

    fetchHistory()
  }, [])

  return (
    <div className="relative">
      <DashboardHomeLink />
      <div className="container mx-auto p-6">
        <div className="flex items-center mb-6">
          <Sparkles className="h-6 w-6 mr-2" />
          <h1 className="text-3xl font-bold">AI Studio</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Create with AI</CardTitle>
                <CardDescription>Use AI to generate content for your projects</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid grid-cols-4 mb-4">
                    <TabsTrigger value="text">Text</TabsTrigger>
                    <TabsTrigger value="image">Image</TabsTrigger>
                    <TabsTrigger value="colors">Colors</TabsTrigger>
                    <TabsTrigger value="layout">Layout</TabsTrigger>
                  </TabsList>

                  <TabsContent value="text">
                    <AITextGenerator title="Generate Text" placeholder="Describe the text you want to generate..." />
                  </TabsContent>

                  <TabsContent value="image">
                    <AIImageGenerator title="Generate Image" placeholder="Describe the image you want to generate..." />
                  </TabsContent>

                  <TabsContent value="colors">
                    <AIColorPaletteGenerator title="Generate Color Palette" />
                  </TabsContent>

                  <TabsContent value="layout">
                    <AILayoutGenerator title="Generate Layout" />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <History className="h-5 w-5 mr-2" />
                  <CardTitle>Recent Generations</CardTitle>
                </div>
                <CardDescription>Your recent AI-generated content</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-8 text-muted-foreground">Loading history...</div>
                ) : history.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No generations yet</div>
                ) : (
                  <div className="space-y-4">
                    {history.map((item) => (
                      <div key={item.id} className="p-3 border rounded-md hover:bg-muted/50 transition-colors">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-xs font-medium bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                              {item.type.replace(/_/g, " ")}
                            </span>
                            <p className="mt-1 text-sm line-clamp-2">{item.prompt}</p>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {new Date(item.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

