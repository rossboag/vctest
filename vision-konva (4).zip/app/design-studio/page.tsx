"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DesignAnalyzer } from "@/components/ai/design-analyzer"
import { ColorPaletteGenerator } from "@/components/ai/color-palette-generator"
import { TypographyRecommender } from "@/components/ai/typography-recommender"
import { AccessibilityChecker } from "@/components/ai/accessibility-checker"
import { DesignSuggestionGenerator } from "@/components/ai/design-suggestion-generator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHomeLink } from "@/components/dashboard-home-link"
import { Palette, Wand2 } from "lucide-react"
import { toast } from "sonner"

// Mock design elements for demo purposes
const mockDesignElements = [
  {
    id: "element1",
    type: "text",
    content: "Welcome to Design Studio",
    style: {
      fontFamily: "Arial",
      fontSize: "32px",
      fontWeight: "bold",
      color: "#333333",
    },
    position: { x: 100, y: 100 },
  },
  {
    id: "element2",
    type: "text",
    content: "Create beautiful designs with AI assistance",
    style: {
      fontFamily: "Arial",
      fontSize: "18px",
      fontWeight: "normal",
      color: "#666666",
    },
    position: { x: 100, y: 150 },
  },
  {
    id: "element3",
    type: "rectangle",
    style: {
      width: 300,
      height: 200,
      fill: "#4285F4",
      opacity: 0.8,
    },
    position: { x: 400, y: 200 },
  },
  {
    id: "element4",
    type: "image",
    src: "/placeholder.jpg",
    style: {
      width: 200,
      height: 150,
    },
    position: { x: 150, y: 250 },
  },
]

const mockCanvasSize = { width: 800, height: 600 }

export default function DesignStudioPage() {
  const [activeTab, setActiveTab] = useState("analyze")
  const [designElements, setDesignElements] = useState(mockDesignElements)
  const [canvasSize, setCanvasSize] = useState(mockCanvasSize)

  return (
    <div className="relative">
      <DashboardHomeLink />
      <div className="container mx-auto p-6">
        <div className="flex items-center mb-6">
          <Palette className="h-6 w-6 mr-2" />
          <h1 className="text-3xl font-bold">Design Studio</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>AI Design Assistant</CardTitle>
                <CardDescription>Use AI to analyze and improve your designs</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid grid-cols-5 mb-4">
                    <TabsTrigger value="analyze">Analyze</TabsTrigger>
                    <TabsTrigger value="colors">Colors</TabsTrigger>
                    <TabsTrigger value="typography">Typography</TabsTrigger>
                    <TabsTrigger value="accessibility">Accessibility</TabsTrigger>
                    <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                  </TabsList>

                  <TabsContent value="analyze">
                    <DesignAnalyzer
                      designElements={designElements}
                      canvasSize={canvasSize}
                      onAnalysisComplete={(analysis) => {
                        toast.success("Design analysis complete!")
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="colors">
                    <ColorPaletteGenerator
                      onPaletteGenerated={(palette) => {
                        toast.success("Color palette generated!")
                        // Here you would typically apply the palette to your design
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="typography">
                    <TypographyRecommender
                      onTypographyGenerated={(typography) => {
                        toast.success("Typography recommendations generated!")
                        // Here you would typically apply the typography to your design
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="accessibility">
                    <AccessibilityChecker
                      designElements={designElements}
                      onCheckComplete={(result) => {
                        toast.success("Accessibility check complete!")
                      }}
                    />
                  </TabsContent>

                  <TabsContent value="suggestions">
                    <DesignSuggestionGenerator
                      designElements={designElements}
                      canvasSize={canvasSize}
                      onSuggestionsGenerated={(suggestions) => {
                        toast.success("Design suggestions generated!")
                      }}
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Wand2 className="h-5 w-5 mr-2" />
                  <CardTitle>Design Preview</CardTitle>
                </div>
                <CardDescription>Preview your design with AI enhancements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-muted rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-muted-foreground">Design Preview</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      (Preview functionality would be implemented here)
                    </p>
                  </div>
                </div>

                <div className="mt-4 space-y-2">
                  <h3 className="text-sm font-medium">Design Elements</h3>
                  <div className="space-y-2">
                    {designElements.map((element) => (
                      <div key={element.id} className="p-2 bg-muted rounded-md text-xs">
                        <div className="flex justify-between">
                          <span className="font-medium">{element.id}</span>
                          <span className="text-muted-foreground capitalize">{element.type}</span>
                        </div>
                        {element.type === "text" && <p className="mt-1 truncate">{element.content}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

