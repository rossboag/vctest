"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { DashboardHomeLink } from "@/components/dashboard-home-link"
import { toast } from "sonner"

export default function NotificationPreferencesPage() {
  const [preferences, setPreferences] = useState({
    email: true,
    push: true,
    inApp: true,
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  // Fetch notification preferences
  const fetchPreferences = useCallback(async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/notifications/preferences")
      const data = await response.json()

      if (response.ok) {
        setPreferences({
          email: data.email,
          push: data.push,
          inApp: data.inApp,
        })
      }
    } catch (error) {
      console.error("Error fetching notification preferences:", error)
      toast.error("Failed to load notification preferences")
    } finally {
      setLoading(false)
    }
  }, [])

  // Save notification preferences
  const savePreferences = async () => {
    try {
      setSaving(true)
      const response = await fetch("/api/notifications/preferences", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(preferences),
      })

      if (response.ok) {
        toast.success("Notification preferences saved")
      } else {
        toast.error("Failed to save notification preferences")
      }
    } catch (error) {
      console.error("Error saving notification preferences:", error)
      toast.error("Failed to save notification preferences")
    } finally {
      setSaving(false)
    }
  }

  // Fetch preferences on mount
  useEffect(() => {
    fetchPreferences()
  }, [fetchPreferences])

  return (
    <div className="relative">
      <DashboardHomeLink />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">Notification Preferences</h1>

        <Card>
          <CardHeader>
            <CardTitle>Notification Settings</CardTitle>
            <CardDescription>Customize how you receive notifications</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-4">Loading preferences...</div>
            ) : (
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="email-notifications">Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                    </div>
                    <Switch
                      id="email-notifications"
                      checked={preferences.email}
                      onCheckedChange={(checked) => setPreferences({ ...preferences, email: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="push-notifications">Push Notifications</Label>
                      <p className="text-sm text-muted-foreground">Receive push notifications in your browser</p>
                    </div>
                    <Switch
                      id="push-notifications"
                      checked={preferences.push}
                      onCheckedChange={(checked) => setPreferences({ ...preferences, push: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="in-app-notifications">In-App Notifications</Label>
                      <p className="text-sm text-muted-foreground">Receive notifications within the application</p>
                    </div>
                    <Switch
                      id="in-app-notifications"
                      checked={preferences.inApp}
                      onCheckedChange={(checked) => setPreferences({ ...preferences, inApp: checked })}
                    />
                  </div>
                </div>

                <Button onClick={savePreferences} disabled={saving} className="w-full">
                  {saving ? "Saving..." : "Save Preferences"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

