module.exports = {
  auth: {
    username: process.env.BROWSERSTACK_USERNAME,
    accessKey: process.env.BROWSERSTACK_ACCESS_KEY,
  },
  browsers: [
    // Desktop browsers
    {
      browser: "chrome",
      browser_version: "latest",
      os: "Windows",
      os_version: "10",
    },
    {
      browser: "firefox",
      browser_version: "latest",
      os: "Windows",
      os_version: "10",
    },
    {
      browser: "edge",
      browser_version: "latest",
      os: "Windows",
      os_version: "10",
    },
    {
      browser: "safari",
      browser_version: "latest",
      os: "OS X",
      os_version: "Big Sur",
    },
    // Mobile browsers
    {
      device: "iPhone 12",
      os: "ios",
      os_version: "14",
      real_mobile: true,
    },
    {
      device: "Samsung Galaxy S21",
      os: "android",
      os_version: "11.0",
      real_mobile: true,
    },
    {
      device: "iPad Pro 12.9 2020",
      os: "ios",
      os_version: "14",
      real_mobile: true,
    },
  ],
  run_settings: {
    project: "Vision Creator",
    build: `Cross-Browser Tests - ${new Date().toISOString()}`,
    parallels: 5,
    networkLogs: true,
    consoleLogs: "verbose",
  },
  connection_settings: {
    local: true,
    localIdentifier: process.env.BROWSERSTACK_LOCAL_IDENTIFIER,
  },
}

