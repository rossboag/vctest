export interface Theme {
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    text: string
    success: string
    warning: string
    error: string
  }
  typography: {
    headingFont: string
    bodyFont: string
    fontSize: {
      small: string
      medium: string
      large: string
      xlarge: string
    }
    lineHeight: {
      tight: string
      normal: string
      relaxed: string
    }
    fontWeight: {
      normal: string
      bold: string
    }
  }
  spacing: {
    small: string
    medium: string
    large: string
  }
  borderRadius: {
    small: string
    medium: string
    large: string
  }
  shadows: {
    small: string
    medium: string
    large: string
  }
  styleGuide: string
}

