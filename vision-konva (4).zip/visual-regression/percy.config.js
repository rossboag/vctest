// @ts-check
/** @type {import('@percy/playwright').PercyConfig} */
module.exports = {
  version: 2,
  discovery: {
    allowedHostnames: ["localhost"],
    disallowedHostnames: ["analytics.google.com"],
    requestHeaders: {
      "X-Percy-Test": "true",
    },
  },
  snapshot: {
    widths: [375, 768, 1280], // Mobile, tablet, desktop
    minHeight: 1024,
    percyCSS: `
      // Hide dynamic content that would cause false positives
      .timestamp, .user-cursor, .random-id { visibility: hidden !important; }
      // Hide animations during testing
      * { animation-duration: 0s !important; transition-duration: 0s !important; }
    `,
  },
  upload: {
    files: ["public/**/*.{png,jpg,jpeg,gif,svg}"],
  },
}

