import { test } from "@playwright/test"
import percySnapshot from "@percy/playwright"

// Test the main editor UI
test.describe("Editor UI Visual Tests", () => {
  test.beforeEach(async ({ page }) => {
    // Login and navigate to editor
    await page.goto("/login")
    await page.fill('input[name="email"]', "test@example.com")
    await page.fill('input[name="password"]', "password123")
    await page.click('button[type="submit"]')
    await page.waitForNavigation()
    await page.goto("/editor")
    // Wait for editor to fully load
    await page.waitForSelector(".konvajs-content", { state: "visible" })
    // Wait for animations to complete
    await page.waitForTimeout(1000)
  })

  test("Editor default state", async ({ page }) => {
    await percySnapshot(page, "Editor - Default State")
  })

  test("Editor with text element", async ({ page }) => {
    // Add a text element
    await page.click('button:has-text("Text")')
    await page.click(".konvajs-content")
    await page.fill(".text-editor-input", "Hello, Vision Creator!")
    await page.press(".text-editor-input", "Escape")
    await percySnapshot(page, "Editor - With Text Element")
  })

  test("Editor with shape element", async ({ page }) => {
    // Add a rectangle
    await page.click('button:has-text("Shape")')
    await page.click('button:has-text("Rectangle")')
    await page.click(".konvajs-content")
    await page.mouse.down()
    await page.mouse.move(200, 200)
    await page.mouse.up()
    await percySnapshot(page, "Editor - With Shape Element")
  })

  test("Editor with right panel open", async ({ page }) => {
    // Open the right panel
    await page.click('button:has-text("Effects")')
    await page.waitForSelector(".effects-panel", { state: "visible" })
    await percySnapshot(page, "Editor - With Effects Panel Open")
  })

  test("Editor with timeline panel open", async ({ page }) => {
    // Open the timeline panel
    await page.click('button:has-text("Timeline")')
    await page.waitForSelector(".timeline-panel", { state: "visible" })
    await percySnapshot(page, "Editor - With Timeline Panel Open")
  })
})

// Test the AI features UI
test.describe("AI Features Visual Tests", () => {
  test.beforeEach(async ({ page }) => {
    // Login and navigate to AI studio
    await page.goto("/login")
    await page.fill('input[name="email"]', "test@example.com")
    await page.fill('input[name="password"]', "password123")
    await page.click('button[type="submit"]')
    await page.waitForNavigation()
    await page.goto("/ai-studio")
    // Wait for page to load
    await page.waitForSelector(".ai-studio-container", { state: "visible" })
  })

  test("AI Studio default state", async ({ page }) => {
    await percySnapshot(page, "AI Studio - Default State")
  })

  test("AI Text Generator UI", async ({ page }) => {
    await page.click('button:has-text("Text Generator")')
    await page.waitForSelector(".ai-text-generator", { state: "visible" })
    await percySnapshot(page, "AI Studio - Text Generator")
  })

  test("AI Image Generator UI", async ({ page }) => {
    await page.click('button:has-text("Image Generator")')
    await page.waitForSelector(".ai-image-generator", { state: "visible" })
    await percySnapshot(page, "AI Studio - Image Generator")
  })

  test("AI Color Palette Generator UI", async ({ page }) => {
    await page.click('button:has-text("Color Palette")')
    await page.waitForSelector(".ai-color-palette-generator", { state: "visible" })
    await percySnapshot(page, "AI Studio - Color Palette Generator")
  })
})

// Test responsive layouts
test.describe("Responsive Layout Visual Tests", () => {
  // Test mobile layout
  test("Mobile layout", async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 })
    await page.goto("/")
    await page.waitForLoadState("networkidle")
    await percySnapshot(page, "Home Page - Mobile")

    await page.goto("/editor")
    await page.waitForLoadState("networkidle")
    await percySnapshot(page, "Editor - Mobile")
  })

  // Test tablet layout
  test("Tablet layout", async ({ page }) => {
    await page.setViewportSize({ width: 768, height: 1024 })
    await page.goto("/")
    await page.waitForLoadState("networkidle")
    await percySnapshot(page, "Home Page - Tablet")

    await page.goto("/editor")
    await page.waitForLoadState("networkidle")
    await percySnapshot(page, "Editor - Tablet")
  })

  // Test desktop layout
  test("Desktop layout", async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 800 })
    await page.goto("/")
    await page.waitForLoadState("networkidle")
    await percySnapshot(page, "Home Page - Desktop")

    await page.goto("/editor")
    await page.waitForLoadState("networkidle")
    await percySnapshot(page, "Editor - Desktop")
  })
})

