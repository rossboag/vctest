const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

// Configuration
const config = {
  unitTestGlob: "__tests__/**/*.test.{ts,tsx}",
  e2eTestGlob: "cypress/e2e/**/*.cy.{js,ts}",
  performanceTestGlob: "__tests__/performance.test.{ts,tsx}",
  accessibilityTestGlob: "__tests__/accessibility.test.{ts,tsx}",
  coverageThreshold: {
    global: {
      statements: 80,
      branches: 70,
      functions: 80,
      lines: 80,
    },
  },
  outputDir: "test-results",
}

// Ensure output directory exists
if (!fs.existsSync(config.outputDir)) {
  fs.mkdirSync(config.outputDir, { recursive: true })
}

// Helper to run command and log output
const runCommand = (command, logFile) => {
  console.log(`Running: ${command}`)

  try {
    const output = execSync(command, { encoding: "utf8" })

    if (logFile) {
      fs.writeFileSync(path.join(config.outputDir, logFile), output)
    }

    console.log("✅ Success!")
    return { success: true, output }
  } catch (error) {
    console.error("❌ Failed!")
    console.error(error.message)

    if (logFile) {
      fs.writeFileSync(path.join(config.outputDir, logFile), `Error: ${error.message}\n\nOutput: ${error.stdout}`)
    }

    return { success: false, error }
  }
}

// Run linting
console.log("\n🔍 Running ESLint...")
const lintResult = runCommand("npm run lint", "lint-results.txt")

// Run type checking
console.log("\n📝 Running TypeScript type checking...")
const typeCheckResult = runCommand("npm run type-check", "type-check-results.txt")

// Run unit tests
console.log("\n🧪 Running unit tests...")
const unitTestResult = runCommand(`jest ${config.unitTestGlob} --coverage`, "unit-test-results.txt")

// Run performance tests
console.log("\n⚡ Running performance tests...")
const performanceTestResult = runCommand(`jest ${config.performanceTestGlob}`, "performance-test-results.txt")

// Run accessibility tests
console.log("\n♿ Running accessibility tests...")
const accessibilityTestResult = runCommand(`jest ${config.accessibilityTestGlob}`, "accessibility-test-results.txt")

// Run E2E tests
console.log("\n🌐 Running E2E tests...")
const e2eTestResult = runCommand("cypress run", "e2e-test-results.txt")

// Generate test summary
const summary = {
  timestamp: new Date().toISOString(),
  results: {
    lint: lintResult.success,
    typeCheck: typeCheckResult.success,
    unitTests: unitTestResult.success,
    performanceTests: performanceTestResult.success,
    accessibilityTests: accessibilityTestResult.success,
    e2eTests: e2eTestResult.success,
  },
  allPassed:
    lintResult.success &&
    typeCheckResult.success &&
    unitTestResult.success &&
    performanceTestResult.success &&
    accessibilityTestResult.success &&
    e2eTestResult.success,
}

// Write summary to file
fs.writeFileSync(path.join(config.outputDir, "test-summary.json"), JSON.stringify(summary, null, 2))

// Print summary
console.log("\n📊 Test Summary:")
console.log("--------------------------------------------------")
console.log(`Linting: ${summary.results.lint ? "✅ Passed" : "❌ Failed"}`)
console.log(`Type Checking: ${summary.results.typeCheck ? "✅ Passed" : "❌ Failed"}`)
console.log(`Unit Tests: ${summary.results.unitTests ? "✅ Passed" : "❌ Failed"}`)
console.log(`Performance Tests: ${summary.results.performanceTests ? "✅ Passed" : "❌ Failed"}`)
console.log(`Accessibility Tests: ${summary.results.accessibilityTests ? "✅ Passed" : "❌ Failed"}`)
console.log(`E2E Tests: ${summary.results.e2eTests ? "✅ Passed" : "❌ Failed"}`)
console.log("--------------------------------------------------")
console.log(`Overall: ${summary.allPassed ? "✅ All tests passed!" : "❌ Some tests failed!"}`)

// Exit with appropriate code
process.exit(summary.allPassed ? 0 : 1)

