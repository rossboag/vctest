import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function main() {
  // Create default notification templates
  const templates = [
    {
      type: "welcome",
      title: "Welcome to Vision Creator!",
      message: "Thank you for joining Vision Creator. Start creating amazing designs today!",
    },
    {
      type: "project_shared",
      title: "Project Shared with You",
      message: "{{senderName}} has shared a project with you: {{projectName}}",
    },
    {
      type: "comment_added",
      title: "New Comment on Your Project",
      message: "{{senderName}} commented on your project: {{projectName}}",
    },
    {
      type: "project_updated",
      title: "Project Updated",
      message: "Your project {{projectName}} has been updated by {{senderName}}",
    },
    {
      type: "subscription_expiring",
      title: "Subscription Expiring Soon",
      message: "Your subscription will expire in {{daysLeft}} days. Renew now to avoid interruption.",
    },
    {
      type: "subscription_renewed",
      title: "Subscription Renewed",
      message: "Your subscription has been successfully renewed. Next billing date: {{nextBillingDate}}",
    },
    {
      type: "export_complete",
      title: "Export Complete",
      message: "Your export of {{projectName}} is ready for download.",
    },
    {
      type: "ai_generation_complete",
      title: "AI Generation Complete",
      message: "Your AI-generated content is ready to view.",
    },
    {
      type: "system_announcement",
      title: "System Announcement",
      message: "{{message}}",
    },
    {
      type: "feature_update",
      title: "New Feature Available",
      message: "We've added a new feature: {{featureName}}. Check it out!",
    },
  ]

  console.log("Creating notification templates...")

  for (const template of templates) {
    // Check if template already exists
    const existingTemplate = await prisma.notificationTemplate.findUnique({
      where: {
        type: template.type,
      },
    })

    if (existingTemplate) {
      console.log(`Template ${template.type} already exists, skipping...`)
      continue
    }

    // Create template
    await prisma.notificationTemplate.create({
      data: template,
    })

    console.log(`Created template: ${template.type}`)
  }

  console.log("Notification templates created successfully!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

