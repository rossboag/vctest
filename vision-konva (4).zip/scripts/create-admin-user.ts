import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function createAdminUser() {
  try {
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: {
        email: "rossboag1@gmail.com",
      },
    })

    if (existingUser) {
      console.log("User already exists. Updating to admin role...")

      // Update user to admin role
      await prisma.user.update({
        where: {
          email: "rossboag1@gmail.com",
        },
        data: {
          role: "ADMIN",
        },
      })

      console.log("User updated to admin role successfully!")
      return
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash("VisionCreator25!", 10)

    // Create the admin user
    const user = await prisma.user.create({
      data: {
        name: "rossboag",
        email: "rossboag1@gmail.com",
        password: hashedPassword,
        role: "ADMIN",
        active: true,
      },
    })

    console.log("Admin user created successfully:", user.id)
  } catch (error) {
    console.error("Error creating admin user:", error)
  } finally {
    await prisma.$disconnect()
  }
}

createAdminUser()

