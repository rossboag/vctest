const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

// Configuration
const config = {
  outputDir: "test-results",
  tests: [
    {
      name: "unit_tests",
      command: "npm run test",
      description: "Unit and integration tests",
    },
    {
      name: "visual_regression",
      command: "npx percy exec -- npx playwright test",
      description: "Visual regression tests",
    },
    {
      name: "load_tests",
      command: "node load-testing/run-load-tests.js",
      description: "API load tests",
    },
    {
      name: "cross_browser",
      command: "node cross-browser/browser-tests.js",
      description: "Cross-browser compatibility tests",
    },
    {
      name: "accessibility",
      command: "npm run test:accessibility",
      description: "Accessibility tests",
    },
    {
      name: "e2e",
      command: "cypress run",
      description: "End-to-end tests",
    },
  ],
}

// Ensure output directory exists
if (!fs.existsSync(config.outputDir)) {
  fs.mkdirSync(config.outputDir, { recursive: true })
}

// Helper to run command and log output
const runCommand = (command, logFile) => {
  console.log(`Running: ${command}`)

  try {
    const output = execSync(command, { encoding: "utf8" })

    if (logFile) {
      fs.writeFileSync(path.join(config.outputDir, logFile), output)
    }

    console.log("✅ Success!")
    return { success: true, output }
  } catch (error) {
    console.error("❌ Failed!")
    console.error(error.message)

    if (logFile) {
      fs.writeFileSync(path.join(config.outputDir, logFile), `Error: ${error.message}\n\nOutput: ${error.stdout}`)
    }

    return { success: false, error }
  }
}

// Run each test
console.log("🚀 Starting all tests...")
const results = {}

for (const test of config.tests) {
  console.log(`\n📊 Running ${test.name}: ${test.description}`)
  const result = runCommand(test.command, `${test.name}-results.txt`)
  results[test.name] = result.success
}

// Generate test summary
const summary = {
  timestamp: new Date().toISOString(),
  results,
  allPassed: Object.values(results).every(Boolean),
}

// Write summary to file
fs.writeFileSync(path.join(config.outputDir, "all-tests-summary.json"), JSON.stringify(summary, null, 2))

// Print summary
console.log("\n📊 All Tests Summary:")
console.log("--------------------------------------------------")
for (const test of config.tests) {
  console.log(`${test.name}: ${results[test.name] ? "✅ Passed" : "❌ Failed"}`)
}
console.log("--------------------------------------------------")
console.log(`Overall: ${summary.allPassed ? "✅ All tests passed!" : "❌ Some tests failed!"}`)

// Exit with appropriate code
process.exit(summary.allPassed ? 0 : 1)

