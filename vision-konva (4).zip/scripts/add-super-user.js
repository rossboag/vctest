// This script can be run with: node scripts/add-super-user.js

const { PrismaClient } = require("@prisma/client")
const bcrypt = require("bcryptjs")

const prisma = new PrismaClient()

async function createSuperUser() {
  try {
    // Define the super user details
    const username = "rossboag"
    const email = "rossboag1@gmail.com"
    const password = "VisionCreator25!"

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: {
        email,
      },
    })

    if (existingUser) {
      console.log("User already exists. Updating to admin role...")

      // Update user to admin role
      await prisma.user.update({
        where: {
          email,
        },
        data: {
          role: "ADMIN",
          name: username,
        },
      })

      console.log("User updated to admin role successfully!")
      return
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create the admin user
    const user = await prisma.user.create({
      data: {
        name: username,
        email,
        password: hashedPassword,
        role: "ADMIN",
        active: true,
      },
    })

    console.log("Super user created successfully:", user.id)
  } catch (error) {
    console.error("Error creating super user:", error)
  } finally {
    await prisma.$disconnect()
  }
}

createSuperUser()

