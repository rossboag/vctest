const { defineConfig } = require("cypress")

module.exports = defineConfig({
  e2e: {
    baseUrl: "http://localhost:3000",
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },

  component: {
    devServer: {
      framework: "next",
      bundler: "webpack",
    },
  },

  viewportWidth: 1280,
  viewportHeight: 720,

  // Define different viewports for testing
  env: {
    mobile: {
      viewportWidth: 375,
      viewportHeight: 667,
    },
    tablet: {
      viewportWidth: 768,
      viewportHeight: 1024,
    },
    desktop: {
      viewportWidth: 1280,
      viewportHeight: 720,
    },
  },
})

