// Optional: configure or set up a testing framework before each test.
// If you delete this file, remove `setupFilesAfterEnv` from `jest.config.js`

// Used for __tests__/testing-library.js
// Learn more: https://github.com/testing-library/jest-dom
import "@testing-library/jest-dom"
import { mockMatchMedia, mockResizeObserver, mockIntersectionObserver } from "./lib/test-utils"

// Mock window.matchMedia
mockMatchMedia()

// Mock ResizeObserver
mockResizeObserver()

// Mock IntersectionObserver
mockIntersectionObserver()

// Mock canvas methods
HTMLCanvasElement.prototype.getContext = jest.fn(() => ({
  fillRect: jest.fn(),
  clearRect: jest.fn(),
  getImageData: jest.fn(() => ({
    data: new Array(4),
  })),
  putImageData: jest.fn(),
  createImageData: jest.fn(() => []),
  setTransform: jest.fn(),
  drawImage: jest.fn(),
  save: jest.fn(),
  restore: jest.fn(),
  scale: jest.fn(),
  rotate: jest.fn(),
  translate: jest.fn(),
  transform: jest.fn(),
  beginPath: jest.fn(),
  moveTo: jest.fn(),
  lineTo: jest.fn(),
  bezierCurveTo: jest.fn(),
  closePath: jest.fn(),
  stroke: jest.fn(),
  fill: jest.fn(),
}))

// Mock Konva
jest.mock("konva", () => {
  return {
    Stage: jest.fn().mockImplementation(() => ({
      add: jest.fn(),
      width: jest.fn(),
      height: jest.fn(),
      scale: jest.fn(),
      position: jest.fn(),
      batchDraw: jest.fn(),
      on: jest.fn(),
      container: jest.fn().mockReturnValue({
        style: {},
      }),
      find: jest.fn().mockReturnValue([]),
    })),
    Layer: jest.fn().mockImplementation(() => ({
      add: jest.fn(),
      batchDraw: jest.fn(),
      destroyChildren: jest.fn(),
      clear: jest.fn(),
      getContext: jest.fn().mockReturnValue({}),
    })),
    Text: jest.fn().mockImplementation(() => ({
      width: jest.fn().mockReturnValue(100),
      height: jest.fn().mockReturnValue(20),
      x: jest.fn(),
      y: jest.fn(),
      text: jest.fn(),
      fontSize: jest.fn(),
      fontFamily: jest.fn(),
      fill: jest.fn(),
      id: jest.fn(),
      getAttr: jest.fn(),
      setAttr: jest.fn(),
      destroy: jest.fn(),
    })),
    Image: jest.fn().mockImplementation(() => ({
      width: jest.fn(),
      height: jest.fn(),
      x: jest.fn(),
      y: jest.fn(),
      image: jest.fn(),
      cache: jest.fn(),
      filters: jest.fn(),
      blurRadius: jest.fn(),
      brightness: jest.fn(),
      contrast: jest.fn(),
      id: jest.fn(),
      destroy: jest.fn(),
    })),
    Line: jest.fn().mockImplementation(() => ({
      points: jest.fn(),
      stroke: jest.fn(),
      strokeWidth: jest.fn(),
      tension: jest.fn(),
      lineCap: jest.fn(),
      lineJoin: jest.fn(),
      id: jest.fn(),
      destroy: jest.fn(),
    })),
    Rect: jest.fn().mockImplementation(() => ({
      width: jest.fn(),
      height: jest.fn(),
      x: jest.fn(),
      y: jest.fn(),
      fill: jest.fn(),
      stroke: jest.fn(),
      strokeWidth: jest.fn(),
      id: jest.fn(),
      destroy: jest.fn(),
    })),
    Circle: jest.fn().mockImplementation(() => ({
      radius: jest.fn(),
      x: jest.fn(),
      y: jest.fn(),
      fill: jest.fn(),
      stroke: jest.fn(),
      strokeWidth: jest.fn(),
      id: jest.fn(),
      destroy: jest.fn(),
    })),
    Group: jest.fn().mockImplementation(() => ({
      add: jest.fn(),
      x: jest.fn(),
      y: jest.fn(),
      id: jest.fn(),
      getChildren: jest.fn().mockReturnValue({
        each: jest.fn(),
      }),
      destroy: jest.fn(),
    })),
    Transformer: jest.fn().mockImplementation(() => ({
      nodes: jest.fn(),
      rotateAnchorOffset: jest.fn(),
      enabledAnchors: jest.fn(),
      boundBoxFunc: jest.fn(),
      destroy: jest.fn(),
    })),
    Animation: jest.fn().mockImplementation(() => ({
      start: jest.fn(),
      stop: jest.fn(),
    })),
    Tween: jest.fn().mockImplementation(() => ({
      play: jest.fn(),
    })),
    Util: {
      getControlPoints: jest.fn().mockReturnValue([]),
    },
    Easings: {
      EaseIn: "easeIn",
      EaseOut: "easeOut",
      EaseInOut: "easeInOut",
    },
    Filters: {
      Blur: "Blur",
      Brighten: "Brighten",
      Contrast: "Contrast",
      Emboss: "Emboss",
      Enhance: "Enhance",
      Grayscale: "Grayscale",
      Noise: "Noise",
      Pixelate: "Pixelate",
      Mask: "Mask",
    },
  }
})

// Mock next/navigation
jest.mock("next/navigation", () => ({
  useRouter: jest.fn().mockReturnValue({
    push: jest.fn(),
    replace: jest.fn(),
    prefetch: jest.fn(),
    back: jest.fn(),
    forward: jest.fn(),
  }),
  usePathname: jest.fn().mockReturnValue("/"),
  useSearchParams: jest.fn().mockReturnValue(new URLSearchParams()),
}))

// Mock next-auth
jest.mock("next-auth/react", () => ({
  useSession: jest.fn().mockReturnValue({
    data: {
      user: {
        id: "1",
        name: "Test User",
        email: "test@example.com",
        image: null,
        role: "user",
      },
      expires: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    },
    status: "authenticated",
  }),
  signIn: jest.fn(),
  signOut: jest.fn(),
  getSession: jest.fn(),
}))

// Mock OpenAI
jest.mock("openai", () => {
  return jest.fn().mockImplementation(() => ({
    chat: {
      completions: {
        create: jest.fn().mockResolvedValue({
          choices: [{ message: { content: "Test response" } }],
        }),
      },
    },
    images: {
      generate: jest.fn().mockResolvedValue({
        data: [{ url: "https://example.com/image.png" }],
      }),
    },
  }))
})

// Mock environment variables
process.env = {
  ...process.env,
  OPENAI_API_KEY: "test-api-key",
  NEXT_PUBLIC_OPENAI_API_KEY: "test-api-key",
  NEXTAUTH_SECRET: "test-secret",
}

